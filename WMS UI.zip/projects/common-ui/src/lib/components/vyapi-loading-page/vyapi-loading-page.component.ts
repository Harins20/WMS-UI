import { Component, input } from '@angular/core';

@Component({
    selector: 'app-vyapi-loading-page',
    imports: [],
    templateUrl: './vyapi-loading-page.component.html',
    styleUrl: './vyapi-loading-page.component.scss',
})
export class VyapiLoadingPageComponent {
    loading = input<boolean>(false);
}
