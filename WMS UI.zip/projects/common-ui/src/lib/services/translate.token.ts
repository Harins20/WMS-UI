import { InjectionToken } from '@angular/core';

export interface CommonUiTranslationService {
    translate(key: string, params?: Record<string, unknown>): string;
}

export const COMMON_UI_TRANSLATION_SERVICE =
    new InjectionToken<CommonUiTranslationService>('COMMON_UI_TRANSLATION_SERVICE');
