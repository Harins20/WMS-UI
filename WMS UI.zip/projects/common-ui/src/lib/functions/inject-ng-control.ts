import { inject } from '@angular/core';
import {
    NgControl,
    FormControlDirective,
    FormControlName,
    NgModel,
} from '@angular/forms';

export function injectNgControl() {
    const ngControl = inject(NgControl, { self: true, optional: true });

    if (!ngControl) {
        throw new Error('Component must be used within a reactive form or ngModel context.');
    }

    if (
        ngControl instanceof FormControlDirective ||
        ngControl instanceof FormControlName ||
        ngControl instanceof NgModel
    ) {
        return ngControl;
    }

    throw new Error('Unsupported NgControl directive');
}
