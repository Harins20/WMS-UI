import { inject, Pipe, PipeTransform } from '@angular/core';
import { COMMON_UI_TRANSLATION_SERVICE } from '../services/translate.token';

/**
 * Custom translate pipe backed by optional translation provider.
 * Usage: {{ 'Some Key' | appTranslate }}
 * With params: {{ 'Hello {{ name }}' | appTranslate:{ name: 'World' } }}
 */
@Pipe({
    name: 'appTranslate',
    standalone: true,
    pure: false,
})
export class AppTranslatePipe implements PipeTransform {
    private translationService = inject(COMMON_UI_TRANSLATION_SERVICE, {
        optional: true,
    });

    transform(
        key: string | null | undefined,
        params?: Record<string, unknown>,
    ): string {
        if (!key) return '';
        if (this.translationService) {
            return this.translationService.translate(key, params);
        }
        let value = key;
        if (params) {
            Object.entries(params).forEach(([k, v]) => {
                value = value.replace(
                    new RegExp(`{{\\s*${k}\\s*}}`, 'g'),
                    String(v),
                );
            });
        }
        return value;
    }
}
