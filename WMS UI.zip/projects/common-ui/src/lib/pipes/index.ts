export * from './translate.pipe';
