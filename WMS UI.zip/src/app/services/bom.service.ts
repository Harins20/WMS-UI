import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class BomService {
    constructor(private http: HttpClient) {}

    getDynamicOptions(): Observable<any[]> {
        return this.http.get<any[]>('/api/dynamic-options'); // Replace with actual API endpoint
    }
}
