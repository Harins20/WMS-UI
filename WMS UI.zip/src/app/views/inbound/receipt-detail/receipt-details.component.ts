import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    signal,
    viewChild,
    computed,
    linkedSignal,
    inject,
    DestroyRef,
    TemplateRef,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { TableModule, Table, TableLazyLoadEvent } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import {
    LoadingComponent,
    ColumnPicklistComponent,
} from '../../../common/components';
import { tableOptions } from '../../../common/constants';
import { filterQuery } from '../../../common/functions';
import { ExcelDownloadService, OptionsService } from '../../../common/services';
import { AsnLine, AsnLineService } from '../asns';
import { ReceiptDetailColumns } from './receipt-detail.columns';
import { Tag } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';

import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
@Component({
    selector: 'app-receipt-details',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        // LoadingComponent,
        Tag,
        TooltipModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './receipt-details.component.html',
    styleUrl: './receipt-details.component.scss',
    providers: [DialogService],
})
export class ReceiptDetailsComponent {
    receiptdetails = signal<AsnLine[]>([]);
    private translate = inject(TranslateService);
    receiptdetailsForExcel = signal<AsnLine[]>([]);
    loadEvent = signal<any>({});
    searchInput = signal<string | undefined>(undefined);
    selectedReceiptDetails = signal<any>([]);
    optionsData = signal<{ [key: string]: any[] }>({
        SKU: [],
        PACKKEY: [],
        UOM: [],
        Status_Desc: [],
        QCSTATUS: [],
    });
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    rows = signal(20);
    totalRecords = signal(0);
    gs = signal<string | undefined>(undefined);
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    columns = signal(
        Object.values(ReceiptDetailColumns).filter(
            (column) => !column.tableHidden,
        ),
    );

    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x) => x.tableAlias && !x.tableHidden)
            .map((x) => x.field),
    );
    tableOptions = signal(tableOptions);
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    private messageService = inject(MessageService);
    private receiptdetailsService = inject(AsnLineService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    private optionService = inject(OptionsService);
    OrginalColumns = signal<any>(ReceiptDetailColumns);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    constructor() {}
    ngOnInit() {
        // this.getReceiptDetails();
        this.loadOptions();
    }

    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         ReceiptDetailColumns,
    //         'vw.',
    //     );

    //     this.getReceiptDetails({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    ngAfterViewInit() {
        this.columns.set(
            Object.values(ReceiptDetailColumns)
                .filter((column) => !column.tableHidden)
                .map((column: any) => {
                    if (column.field === 'Status_Desc') {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                }),
        );
    }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getReceiptDetails(event);
    }
    loadOptions() {
        this.GetItemOptions();
        this.GetPackkeyOptions();
        this.GetUomOptions();
        this.GetQcStatusOptions();
        this.GetStatusOptions();
    }

    GetItemOptions() {
        const subscription = this.optionService.getItems().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, SKU: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPackkeyOptions() {
        const subscription = this.optionService.getPackkey().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, PACKKEY: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetUomOptions() {
        const subscription = this.optionService.getUomTypeOptions().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, UOM: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetQcStatusOptions() {
        const subscription = this.optionService.getQcStatusOptions().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, QCSTATUS: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetStatusOptions() {
        const subscription = this.optionService
            .getReciptStatusOptions()
            .subscribe({
                next: (data) => {
                    const remap = data.map((x) => ({ ...x, value: x.Label }));
                    this.optionsData.update((old) => ({
                        ...old,
                        Status_Desc: remap,
                    }));
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    getReceiptDetails(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.selectedReceiptDetails.set([]);
        this.receiptdetails.set([]);
        const subscription = this.receiptdetailsService
            .getAsnLinesPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res) => {
                    let idBase = data.first || 0;
                    this.receiptdetails.set(
                        res.Response.AsnLines.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idBase + (idx + 1),
                        })),
                    );

                    this.totalRecords.set(res.Response.totalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Receipt Details list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.gs.set(undefined);
    }
    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }
    getReceiptDetailsForExcel(data: any = this.loadEvent(), type: string) {
        this.loading.set(true);
        this.receiptdetailsForExcel.set([]);
        const subscription = this.receiptdetailsService
            .getAsnLinesPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    this.receiptdetailsForExcel.set(res.Response.AsnLines);
                    if (res?.Response?.AsnLines && type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            'Receipt Details-list',
                            [],
                            res.Response.AsnLines,
                        );
                    } else {
                        downloadCSVFile(
                            res.Response.AsnLines,
                            'Receipt Detail-List',
                        );
                    }
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Receipt Details list for excel',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    export(type: string) {
        const event = this.loadEvent();

        this.getReceiptDetailsForExcel(
            {
                ...event,
                first: 0,
                rows: this.totalRecords(),
            },
            type,
        );
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.receiptdetails().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedReceiptDetails().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedReceiptDetails().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    onEditAction(AsnLine: AsnLine) {}
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getReceiptDetails();
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
