import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import { selectOption } from '../../../../common/models';
import { TabsModule } from 'primeng/tabs';
import { DatePickerModule } from 'primeng/datepicker';
import { TextareaModule } from 'primeng/textarea';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { AsnViewColumns } from './asn-view.columns';
import { OptionsService } from '../../../../common/services';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import {
    InputDatepickerComponent,
    InputSelectComponent,
    InputTextComponent,
} from '../../../../common/components';
import { InputTextareaComponent } from '../../../../common/components/input-textarea/input-textarea.component';

@Component({
    selector: 'asn-view-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        TabsModule,
        DatePickerModule,
        TextareaModule,
        ToggleButtonModule,
        AppTranslatePipe, InputSelectComponent,
        InputTextComponent,
        InputDatepickerComponent,
        InputTextareaComponent,
    ],
    templateUrl: './asn-view-form.component.html',
    styleUrl: './asn-view-form.component.scss',
})
export class AsnViewFormComponent {
    asnData = input<any>();
    private optionService = inject(OptionsService);
    private destroyRef = inject(DestroyRef);

    loading = signal(false);
    formControlsArray = signal(
        Object.values(AsnViewColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue),
        ]),
    );

    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    form = new FormGroup(this.formControls());
    typeOptions = signal<selectOption[]>([]);

    ngOnChanges() {
        this.GetTypeOptions();
        if (this.asnData()) {
            this.form.patchValue({
                ...this.asnData(),
            });
            Object.values(AsnViewColumns).forEach((column) => {
                if (column) {
                    this.form.controls[column.field].disable();
                }
            });
        }
    }

    GetTypeOptions() {
        const subscription = this.optionService
            .getReceiptTypeOptions()
            .subscribe({
                next: (data) => {
                    this.typeOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
}
