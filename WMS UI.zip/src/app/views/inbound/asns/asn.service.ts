import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { Asn } from './asn.model';
import { AuthService } from '../../../common/services';
import { ResponseDto } from '../../../common/models';
import { AppConfigService } from '../../../../app.config.service';
import { map } from 'rxjs';
import { AsnColumns } from './asn.columns';
import { stringToDate, upperCaseArray } from '../../../common/functions';
interface AsnPage {
    AsnLines: Asn[];
    totalRecords: number;
}
@Injectable({
    providedIn: 'root',
})
export class AsnService {
    isPanelOpen = false;
    FormType = signal<string>('');
    SetUpdateData = signal<any>({});
    FormReset = signal(false);
    SetActive = signal(false);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getAsns() {
        return this.httpClient
            .get<
                ResponseDto<Asn[]>
            >(this.config.appConfig()?.InbUrl + 'Asn', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((response) => {
                    response.Response.forEach((asn: any) => {
                        Object.keys(asn).forEach((key) => {
                            if (AsnColumns[key]?.type === 'date') {
                                asn[key] = stringToDate(asn[key]);
                            }
                        });
                    });
                    return response;
                }),
            );
    }
    getAsnsPage(data: any) {
        return this.httpClient
            .post<
                ResponseDto<AsnPage>
            >(this.config.appConfig()?.InbUrl + 'Asn/asnpaged', data, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((response) => {
                    if (
                        response?.Response?.AsnLines &&
                        Array.isArray(response.Response.AsnLines)
                    ) {
                        response.Response.AsnLines = upperCaseArray(
                            response.Response.AsnLines,
                        );
                        response.Response.AsnLines.forEach((asn: any) => {
                            Object.keys(asn).forEach((key) => {
                                if (AsnColumns[key]?.type === 'date') {
                                    asn[key] = stringToDate(asn[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    GetAsnAttachment(Id: any) {
        return this.httpClient.get(
            this.config.appConfig()?.InbUrl +
                `asn/attachment?Facility=${this.authService.facility()}&Id=${Id}`,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    createAsns(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InbUrl + 'Asn',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    updateAsns(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    deleteAsn(data: any) {
        return this.httpClient.delete(this.config.appConfig()?.InbUrl + 'Asn', {
            headers: this.authService.getAuthHeaders(),
            body: data,
        });
    }

    cancelAsn(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/Cancel',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    closeAsn(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/Close',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    reopenAsn(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/ReOpen',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    getReceiptKeyDetail(receiptKey: any) {
        return this.httpClient
            .get<
                ResponseDto<Asn>
            >(this.config.appConfig()?.InbUrl + `Asn?ReceiptKey=${receiptKey}`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((response) => {
                    const asn: any = response.Response;
                    Object.keys(response.Response).forEach((key) => {
                        if (AsnColumns[key]?.type === 'date') {
                            asn[key] = stringToDate(asn[key]);
                        }
                    });
                    return asn;
                }),
            );
    }

    createASN(data: any) {
        this.SetActive.set(true);
        return this.httpClient.post(
            this.config.appConfig()?.InbUrl + 'Asn/edi',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
