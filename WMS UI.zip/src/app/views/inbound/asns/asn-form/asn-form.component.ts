import { MessageService } from 'primeng/api';
import {
    Component,
    computed,
    DestroyRef,
    effect,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { selectOption } from '../../../../common/models';
import {
    Base64ConvertService,
    OptionsService,
} from '../../../../common/services';
import { safeAtob } from '../../../../common/services/auth.service';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { AsnColumns } from '../asn.columns';
import { DatePickerModule } from 'primeng/datepicker';
import { FileUpload } from 'primeng/fileupload';
import { acceptedImageTypes } from '../../../../common/constants';
import { TextareaModule } from 'primeng/textarea';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { InputDatepickerComponent } from '../../../../common/components/input-datepicker/input-datepicker.component';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import {
    InputNumberComponent,
    InputSelectComponent,
    InputTextareaComponent,
    InputTextComponent,
} from '../../../../common/components';
import { CommonModule } from '@angular/common';
import { InputCheckboxComponent } from '../../../../common/components/input-checkbox/input-checkbox.component';
import { AsnService } from '../asn.service';
import { LayoutService } from '../../../../layout/service/layout.service';

@Component({
    selector: 'asn-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        InputTextareaComponent,
        ButtonModule,
        DatePickerModule,
        FileUpload,
        TextareaModule,
        ToggleButtonModule,
        AppTranslatePipe,
        InputSelectComponent,
        InputTextComponent,
        InputDatepickerComponent,
        InputCheckboxComponent,
        CommonModule,
        InputNumberComponent,
    ],
    templateUrl: './asn-form.component.html',
    styleUrl: './asn-form.component.scss',
    providers: [DialogService],
})
export class AsnFormComponent {
    asnData = input<any>();

    attachmentData = signal<string | null>(null);

    private destroyRef = inject(DestroyRef);
    private messageService = inject(MessageService);
    private optionService = inject(OptionsService);
    private ref = inject(DynamicDialogRef);
    private base64convert = inject(Base64ConvertService);
    private asnsService = inject(AsnService);

    ConfirmationRef: DynamicDialogRef | undefined;

    setViewTAb = signal<boolean>(true);
    activeTab = signal<number>(0);
    minDate = signal<Date>(new Date());

    asnColumns: any[] = [];
    language = signal<string | null>('');
    loading = signal(false);

    ownerOptions = signal<selectOption[]>([]);
    typeOptions = signal<selectOption[]>([]);
    shipfromOptions = signal<selectOption[]>([]);
    carrierOptions = signal<selectOption[]>([]);

    LayoutService = inject(LayoutService);

    isDarkTheme = computed(() => this.LayoutService.layoutConfig().darkTheme);

    formControlsArray = signal(
        Object.values(AsnColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );

    formControls = computed(() => Object.fromEntries(this.formControlsArray()));

    form = new FormGroup(this.formControls());

    constructor() {
        this.loadAttachment();
    }

    goToTab(index: number): void {
        this.activeTab.set(index);
    }

    closePanel(): void {
        this.ref.close();
    }

    typeRestricted(params: string): boolean {
        return acceptedImageTypes.includes(params);
    }

    private loadAttachment(): void {
        effect((onCleanup) => {
            const data = this.asnData();

            if (!data?.AttachmentId) {
                return;
            }

            const subscription = this.asnsService
                .GetAsnAttachment(data.AttachmentId)
                .subscribe({
                    next: (imageData: any) => {
                        data.FileData = imageData;

                        this.form.patchValue({
                            ...data,
                            FILENAME: data.AttachmentFileName,
                            TRADERKEY: safeAtob(
                                sessionStorage.getItem('TraderKey'),
                            ),
                            FILEDATA: imageData,
                        });
                    },
                    error: (error) => {
                        console.error('Error getting attachment:', error);
                    },
                });

            onCleanup(() => subscription.unsubscribe());
        });
    }

    ngOnInit(): void {
        this.language.set(sessionStorage.getItem('language'));

        const data = this.asnData();

        if (data) {
            this.form.patchValue({
                ...data,
                FILENAME: data.AttachmentFileName,
                TRADERKEY: safeAtob(sessionStorage.getItem('TraderKey')),
                FILEDATA: data.FileData,
            });

            const restrictedFields = [
                'TYPE',
                'EXPECTEDRECEIPTDATE',
                'RECEIPTDATE',
                'POKEY',
                'WAREHOUSEREFERENCE',
                'TRAILERNUMBER',
                'EXTERNALRECEIPTKEY2',
                'RMA',
                'BOE',
                'PRONUMBER',
                'DOOR',
                'CONSIGNEEKEY',
                'TEMPERATURE',
                'SIGNATORY',
                'ALLOWAUTORECEIPT',
                'TRACKINVENTORYBY',
                'SUSR1',
                'SUSR2',
                'SUSR3',
                'SUSR4',
                'SUSR5',
                'SUPPLIERCODE',
                'CARRIERKEY',
                'TRANSPORTATIONMODE',
                'TRANSPORTATIONSERVICE',
                'TRANSPORTATIONSTATUS',
                'CARRIERROUTESTATUS',
                'ORIGINCOUNTRY',
                'DESTINATIONCOUNTRY',
                'PLACEOFLOADING',
                'PLACEOFDISCHARGE',
                'PLACEOFDELIVERY',
                'INCOTERMS',
                'TERMSNOTE',
                'TRAILEROWNER',
                'TRAILERTYPE',
                'TRAILERKEY',
                'DRIVERNAME',
                'VEHICLENUMBER',
                'VEHICLEDATE',
                'CONTAINERKEY',
                'CONTAINERTYPE',
                'CONTAINERQTY',
                'BILLEDCONTAINERQTY',
                'GROSSWEIGHT',
                'TOTALVOLUME',
                'SCHEDULEDSHIPDATE',
                'ACTUALSHIPDATE',
                'ACTUALDEPARTUREDATE',
                'ARRIVALDATETIME',
                'EFFECTIVEDATE',
                'PROMISEDDELIVERYDATE',
                'PROMISEDSHIPDATE',
                'REQUIREDDELIVERYDATE',
                'REQUIREDSHIPDATE',
                'PLANNEDDELIVERYDATE',
                'PLANNEDSHIPDATE',
                'EARLIESTDELIVERYDATE',
                'EARLIESTSHIPDATE',
                'ADVICENUMBER',
                'ADVICEDATE',
                'PACKINGSLIPNUMBER',
                'FREIGHTCHARGEAMOUNT',
                'FREIGHTCHARGEBASEAMOUNT',
                'FREIGHTCOSTAMOUNT',
                'FREIGHTCOSTBASEAMOUNT',
                'TMFREIGHTCHARGECURRENCY',
                'TMFREIGHTCOSTCURRENCY',
                'SOURCELOCATION',
                'SOURCEVERSION',
                'REFERENCETYPE',
                'REFERENCEDOCUMENT',
                'REFERENCELOCATION',
                'REFERENCEVERSION',
                'REFERENCEACCOUNTINGENTITY',
                'RETURNFROMPARTY',
                'RETURNLOTS',
                'PRODUCTIONSTATUS',
            ];

            Object.values(AsnColumns).forEach((column) => {
                if (column.restrictEdit) {
                    if (
                        data.STATUS_DESC === 'New' &&
                        restrictedFields.includes(column.field)
                    ) {
                        this.form.controls[column.field].enable({
                            emitEvent: false,
                        });
                    } else {
                        this.form.controls[column.field].disable({
                            emitEvent: false,
                        });
                    }
                }
            });
        } else {
            Object.values(AsnColumns).forEach((column) => {
                if (column.restrictInsert) {
                    this.form.controls[column.field].disable({
                        emitEvent: false,
                    });
                }
            });

            this.form.patchValue({
                TRADERKEY: safeAtob(sessionStorage.getItem('TraderKey')),
            });
        }

        this.setupInsuranceControls();

        this.GetOwnerOptions();
        this.GetTypeOptions();
        this.GetShipFromOptions();
        this.handleShipFromSelection();
        this.GetCarrierOptions();
        this.handleCarrierSelection();
        this.getColumns();
    }

    private setupInsuranceControls(): void {
        const insuredControl = this.form.get('INSURED');
        const insuranceNoControl = this.form.get('INSURANCENO');

        if (!insuredControl || !insuranceNoControl) {
            console.warn(
                'INSURED or INSURANCENO control is missing in AsnColumns.',
            );
            return;
        }

        const updateInsuranceState = (checked: boolean | null): void => {
            if (checked) {
                insuranceNoControl.enable({
                    emitEvent: false,
                });
            } else {
                insuranceNoControl.disable({
                    emitEvent: false,
                });
            }
        };

        updateInsuranceState(insuredControl.value);

        insuredControl.valueChanges
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((checked) => {
                updateInsuranceState(checked);
            });
    }

    hasError(formControlName: string): boolean {
        const formControl = this.form.get(formControlName);

        return !!(
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);

        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel(): void {
        this.asnsService.isPanelOpen = false;
        this.ref?.close();
    }

    GetOwnerOptions(): void {
        this.optionService
            .getOwnerOptions()
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
                error: (error) => {
                    console.error('Error fetching owner options:', error);
                },
            });
    }

    GetTypeOptions(): void {
        this.optionService
            .getReceiptTypeOptions()
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe({
                next: (data) => {
                    this.typeOptions.set(data);
                },
                error: (error) => {
                    console.error('Error fetching type options:', error);
                },
            });
    }

    GetShipFromOptions(): void {
        this.optionService
            .getShipFromOptions()
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe({
                next: (data) => {
                    this.shipfromOptions.set(data);
                },
                error: (error) => {
                    console.error('Error fetching ship-from options:', error);
                },
            });
    }

    handleShipFromSelection(): void {
        this.form
            .get('SUPPLIERCODE')
            ?.valueChanges.pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((selectedValue) => {
                if (!selectedValue) {
                    return;
                }

                const selectedTrader: any = this.shipfromOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (!selectedTrader) {
                    return;
                }

                this.form.patchValue({
                    SUPPLIERNAME: selectedTrader.Company,
                    SHIPFROMADDRESSLINE1: selectedTrader.Address1,
                    SHIPFROMADDRESSLINE2: selectedTrader.Address2,
                    SHIPFROMADDRESSLINE3: selectedTrader.Address3,
                    SHIPFROMADDRESSLINE4: selectedTrader.Address4,
                    SHIPFROMADDRESSLINE5: selectedTrader.Address5 || '',
                    SHIPFROMADDRESSLINE6: selectedTrader.Address6 || '',
                    SHIPFROMCITY: selectedTrader.City,
                    SHIPFROMSTATE: selectedTrader.State,
                    SHIPFROMZIP: selectedTrader.Zip,
                    SHIPFROMISOCOUNTRY: selectedTrader.Country || '',
                    SHIPFROMPHONE: selectedTrader.Phone1,
                    SHIPFROMEMAIL: selectedTrader.Email1,
                    SHIPFROMCONTACT: selectedTrader.Contact1,
                });

                this.form.updateValueAndValidity();
            });
    }

    GetCarrierOptions(): void {
        this.optionService
            .getCarrierOptions()
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe({
                next: (data) => {
                    this.carrierOptions.set(data);
                },
                error: (error) => {
                    console.error('Error fetching carrier options:', error);
                },
            });
    }

    handleCarrierSelection(): void {
        this.form
            .get('CARRIERKEY')
            ?.valueChanges.pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((selectedValue) => {
                if (!selectedValue) {
                    return;
                }

                const selectedShipTo: any = this.carrierOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (!selectedShipTo) {
                    return;
                }

                this.form.patchValue({
                    CARRIERNAME: selectedShipTo.Company,
                    CARRIERADDRESS1: selectedShipTo.B_Address1,
                    CARRIERADDRESS2: selectedShipTo.B_Address2,
                    CARRIERCITY: selectedShipTo.B_City,
                    CARRIERSTATE: selectedShipTo.B_State,
                    CarrierCountry: selectedShipTo.B_Country,
                    CARRIERZIP: selectedShipTo.B_Zip,
                    CarrierPhone: selectedShipTo.B_Phone1,
                });

                this.form.updateValueAndValidity();
            });
    }

    onSubmit(): void {
        if (this.form.valid) {
            this.setViewTAb.set(true);

            Object.values(AsnColumns).forEach((column) => {
                if (column.restrictEdit) {
                    this.form.controls[column.field].enable({
                        emitEvent: false,
                    });
                }
            });

            this.ref.close(this.form.getRawValue());
            this.form.reset();
            return;
        }

        this.setViewTAb.set(false);

        this.messageService.add({
            severity: 'warn',
            summary: 'Mandatory Field',
            detail: 'Please fill the mandatory field',
        });

        this.form.markAllAsTouched();
        markAllControlsAsDirty(Object.values(this.form.controls));
    }

    async onFileSelect(event: any): Promise<void> {
        const file = event?.files?.[0];

        if (!file) {
            return;
        }

        const fileName = file.name;

        const base64: string = (await this.base64convert.baseConverFile(
            file,
        )) as string;

        this.form.get('FILENAME')?.setValue(fileName);

        if (base64) {
            this.form.get('FILEDATA')?.setValue(base64);
            this.attachmentData.set(base64);
        }
    }

    getColumns(): void {
        this.optionService
            .getColumns(AsnColumns, 'RECEIPT')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe({
                next: (data) => {
                    this.asnColumns = data;
                },
                error: (error) => {
                    console.error('Error fetching ASN columns:', error);
                },
            });
    }
}
