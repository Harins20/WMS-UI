import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { ExplodedLineColumns } from './exploded-lines.columns';
import { ExplodedLines } from './exploded-lines.model';
import { ExplodedLineService } from './exploded-lines.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    CustomTableComponent,
} from '../../../../../common/components';
import { ExcelDownloadService } from '../../../../../common/services/excel-download.service';
import { AsnLine } from '../asn-line.model';
import { AsnLineFormComponent } from '../asn-lines-form/asn-lines-form.component';
import { AsnLineService } from '../asn-lines.service';
import { tableOptions } from '../../../../../common/constants';
import { TagModule } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../../../common/components/common-errorbox/common-errorbox.component';
import { downloadCSVFile } from '../../../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-explodedlines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        TagModule,
        AppTranslatePipe,
        CustomTableComponent,
    ],
    templateUrl: './exploded-lines.component.html',
    styleUrl: './exploded-lines.component.scss',
    providers: [DialogService],
})
export class ExplodedLineComponent {
    private translate = inject(TranslateService);
    actions: MenuItem[] = [
        {
            label: this.translate.instant('Receive'),
            command: () => this.ReceiveASNLines(),
        },
        {
            label: this.translate.instant('UnReceive'),
            command: () => this.UnReceiveASNLines(),
        },
    ];

    receiptKey = input.required<string>();
    receiptLineNumber = input.required<string>();
    storerKey = input.required<string>();
    explodedlines = signal<ExplodedLines[]>([]);
    selectedExplodedLines = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    columns = computed(() => {
        const template = this.customStatusCellTemplate();
        return Object.values(ExplodedLineColumns)
            .filter((column) => !column.tableHidden)
            .map((col) => {
                if (col.field === 'Status_Desc') {
                    return {
                        ...col,
                        customCellTemplate: template,
                    };
                }
                return col;
            });
    });
    tableOptions = signal(tableOptions);
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    ref: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private explodedlinesService = inject(ExplodedLineService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    private asnlinesService = inject(AsnLineService);
    ConfirmationRef: DynamicDialogRef | undefined;

    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    constructor() {}
    ngOnInit() {
        this.getExplodedLines();
    }

    getExplodedLines() {
        this.loading.set(true);
        const subscription = this.explodedlinesService
            .getExplodedLines(this.receiptKey(), this.receiptLineNumber())
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res) => {
                    this.explodedlines.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Exploded Line list',
                            detail: 'Network error occurred. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getExplodedLines();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            'Exploded Lines-list',
            [],
            this.explodedlines(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.explodedlines(), 'Exploded Lines-list');
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.explodedlines().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedExplodedLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedExplodedLines().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    OpenUpdateExplodedLineForm(asnExplodeData: any) {
        this.ref = this.dialogService.open(AsnLineFormComponent, {
            inputValues: {
                asnlineData: asnExplodeData,
                Identify: 'exploded',
            },
            header: this.translate.instant('Update Exploded Line'),
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '65rem',
            style: { height: '45rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('ASNLineUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        const updatedData: AsnLine = {
                            ...data,
                        };
                        this.asnlinesService
                            .updateAsnLines(updatedData)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getExplodedLines();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Exploded Line Update',
                                        detail: data.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Exploded Line Update',
                                            detail: error.error.message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    ReceiveASNLines() {
        if (
            this.selectedExplodedLines().length === 0 &&
            (this.explodedlines().length === 0 || this.explodedlines()[0] === undefined)
        ) {
            this.messageService.add({
                severity: 'error',
                summary: 'Receive Receipt Lines',
                detail: 'No lines available to Receive.',
            });
            return;
        }

        const isHeader = this.selectedExplodedLines().length === 0;
        const count = isHeader ? 1 : this.selectedExplodedLines().length;
        const headertext = this.translate.instant('Receive ASN Line');
        const name = isHeader
            ? this.translate.instant('ASN')
            : (count > 1
                ? this.translate.instant('Asn Lines')
                : this.translate.instant('ASN Line'));
        const value = this.translate.instant('ReceiveASN', {
            no: isHeader ? this.receiptKey() : count,
            name: name,
        });

        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                if (this.selectedExplodedLines().length > 0) {
                    const explodedParent = this.selectedExplodedLines().filter(
                        (x: any) =>
                            (x.ORIGINALLINENUMBER === null ||
                                x.ORIGINALLINENUMBER === '' ||
                                x.ORIGINALLINENUMBER === undefined) &&
                            x.IsExploded === true,
                    );
                    const parentLines = this.selectedExplodedLines().filter(
                        (x: any) =>
                            (x.ORIGINALLINENUMBER === null ||
                                x.ORIGINALLINENUMBER === '' ||
                                x.ORIGINALLINENUMBER === undefined) &&
                            x.IsExploded === false,
                    );
                    const explodedLines = this.selectedExplodedLines().filter(
                        (x: any) =>
                            x.ORIGINALLINENUMBER !== null &&
                            x.ORIGINALLINENUMBER !== '',
                    );

                    const receiptLines = [...parentLines, ...explodedLines];

                    const validLines = receiptLines.filter(
                        (x) => x.Status_Desc !== 'Received',
                    );

                    const inValidLines = receiptLines.filter(
                        (x) => x.Status_Desc === 'Received',
                    );
                    if (validLines.length > 0) {
                        this.loading.set(true);
                        const subscription = this.asnlinesService
                            .receiveAsnLines(validLines)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedExplodedLines.set([]);
                                    this.getExplodedLines();
                                }),
                            )
                            .subscribe({
                                next: (response) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Receive Receipt Lines',
                                        detail: 'Receipt Lines received successfully.',
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        const errorMessage =
                                            error?.error?.message ||
                                            'Failed to receive Receipt Lines.';
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Receive Receipt Lines',
                                            detail: errorMessage,
                                        });
                                    }
                                },
                            });

                        this.destroyRef.onDestroy(() => subscription.unsubscribe());
                    } else {
                        if (explodedParent.length > 0 && inValidLines.length > 0) {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: `"Reception action for exploded lines can only be done in exploded child lines view."
                                "Only new / in-receiving lines can be received."`,
                            });
                        } else if (explodedParent.length > 0) {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: 'Reception action for exploded lines can only be done in exploded child lines view.',
                            });
                        } else {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: 'Only new / in-receiving lines can be received.',
                            });
                        }
                    }
                } else {
                    const requestBody = {
                        ReceiptKey: this.receiptKey(),
                    };
                    const subscription = this.asnlinesService
                        .receiveAsn(requestBody)
                        .pipe(
                            finalize(() => {
                                this.loading.set(false);
                                this.selectedExplodedLines.set([]);
                                this.getExplodedLines();
                            }),
                        )
                        .subscribe({
                            next: (response) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Receive Receipt Lines',
                                    detail: 'Receipt Lines received successfully.',
                                });
                            },
                            error: (error) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef = this.dialogService.open(
                                        CommonErrorboxComponent,
                                        {
                                            inputValues: {
                                                error: error,
                                            },
                                            header: 'Multiple Error',
                                            closable: true,
                                            modal: true,
                                            draggable: true,
                                            keepInViewport: true,
                                            width: '39rem',
                                            style: { maxHeight: '40rem' },
                                        },
                                    );
                                } else {
                                    const errorMessage =
                                        error?.error?.message ||
                                        'Failed to receive Receipt Lines.';
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Receive Receipt Lines',
                                        detail: errorMessage,
                                    });
                                }
                            },
                        });

                    this.destroyRef.onDestroy(() => subscription.unsubscribe());
                }
            }
        });
    }

    UnReceiveASNLines() {
        if (
            this.selectedExplodedLines().length === 0 &&
            (this.explodedlines().length === 0 || this.explodedlines()[0] === undefined)
        ) {
            this.messageService.add({
                severity: 'error',
                summary: 'Unreceive Receipt Lines',
                detail: 'No lines available to Unreceive.',
            });
            return;
        }

        const isHeader = this.selectedExplodedLines().length === 0;
        const count = isHeader ? 1 : this.selectedExplodedLines().length;
        const headertext = this.translate.instant('UnReceive ASN Line');
        const name = isHeader
            ? this.translate.instant('ASN')
            : (count > 1
                ? this.translate.instant('Asn Lines')
                : this.translate.instant('ASN Line'));
        const value = this.translate.instant('UnReceiveASN', {
            no: isHeader ? this.receiptKey() : count,
            name: name,
        });

        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                if (this.selectedExplodedLines().length > 0) {
                    const explodedParent = this.selectedExplodedLines().filter(
                        (x: any) =>
                            (x.ORIGINALLINENUMBER === null ||
                                x.ORIGINALLINENUMBER === '' ||
                                x.ORIGINALLINENUMBER === undefined) &&
                            x.IsExploded === true,
                    );
                    const parentLines = this.selectedExplodedLines().filter(
                        (x: any) =>
                            (x.ORIGINALLINENUMBER === null ||
                                x.ORIGINALLINENUMBER === '' ||
                                x.ORIGINALLINENUMBER === undefined) &&
                            x.IsExploded === false,
                    );
                    const explodedLines = this.selectedExplodedLines().filter(
                        (x: any) =>
                            x.ORIGINALLINENUMBER !== null &&
                            x.ORIGINALLINENUMBER !== '',
                    );

                    const receiptLines = [...parentLines, ...explodedLines];

                    const validLines = receiptLines.filter(
                        (x) => x.Status_Desc !== 'New',
                    );

                    const inValidLines = receiptLines.filter(
                        (x) => x.Status_Desc === 'New',
                    );
                    if (validLines.length > 0) {
                        this.loading.set(true);
                        const subscription = this.asnlinesService
                            .unreceiveAsnLines(validLines)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedExplodedLines.set([]);
                                    this.getExplodedLines();
                                }),
                            )
                            .subscribe({
                                next: (response) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'UnReceive Receipt Lines',
                                        detail: 'Receipt Lines unreceived successfully.',
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        const errorMessage =
                                            error?.error?.message ||
                                            'Failed to unreceive Receipt Lines.';
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'UnReceive Receipt Lines',
                                            detail: errorMessage,
                                        });
                                    }
                                },
                            });

                        this.destroyRef.onDestroy(() => subscription.unsubscribe());
                    } else {
                        if (explodedParent.length > 0 && inValidLines.length > 0) {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: `"Reception action for exploded lines can only be done in exploded child lines view.",
                      "Only received / in-receiving lines can be un-received."`,
                            });
                        } else if (explodedParent.length > 0) {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: 'Reception action for exploded lines can only be done in exploded child lines view.',
                            });
                        } else {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: 'Only received / in-receiving lines can be un-received.',
                            });
                        }
                    }
                } else {
                    const requestBody = {
                        ReceiptKey: this.receiptKey(),
                    };
                    const subscription = this.asnlinesService
                        .unreceiveAsn(requestBody)
                        .pipe(
                            finalize(() => {
                                this.loading.set(false);
                                this.selectedExplodedLines.set([]);
                                this.getExplodedLines();
                            }),
                        )
                        .subscribe({
                            next: (response) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'UnReceive Receipt Lines',
                                    detail: 'Receipt Lines unreceived successfully.',
                                });
                            },
                            error: (error) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef = this.dialogService.open(
                                        CommonErrorboxComponent,
                                        {
                                            inputValues: {
                                                error: error,
                                            },
                                            header: 'Multiple Error',
                                            closable: true,
                                            modal: true,
                                            draggable: true,
                                            keepInViewport: true,
                                            width: '39rem',
                                            style: { maxHeight: '40rem' },
                                        },
                                    );
                                } else {
                                    const errorMessage =
                                        error?.error?.message ||
                                        'Failed to unreceive Receipt Lines.';
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'UnReceive Receipt Lines',
                                        detail: errorMessage,
                                    });
                                }
                            },
                        });

                    this.destroyRef.onDestroy(() => subscription.unsubscribe());
                }
            }
        });
    }

    onEditAction(explodedlines: ExplodedLines) {}
}
