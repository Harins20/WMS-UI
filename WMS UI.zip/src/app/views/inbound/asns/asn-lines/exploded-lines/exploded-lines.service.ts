import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { ExplodedLines } from './exploded-lines.model';
import { AppConfigService } from '../../../../../../app.config.service';
import { ResponseDto } from '../../../../../common/models';
import { AuthService } from '../../../../../common/services';
import { ExplodedLineColumns } from './exploded-lines.columns';
import { map } from 'rxjs';
import { stringToDate } from '../../../../../common/functions';

@Injectable({
    providedIn: 'root',
})
export class ExplodedLineService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getExplodedLines(receiptKey: string, line: string) {
        const url =
            this.config.appConfig()?.InbUrl +
            `Asn/Lines/Exploded?ReceiptKey=${receiptKey}&Line=${line}`;

        return this.httpClient
            .get<ResponseDto<ExplodedLines[]>>(url, {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe(
                map((response) => {
                    response.Response.forEach((asn: any) => {
                        Object.keys(asn).forEach((key) => {
                            if (ExplodedLineColumns[key]?.type === 'date') {
                                asn[key] = stringToDate(asn[key]);
                            }
                        });
                    });
                    return response;
                }),
            );
    }

    receiveExplodedLines(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/Lines/Receive',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    unreceiveExplodedLines(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/Lines/UnReceive',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
