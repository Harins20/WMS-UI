import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { AsnLine } from './asn-line.model';
import { AppConfigService } from '../../../../../app.config.service';
import { ResponseDto } from '../../../../common/models';
import { AuthService } from '../../../../common/services';
import { map } from 'rxjs';
import { AsnLineColumns } from './asn-line.columns';
import { stringToDate } from '../../../../common/functions';

interface AsnLinesPage {
    AsnLines: AsnLine[];
    totalRecords: number;
}

@Injectable({
    providedIn: 'root',
})
export class AsnLineService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);
    TraderKey = signal<string | null>(
        this.safeAtob(sessionStorage.getItem('TraderKey')),
    );
    safeAtob(val: string | null): string | null {
        if (!val) return null;
        try {
            return atob(val);
        } catch {
            return null;
        }
    }
    getAsnLines(data: any, receiptKey: string) {
        return this.httpClient.post<ResponseDto<AsnLinesPage>>(
            this.config.appConfig()?.InbUrl +
                `asn/lines/page?RECEIPTKEY=${receiptKey}&TRADERKEY=${this.TraderKey()}`,
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getAsnLinesPage(data: any) {
        return this.httpClient
            .post<AsnLinesPage>(
                this.config.appConfig()?.InbUrl + `asn/lines/page`,
                data,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((response: any) => {
                    response.Response.AsnLines.forEach((asn: any) => {
                        Object.keys(asn).forEach((key) => {
                            if (AsnLineColumns[key]?.type === 'date') {
                                asn[key] = stringToDate(asn[key]);
                            }
                        });
                    });
                    return response;
                }),
            );
    }

    createAsnLines(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InbUrl + 'Asn/Lines',
            [data],
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    updateAsnLines(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/Lines',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    receiveAsn(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/Receive',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    unreceiveAsn(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/UnReceive',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    receiveAsnLines(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/Lines/Receive',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    unreceiveAsnLines(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/Lines/UnReceive',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    explodeAsnLines(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/Lines/Explode',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    unexplodeAsnLines(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Asn/Lines/UnExplode',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    putaway(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Putaway',
            { headers: this.authService.getAuthHeaders(), body: data },
        );
    }

    deleteAsnLines(data: any) {
        return this.httpClient.delete(
            this.config.appConfig()?.InbUrl + 'Asn/Lines',
            { headers: this.authService.getAuthHeaders(), body: data },
        );
    }
}
