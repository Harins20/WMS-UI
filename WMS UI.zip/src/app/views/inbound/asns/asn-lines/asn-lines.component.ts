import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    EventEmitter,
    inject,
    input,
    linkedSignal,
    Output,
    output,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize, map } from 'rxjs';
import { AsnLineColumns } from './asn-line.columns';
import { AsnLine } from './asn-line.model';
import { AsnLineService } from './asn-lines.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../../common/components';
import { Route, Router } from '@angular/router';
import { AsnLineFormComponent } from './asn-lines-form/asn-lines-form.component';
import { Location } from '@angular/common';
import { PutawayLineComponent } from '../putaway/putaway.component';
import inboundRoutes from '../../inbound.routes';
import { TabService } from '../../../../tabs/tab.service';
import { ExcelDownloadService } from '../../../../common/services/excel-download.service';
import { AsnService } from '../asn.service';
import { tableOptions } from '../../../../common/constants';
import { TagModule } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';
import { AccordionModule } from 'primeng/accordion';
import { TabsModule } from 'primeng/tabs';
import { AsnViewFormComponent } from '../asn-view-form/asn-view-form.component';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';

import { StyledBackBtnComponent } from '../../../../common/components/styled-back-btn/styled-back-btn.component';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';
import { lowercasecolumn } from '../../../../common/functions/Uppercase';
import { CustomTablePaginationComponent } from '../../../../common/components/custom-table-pagination/custom-table-pagination.component';
@Component({
    selector: 'app-asnlines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TabsModule,
        TagModule,
        TooltipModule,
        AccordionModule,
        AsnViewFormComponent,
        AppTranslatePipe,
        StyledBackBtnComponent,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './asn-lines.component.html',
    styleUrl: './asn-lines.component.scss',
    providers: [DialogService],
})
export class AsnLineComponent {
    ref: DynamicDialogRef | undefined;
    private translate = inject(TranslateService);
    private router = inject(Router);
    receiptKey = input.required<string>();
    storerKey = input.required<string>();
    asnlines = signal<AsnLine[]>([]);
    selectedAsnLines = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    AsnHeader = signal<any>([]);
    loading = signal(false);
    mainLoading = signal(false);
    dt = viewChild.required<Table>('dt');
    @Output() backClick = new EventEmitter<void>();
    columns = signal(
        Object.values(AsnLineColumns).filter((column) => !column.tableHidden),
    );
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    selectedColumns = linkedSignal(() => this.columns());
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    exportFileName = 'Asn Lines List';
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    Excel = this.translate.instant('Excel');
    Receive = this.translate.instant('Receive');
    UnReceive = this.translate.instant('UnReceive');
    Explode = this.translate.instant('Explode');
    UnExplode = this.translate.instant('UnExplode');
    actions: MenuItem[] = [
        {
            label: this.Receive,
            command: () => this.ReceiveASNLines(),
        },
        {
            label: this.UnReceive,
            command: () => this.UnReceiveASNLines(),
        },
        {
            label: this.Explode,
            command: () => this.ExplodeASNLines(),
        },
        {
            label: this.UnExplode,
            command: () => this.UnExplodeASNLines(),
        },
        {
            label: 'Print label',
            command: () => this.onClickPrintLabel(),
        },
    ];

    exportTypes: MenuItem[] = [
        {
            label: this.Excel,
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    totalRecords = signal(15);
    loadEvent = signal<any>({});
    OrginalColumns = signal<any>(AsnLineColumns);
    private messageService = inject(MessageService);
    private asnlinesService = inject(AsnLineService);
    private destroyRef = inject(DestroyRef);
    private tabService = inject(TabService);
    private dialogService = inject(DialogService);
    private excelDownloadService = inject(ExcelDownloadService);
    private asnService = inject(AsnService);
    ConfirmationRef: DynamicDialogRef | undefined;
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    constructor(private location: Location) {}
    isAsnReceived = computed(
        () =>
            this.AsnHeader()?.STATUS === '0' ||
            this.AsnHeader()?.STATUS === '9',
    );
    ngOnInit() {
        if (this.receiptKey()) {
            this.getAsnHeader();
        }
    }

    customreceiptCellTemplate =
        viewChild.required<TemplateRef<any>>('customreceiptCell');
    ngAfterViewInit() {
        this.columns.update((columns) =>
            columns.map((column: any) => {
                if (column.field === 'Status_Desc') {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }
                if (column.field === 'RECEIPTLINENUMBER') {
                    return {
                        ...column,
                        customCellTemplate: this.customreceiptCellTemplate(),
                    };
                }

                return column;
            }),
        );
    }
    getAsnHeader() {
        const subscription = this.asnService
            .getReceiptKeyDetail(this.receiptKey())
            .subscribe({
                next: (data: any) => {
                    this.AsnHeader.set(data);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getAsnLines(event);
    }
    getAsnLines(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.asnlines.set([]);
        const subscription = this.asnlinesService
            .getAsnLines(data, this.receiptKey())
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res) => {
                    let idBase = data.first || 0;

                    this.asnlines.set(
                        res.Response.AsnLines.filter(
                            (x) =>
                                x.ORIGINALLINENUMBER === null ||
                                x.ORIGINALLINENUMBER === '' ||
                                x.ORIGINALLINENUMBER === undefined,
                        ).map((x: any, idx: number) => ({
                            ...x,
                            rowId: idBase + idx + 1,
                        })),
                    );
                    this.totalRecords.set(res.Response.totalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'ASN Line list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    this.loading.set(true);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }
    OnClick() {
        //
        // this.backClick.emit();
        // this.router.navigate(['/asn']);
        this.location.back();
    }

    handleBack() {
        if (window.history.length > 1) {
            this.location.back();
        } else {
            this.location.go('/');
        }
    }
    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getAsnLines();
    }
    getAsnForExcel(data: any = this.loadEvent(), type: string) {
        const subscription = this.asnlinesService
            .getAsnLines(data, this.receiptKey())
            .subscribe({
                next: (res: any) => {
                    const asnLines = res?.Response?.AsnLines || [];

                    if (type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            asnLines,
                        );
                    } else {
                        downloadCSVFile(asnLines, this.exportFileName);
                    }
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    export(type: string) {
        const event = this.loadEvent();
        this.getAsnForExcel(
            {
                ...event,
                first: 0,
                rows: this.totalRecords(),
            },
            type,
        );
    }

    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(this.asnlines().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedAsnLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedAsnLines().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.ref = this.dialogService.open(ColumnPicklistComponent, {
            inputValues: {
                selectedColumns: this.selectedColumns(),
                unSelectedColumns: this.unSelectedColumns(),
            },
            header: headertext,
            closable: true,
            modal: true,
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {});
    }

    onClickExplodedLineId(event: Event, row: AsnLine): void {
        event.preventDefault();

        const route = inboundRoutes.find(
            (route) => route.data?.name === 'explodedline',
        ) as Route;

        const params = [
            { name: 'receiptKey', value: this.receiptKey() },
            { name: 'receiptLineNumber', value: row.RECEIPTLINENUMBER },
            { name: 'storerKey', value: row.TRADERKEY },
        ];

        this.tabService.addTabWithParams(
            route,
            '',
            'Exploded Lines - ' + row.RECEIPTLINENUMBER,
            params,
        );
    }
    onClickPrintLabel(): void {
        const data =
            !this.selectedAsnLines() || this.selectedAsnLines().length == 0
                ? [{ ReceiptKey: this.receiptKey() }]
                : this.selectedAsnLines().map((x: any) => ({
                      ReceiptKey: x.RECEIPTKEY,
                      Line: x.RECEIPTLINENUMBER,
                  }));

        const route = inboundRoutes.find(
            (route) => route.data?.name === 'Multi Report Viewer',
        ) as Route;

        const params = [{ name: 'receipt', value: data }];

        this.tabService.addTabWithParams(
            route,
            '',
            'ASN - ' + this.receiptKey() + ' Labels',
            params,
        );
    }
    OpenCreateASNLineForm() {
        const headertext = this.translate.instant('Create ASNLine');
        this.ref = this.dialogService.open(AsnLineFormComponent, {
            inputValues: {
                asnlineCreateData: this.AsnHeader(),
            },
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });

        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('ASNLineCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );

                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        const requestBody = {
                            ...this.AsnHeader(),
                            ...data,
                            ExternalReceiptKey: data.EXTERNRECEIPTKEY,
                        };

                        const l = lowercasecolumn(requestBody);

                        this.loading.set(true);

                        this.asnlinesService
                            .createAsnLines(l)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getAsnLines();
                                }),
                            )
                            .subscribe({
                                next: (response: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New ASN Line creation',
                                        detail: response.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Error creating ASN Line',
                                            detail:
                                                error?.error?.message ||
                                                'Error occurred while creating ASN Line.',
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateASNLineForm(asnlineData: any) {
        const headertext = this.translate.instant('Update ReceiptLine');
        const selectedAsn: AsnLine = Array.isArray(asnlineData)
            ? asnlineData[0]
            : asnlineData;
        this.ref = this.dialogService.open(AsnLineFormComponent, {
            inputValues: {
                asnlineData: selectedAsn,
                Identify: 'ASNLines',
            },
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('ASNLineUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );

                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        const updatedData: AsnLine = {
                            ...asnlineData,
                            ...data,
                            ExternalReceiptKey: data.EXTERNRECEIPTKEY,
                        };
                        this.asnlinesService
                            .updateAsnLines(updatedData)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedAsnLines.set([]);
                                    this.getAsnLines();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'ASN Line Update',
                                        detail: data.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'ASN Line Update',
                                            detail: error.error
                                                .message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenPutawayForm() {
        const headertext = this.translate.instant('Update Putaway');
        this.ref = this.dialogService.open(PutawayLineComponent, {
            inputValues: {
                receiptKey: this.receiptKey(),
            },
            header: headertext,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '65rem',
            style: { maxHeight: '40rem' },
        });

        this.ref.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const requestBody = data.map((item: any) => ({
                    ReceiptKey: item.ReceiptKey,
                    ReceiptLineNumber: item.ReceiptLineNumber,
                    Suggested_Loc: item.PutawayLoc,
                    Timestamp: new Date().toISOString(),
                    Putaway_Qty: item.PutawayQty,
                }));
                this.loading.set(false);
            }
        });
    }

    DeleteAsnLineConfirmation() {
        const headertext = this.translate.instant('Confirm Deletion');
        const count = this.selectedAsnLines().length;
        const name =
            count > 1
                ? this.translate.instant('Asn Lines')
                : this.translate.instant('ASN Line');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                // duplicate: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const Rdata = this.selectedAsnLines().map((x: any) =>
                    x.SERIALKEY.toString(),
                );

                const requestBody = {
                    RECEIPTKEY: this.receiptKey(),
                    SERIALKEY: Rdata,
                };

                const subscription = this.asnlinesService
                    .deleteAsnLines(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedAsnLines.set([]);
                            this.getAsnLines();
                            this.getAsnHeader();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Delete ASN Line',
                                detail: 'ASN Line deleted successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    'Failed to delete ASN Line.';

                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Delete ASN Line',
                                    detail: errorMessage,
                                });
                            }
                            this.loading.set(false);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    ReceiveASNLines() {
        const isHeader = this.selectedAsnLines().length === 0;
        const count = isHeader ? 1 : this.selectedAsnLines().length;
        const headertext = this.translate.instant('Receive ASN Line');
        const name = isHeader
            ? this.translate.instant('ASN')
            : count > 1
              ? this.translate.instant('Asn Lines')
              : this.translate.instant('ASN Line');
        const value = this.translate.instant('ReceiveASN', {
            no: isHeader ? this.receiptKey() : count,
            name: name,
        });

        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                if (this.selectedAsnLines().length > 0) {
                    const explodedParent = this.selectedAsnLines().filter(
                        (x: any) =>
                            (x.ORIGINALLINENUMBER === null ||
                                x.ORIGINALLINENUMBER === '' ||
                                x.ORIGINALLINENUMBER === undefined) &&
                            x.IsExploded === true,
                    );
                    const parentLines = this.selectedAsnLines().filter(
                        (x: any) =>
                            (x.ORIGINALLINENUMBER === null ||
                                x.ORIGINALLINENUMBER === '' ||
                                x.ORIGINALLINENUMBER === undefined) &&
                            x.IsExploded === false,
                    );
                    const explodedLines = this.selectedAsnLines().filter(
                        (x: any) =>
                            x.ORIGINALLINENUMBER !== null &&
                            x.ORIGINALLINENUMBER !== '',
                    );

                    const receiptLines = [...parentLines, ...explodedLines];

                    const validLines = receiptLines.filter(
                        (x) => x.Status_Desc !== 'Received',
                    );

                    const inValidLines = receiptLines.filter(
                        (x) => x.Status_Desc === 'Received',
                    );

                    if (validLines.length > 0) {
                        this.loading.set(true);
                        const subscription = this.asnlinesService
                            .receiveAsnLines(validLines)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedAsnLines.set([]);
                                    this.getAsnLines();
                                    this.getAsnHeader();
                                }),
                            )
                            .subscribe({
                                next: (response) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Receive Receipt Lines',
                                        detail: 'ASN Lines received successfully.',
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        const errorMessage =
                                            error?.error?.message ||
                                            'An unexpected error occurred while receiving ASN Lines. Please try again later.';
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Receive Receipt Lines',
                                            detail: errorMessage,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });

                        this.destroyRef.onDestroy(() =>
                            subscription.unsubscribe(),
                        );
                    } else {
                        if (
                            explodedParent.length > 0 &&
                            inValidLines.length > 0
                        ) {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: `Reception action for exploded lines can only be done in the exploded child lines view. 
                                         Only new or in-receiving lines can be received.`,
                            });
                        } else if (explodedParent.length > 0) {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: 'Reception action for exploded lines can only be done in the exploded child lines view.',
                            });
                        } else {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: 'Only new or in-receiving lines can be received.',
                            });
                            this.loading.set(false);
                        }
                    }
                } else {
                    if (
                        this.asnlines().length === 0 ||
                        this.asnlines()[0] === undefined
                    ) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Receive Receipt Lines',
                            detail: 'No lines available to receive.',
                        });
                    } else {
                        const requestBody = {
                            ReceiptKey: this.receiptKey(),
                        };
                        const subscription = this.asnlinesService
                            .receiveAsn(requestBody)
                            .pipe(
                                finalize(() => {
                                    this.mainLoading.set(false);
                                    this.selectedAsnLines.set([]);
                                    this.getAsnLines();
                                    this.getAsnHeader();
                                }),
                            )
                            .subscribe({
                                next: (response) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Receive Receipt Lines',
                                        detail: 'Receipt Lines received successfully.',
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        const errorMessage =
                                            error?.error?.message ||
                                            'An unexpected error occurred while receiving ASN Lines. Please try again later.';
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Receive Receipt Lines',
                                            detail: errorMessage,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });

                        this.destroyRef.onDestroy(() =>
                            subscription.unsubscribe(),
                        );
                    }
                }
            }
        });
    }
    UnReceiveASNLines() {
        if (
            this.selectedAsnLines().length === 0 &&
            (this.asnlines().length === 0 || this.asnlines()[0] === undefined)
        ) {
            this.messageService.add({
                severity: 'error',
                summary: 'Unreceive Receipt Lines',
                detail: 'No lines available to Unreceive.',
            });
            return;
        }

        const isHeader = this.selectedAsnLines().length === 0;
        const count = isHeader ? 1 : this.selectedAsnLines().length;
        const headertext = this.translate.instant('UnReceive ASN Line');
        const name = isHeader
            ? this.translate.instant('ASN')
            : count > 1
              ? this.translate.instant('Asn Lines')
              : this.translate.instant('ASN Line');
        const value = this.translate.instant('UnReceiveASN', {
            no: isHeader ? this.receiptKey() : count,
            name: name,
        });

        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                if (this.selectedAsnLines().length > 0) {
                    const explodedParent = this.selectedAsnLines().filter(
                        (x: any) =>
                            (x.ORIGINALLINENUMBER === null ||
                                x.ORIGINALLINENUMBER === '' ||
                                x.ORIGINALLINENUMBER === undefined) &&
                            x.IsExploded === true,
                    );
                    const parentLines = this.selectedAsnLines().filter(
                        (x: any) =>
                            (x.ORIGINALLINENUMBER === null ||
                                x.ORIGINALLINENUMBER === '' ||
                                x.ORIGINALLINENUMBER === undefined) &&
                            x.IsExploded === false,
                    );
                    const explodedLines = this.selectedAsnLines().filter(
                        (x: any) =>
                            x.ORIGINALLINENUMBER !== null &&
                            x.ORIGINALLINENUMBER !== '',
                    );

                    const receiptLines = [...parentLines, ...explodedLines];

                    const validLines = receiptLines.filter(
                        (x) => x.Status_Desc !== 'New',
                    );

                    const inValidLines = receiptLines.filter(
                        (x) => x.Status_Desc === 'New',
                    );
                    if (validLines.length > 0) {
                        this.loading.set(true);
                        const subscription = this.asnlinesService
                            .unreceiveAsnLines(validLines)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedAsnLines.set([]);
                                    this.getAsnLines();
                                    this.getAsnHeader();
                                }),
                            )
                            .subscribe({
                                next: (response) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'UnReceive Receipt Lines',
                                        detail: 'Receipt Lines unreceived successfully.',
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        const errorMessage =
                                            error?.error?.message ||
                                            'Failed to unreceive Receipt Lines.';
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'UnReceive Receipt Lines',
                                            detail: errorMessage,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });

                        this.destroyRef.onDestroy(() =>
                            subscription.unsubscribe(),
                        );
                    } else {
                        if (
                            explodedParent.length > 0 &&
                            inValidLines.length > 0
                        ) {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: `"Reception action for exploded lines can only be done in exploded child lines view.",
                      "Only received / in-receiving lines can be un-received."`,
                            });
                        } else if (explodedParent.length > 0) {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: 'Reception action for exploded lines can only be done in exploded child lines view.',
                            });
                        } else {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Receive Receipt Lines',
                                detail: 'Only received / in-receiving lines can be un-received.',
                            });
                            this.loading.set(false);
                        }
                    }
                } else {
                    const requestBody = {
                        ReceiptKey: this.receiptKey(),
                    };
                    const subscription = this.asnlinesService
                        .unreceiveAsn(requestBody)
                        .pipe(
                            finalize(() => {
                                this.loading.set(false);
                                this.selectedAsnLines.set([]);
                                this.getAsnLines();
                                this.getAsnHeader();
                            }),
                        )
                        .subscribe({
                            next: (response) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'UnReceive Receipt Lines',
                                    detail: 'Receipt Lines unreceived successfully.',
                                });
                            },
                            error: (error) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef =
                                        this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                } else {
                                    const errorMessage =
                                        error?.error?.message ||
                                        'Failed to unreceive Receipt Lines.';
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'UnReceive Receipt Lines',
                                        detail: errorMessage,
                                    });
                                }
                                this.loading.set(false);
                            },
                        });

                    this.destroyRef.onDestroy(() => subscription.unsubscribe());
                }
            }
        });
    }
    ExplodeASNLines() {
        const isHeader = this.selectedAsnLines().length === 0;
        const count = isHeader ? 1 : this.selectedAsnLines().length;
        const headertext = this.translate.instant('Explode ASN Line');
        const name = isHeader
            ? this.translate.instant('ASN')
            : count > 1
              ? this.translate.instant('Asn Lines')
              : this.translate.instant('ASN Line');
        const value = this.translate.instant('ExplodeASN', {
            no: isHeader ? this.receiptKey() : count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                const validAsnLines = this.selectedAsnLines().filter(
                    (line: any) => line.Status_Desc === 'New',
                );
                this.loading.set(true);
                if (validAsnLines.length === 0) {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Explode ASN Lines',
                        detail: 'Only ASN Lines with "New" status can be exploded.',
                    });
                    this.loading.set(false);
                    return;
                }

                const requestBody = validAsnLines.map((line: AsnLine) => ({
                    ...line,
                }));

                const subscription = this.asnlinesService
                    .explodeAsnLines(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedAsnLines.set([]);
                            this.getAsnLines();
                            this.getAsnHeader();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Explode ASN Lines',
                                detail: 'ASN Lines exploded successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    'Failed to explode ASN Lines.';
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Explode ASN Lines',
                                    detail: errorMessage,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            }
        });
    }

    UnExplodeASNLines() {
        const validAsnLines = this.selectedAsnLines().filter(
            (line: any) => line.IsExploded === true,
        );
        if (validAsnLines.length === 0) {
            this.messageService.add({
                severity: 'error',
                summary: 'UnExplode ASN Lines',
                detail: 'Only ASN Lines that are exploded can be unexploded.',
            });
            return;
        }

        const count = validAsnLines.length;
        const name =
            count > 1
                ? this.translate.instant('Asn Lines')
                : this.translate.instant('ASN Line');
        const headertext = this.translate.instant('UnExplode ASN Line');
        const value = this.translate.instant('UnExplodeASN', {
            no: count,
            name: name,
        });

        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                this.loading.set(true);
                const requestBody = validAsnLines.map((line: AsnLine) => ({
                    ...line,
                }));

                const subscription = this.asnlinesService
                    .unexplodeAsnLines(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedAsnLines.set([]);
                            this.getAsnLines();
                            this.getAsnHeader();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'UnExplode ASN Lines',
                                detail: 'ASN Lines unexploded successfully.',
                            });
                            this.loading.set(false);
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    'Failed to unexplode ASN Lines.';
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'UnExplode ASN Lines',
                                    detail: errorMessage,
                                });
                            }
                            this.loading.set(false);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    Putaway() {
        const validAsnLines = this.selectedAsnLines().filter(
            (line: any) => line.Status_Desc === 'Received',
        );
        this.loading.set(true);
        if (validAsnLines.length === 0) {
            this.messageService.add({
                severity: 'error',
                summary: 'Putaway',
                detail: 'Only ASN Lines with status "Received" can be put away.',
            });
            this.mainLoading.set(false);
            return;
        }

        const requestBody = validAsnLines.map((line: AsnLine) => ({
            ...line,
        }));

        const subscription = this.asnlinesService
            .putaway(requestBody)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                    this.selectedAsnLines.set([]);
                    this.getAsnLines();
                    this.getAsnHeader();
                }),
            )
            .subscribe({
                next: (response) => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Putaway',
                        detail: 'Putaway done successfully.',
                    });
                },
                error: (error) => {
                    if (
                        error.error.Message ===
                            'One or more errors occurred!' ||
                        error.error.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: error,
                                },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                    } else {
                        const errorMessage =
                            error?.error?.message || 'Failed to Putaway';
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Putaway',
                            detail: errorMessage,
                        });
                    }
                    this.loading.set(false);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    onEditAction(asnlines: AsnLine) {}
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
