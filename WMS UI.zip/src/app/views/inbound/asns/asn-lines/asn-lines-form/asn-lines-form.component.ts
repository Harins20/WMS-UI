import { InputSelectComponent } from './../../../../../common/components/input-select/input-select.component';
import { InputTextComponent } from './../../../../../common/components/input-text/input-text.component';
import { MessageService } from 'primeng/api';
import { CommonModule } from '@angular/common';
import {
    Component,
    DestroyRef,
    inject,
    input,
    signal,
    computed,
    effect,
} from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { IftaLabelModule } from 'primeng/iftalabel';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { AsnLineColumns } from '../asn-line.columns';
import { OptionsService } from '../../../../../common/services';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../../common/functions';
import { TabsModule } from 'primeng/tabs';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { selectOption } from '../../../../../common/models';
import { Select } from 'primeng/select';
import { AsnService } from '../../asn.service';
import { InputNumber } from 'primeng/inputnumber';
import { DatePickerModule } from 'primeng/datepicker';
import { ExplodedLineColumns } from '../exploded-lines/exploded-lines.columns';
import { InputDatepickerComponent } from '../../../../../common/components';
import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
@Component({
    selector: 'asn-line-form',
    imports: [
        ReactiveFormsModule,
        CommonModule,
        IftaLabelModule,
        InputTextModule,
        PasswordModule,
        ButtonModule,
        TabsModule,
        DatePickerModule,
        InputDatepickerComponent,
        AppTranslatePipe,
        InputTextComponent,
        InputSelectComponent,
    ],
    templateUrl: './asn-lines-form.component.html',
    styleUrl: './asn-lines-form.component.scss',
})
export class AsnLineFormComponent {
    asnlineData = input<any>();
    Identify = input<any>();
    asnlineCreateData = input<any>();
    private destroyRef = inject(DestroyRef);
    private ref = inject(DynamicDialogRef);
    setViewTAb = signal<boolean>(true);
    activeTab = signal<number>(0);
    loading = signal(false);
    asnLineColumns: any[] = [];
    private messageService = inject(MessageService);
    formControlsArray = signal(
        Object.values(AsnLineColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    private optionService = inject(OptionsService);
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    asnlineform = new FormGroup(this.formControls());
    itemOptions = signal<selectOption[]>([]);
    packOptions = signal<selectOption[]>([]);
    uomOptions = signal<selectOption[]>([]);
    selectedAsnLines = signal<selectOption[]>([]);
    locationOptions = signal<selectOption[]>([]);
    statusOptions = signal<selectOption[]>([]);
    private asnService = inject(AsnService);

    minExpirationDate: Date = new Date(); // default: today

    onManufactureDateSelect(selectedDate: any): void {
        if (selectedDate) {
            const nextDay = new Date(selectedDate);
            nextDay.setDate(nextDay.getDate() + 1); // start from the NEXT day
            this.minExpirationDate = nextDay;

            // Clear expiration date if it's now before the new minDate
            const currentExpiration = this.asnlineform.get('LOTTABLE05')?.value;
            if (
                currentExpiration &&
                new Date(currentExpiration) <= selectedDate
            ) {
                this.asnlineform.get('LOTTABLE05')?.reset();
            }
        }
    }

    ngOnInit() {
        this.getColumns();
        this.GetQCStatusOptions();
        this.GetPackOptions();
        this.GetLocationOptions();
        if (this.Identify() === 'ASNLines' && this.asnlineData()) {
            Object.values(AsnLineColumns).forEach((column) => {
                if (column.restrictEdit) {
                    this.asnlineform.controls[column.field].disable();
                } else if (this.asnlineData().Status_Desc !== 'New') {
                    if (column.field === 'QCSTATUS') {
                        this.asnlineform.controls[column.field].enable();
                    } else {
                        this.asnlineform.controls[column.field].disable();
                    }
                } else if (this.asnlineData().IsExploded === true) {
                    this.asnlineform.controls[column.field].disable();
                }
            });
            // this.GetUOMOptions(this.asnlineData()?.PACKKEY);
            const selectedStorerKey = this.asnlineData()?.TRADERKEY;
            if (selectedStorerKey) {
                this.GetItemOptions(selectedStorerKey);
            }
            this.asnlineform.patchValue({
                ...this.asnlineData(),
                LOTTABLE04: this.asnlineData()?.LOTTABLE04
                    ? new Date(this.asnlineData()?.LOTTABLE04 + 'Z')
                    : null,
                LOTTABLE05: this.asnlineData()?.LOTTABLE05
                    ? new Date(this.asnlineData()?.LOTTABLE05 + 'Z')
                    : null,
            });
        } else if (this.Identify() === 'exploded' && this.asnlineData()) {
            const restrictedField = 'QCSTATUS';
            Object.values(ExplodedLineColumns).forEach((column) => {
                if (this.asnlineform.controls[column.field]) {
                    this.asnlineform.controls[column.field].disable();

                    if (
                        this.asnlineData().Status_Desc !== 'New' &&
                        column.field === restrictedField
                    ) {
                        this.asnlineform.controls[column.field].enable();
                    } else {
                        this.asnlineform.controls[column.field].disable();
                    }
                }
            });

            const selectedStorerKey = this.asnlineData()?.TRADERKEY;
            if (selectedStorerKey) {
                this.GetItemOptions(selectedStorerKey);
            }
            this.asnlineform.patchValue({
                ...this.asnlineData(),
                LOTTABLE04: new Date(this.asnlineData()?.LOTTABLE04),
                LOTTABLE05: new Date(this.asnlineData()?.LOTTABLE05),
            });
        } else {
            Object.values(AsnLineColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.asnlineform.controls[column.field].disable();
            });
            // console.log(this.asnlineCreateData());

            this.asnlineform.patchValue({
                EXTERNRECEIPTKEY: this.asnlineCreateData().EXTERNRECEIPTKEY,
                TRADERKEY: this.asnlineCreateData().TRADERKEY,
            });
            const selectedStorerKey = this.asnlineCreateData()?.TRADERKEY;
            if (selectedStorerKey) {
                this.GetItemOptions(selectedStorerKey);
            }
        }
    }

    targetValue = this.asnlineform.controls['PACKKEY'].valueChanges.subscribe(
        (value) => {
            if (value) {
                this.GetUOMOptions(value);
            }
        },
    );
    hasError(formControlName: string) {
        const formControl = this.asnlineform.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    closePanel() {
        this.ref.close();
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.asnlineform.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }

    GetItemOptions(StorerKey: string) {
        const subscription = this.optionService
            .getItemDetailsOptions(StorerKey)
            .subscribe({
                next: (data: any) => {
                    this.itemOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPackOptions() {
        const subscription = this.optionService.getPackOptions().subscribe({
            next: (data) => {
                this.packOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching pack dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetUOMOptions(Packkey: string) {
        const subscription = this.optionService
            .getUomOptions(Packkey)
            .subscribe({
                next: (data) => {
                    this.uomOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching UOM dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetLocationOptions() {
        const subscription = this.optionService.getLocationOptions().subscribe({
            next: (data) => {
                this.locationOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching UOM dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetQCStatusOptions() {
        const subscription = this.optionService.getQcStatusOptions().subscribe({
            next: (data) => {
                this.statusOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching UOM dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GROSSWGT$ = this.asnlineform.controls['GROSSWGT'].valueChanges.subscribe(
        (value) => {
            const netwgt = this.asnlineform.get('NETWGT') as FormControl;
            netwgt.setValidators([
                Validators.required,
                Validators.max(value || 0),
            ]);
            var TareQty = (value || 0) - (netwgt.value || 0);
            var tareControl = this.asnlineform.get('TAREWGT');
            tareControl?.setValue(TareQty);
        },
    );

    NETWGT$ = this.asnlineform.controls['NETWGT'].valueChanges.subscribe(
        (value) => {
            var TareQty =
                (this.asnlineform.get('GROSSWGT')?.value || 0) - (value || 0);
            var tareControl = this.asnlineform.get('TAREWGT');
            tareControl?.setValue(TareQty);

            tareControl?.updateValueAndValidity();
        },
    );

    ITEM$ = this.asnlineform.controls['SKU'].valueChanges.subscribe((value) => {
        if (value) {
            this.itemOptions().map((x: any) => {
                if (x.label == value) {
                    const grossWgtControl = this.asnlineform.get('GROSSWGT');
                    const netWgtControl = this.asnlineform.get('NETWGT');
                    grossWgtControl?.setValue(x.StdGrossWgt);
                    netWgtControl?.setValue(x?.StdNetWgt);

                    grossWgtControl?.updateValueAndValidity();
                    netWgtControl?.updateValueAndValidity();
                }
            });
        }
    });

    onSubmit() {
        if (this.asnlineform.valid) {
            this.setViewTAb.set(true);
            this.ref.close(this.asnlineform.getRawValue());
        } else {
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.setViewTAb.set(false);
            this.asnlineform.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.asnlineform.controls));
        }
    }
    getColumns() {
        this.optionService.getColumns(AsnLineColumns, 'VY_ASNLINES').subscribe({
            next: (data) => {
                this.asnLineColumns = data;
            },
        });
    }
}
