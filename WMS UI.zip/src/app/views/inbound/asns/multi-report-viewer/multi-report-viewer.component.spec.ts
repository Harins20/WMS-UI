import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiReportViewerComponent } from './multi-report-viewer.component';

describe('MultiReportViewerComponent', () => {
  let component: MultiReportViewerComponent;
  let fixture: ComponentFixture<MultiReportViewerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MultiReportViewerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MultiReportViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
