import {
    Component,
    effect,
    ElementRef,
    inject,
    input,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConfigService } from '../../../../../app.config.service';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';

declare var Stimulsoft: any;

interface InputData {
    ReceiptKey: string;
    Line?: string;
}
@Component({
    selector: 'app-multi-report-viewer',
    imports: [ButtonModule, CardModule],
    templateUrl: './multi-report-viewer.component.html',
    styleUrl: './multi-report-viewer.component.scss',
})
export class MultiReportViewerComponent {
    receipt = input<InputData[]>([]);
    currentReceiptKey = linkedSignal<string>(
        () => this.receipt()[this.currentPage()].ReceiptKey,
    );
    currentLine = linkedSignal<string | undefined>(
        () => this.receipt()[this.currentPage()].Line,
    );

    currentPage = signal<number>(0);
    viewInitlized = signal<boolean>(false);
    private config = inject(AppConfigService);
    viewcontainer = viewChild<ElementRef>('customReportViewer');
    // private router = inject(Router);
    log = effect(() => {
        if (
            this.viewcontainer() &&
            this.viewInitlized() &&
            this.currentReceiptKey()
        ) {
            const options = new Stimulsoft.Viewer.StiViewerOptions();
            options.appearance.fullScreenMode = false;

            const viewer = new Stimulsoft.Viewer.StiViewer(
                options,
                'StiViewer',
                false,
            );

            const report = new Stimulsoft.Report.StiReport();
            report.loadFile('/assets/reports/ASN Line Label.mrt');

            const jsonDataSource =
                report.dictionary.databases.getByName('LabelData');

            const newUrl =
                this.config.appConfig()?.InbUrl +
                `Asn/Lines/LabelData?Facility={FACILITY}&ReceiptKey={RECEIPTKEY}&line={LINE}`;

            jsonDataSource.pathData = newUrl;

            var receiptKeyVariable =
                report.dictionary.variables.getByName('RECEIPTKEY');
            receiptKeyVariable.value = this.currentReceiptKey();
            receiptKeyVariable.requestFromUser = false;
            var lineVariable = report.dictionary.variables.getByName('LINE');
            lineVariable.value = this.currentLine();
            lineVariable.requestFromUser = false;
            var facilityVariable =
                report.dictionary.variables.getByName('FACILITY');
            let facility = atob(sessionStorage.getItem('Facility') ?? '');
            facilityVariable.value = facility;
            facilityVariable.requestFromUser = false;

            viewer.report = report;
            viewer.renderHtml(this.viewcontainer()?.nativeElement);
        }
    });

    ngAfterViewInit(): void {
        Stimulsoft.Base.StiLicense.Key =
            '6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHnbeLC+bqPRqQ+5kkhFK29KQ+9iuHzyQojjOXTfUVm/KXZ4TwNf75psyetLPBiBfndUD7BZmK4zaHQAFah78X6NqhijqHmnqlANbaXbf6oqXdHOggFKuc56nN1QPq/iG8EpVmKzEekpF5ymIAqkEyEE7ooM88jNzMCQQ3iK8ffoV8C+BRYRNAKBVj1LouW3vCj5bTTtZhPzdtJXyAFS06G7dXNyRK2NaqYITw7HFMAB+tGvzFW7s6F0656aSVlMNSUj6Nsr3tzuFyDT/t72P8Ea4L0bXWshSRgM2kJKu1qmgE+mz4zQ4Yi7wdTI1jh3JVdEQuOeFT2yqY28VGSP7cdOcpWG+1Nv3/S+zZoRan4slHZma90QrLzIdZOOV1KS5Dt5ftiHCOC/5+ENThUiQBKg2u3wTnaWd06nqrXUY282ehdHQE/IdzxGw/NA3YVviwOWLJrzHsPifS2kvgLfZMaC65ErUTS1TcQH/WQ+PJmayG3y20+bZAe8Fx63nNwNHg0SHyQc8/uwNXjA1RxLOjOW';
        setTimeout(() => this.viewInitlized.set(true), 1);
    }
    nextPage() {
        if (this.currentPage() < this.receipt().length - 1) {
            this.currentPage.set(this.currentPage() + 1);
            //this.initializeViewer();
        }
    }

    prevPage() {
        if (this.currentPage() > 0) {
            this.currentPage.set(this.currentPage() - 1);
            //this.initializeViewer();
        }
    }
}
