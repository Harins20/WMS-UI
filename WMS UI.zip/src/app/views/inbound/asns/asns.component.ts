import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    effect,
    inject,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize, lastValueFrom, take } from 'rxjs';
import { AsnColumns } from './asn.columns';
import { Asn } from './asn.model';
import { AsnService } from './asn.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ConfirmationDialogComponent,
    LoadingComponent,
    CommonErrorboxComponent,
} from 'common-ui';
import { ViewImageDialogComponent } from '../../../common/components';
import { Route } from '@angular/router';
import { AsnFormComponent } from './asn-form/asn-form.component';
import { TabService } from '../../../tabs/tab.service';
import inboundRoutes from '../inbound.routes';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { TagModule } from 'primeng/tag';
import * as XLSX from 'xlsx';
import { TooltipModule } from 'primeng/tooltip';
import { ActionService } from '../../../layout/service/action.service';
import { convertExcelDate } from '../../../common/functions/numberToDate';

import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { OptionsService } from '../../../common/services/options.service';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import {
    lowercasecolumn,
    uppercasecolumn,
} from '../../../common/functions/Uppercase';

@Component({
    selector: 'app-asns',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        FileUpload,
        TagModule,
        TooltipModule,
        AppTranslatePipe,
        CustomTablePaginationComponent,
        LoadingComponent,
    ],
    templateUrl: './asns.component.html',
    styleUrl: './asns.component.scss',
    providers: [DialogService, DynamicDialogRef],
})
export class AsnsComponent {
    asns = signal<Asn[]>([]);
    selectedAsns = signal<any>([]);
    loading = signal(false);
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(15);

    excelData: any = [];
    exportFileName = 'Asn-list';

    columns = signal<any>([]);
    OrginalColumns = signal<any>(AsnColumns);
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x: any) => x.tableAlias && !x.tableHidden)
            .map((x: any) => x.field),
    );

    private messageService = inject(MessageService);
    private actionService = inject(ActionService);
    public asnsService = inject(AsnService);
    private destroyRef = inject(DestroyRef);
    ConfirmationRef: DynamicDialogRef | undefined;
    ref: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private translate = inject(TranslateService);
    private tabService = inject(TabService);
    private optionService = inject(OptionsService);
    private excelDownloadService = inject(ExcelDownloadService);
    Excel = this.translate.instant('Excel');
    Cancel = this.translate.instant('Cancel');
    Close = this.translate.instant('Close');
    CSV = this.translate.instant('CSV');
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');

    getColumns() {
        this.optionService.getColumns(AsnColumns, 'RECEIPT').subscribe({
            next: (data) => {
                const FilterField = data.map((x: any) => x.field);

                const GetFilterFields = Object.values(AsnColumns).filter(
                    (x: any) => {
                        return !FilterField.includes(x.field);
                    },
                );

                const allowedFields = [
                    'UDFSTR1',
                    'UDFSTR2',
                    'UDFSTR3',
                    'UDFSTR4',
                    'UDFSTR5',
                ];

                const limitedColumns = data.filter(
                    (x: any) =>
                        !x.field?.startsWith('UDF') ||
                        allowedFields.includes(x.field),
                );

                const columns = [...GetFilterFields, ...limitedColumns];
                let updatedColumns = columns;

                updatedColumns = updatedColumns.map((column: any) => {
                    if (column.field === 'STATUS_DESC') {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                });
                this.columns.set(
                    updatedColumns.filter((column: any) => !column.tableHidden),
                );
            },
        });
    }

    exportTypes: MenuItem[] = [
        {
            label: this.Excel,
            command: () => this.exportExcel(),
        },
        {
            label: this.CSV,
            command: () => this.exportCSV(),
        },
    ];
    actions: MenuItem[] = [
        {
            label: this.Cancel,
            command: () => this.CancelAsnConfirmation(),
        },
        {
            label: this.Close,
            command: () => this.CloseAsnConfirmation(),
        },
        {
            label: 'Print label',
            command: () => this.onClickPrintLabel(),
        },
    ];

    onClickPrintLabel(): void {
        const data = this.selectedAsns().map((x: any) => ({
            ReceiptKey: x.RECEIPTKEY,
        }));

        const route = inboundRoutes.find(
            (route) => route.data?.name === 'Multi Report Viewer',
        ) as Route;

        const params = [{ name: 'receipt', value: data }];

        this.tabService.addTabWithParams(route, '', 'ASN Labels', params);
    }

    ngOnInit() {
        // this.getAsns();
        this.GetActions();
        this.getColumns();
    }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getAsns(event);
    }
    getImageDatax = effect(() => {
        this.asns()?.forEach((x: any) => {
            if (x.ATTACHMENTID) {
                this.asnsService
                    .GetAsnAttachment(x.ATTACHMENTID)
                    .pipe((imageData) => (x.FILEDATA = imageData));
            }
        });
    });
    getAsns(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.asns.set([]);
        const subscription = this.asnsService
            .getAsnsPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let idBase = data.first || 0;
                    this.asns.set(
                        res.Response.AsnLines.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idBase + (idx + 1),
                            RECEIPTDATE:
                                x.RECEIPTDATE ?? new Date(x.RECEIPTDATE),
                        })),
                    );
                    this.totalRecords.set(res.Response.totalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'ASN Lines list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    } else if (
                        error.error.Message ===
                            'One or more errors occurred!' ||
                        error.error.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: error,
                                },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                    } else {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'ASN Lines list',
                            detail:
                                error.error.message ||
                                (error.error.Message as string),
                        });
                    }
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetActions() {
        const subscription = this.actionService
            .getActions()
            .pipe()
            .subscribe({
                next: (data) => {
                    if (data.length > 0) {
                        data.map((x: any) => {
                            if (x.Name === 'Re-open ASN') {
                                this.actions.push({
                                    label: 'Reopen',
                                    command: () => this.reopenASN(),
                                });
                            }
                        });
                    }
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetAsnAttachment(Id: any) {
        return this.asnsService.GetAsnAttachment(Id);
    }

    // getAsnForExcel(
    //     data: any = { Page: 1, PageSize: this.totalRecords },
    //     type: string,
    // ) {
    //     const subscription = this.asnsService
    //         .getAsnsPage(data)
    //         .pipe()
    //         .subscribe({
    //             next: (res: any) => {
    //                 let idBase = data.Page * data.PageSize - data.PageSize;
    //                 let desc = false;
    //                 if (
    //                     data.OrderBy &&
    //                     data.OrderBy.includes('SerialKey desc')
    //                 ) {
    //                     idBase =
    //                         this.totalRecords() -
    //                         (data.Page - 1) * data.PageSize;
    //                     desc = true;
    //                 }

    //                 if (res.AsnLines && type === 'Excel') {
    //                     this.excelDownloadService.downloadExcelFile(
    //                         this.exportFileName,
    //                         [],
    //                         res.AsnLines,
    //                     );
    //                 } else {
    //                     downloadCSVFile(res.AsnLines, this.exportFileName);
    //                 }
    //             },
    //         });
    // }
    getAsnForExcel(data: any = this.loadEvent(), type: string) {
        const subscription = this.asnsService.getAsnsPage(data).subscribe({
            next: (res: any) => {
                const asnLines = res.Response.AsnLines || [];

                if (type === 'Excel') {
                    this.excelDownloadService.downloadExcelFile(
                        this.exportFileName,
                        [],
                        asnLines,
                    );
                } else {
                    downloadCSVFile(asnLines, this.exportFileName);
                }
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    export(type: string) {
        const event = this.loadEvent();
        this.getAsnForExcel(
            {
                ...event,
                first: 0,
                rows: this.totalRecords(),
            },
            type,
        );
    }

    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedAsns().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedAsns().length > 0 ? true : false,
    );

    async OpenImage(asn: any) {
        const image = await lastValueFrom(asn.FILEDATA.pipe(take(1)));
        this.ref = this.dialogService.open(ViewImageDialogComponent, {
            inputValues: {
                image: image,
                fileName: asn?.ATTACHMENTFILENAME,
            },
            header: 'Attachment',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '55rem',
            style: { height: '45rem' },
        });
        this.ref.onClose.subscribe(() => {});
    }
    onClickReceiptKey(row: Asn): void {
        const route = inboundRoutes.find(
            (route) => route.data?.name === 'asnline',
        ) as Route;
        var params = [
            { name: 'receiptKey', value: row.RECEIPTKEY },
            { name: 'storerKey', value: row.TRADERKEY },
        ];
        this.tabService.addTabWithParams(
            route,
            '',
            'Receipt Details - ' + row.RECEIPTKEY,
            params,
        );
    }

    exportExcelTemplate() {
        const Column = [
            'Owner',
            'ExternalRef',
            'Type',
            'ExpectedReceiptDate',
            'ShipFrom',
            'CarrierKey',
            'Sku',
            'PoDate',
            'PoQuantity',
            'PoKey',
            'PoLineNo',
            'AltSku',
            'Quantity',
            'Lpn',
            'PackKey',
            'Uom',
            'ToLoc',
            'Price',
            'Lottable01',
            'Lottable02',
            'Lottable03',
            'ManufactureDate',
            'ExpirationDate',
            'Lottable06',
            'Lottable07',
            'Lottable08',
            'Lottable09',
            'Lottable10',
            'Remarks',
        ];
        this.excelDownloadService.downloadExcelFile(
            'ASN-Template',
            Column,
            null,
        );
    }

    OpenCreateASNForm() {
        const headerText = this.translate.instant('Create ASN');
        this.ref = this.dialogService.open(AsnFormComponent, {
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });

        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('ASNCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        const ignoredFields = Object.values(AsnColumns)
                            .filter((col: any) => col.ignoreInRequest)
                            .map((col: any) => col.field);

                        const copy = { ...data };
                        ignoredFields.forEach((field) => {
                            delete copy[field];
                        });
                        const updatedData: Asn = {
                            ...copy,
                            ExternalReceiptKey: data.EXTERNRECEIPTKEY,
                        };
                        const L = lowercasecolumn(updatedData);

                        this.loading.set(true);

                        this.asnsService
                            .createAsns(L)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getAsns();
                                }),
                            )
                            .subscribe({
                                next: (response: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Receipt creation',
                                        detail:
                                            response?.Response?.Message ||
                                            'Receipt created successfully.',
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New Receipt creation',
                                            detail:
                                                (error.error
                                                    .message as string) ||
                                                (error.error
                                                    .Message as string) ||
                                                'Error occurred while creating Receipt.',
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateASNForm(asnData: any) {
        const selectedAsn: Asn = Array.isArray(asnData) ? asnData[0] : asnData;

        this.ref = this.dialogService.open(AsnFormComponent, {
            inputValues: {
                asnData: selectedAsn,
            },

            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });

        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('ASNUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        const updatedData: Asn = {
                            ...asnData,
                            ...data,
                            ExternalReceiptKey: data.EXTERNRECEIPTKEY,
                        };
                        const L = lowercasecolumn(updatedData);
                        this.loading.set(true);
                        this.asnsService
                            .updateAsns(L)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    // this.getAsns();
                                }),
                            )
                            .subscribe({
                                next: (response: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Receipt Update',
                                        detail: response.Response as string,
                                    });
                                    this.getAsns();
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Receipt Update',
                                            detail: error?.error
                                                ?.Message as string,
                                        });
                                    }
                                    this.loading.set(true);
                                },
                            });
                    }
                });
            }
        });
    }

    CancelAsnConfirmation() {
        const headertext = this.translate.instant('Cancel ASN');
        const value = this.translate.instant('ASNCancel', {
            no: this.selectedAsns().length,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                // duplicate: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                const validAsns = this.selectedAsns().filter(
                    (x: any) => x.STATUS_DESC === 'New',
                );

                this.loading.set(true);

                if (validAsns.length === 0) {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Cancel ASN',
                        detail: 'Only Receipt with "New" status can be cancelled.',
                    });
                    this.loading.set(false);
                    return;
                }

                const requestBody = {
                    ReceiptKey: validAsns.map((x: any) => x.RECEIPTKEY),
                };

                const subscription = this.asnsService
                    .cancelAsn(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedAsns.set([]);
                            this.getAsns();
                        }),
                    )
                    .subscribe({
                        next: () => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Cancel Receipt',
                                detail: 'Receipt cancelled successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    error?.error?.Message ||
                                    'Failed to cancel Receipt.';

                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Cancel Receipt',
                                    detail: errorMessage,
                                });
                            }
                            this.loading.set(false);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    reopenASN() {
        const validAsns = this.selectedAsns().filter(
            (x: any) => x.STATUS_DESC === 'Closed',
        );
        this.loading.set(true);

        if (validAsns.length === 0) {
            this.messageService.add({
                severity: 'error',
                summary: 'Reopen Receipt',
                detail: 'Only Receipt with "Closed" status can be reopened.',
            });
            this.loading.set(false);
            return;
        }

        const requestBody = {
            ReceiptKey: validAsns.map((x: any) => x.RECEIPTKEY),
        };

        const subscription = this.asnsService
            .reopenAsn(requestBody)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                    this.selectedAsns.set([]);
                    this.getAsns();
                }),
            )
            .subscribe({
                next: () => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Reopen Receipt',
                        detail: 'Receipt reopened successfully.',
                    });
                },
                error: (error) => {
                    if (
                        error.error.Message ===
                            'One or more errors occurred!' ||
                        error.error.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: error,
                                },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                    } else {
                        const errorMessage =
                            error?.error?.message ||
                            error?.error?.Message ||
                            'Failed to reopen Receipt.';

                        this.messageService.add({
                            severity: 'error',
                            summary: 'Reopen Receipt',
                            detail: errorMessage,
                        });
                    }

                    this.loading.set(false);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    onFileSelect(event: any) {
        const file = event.files[0];
        this.loading.set(true);
        const reader = new FileReader();
        reader.onload = async (e: any) => {
            const workbook = XLSX.read(e.target.result, { type: 'binary' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            this.excelData = XLSX.utils.sheet_to_json(worksheet, { raw: true });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const sheetData: any[][] = XLSX.utils.sheet_to_json(sheet, {
                header: 1,
            });
            if (this.excelData.length > 0) {
                const dataRows = sheetData.slice(1);
                const FinalData = dataRows.map(
                    (row: any[], rowIndex: number) => {
                        return {
                            STORERKEY: row[0] ? row[0].toString() : null,
                            ExternalReceiptKey: row[1]
                                ? row[1].toString()
                                : null,
                            ReceiptDate:
                                row[2] !== undefined &&
                                row[2] !== null &&
                                row[2] !== ''
                                    ? convertExcelDate(row[2])
                                    : new Date(),
                            Type: '1',
                            SupplierCode: row[3] ? row[3].toString() : null,
                            CarrierCode: row[4] ? row[4].toString() : null,
                            Sku: row[5] ? row[5].toString() : null,
                            PoDate: row[6] ? convertExcelDate(row[6]) : null,
                            PoQuantity: row[7],
                            PoKey: row[8],
                            PoLineNumber: row[9],
                            AltSku: row[10] ? row[10].toString() : null,
                            Quantity: row[11],
                            ToId: row[12],
                            PackKey: row[13] ? row[13].toString() : null,
                            Uom: row[14],
                            ToLoc: row[15] ? row[15].toString() : null,
                            PriceEach: row[16],
                            Lottable01: row[17],
                            Lottable02: row[18],
                            Lottable03: row[19],
                            Lottable04: row[20]
                                ? convertExcelDate(row[20])
                                : null,
                            Lottable05: row[21]
                                ? convertExcelDate(row[21])
                                : null,
                            Lottable06: row[22],
                            Lottable07: row[23],
                            Lottable08: row[24],
                            Lottable09: row[25],
                            Lottable10: row[26],
                            Status: '0',
                            Remarks: row[27],
                        };
                    },
                );

                this.asnsService
                    .createASN(FinalData)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.getAsns();
                        }),
                    )
                    .subscribe({
                        next: (res: any) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Receipt upload',
                                detail: res.Response,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Receipt',
                                    detail: error?.error?.Message as string,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            } else {
                this.loading.set(false);
                this.messageService.add({
                    severity: 'warn',
                    summary: 'Receipt Upload',
                    detail: 'The file contains no data rows. Please add data below the header row and try again.',
                });
            }
        };
        reader.readAsArrayBuffer(file);
    }

    CloseAsnConfirmation() {
        const headertext = this.translate.instant('Close Receipt');
        const value = this.translate.instant('ASNClose', {
            no: this.selectedAsns().length,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                // duplicate: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                const validAsns = this.selectedAsns().filter(
                    (x: any) => x.STATUS_DESC === 'Received',
                );
                this.loading.set(true);

                if (validAsns.length === 0) {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Close Receipt',
                        detail: 'Only Receipt with "Received" status can be closed.',
                    });
                    this.loading.set(false);
                    return;
                }

                const requestBody = {
                    ReceiptKey: validAsns.map((x: any) => x.RECEIPTKEY),
                };

                const subscription = this.asnsService
                    .closeAsn(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedAsns.set([]);
                            this.getAsns();
                        }),
                    )
                    .subscribe({
                        next: () => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Close Receipt',
                                detail: 'Receipt closed successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    error?.error?.Message ||
                                    'Failed to close Receipt.';

                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Close Receipt',
                                    detail: errorMessage,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    DeleteConfirmation() {
        const headertext = this.translate.instant('Confirm Deletion');
        const count = this.selectedAsns().length;
        const name =
            count > 1
                ? this.translate.instant('ASNs')
                : this.translate.instant('ASN');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                // duplicate: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const Rdata = this.selectedAsns().map((x: any) => x.RECEIPTKEY);
                this.loading.set(true);
                const requestBody = {
                    RECEIPTKEY: Rdata,
                };

                const subscription = this.asnsService
                    .deleteAsn(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedAsns.set([]);
                            this.getAsns();
                        }),
                    )
                    .subscribe({
                        next: () => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Delete Receipt',
                                detail: 'Receipt deleted successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    error?.error?.Message ||
                                    'Failed to delete Receipt.';

                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Delete Receipt',
                                    detail: errorMessage,
                                });
                            }
                            this.loading.set(true);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }
}
