export interface Putaway {
    ReceiptKey: string;
    ReceiptLineNumber: string;
    QtyReceived: string;
    QtyPutaway: string;
    QtyExpected: string;
    Qty_To_Be_Putaway: string;
    Suggested_Location: string;
    PutawayLoc: string;
    Warning: string;
}
