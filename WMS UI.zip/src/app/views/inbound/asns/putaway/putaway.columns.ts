import { Validators } from '@angular/forms';
import { Columns } from '../../../../common/models';

export const PutawayColumns: Columns = {
    rowId: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
    },
    RECEIPTKEY: {
        label: 'Receipt Key',
        field: 'RECEIPTKEY',
        restrictInsert: true,
        restrictEdit: true,
        // tableHidden: true,
    },
    RECEIPTLINENUMBER: {
        label: 'Line No',
        field: 'RECEIPTLINENUMBER',
        restrictInsert: true,
        restrictEdit: true,
    },
    PUTAWAYLOC: {
        label: 'Putaway Location',
        field: 'PUTAWAYLOC',
        validators: [Validators.maxLength(200)],
    },
    QTYPUTAWAY: {
        label: 'Qty to Putaway',
        field: 'QTYPUTAWAY',
        validators: [Validators.required, Validators.maxLength(50)],
        defaultValue: '0',
    },
    SUGGESTED_LOCATION: {
        label: 'Suggested Location',
        field: 'SUGGESTED_LOCATION',
        type: 'text',
    },
    SKU: {
        label: 'SKU',
        field: 'SKU',
    },
    PACKKEY: {
        label: 'Pack key',
        field: 'PACKKEY',
    },

    QTYRECEIVED: {
        label: 'Quantity Received',
        field: 'QTYRECEIVED',
        type: 'text',
        validators: [Validators.maxLength(50)],
        restrictEdit: true,
    },

    QTYEXPECTED: {
        label: 'Expected Quantity',
        field: 'QTYEXPECTED',
        validators: [Validators.required, Validators.maxLength(50)],
        defaultValue: '0',
    },
    QTY_TO_BE_PUTAWAY: {
        label: 'Qty to be Putaway',
        field: 'QTY_TO_BE_PUTAWAY',
        validators: [Validators.required, Validators.maxLength(50)],
        defaultValue: '0',
    },
    WARNING: {
        label: 'Warning',
        field: 'WARNING',
        type: 'select',
    },
};
