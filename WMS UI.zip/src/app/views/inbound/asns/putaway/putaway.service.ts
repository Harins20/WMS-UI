import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Putaway } from './putaway.model';
import { AppConfigService } from '../../../../../app.config.service';
import { ResponseDto } from '../../../../common/models';
import { AuthService } from '../../../../common/services';
import { map } from 'rxjs';
import { PutawayColumns } from './putaway.columns';
import { stringToDate } from '../../../../common/functions';

@Injectable({
    providedIn: 'root',
})
export class PutawayService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getPutaway(event: any, receiptKey: any) {
        return this.httpClient
            .post<
                ResponseDto<Putaway[]>
            >(this.config.appConfig()?.InbUrl + `Putaway/Generate/${receiptKey}`, event, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((response: any) => {
                    response?.Response?.Putaway.forEach((asn: any) => {
                        Object.keys(asn).forEach((key) => {
                            if (PutawayColumns[key]?.type === 'date') {
                                asn[key] = stringToDate(asn[key]);
                            }
                        });
                    });
                    return response;
                }),
            );
    }

    finalizePutaway(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Putaway/Finalize',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
