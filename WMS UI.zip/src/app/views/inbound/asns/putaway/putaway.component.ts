import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize, lastValueFrom } from 'rxjs';
import { PutawayColumns } from './putaway.columns';
import { Putaway } from './putaway.model';
import { PutawayService } from './putaway.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    CustomTableComponent,
    LoadingComponent,
} from '../../../../common/components';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Select } from 'primeng/select';
import { selectOption } from '../../../../common/models';
import {
    ExcelDownloadService,
    OptionsService,
} from '../../../../common/services';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';
import { InputTextComponent } from '../../../../common/components/input-text/input-text.component';
import { CustomTablePaginationComponent } from '../../../../common/components/custom-table-pagination/custom-table-pagination.component';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-putawaylines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        TooltipModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTablePaginationComponent,
        Select,
    ],
    templateUrl: './putaway.component.html',
    styleUrl: './putaway.component.scss',
    providers: [DialogService],
})
export class PutawayLineComponent {
    private ref = inject(DynamicDialogRef);
    receiptKey = input.required<string>();
    storerKey = input.required<string>();
    putawaylines = signal<Putaway[]>([]);
    selectedPutaway = signal<any>([]);
    loading = signal(false);
    customQtyCellTemplate =
        viewChild.required<TemplateRef<any>>('customQtyCell');
    customLocCellTemplate =
        viewChild.required<TemplateRef<any>>('customLocCell');
    customQtyOutputCellTemplate = viewChild.required<TemplateRef<any>>(
        'customQtyOutputCell',
    );
    customLocOutputCellTemplate = viewChild.required<TemplateRef<any>>(
        'customLocOutputCell',
    );
    columns = computed(() => {
        const QtyTpl = this.customQtyCellTemplate();
        const QtyOutTpl = this.customQtyOutputCellTemplate();

        const LocTpl = this.customLocCellTemplate();
        const LocOutTpl = this.customLocOutputCellTemplate();

        return Object.values(PutawayColumns)
            .filter((column) => !column.tableHidden)
            .map((col) => {
                if (col.field === 'QTYPUTAWAY') {
                    return {
                        ...col,
                        editable: true,
                        customCellTemplate: QtyTpl,
                        customOutputTemplate: QtyOutTpl,
                    };
                }
                if (col.field === 'PUTAWAYLOC') {
                    return {
                        ...col,
                        editable: true,
                        customCellTemplate: LocTpl,
                        customOutputTemplate: LocOutTpl,
                    };
                }

                return col;
            });
    });

    selectedColumns = linkedSignal(() => this.columns());

    loadEvent = signal<any>({});
    totalRecords = signal(15);

    putaway = signal<any[]>([]);
    private messageService = inject(MessageService);
    private putawayService = inject(PutawayService);
    private translate = inject(TranslateService);
    ConfirmationRef: DynamicDialogRef | undefined;
    private destroyRef = inject(DestroyRef);
    private optionService = inject(OptionsService);
    locationOptions = signal<selectOption[]>([]);

    private dialogService = inject(DialogService);
    private excelDownloadService = inject(ExcelDownloadService);
    exportFileName = 'Asn-list';
    ngOnInit() {
        this.GetLocationOptions();
    }

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedPutaway().length > 0 ? true : false,
    );
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getPutaway(event);
    }
    getPutaway(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.putaway.set([]);
        const subscription = this.putawayService
            .getPutaway(data, this.receiptKey())
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    const data = res.Response?.Putaway;
                    this.totalRecords.set(res.Response?.totalRecords);
                    this.putaway.set(
                        data?.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                            BALANCEQTY: x.QTYRECEIVED - x.QTYPUTAWAY,
                            PUTAWAYQTY: x.QTYRECEIVED - x.QTYPUTAWAY,
                            PUTAWAYLOC: null,
                            QTYPUTAWAY: x.QTY_TO_BE_PUTAWAY,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Putaway list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    } else if (
                        error.error.Message ===
                            'One or more errors occurred!' ||
                        error.error.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: error,
                                },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                    } else {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Putaway list',
                            detail:
                                (error.error.message as string) ||
                                (error.error.Message as string),
                        });
                    }
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getputawayForExcel(data: any = this.loadEvent(), type: string) {
        const subscription = this.putawayService
            .getPutaway(data, this.receiptKey())
            .subscribe({
                next: (res: any) => {
                    const asnLines = res.Response.AsnLines || [];

                    if (type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            asnLines,
                        );
                    } else {
                        downloadCSVFile(asnLines, this.exportFileName);
                    }
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    export(type: string) {
        const event = this.loadEvent();
        this.getputawayForExcel(
            {
                ...event,
                first: 0,
                rows: this.totalRecords(),
            },
            type,
        );
    }

    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }
    FinalizePutaway() {
        if (this.selectedPutaway().length === 0) {
            return;
        }

        if (
            this.selectedPutaway().some(
                (item: any) =>
                    (!item.SUGGESTED_LOCATION && !item.PUTAWAYLOC) ||
                    item.QTYPUTAWAY === null ||
                    item.QTYPUTAWAY === undefined ||
                    item.QTYPUTAWAY === 0,
            )
        ) {
            this.messageService.add({
                severity: 'warn',
                summary: this.translate.instant('Putaway Location'),
                detail: this.translate.instant('PutawayError'),
            });
            return;
        }

        const headertext = this.translate.instant('Confirm Putaway');
        const value = this.translate.instant('PutawayConfirmation', {
            no: this.selectedPutaway().length,
        });

        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                this.loading.set(true);
                const requestBody = this.selectedPutaway().map((item: any) => ({
                    RECEIPTKEY: item.RECEIPTKEY,
                    RECEIPTLINENUMBER: item.RECEIPTLINENUMBER,
                    Suggested_Loc:
                        item.PUTAWAYLOC === null
                            ? item.SUGGESTED_LOCATION
                            : item.PUTAWAYLOC,
                    TIMESTAMP: new Date().toISOString(),
                    Putaway_Qty: item.QTYPUTAWAY,
                }));
                this.putawayService
                    .finalizePutaway(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedPutaway.set([]);
                            this.getPutaway(this.loadEvent());
                        }),
                    )
                    .subscribe({
                        next: (response: any) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Putaway',
                                detail: response.Response as string,
                            });
                            this.ref.close();
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Putaway',
                                    detail: error.error.message as string,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            }
        });
    }

    GetLocationOptions() {
        const subscription = this.optionService.getLocationOptions().subscribe({
            next: (data) => {
                this.locationOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching Location dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
}
