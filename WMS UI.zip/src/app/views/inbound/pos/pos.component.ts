import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { ConfirmationDialogComponent } from '../../../common/components';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { POColumns } from './po.columns';
import { PO } from './po.model';
import { POService } from './po.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ColumnPicklistComponent } from '../../../common/components';
import { Route, Router } from '@angular/router';
import { PoFormComponent } from './po-form/po-form.component';
import inboundRoutes from '../inbound.routes';
import { TabService } from '../../../tabs/tab.service';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { tableOptions } from '../../../common/constants';
import { LoadingComponent } from '../../../common/components/common-loading/loading.component';
import { TagModule } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';

import { copyToClipboardText } from '../../../common/functions/clickToCopy';
import { POLineService } from './po-lines/po-line.service';
import { POLines } from './po-lines';
import { OptionsService } from '../../../common/services/options.service';
import { filterQuery } from '../../../common/functions';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import {
    lowercasecolumn,
    uppercasecolumn,
} from '../../../common/functions/Uppercase';

@Component({
    selector: 'app-poss',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        LoadingComponent,
        TagModule,
        TooltipModule,
        AppTranslatePipe,
        CustomTablePaginationComponent,
    ],
    templateUrl: './pos.component.html',
    styleUrl: './pos.component.scss',
    providers: [DialogService],
})
export class PosComponent {
    hoveredRow: string | null = null;
    pos = signal<PO[]>([]);
    poExcel = signal<PO[]>([]);
    selectedPOs = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    private translate = inject(TranslateService);
    columns = signal<any>([]);
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(15);
    globalFilterColumns = computed(() =>
        this.columns().map((x: any) => x.field),
    );
    tableOptions = signal(tableOptions);
    selectedColumns = linkedSignal(() => this.columns());
    exportFileName = 'PO-list';
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    ref: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private poService = inject(POService);
    private destroyRef = inject(DestroyRef);
    private tabService = inject(TabService);
    private dialogService = inject(DialogService);
    private excelDownloadService = inject(ExcelDownloadService);
    private optionService = inject(OptionsService);
    ConfirmationRef: DynamicDialogRef | undefined;
    private router = inject(Router);
    selectedPOLines = signal<any>([]);
    private polinesService = inject(POLineService);
    polines = signal<POLines[]>([]);
    poKey = computed(() =>
        this.selectedPOs().length > 0 ? this.selectedPOs()[0].POKEY : '',
    );
    OrginalColumns = signal<any>(POColumns);
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    FilteredRequests = signal<any[]>([]);
    constructor() {}
    ngOnInit() {
        // this.getPOPage();
        this.getColumns();
    }
    loadData(event: TableLazyLoadEvent) {
        // console.log(event);

        this.loadEvent.set(event);

        this.getPOPage(event);
    }
    getColumns() {
        this.optionService.getColumns(POColumns, 'PO').subscribe({
            next: (data) => {
                const FilterField = data.map((x: any) => x.field);

                const GetFilterFields = Object.values(POColumns).filter(
                    (x: any) => {
                        return !FilterField.includes(x.field);
                    },
                );

                const allowedFields = [
                    'UDFSTR1',
                    'UDFSTR2',
                    'UDFSTR3',
                    'UDFSTR4',
                    'UDFSTR5',
                ];

                const limitedColumns = data.filter(
                    (x: any) =>
                        !x.field?.startsWith('UDF') ||
                        allowedFields.includes(x.field),
                );

                const columns = [...GetFilterFields, ...limitedColumns];

                let updatedColumns = columns;

                updatedColumns = updatedColumns.map((column: any) => {
                    if (column.field === 'STATUSDESC') {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                });
                this.columns.set(
                    updatedColumns.filter((column: any) => !column.tableHidden),
                );
            },
        });
    }
    // getPOs() {
    //     this.loading.set(true);
    //     this.pos.set([]);
    //     const subscription = this.poService
    //         .getPO()
    //         .pipe(
    //             finalize(() => {
    //                 this.loading.set(false);
    //             }),
    //         )
    //         .subscribe({
    //             next: (res) => {
    //                 this.pos.set(
    //                     res.Response.map((x: any, idx: number) => ({
    //                         ...x,
    //                         rowId: idx + 1,
    //                         PODATE: x.PODATE ? new Date(x.PODATE) : null,
    //                     })),
    //                 );
    //             },
    //             error: (error: HttpErrorResponse) => {
    //                 if (error.status === 0)
    //                     this.messageService.add({
    //                         severity: 'error',
    //                         summary: 'PO list',
    //                         detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
    //                     });
    //             },
    //         });

    //     this.destroyRef.onDestroy(() => subscription.unsubscribe());
    // }
    getPOPage(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.pos.set([]);
        const subscription = this.poService
            .getPOPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    const U = uppercasecolumn(res?.Response.PurchaseOrders);
                    let idBase = data.first || 0;

                    this.pos.set(
                        U.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idBase + (idx + 1),
                        })),
                    );
                    this.totalRecords.set(res.Response.TotalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'PO list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    } else if (
                        error.error.Message ===
                            'One or more errors occurred!' ||
                        error.error.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: error,
                                },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                    } else {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'PO list',
                            detail:
                                error.error.message ||
                                (error.error.Message as string),
                        });
                    }
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getPOPage();
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getPOPage();
    }
    getPOForExcel(data: any = this.loadEvent(), type: string) {
        const subscription = this.poService.getPOPage(data).subscribe({
            next: (res: any) => {
                const purchaseOrders = res?.Response?.PurchaseOrders || [];

                this.poExcel.set(purchaseOrders);

                if (type === 'Excel') {
                    this.excelDownloadService.downloadExcelFile(
                        this.exportFileName,
                        [],
                        purchaseOrders,
                    );
                } else {
                    downloadCSVFile(purchaseOrders, this.exportFileName);
                }
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    export(type: string) {
        const event = this.loadEvent();

        this.getPOForExcel(
            {
                ...event,
                first: 0,
                rows: this.totalRecords(),
            },
            type,
        );
    }
    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(this.pos().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedPOs().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedPOs().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.ref = this.dialogService.open(ColumnPicklistComponent, {
            inputValues: {
                selectedColumns: this.selectedColumns(),
                unSelectedColumns: this.unSelectedColumns(),
            },
            header: headertext,
            closable: true,
            modal: true,
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {});
    }

    copyToClipboard(text: string) {
        copyToClipboardText(text, this.messageService);
    }

    OpenCreatePOForm() {
        const headertext = this.translate.instant('Create PO');
        this.ref = this.dialogService.open(PoFormComponent, {
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('POCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        const ignoredFields = Object.values(POColumns)
                            .filter((col: any) => col.ignoreInRequest)
                            .map((col: any) => col.field);

                        const copy = { ...data };
                        ignoredFields.forEach((field) => {
                            delete copy[field];
                        });
                        const externPoKey =
                            data.EXTERNPOKEY ||
                            data.ExternalPoKey ||
                            data.ExternPoKey ||
                            data.externpokey ||
                            data.externalpokey ||
                            '';
                        const sellerName =
                            data.SELLERNAME ||
                            data.SellerName ||
                            data.sellername ||
                            data.SELLERCODE ||
                            '';
                        const updatedData = {
                            ...copy,
                            ExternalPoKey: externPoKey,
                            ExternPoKey: externPoKey,
                            SellerName: sellerName,
                        };
                        const L = lowercasecolumn(updatedData);
                        this.loading.set(true);
                        this.poService
                            .createPO(L)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getPOPage();
                                }),
                            )
                            .subscribe({
                                next: (resData: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New PO creation',
                                        detail: resData?.Response?.Message as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New PO creation',
                                            detail: error?.error?.message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdatePOForm(poData: any) {
        const headertext = this.translate.instant('Update PO');

        this.ref = this.dialogService.open(PoFormComponent, {
            inputValues: {
                poData: poData,
            },
            // header: 'Update Receipt - ' + selectedAsn.RECEIPTKEY,
            // closable: true,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });

        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('POUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        const selectedPo = Array.isArray(poData) ? poData[0] : poData;
                        const ignoredFields = Object.values(POColumns)
                            .filter((col: any) => col.ignoreInRequest)
                            .map((col: any) => col.field);

                        const copy = { ...data };
                        ignoredFields.forEach((field) => {
                            delete copy[field];
                        });
                        const externPoKey =
                            data.EXTERNPOKEY ||
                            data.ExternalPoKey ||
                            data.ExternPoKey ||
                            data.externpokey ||
                            data.externalpokey ||
                            selectedPo?.EXTERNPOKEY ||
                            selectedPo?.EXTERNALPOKEY ||
                            selectedPo?.ExternalPoKey ||
                            selectedPo?.ExternPoKey ||
                            '';
                        const sellerName =
                            data.SELLERNAME ||
                            data.SellerName ||
                            data.sellername ||
                            selectedPo?.SELLERNAME ||
                            selectedPo?.SellerName ||
                            selectedPo?.SELLERCODE ||
                            '';
                        const updatedData = {
                            ...selectedPo,
                            ...copy,
                            ExternalPoKey: externPoKey,
                            ExternPoKey: externPoKey,
                            SellerName: sellerName,
                        };
                        const L = lowercasecolumn(updatedData);
                        this.loading.set(true);
                        this.poService
                            .updatePO(L)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getPOPage();
                                }),
                            )
                            .subscribe({
                                next: (resData: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'PO Update',
                                        detail: resData.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'PO Update',
                                            detail: error?.error?.message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    getPOLines() {
        this.loading.set(true);
        this.polines.set([]);
        const subscription = this.polinesService
            .getPOLines(this.poKey())
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res) => {
                    const U: any = uppercasecolumn(res.Response);
                    this.polines.set(
                        U.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'PO Lines list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    OnClickCreateASN() {
        const poKey = this.poKey();
        if (!poKey) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Create ASN',
                detail: 'Please select at least one PO.',
            });
            return;
        }

        const headertext = this.translate.instant('Create Receipt');
        const value = this.translate.instant('CreateReceiptFromPO', {
            no: this.selectedPOs().length,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                const Rdata = this.selectedPOs().map((x: any) => x.SERIALKEY);
                this.loading.set(true);

                const requestBody = {
                    POKEY: poKey,
                    SERIALKEY: Rdata,
                };

                const subscription = this.polinesService
                    .createASNHeader(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedPOs.set([]);
                            this.getPOPage();
                        }),
                    )
                    .subscribe({
                        next: () => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Create ASN',
                                detail: 'ASN created successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message === 'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: { error },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Create ASN',
                                    detail:
                                        error?.error?.message || 'Failed to create ASN',
                                });
                            }
                            this.loading.set(false);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    DeletePO() {
        const headertext = this.translate.instant('Confirm Deletion');
        const count = this.selectedPOs().length;
        const name =
            count > 1
                ? this.translate.instant('POs')
                : this.translate.instant('PO');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                // duplicate: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const Rdata = this.selectedPOs().map((x: any) => {
                    return x.POKEY;
                });
                this.loading.set(true);
                const subscription = this.poService
                    .deletePO(Rdata)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedPOs.set([]);
                            this.getPOPage();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Delete PO',
                                detail: 'PO deleted successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Delete PO',
                                    detail:
                                        error.error.message ||
                                        'Failed to delete PO.',
                                });
                            }
                            this.loading.set(false);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }
    onClickPOKey(event: any): void {
        // event.preventDefault();
        const route = inboundRoutes.find(
            (route) => route.data?.name === 'poline',
        ) as Route;

        const params = [
            { name: 'poKey', value: event.POKEY },
            { name: 'storerKey', value: event.TRADERKEY },
        ];

        this.tabService.addTabWithParams(
            route,
            '',
            'PO Details - ' + event.POKEY,
            params,
        );
    }

    onEditAction(po: PO) {}

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
    onFilter(event: any) {
        console.log(event);

        this.FilteredRequests.set(event);
    }
}
