import { Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';
import {
    Component,
    DestroyRef,
    inject,
    signal,
    computed,
    input,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { IftaLabelModule } from 'primeng/iftalabel';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { POColumns } from '../po.columns';
import {
    AuthService,
    OptionsService,
    safeAtob,
} from '../../../../common/services';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { DatePickerModule } from 'primeng/datepicker';
import { selectOption } from '../../../../common/models';
import { InputSelectComponent } from '../../../../common/components/input-select/input-select.component';
import { InputTextComponent } from '../../../../common/components/input-text/input-text.component';
import { InputDatepickerComponent } from '../../../../common/components/input-datepicker/input-datepicker.component';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';

@Component({
    selector: 'po-po-form',
    imports: [
        ReactiveFormsModule,
        CommonModule,
        IftaLabelModule,
        InputTextModule,
        PasswordModule,
        ButtonModule,
        DatePickerModule,
        InputSelectComponent,
        InputTextComponent,
        InputDatepickerComponent,
        AppTranslatePipe,
        CommonModule,
    ],
    templateUrl: './po-form.component.html',
    styleUrls: ['./po-form.component.scss'],
})
export class PoFormComponent {
    poData = input<any>();
    private destroyRef = inject(DestroyRef);
    private ref = inject(DynamicDialogRef);
    private optionService = inject(OptionsService);
    private authService = inject(AuthService);
    minDate = signal<Date>(new Date());

    poColumns: any[] = [];
    loading = signal(false);
    formControlsArray = signal(
        Object.values(POColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );

    // ✅ Single signal for tab validation warning
    setViewTAb = signal<boolean>(true);
    // ✅ Single signal for active tab
    activeTab = signal<number>(0);
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    poform = new FormGroup(this.formControls());
    ownerOptions = signal<selectOption[]>([]);
    carrierOptions = signal<selectOption[]>([]);
    shipfromOptions = signal<selectOption[]>([]);
    ngOnInit() {
        if (this.poData()) {
            const rawPoData = Array.isArray(this.poData())
                ? this.poData()[0]
                : this.poData();
            const externPoKey =
                rawPoData?.EXTERNALPOKEY ??
                rawPoData?.externalpokey ??
                rawPoData?.EXTERNPOKEY ??
                rawPoData?.externpokey ??
                rawPoData?.EXTERNALPOKEY ??
                '';
            const sellerName =
                rawPoData?.SELLERNAME ||
                rawPoData?.SellerName ||
                rawPoData?.sellername ||
                '';
            const carrierName =
                rawPoData?.CARRIERNAME ||
                rawPoData?.CarrierName ||
                rawPoData?.carriername ||
                '';
            this.poform.patchValue({
                ...rawPoData,
                EXTERNALPOKEY: externPoKey,
                SELLERNAME: sellerName,
                CARRIERNAME: carrierName,
                LASTGRNDATE: rawPoData?.LASTGRNDATE
                    ? new Date(rawPoData.LASTGRNDATE)
                    : null,
                PODATE: rawPoData?.PODATE ? new Date(rawPoData.PODATE) : null,
            });
            Object.values(POColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.poform.controls[column.field].disable();
            });
        } else {
            Object.values(POColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.poform.controls[column.field].disable();
            });
            this.poform.patchValue({
                TRADERKEY: safeAtob(sessionStorage.getItem('TraderKey')),
            });
        }
        this.GetOwnerOptions();
        this.GetShipFromOptions();
        this.handleShipFromSelection();
        this.GetCarrierOptions();
        this.handleCarrierSelcetion();
        this.getColumns();
    }
    hasError(formControlName: string) {
        const formControl = this.poform.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    // ✅ Navigate to tab
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    closePanel() {
        this.ref.close();
    }
    getErrors(formControlName: string, title?: string) {
        const formControl = this.poform.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }

    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetCarrierOptions() {
        const subscription = this.optionService.getCarrierOptions().subscribe({
            next: (data) => {
                this.carrierOptions.set(data);
                const carrierKey = this.poform.get('CARRIERKEY')?.value;
                if (carrierKey && !this.poform.get('CARRIERNAME')?.value) {
                    const carrier: any = data.find(
                        (c: any) => c.value === carrierKey,
                    );
                    if (carrier) {
                        this.poform.patchValue({
                            CARRIERNAME:
                                carrier.Company ||
                                carrier.label ||
                                carrier.value ||
                                carrierKey,
                        });
                    }
                }
            },
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetShipFromOptions() {
        const subscription = this.optionService.getShipFromOptions().subscribe({
            next: (data) => {
                this.shipfromOptions.set(data);
                const sellerCode = this.poform.get('SELLERCODE')?.value;
                if (sellerCode && !this.poform.get('SELLERNAME')?.value) {
                    const trader: any = data.find(
                        (t: any) => t.value === sellerCode,
                    );
                    if (trader) {
                        this.poform.patchValue({
                            SELLERNAME:
                                trader.Company ||
                                trader.label ||
                                trader.value ||
                                sellerCode,
                        });
                    }
                }
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    handleShipFromSelection() {
        this.poform
            .get('SELLERCODE')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedTrader: any = this.shipfromOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (selectedTrader) {
                    this.poform.patchValue({
                        SELLERNAME:
                            selectedTrader.Company ||
                            selectedTrader.label ||
                            selectedTrader.value ||
                            selectedValue,
                    });
                } else {
                    this.poform.patchValue({
                        SELLERNAME: selectedValue,
                    });
                }
            });
    }
    handleCarrierSelcetion() {
        this.poform
            .get('CARRIERKEY')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedCarrier: any = this.carrierOptions().find(
                    (carrier) => carrier.value === selectedValue,
                );

                if (selectedCarrier) {
                    this.poform.patchValue({
                        CARRIERNAME:
                            selectedCarrier.Company ||
                            selectedCarrier.label ||
                            selectedCarrier.value ||
                            selectedValue,
                    });
                } else {
                    this.poform.patchValue({
                        CARRIERNAME: selectedValue,
                    });
                }
            });
    }
    onSubmit() {
        if (this.poform.valid) {
            this.setViewTAb.set(true);
            const poDate = this.poform.value.PODATE;

            const poformattedPoDate = poDate
                ? `${poDate.getFullYear()}-${String(poDate.getMonth() + 1).padStart(2, '0')}-${String(poDate.getDate()).padStart(2, '0')}`
                : null;

            const sellerCode = this.poform.get('SELLERCODE')?.value;
            let sellerName = this.poform.get('SELLERNAME')?.value;
            if (!sellerName && sellerCode) {
                const trader: any = this.shipfromOptions().find(
                    (t: any) => t.value === sellerCode,
                );
                sellerName =
                    trader?.Company ||
                    trader?.label ||
                    trader?.value ||
                    sellerCode;
                this.poform.patchValue({ SELLERNAME: sellerName });
            }

            const carrierKey = this.poform.get('CARRIERKEY')?.value;
            let carrierName = this.poform.get('CARRIERNAME')?.value;
            if (!carrierName && carrierKey) {
                const carrier: any = this.carrierOptions().find(
                    (c: any) => c.value === carrierKey,
                );
                carrierName =
                    carrier?.Company ||
                    carrier?.label ||
                    carrier?.value ||
                    carrierKey;
                this.poform.patchValue({ CARRIERNAME: carrierName });
            }

            const payload = {
                ...this.poform.getRawValue(),
                externalpokey: this.poform.getRawValue().EXTERNALPOKEY,
                SELLERNAME: sellerName || this.poform.getRawValue().SELLERNAME,
                CARRIERNAME:
                    carrierName || this.poform.getRawValue().CARRIERNAME,
                // PODATE: poformattedPoDate,
            };
            this.ref.close(payload);
            this.poform.reset();
        } else {
            this.setViewTAb.set(false);
            this.poform.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.poform.controls));
        }
    }

    getColumns() {
        this.optionService.getColumns(POColumns, 'PO').subscribe({
            next: (data) => {
                this.poColumns = data;
            },
        });
    }
}
