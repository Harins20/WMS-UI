import { CommonModule } from '@angular/common';
import {
    Component,
    DestroyRef,
    inject,
    signal,
    computed,
    input,
} from '@angular/core';
import {
    AbstractControl,
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { IftaLabelModule } from 'primeng/iftalabel';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { Router } from '@angular/router';
import { POColumns } from '../po.columns';
import { AuthService, OptionsService } from '../../../../common/services';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { Select } from 'primeng/select';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { DatePickerModule } from 'primeng/datepicker';
import { selectOption } from '../../../../common/models';
import { POService } from '../po.service';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import {
    InputDatepickerComponent,
    InputNumberComponent,
    InputSelectComponent,
    InputTextComponent,
} from '../../../../common/components';

@Component({
    selector: 'po-view-form',
    imports: [
        ReactiveFormsModule,
        CommonModule,
        IftaLabelModule,
        InputTextModule,
        PasswordModule,
        ButtonModule,
        DatePickerModule,
        AppTranslatePipe,
        InputSelectComponent,
        InputSelectComponent,
        InputTextComponent,
        InputDatepickerComponent,
    ],
    templateUrl: './po-view-form.component.html',
})
export class PoViewFormComponent {
    poData = input<any>();
    private destroyRef = inject(DestroyRef);
    private optionService = inject(OptionsService);

    loading = signal(false);
    formControlsArray = signal(
        Object.values(POColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue),
        ]),
    );
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    poform = new FormGroup(this.formControls());
    ownerOptions = signal<selectOption[]>([]);
    carrierOptions = signal<selectOption[]>([]);
    shipfromOptions = signal<selectOption[]>([]);
    ngOnInit() {
        this.GetOwnerOptions();
        this.GetShipFromOptions();
        this.handleShipFromSelection();
        this.GetCarrierOptions();
        this.handleCarrierSelection();
    }
    ngOnChanges() {
        Object.values(POColumns).forEach((column) => {
            if (column) this.poform.controls[column.field].disable();
        });
        if (this.poData()) {
            const e = this.poData();
            this.poform.patchValue({
                ...this.poData(),
                EXTERNALPOKEY: this.poData()?.EXTERNPOKEY,
                PODATE: this.poData()?.PODATE
                    ? new Date(this.poData().PODATE)
                    : null,
                LASTGRNDATE: this.poData()?.LastGrnDate
                    ? new Date(this.poData().LastGrnDate)
                    : null,
            });
        }
    }
    hasError(formControlName: string) {
        const formControl = this.poform.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.poform.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetShipFromOptions() {
        const subscription = this.optionService.getShipFromOptions().subscribe({
            next: (data) => {
                this.shipfromOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetCarrierOptions() {
        const subscription = this.optionService.getCarrierOptions().subscribe({
            next: (data) => {
                this.carrierOptions.set(data);
            },
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    handleCarrierSelection() {
        this.poform
            .get('CARRIERKEY')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedCarrier: any = this.carrierOptions().find(
                    (carrier) => carrier.value === selectedValue,
                );

                if (selectedCarrier) {
                    this.poform.patchValue({
                        CARRIERNAME:
                            selectedCarrier.Company ||
                            selectedCarrier.label ||
                            selectedCarrier.value ||
                            selectedValue,
                    });
                } else {
                    this.poform.patchValue({
                        CARRIERNAME: selectedValue,
                    });
                }
            });
    }

    handleShipFromSelection() {
        this.poform
            .get('SELLERCODE')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedTrader: any = this.shipfromOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (selectedTrader) {
                    this.poform.patchValue({
                        SELLERNAME:
                            selectedTrader.Company ||
                            selectedTrader.label ||
                            selectedTrader.value ||
                            selectedValue,
                    });
                } else {
                    this.poform.patchValue({
                        SELLERNAME: selectedValue,
                    });
                }
            });
    }
}
