import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { POLinesColumns } from './po-lines.columns';
import { POLines } from './po-lines.model';
import { POLineService } from './po-line.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    LoadingComponent,
    CustomTableComponent,
} from '../../../../common/components';
import { PoLineFormComponent } from './po-line-form/po-line-form.component';
import { Location } from '@angular/common';
import { ExcelDownloadService } from '../../../../common/services/excel-download.service';
import { POService } from '../po.service';
import { tableOptions } from '../../../../common/constants';
import { Tag } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';
import { ConfirmationDialogComponent } from '../../../../common/components';
import { AccordionModule } from 'primeng/accordion';
import { PoViewFormComponent } from '../po-view-form/po-view-form.component';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-polines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        Tag,
        TooltipModule,
        AccordionModule,
        PoViewFormComponent,
        AppTranslatePipe,
        LoadingComponent,
        CustomTableComponent,
    ],
    templateUrl: './po-lines.component.html',
    styleUrl: './po-lines.component.scss',
    providers: [DialogService],
})
export class POLineComponent {
    ref: DynamicDialogRef | undefined;
    storerKey = input.required<string>();
    poKey = input.required<string>();
    POHeader = signal<any>([]);
    externalPoKey = input.required<string>();
    polines = signal<POLines[]>([]);
    selectedPOLines = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    private translate = inject(TranslateService);
    columns = signal(
        Object.values(POLinesColumns).filter((column) => !column.tableHidden),
    );
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    ConfirmationRef: DynamicDialogRef | undefined;
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    selectedColumns = linkedSignal(() => this.columns());
    exportFileName = 'PO Lines List';
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportCSV(),
        },
    ];

    private messageService = inject(MessageService);
    private polinesService = inject(POLineService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    private poService = inject(POService);

    private dialogService = inject(DialogService);
    constructor(private location: Location) { }
    ngOnInit() {
        this.getPOLines();
        if (this.poKey()) {
            this.getPOHeader();
        }
    }
    ngAfterViewInit() {
        this.columns.set(
            Object.values(POLinesColumns)
                .filter((column) => !column.tableHidden)
                .map((column: any) => {
                    if (column.field === 'STATUSDESC') {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                }),
        );
    }
    getPOHeader() {
        const subscription = this.poService
            .getPoKeyDetail(this.poKey())
            .subscribe({
                next: (data: any) => {
                    this.POHeader.set(data.Response);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    getPOLines() {
        this.loading.set(true);
        this.polines.set([]);
        const subscription = this.polinesService
            .getPOLines(this.poKey())
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res) => {
                    this.polines.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'PO Lines list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getPOLines();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.polines(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.polines(), this.exportFileName);
    }
    deleteSelectedProducts() { }

    options(field: string) {
        const uniqueValues = new Set(this.polines().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedPOLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedPOLines().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.ref = this.dialogService.open(ColumnPicklistComponent, {
            inputValues: {
                selectedColumns: this.selectedColumns(),
                unSelectedColumns: this.unSelectedColumns(),
            },
            header: headertext,
            closable: true,
            modal: true,
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => { });
    }

    OpenCreatePOLineForm() {
        const headertext = this.translate.instant('Create PO Line');

        this.ref = this.dialogService.open(PoLineFormComponent, {
            inputValues: {
                polineCreateData: this.POHeader(),
            },
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('POLineCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        const requestBody = {
                            ...this.POHeader(),
                            ...data,
                        };
                        this.polinesService
                            .createPOLine(requestBody)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getPOLines();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New PO Line creation',
                                        detail: data.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                        'One or more errors occurred!' ||
                                        error.error.message ===
                                        'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New PO Line creation',
                                            detail: error.error.message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdatePOLineForm(polinesData: any) {
        const headertext = this.translate.instant('Update PO Line');
        this.ref = this.dialogService.open(PoLineFormComponent, {
            inputValues: {
                polinesData: polinesData,
            },
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('POLineUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.polinesService
                            .updatePOLine(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getPOLines();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'PO Line Update',
                                        detail: data.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                        'One or more errors occurred!' ||
                                        error.error.message ===
                                        'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'PO Line Update',
                                            detail: error.error.message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    DeletePOLines() {
        const headertext = this.translate.instant('Confirm Deletion');
        const count = this.selectedPOLines().length;
        const name =
            count > 1
                ? this.translate.instant('PO Lines')
                : this.translate.instant('PO Line');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                // duplicate: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const Rdata = this.selectedPOLines().map((x: any) =>
                    String(x.SERIALKEY),
                );
                this.loading.set(true);
                const requestBody = {
                    POKEY: this.poKey(),
                    SerialKeys: Rdata,
                };

                const subscription = this.polinesService
                    .deletePOLine(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedPOLines.set([]);
                            this.getPOLines();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Delete PO Line',
                                detail: 'PO Line deleted successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                'One or more errors occurred!' ||
                                error.error.message ===
                                'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    'Failed to delete PO Line.';

                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Delete PO Line',
                                    detail: errorMessage,
                                });
                            }
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    isLineNew(line: any): boolean {
        if (!line) {
            return false;
        }

        const receiptKey = (line.RECEIPTKEY ?? line.ReceiptKey ?? '').toString().trim();
        if (receiptKey) {
            return false;
        }

        if (
            line.IsASNCreated === true ||
            line.isASNCreated === true ||
            line.ISASNCREATED === true
        ) {
            return false;
        }

        const statusDesc = (
            line.STATUSDESC ??
            line.StatusDesc ??
            line.statusDesc ??
            ''
        )
            .toString()
            .trim();

        const status = String(
            line.STATUS ??
            line.Status ??
            line.status ??
            ''
        ).trim();

        if (statusDesc) {
            return statusDesc.toLowerCase() === 'new';
        }

        if (status) {
            return status === '0';
        }

        return false;
    }

    OnClickCreateASN() {
        const selected = this.selectedPOLines();
        if (!selected || selected.length === 0) {
            this.messageService.add({
                severity: 'warn',
                summary: this.translate.instant('Create Receipt'),
                detail: this.translate.instant('Please select at least one PO Line.'),
            });
            return;
        }

        const nonNewLines = selected.filter(
            (line: any) => !this.isLineNew(line),
        );

        if (nonNewLines.length > 0) {
            this.messageService.add({
                severity: 'warn',
                summary: this.translate.instant('Create Receipt'),
                detail: this.translate.instant('Receipt has already been created.'),
            });
            return;
        }

        const headertext = this.translate.instant('Create Receipt');
        const count = selected.length;
        const value = this.translate.instant('CreateReceiptFromPOLines', {
            no: count,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                const Rdata = this.selectedPOLines().map((x: any) => {
                    return x.SERIALKEY;
                });
                this.loading.set(true);
                const requestBody = {
                    POKEY: this.poKey(),
                    SERIALKEY: Rdata,
                };
                const subscription = this.polinesService
                    .createASN(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedPOLines.set([]);
                            this.getPOLines();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Create Receipt',
                                detail: 'Receipt created successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                'One or more errors occurred!' ||
                                error.error.message === 'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message || 'Failed to create Receipt';

                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Create Receipt',
                                    detail: errorMessage,
                                });
                            }
                            this.loading.set(false);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
