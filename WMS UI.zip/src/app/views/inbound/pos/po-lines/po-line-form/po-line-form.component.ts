import { CommonModule } from '@angular/common';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { IftaLabelModule } from 'primeng/iftalabel';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { Select } from 'primeng/select';
import { selectOption } from '../../../../../common/models';
import { OptionsService } from '../../../../../common/services';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../../common/functions';
import { POLinesColumns } from '../po-lines.columns';
import { KeyFilterModule } from 'primeng/keyfilter';
import { POLineService } from '../po-line.service';
import {
    InputNumberComponent,
    InputSelectComponent,
} from '../../../../../common/components';
import { InputTextComponent } from '../../../../../common/components/input-text/input-text.component';
import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'po-line-form',
    imports: [
        ReactiveFormsModule,
        CommonModule,
        IftaLabelModule,
        InputTextModule,
        PasswordModule,
        ButtonModule,
        CalendarModule,
        KeyFilterModule,
        InputNumberComponent,
        InputTextComponent,
        AppTranslatePipe,
        InputSelectComponent,
        InputNumberComponent,
    ],
    templateUrl: './po-line-form.component.html',
    styleUrls: ['./po-line-form.component.scss'],
})
export class PoLineFormComponent {
    polinesData = input<any>();
    polineCreateData = input<any>();
    private ref = inject(DynamicDialogRef);
    private destroyRef = inject(DestroyRef);
    private optionService = inject(OptionsService);
    private PolineService = inject(POLineService);
    private messageService = inject(MessageService);

    loading = signal(false);
    formControlsArray = signal(
        Object.values(POLinesColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    polineform = new FormGroup(this.formControls());
    itemOptions = signal<selectOption[]>([]);
    packOptions = signal<selectOption[]>([]);

    // ✅ Single signal for tab validation warning
    setViewTAb = signal<boolean>(true);
    activeTab = signal<number>(0);
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    ngOnInit() {
        if (this.polinesData()) {
            Object.values(POLinesColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.polineform.controls[column.field].disable();
            });
            const selectedStorerKey = this.polinesData()?.TRADERKEY;
            if (selectedStorerKey) {
                this.GetItemOptions(selectedStorerKey);
            }
            this.polineform.patchValue({
                ...this.polinesData(),
            });
        } else {
            Object.values(POLinesColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.polineform.controls[column.field].disable();
            });
            this.polineform.patchValue({
                ...this.polineCreateData(),
            });
            const selectedStorerKey = this.polineCreateData()?.TRADERKEY;
            if (selectedStorerKey) {
                this.GetItemOptions(selectedStorerKey);
            }
        }
        this.GetPackOptions();
    }

    hasError(formControlName: string) {
        const formControl = this.polineform.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.polineform.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }
    closePanel() {
        this.ref.close();
    }
    onCancel() {
        this.ref.close();
    }

    itemPrice$ = this.polineform.controls['SKU'].valueChanges.subscribe(
        (value) => {
            if (value) {
                this.itemOptions().forEach((item: any) => {
                    if (item.value === value) {
                        this.polineform.get('Price')?.setValue(item.Price);
                    }
                });
            }
        },
    );

    GetItemOptions(StorerKey: string) {
        const subscription = this.PolineService.getItemDetailsOptions(
            StorerKey,
        ).subscribe({
            next: (data) => {
                this.itemOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPackOptions() {
        const subscription = this.optionService.getPackOptions().subscribe({
            next: (data) => {
                this.packOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching pack dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    onSubmit() {
        if (this.polineform.valid) {
            this.setViewTAb.set(true);

            this.ref.close(this.polineform.getRawValue());
            this.polineform.reset();
        } else {
            this.setViewTAb.set(false);
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.polineform.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.polineform.controls));
        }
    }
}
