import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { POLines } from './po-lines.model';
import { AppConfigService } from '../../../../../app.config.service';
import { AuthService } from '../../../../common/services';
import { ResponseDto } from '../../../../common/models';
import { map } from 'rxjs';
@Injectable({
    providedIn: 'root',
})
export class POLineService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getPOLines(poKey: string) {
        return this.httpClient.get<ResponseDto<POLines[]>>(
            this.config.appConfig()?.InbUrl + `Po/Lines?PoKey=${poKey}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    createPOLine(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InbUrl + 'Po/Lines',
            [data],
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    updatePOLine(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Po/Lines',
            [data],
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    deletePOLine(data: any) {
        return this.httpClient.delete(
            this.config.appConfig()?.InbUrl + 'Po/Lines',
            {
                headers: this.authService.getAuthHeaders(),
                body: data,
            },
        );
    }
    createASN(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InbUrl + 'Po/Asn',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    createASNHeader(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InbUrl + 'Po/Asnheader',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    getItemDetailsOptions(TraderKey: string) {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    `items?TraderKey=${TraderKey}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value) => [
                    {
                        label: 'RTL-BED-DUV-DBL',
                        value: 'RTL-BED-DUV-DBL',
                    },
                    {
                        label: 'RTL-CBL-USBC-2M',
                        value: 'RTL-CBL-USBC-2M',
                    },
                    {
                        label: 'RTL-HDP-BT-BLK',
                        value: 'RTL-HDP-BT-BLK',
                    },
                    {
                        label: 'RTL-JKT-RAIN-M',
                        value: 'RTL-JKT-RAIN-M',
                    },
                    {
                        label: 'RTL-JNS-SLM-32',
                        value: 'RTL-JNS-SLM-32',
                    },
                    {
                        label: 'RTL-MUG-CER-350',
                        value: 'RTL-MUG-CER-350',
                    },
                    {
                        label: 'RTL-PWB-10K',
                        value: 'RTL-PWB-10K',
                    },
                    {
                        label: 'RTL-SNK-RUN-42',
                        value: 'RTL-SNK-RUN-42',
                    },
                    {
                        label: 'RTL-SPK-MINI',
                        value: 'RTL-SPK-MINI',
                    },
                    {
                        label: 'RTL-TSH-BLK-M',
                        value: 'RTL-TSH-BLK-M',
                    },
                    {
                        label: 'RTL-TSH-WHT-L',
                        value: 'RTL-TSH-WHT-L',
                    },
                    {
                        label: 'RTL-TWL-BATH',
                        value: 'RTL-TWL-BATH',
                    },
                ]),
            );
    }
}
