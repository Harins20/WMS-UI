export interface POLines {
    SERIALKEY: string;
    TRADERKEY: string;
    EXTERNPOKEY: string;
    POKEY: string;
    EXTERNLINENO: string;
    POLINENUMBER: string;
    SKU: string;
    UOM: string;
    PACKKEY: string;
    QTYORDERED: number;
    Price: number;
    STATUS: string;
    StatusDesc: string;
    IsASNCreated: true;
    RECEIPTKEY: string;
    ReceiptLineNumber: string;
    AddWho: string;
    AddDate: string;
    EditWho: string;
    EditDate: string;
}
