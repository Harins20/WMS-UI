import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { PO } from './po.model';
import { AuthService } from '../../../common/services';
import { ResponseDto } from '../../../common/models';
import { AppConfigService } from '../../../../app.config.service';
import { map } from 'rxjs';
import { POColumns } from './po.columns';
import { stringToDate } from '../../../common/functions';

interface POPage {
    Response: {
        PurchaseOrders: PO[];
        TotalRecords: number;
    };
    Message: string;
    Success: boolean;
}

@Injectable({
    providedIn: 'root',
})
export class POService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getPO() {
        return this.httpClient.get<ResponseDto<PO[]>>(
            this.config.appConfig()?.InbUrl + 'PO',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getPOPage(data: any) {
        return this.httpClient
            .post<POPage>(this.config.appConfig()?.InbUrl + 'Po/page', data, {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe(
                map((response) => {
                    if (response?.Response?.PurchaseOrders) {
                        response.Response.PurchaseOrders.forEach((po: any) => {
                            Object.keys(po).forEach((key) => {
                                if (POColumns[key]?.type === 'date') {
                                    po[key] = stringToDate(po[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    createPO(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InbUrl + 'Po',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    updatePO(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Po',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    deletePO(data: any) {
        return this.httpClient.delete(this.config.appConfig()?.InbUrl + 'Po', {
            headers: this.authService.getAuthHeaders(),
            body: data,
        });
    }

    getPoKeyDetail(poKey: any) {
        return this.httpClient.get<ResponseDto<PO[]>>(
            this.config.appConfig()?.InbUrl + `Po?PoKey=${poKey}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
