export interface PO {
    SERIALKEY: number;
    TRADERKEY: string;
    EXTERNPOKEY: string;
    POKEY: string;
    PODATE: Date | null;
    SELLERCODE: string;
    SELLERNAME: string;
    GrnCount: Number;
    LastGrnDate: Date;
    STATUS: string;
    UDFSTR1: string;
    UDFSTR2: string;
    UDFSTR3: string;
    UDFSTR4: string;
    UDFSTR5: string;
    AddWho: string;
    AddDate: Date;
    EditWho: string;
    EditDate: Date;
}
