import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { Putaway } from './../asns/putaway/putaway.model';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    effect,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { PutawayDetailColumns } from './putaway-detail.columns';
import { PutawayDetail } from './putaway-detail.model';
import { PutawayDetailService } from './putaway-detail.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { tableOptions } from '../../../common/constants';
import { LoadingComponent } from '../../../common/components/common-loading/loading.component';
import { OptionsService } from '../../../common/services';
import { filterQuery } from '../../../common/functions/filterQuery';
import { TooltipModule } from 'primeng/tooltip';

import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { ColumnPicklistComponent } from '../../../common/components';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
@Component({
    selector: 'app-putaway',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './putaway-details.component.html',
    styleUrl: './putaway-details.component.scss',
    providers: [DialogService],
})
export class PutawayComponent {
    putaway = signal<PutawayDetail[]>([]);
    putawayForExcel = signal<PutawayDetail[]>([]);
    selectedPutaway = signal<any>([]);
    private translate = inject(TranslateService);
    optionsData = signal<{ [key: string]: any[] }>({
        TRADERKEY: [],
        SKU: [],
        PACKKEY: [],
        UOM: [],
        Status_Desc: [],
        TOLOC: [],
    });
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    rows = signal(15);
    totalRecords = signal(0);
    dt = viewChild.required<Table>('dt');
    gs = signal<string | undefined>(undefined);

    columns = signal(
        Object.values(PutawayDetailColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x) => x.tableAlias && !x.tableHidden)
            .map((x) => x.field),
    );
    tableOptions = signal(tableOptions);
    OrginalColumns = signal<any>(PutawayDetailColumns);
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    private messageService = inject(MessageService);
    private putawayService = inject(PutawayDetailService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    private optionService = inject(OptionsService);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    loadEvent = signal<any>({});
    constructor() {}
    ngOnInit() {
        this.getPutaways();
        this.loadOptions();
    }
    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         PutawayDetailColumns,
    //         'vw.',
    //     );

    //     this.getPutaways({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getPutaways(event);
    }
    loadOptions() {
        this.GetOwnerOptions();
        this.GetPackkeyOptions();
        this.GetUomOptions();
        this.GetQcStatusOptions();
        this.GetStatusOptions();
        this.GetLocationOption();
    }

    GetPackkeyOptions() {
        const subscription = this.optionService.getPackkey().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, PACKKEY: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetUomOptions() {
        const subscription = this.optionService.getUomTypeOptions().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, UOM: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetQcStatusOptions() {
        const subscription = this.optionService.getQcStatusOptions().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, QCSTATUS: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetLocationOption() {
        const subscription = this.optionService.getLocation().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, TOLOC: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetStatusOptions() {
        const subscription = this.optionService
            .getReciptStatusOptions()
            .subscribe({
                next: (data) => {
                    const remap = data.map((x) => ({ ...x, value: x.Label }));
                    this.optionsData.update((old) => ({
                        ...old,
                        Status_Desc: remap,
                    }));
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetOwnerOptions() {
        const subscription = this.optionService.getOwnerOptions().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, TRADERKEY: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    getPutaways(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.putaway.set([]);
        this.selectedPutaway.set([]);
        const subscription = this.putawayService
            .getPutawayPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let idBase = data?.first || 0;
                    this.putaway.set(
                        res.Putaway.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idBase + idx + 1,
                        })),
                    );

                    this.totalRecords.set(res.totalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Putaway list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    this.loading.set(false);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    getPutawaysForExcel(data: any = this.loadEvent(), type: string) {
        this.loading.set(true);
        this.putawayForExcel.set([]);
        const subscription = this.putawayService
            .getPutawayPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    this.putawayForExcel.set(res.Putaway);
                    if (res?.Putaway && type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            'Putaway-List',
                            [],
                            res.Putaway,
                        );
                    } else {
                        downloadCSVFile(res.Putaway, 'Putaway-List');
                    }
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Putaway list for excel',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    this.loading.set(false);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    export(type: string) {
        const event = this.loadEvent();

        this.getPutawaysForExcel(
            {
                ...event,
                first: 0,
                rows: this.totalRecords(),
            },
            type,
        );
    }
    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(this.putaway().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedPutaway().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedPutaway().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    onEditAction(putaway: PutawayDetail) {}
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
