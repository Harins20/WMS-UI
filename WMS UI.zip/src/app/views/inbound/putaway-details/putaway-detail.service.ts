import { Putaway } from './../asns/putaway/putaway.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { PutawayDetail } from './putaway-detail.model';
import { AuthService } from '../../../common/services';
import { ResponseDto } from '../../../common/models';
import { AppConfigService } from '../../../../app.config.service';
import { PutawayDetailColumns } from './putaway-detail.columns';
import { map } from 'rxjs';
import { stringToDate } from '../../../common/functions';

@Injectable({
    providedIn: 'root',
})
export class PutawayDetailService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getPutaway() {
        return this.httpClient.get<ResponseDto<PutawayDetail[]>>(
            this.config.appConfig()?.InbUrl + 'Putaway',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getPutawayPage(data: any) {
        return this.httpClient
            .post<PutawayDetailPage>(
                this.config.appConfig()?.InbUrl + 'Putaway/putawaypage',
                data,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((response) => {
                    response.Putaway.forEach((asn: any) => {
                        Object.keys(asn).forEach((key) => {
                            if (PutawayDetailColumns[key]?.type === 'date') {
                                asn[key] = stringToDate(asn[key]);
                            }
                        });
                    });
                    return response;
                }),
            );
    }
}

interface PutawayDetailPage {
    Putaway: PutawayDetail[];
    totalRecords: number;
}
