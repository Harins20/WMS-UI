export interface PutawayDetail {
    PutawayDetail: any;
    SERIALKEY: string;
    ITRNKEY: string;
    RECEIPTKEY: string;
    RECEIPTLINENUMBER: string;
    SOURCETYPE: string;
    TRADERKEY: string;
    SKU: string;
    LOT: string;
    FROMLOC: string;
    FromId: string;
    TOLOC: string;
    ToId: string;
    QTY: number;
    UOM: string;
    PACKKEY: string;
    GROSSWGT: number;
    NETWGT: number;
    TAREWGT: number;
    ADDDATE: Date;
    ADDWHO: string;
    EDITDATE: Date;
    EDITWHO: string;
}
