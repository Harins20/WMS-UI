import { Validators } from '@angular/forms';
import { Columns } from '../../../common/models';

export const PutawayDetailColumns: Columns = {
    rowId: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
    },
    SERIALKEY: {
        label: 'Serial Key',
        field: 'SERIALKEY',
        tableAlias: 'vw.',
        tableHidden: true,
    },
    RECEIPTKEY: {
        label: 'Receipt Key',
        field: 'RECEIPTKEY',
        tableAlias: 'vw.',
    },
    RECEIPTLINENUMBER: {
        label: 'Receipt Line Number',
        field: 'RECEIPTLINENUMBER',
        tableAlias: 'vw.',
    },
    ITRNKEY: {
        label: 'ITRN Key',
        field: 'ITRNKEY',
        tableAlias: 'vw.',
    },
    SOURCETYPE: {
        label: 'Source Type',
        field: 'SOURCETYPE',
        tableAlias: 'vw.',
    },
    TRADERKEY: {
        label: 'Owner',
        field: 'TRADERKEY',
        type: 'select',
        tableAlias: 'vw.',
    },
    SKU: {
        label: 'Sku',
        field: 'SKU',
        tableHidden: true,
        tableAlias: 'vw.',
        type: 'select',
    },
    TOID: {
        label: 'LPN',
        field: 'TOID',
        tableAlias: 'vw.',
    },
    TOLOC: {
        label: 'Location',
        field: 'TOLOC',
        type: 'select',
        tableAlias: 'vw.',
    },
    QTY: {
        label: 'Quantity',
        field: 'QTY',
        tableAlias: 'vw.',
    },
    UOM: {
        label: 'UOM',
        field: 'UOM',
        tableAlias: 'vw.',
        type: 'select',
    },
    GROSSWGT: {
        label: 'Gross Weight',
        field: 'GROSSWGT',
        tableAlias: 'vw.',
    },
    NETWGT: {
        label: 'Net Weight',
        field: 'NETWGT',
        tableAlias: 'vw.',
    },
    TAREWGT: {
        label: 'Tare Weight',
        field: 'TAREWGT',
        tableAlias: 'vw.',
    },
    LOT: {
        label: 'LOT',
        field: 'LOT',
        tableAlias: 'vw.',
    },
    FROMLOC: {
        label: 'From Location',
        field: 'FROMLOC',
        tableAlias: 'vw.',
    },
    PACKKEY: {
        label: 'Pack Key',
        field: 'PACKKEY',
        type: 'select',
        tableAlias: 'vw.',
    },
    ADDDATE: {
        label: 'Add Date',
        field: 'ADDDATE',
        type: 'date',
        tableAlias: 'vw.',
    },
    ADDWHO: {
        label: 'Add Who',
        field: 'ADDWHO',
        tableAlias: 'vw.',
    },
    EDITDATE: {
        label: 'Edit Date',
        field: 'EDITDATE',
        type: 'date',
        tableAlias: 'vw.',
    },
    EDITWHO: {
        label: 'Edit Who',
        field: 'EDITWHO',
        tableAlias: 'vw.',
    },
};
