import {
    AsnsComponent,
    AsnLineComponent,
    ExplodedLineComponent,
    MultiReportViewerComponent,
} from './asns';
import { PutawayLineComponent } from './asns/putaway/putaway.component';
import { PosComponent, POLineComponent } from './pos';
import { PutawayComponent } from './putaway-details';
import { ReceiptDetailsComponent } from './receipt-detail';

export default [
    { data: { name: 'Receipt' }, path: 'asns', component: AsnsComponent },
    { data: { name: 'POs' }, path: 'po', component: PosComponent },
    {
        data: { name: 'asnline' },
        path: 'asns/lines/:receiptKey/:storerKey',
        component: AsnLineComponent,
    },
    {
        data: { name: 'putaway' },
        path: 'asns/putaway/:receiptKey',
        component: PutawayLineComponent,
    },
    {
        data: { name: 'explodedline' },
        path: 'exploded-lines/:receiptKey/:line',
        component: ExplodedLineComponent,
    },
    {
        data: { name: 'poline' },
        path: 'po-lines/:poKey/:storerKey',
        component: POLineComponent,
    },
    {
        data: { name: 'Putaway Details' },
        path: 'putaway-details',
        component: PutawayComponent,
    },
    {
        data: { name: 'Receipt Details' },
        path: 'receipt-details',
        component: ReceiptDetailsComponent,
    },
    {
        data: { name: 'Multi Report Viewer' },
        path: 'report-viewer',
        component: MultiReportViewerComponent,
    },
];
