import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../common/components';
import { tableOptions } from '../../../common/constants';
import { filterQuery } from '../../../common/functions/filterQuery';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { AdjustmentFormComponent } from './adjustment-form/adjustment-form.component';
import { ConfirmationNotesComponent } from './confirmation-notes/confirmation-notes.component';
import { InventoryColumns } from './inventory.columns';
import { Inventories } from './inventory.model';
import { InventoryService } from './inventory.service';
import { MoveFormComponent } from './move-form/move-form-component';
import { OptionsService } from '../../../common/services';
import { Tag } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-inventory',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        Tag,
        TooltipModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './inventory.component.html',
    styleUrl: './inventory.component.scss',
    providers: [DialogService],
})
export class InventoryComponent {
    private translate = inject(TranslateService);
    actions: MenuItem[] = [
        {
            label: this.translate.instant('LPN Hold'),
            command: () => this.lpnHold(),
        },
        {
            label: this.translate.instant('LOT Hold'),
            command: () => this.lotHold(),
        },
    ];
    OrginalColumns = signal<any>(InventoryColumns);
    inventory = signal<Inventories[]>([]);
    inventoriesForExcel = signal<Inventories[]>([]);
    selectedInventory = signal<any>([]);
    loadEvent = signal<any>({});
    searchInput = signal<string | undefined>(undefined);
    optionsData = signal<{ [key: string]: any[] }>({
        SKU: [],
        PACKKEY: [],
        UOM: [],
        Location: [],
        TRADERKEY: [],
        STATUS: [],
    });
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    totalRecords = signal(0);
    gs = signal<string | undefined>(undefined);

    columns = signal<any[]>([]);

    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x) => x.tableAlias && !x.tableHidden)
            .map((x) => x.field),
    );

    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    private messageService = inject(MessageService);
    private inventoryService = inject(InventoryService);
    private destroyRef = inject(DestroyRef);
    moveFormRef: DynamicDialogRef | undefined;
    adjFormRef: DynamicDialogRef | undefined;
    lpnCommonRef: DynamicDialogRef | undefined;
    lotCommonRef: DynamicDialogRef | undefined;
    lpnFormRef: DynamicDialogRef | undefined;
    lotFormRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;
    ConfirmationRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private excelDownloadService = inject(ExcelDownloadService);
    private optionService = inject(OptionsService);
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    constructor() {}
    ngOnInit() {
        // this.getInventories();
        this.loadOptions();
    }
    ngAfterViewInit() {
        this.columns.set(
            Object.values(InventoryColumns)
                .filter((column) => !column.tableHidden)
                .map((column: any) => {
                    if (column.field === 'STATUS') {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                }),
        );
    }
    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         InventoryColumns,
    //         'vw.',
    //     );

    //     this.getInventories({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getInventories(event);
    }
    loadOptions() {
        this.GetItemOptions();
        this.GetPackkeyOptions();
        this.GetUomOptions();
        this.GetOwnerOption();
        this.GetLocationOption();
        this.GetStatusOption();
    }

    GetItemOptions() {
        const subscription = this.optionService.getItems().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, SKU: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPackkeyOptions() {
        const subscription = this.optionService.getPackkey().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, PACKKEY: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetUomOptions() {
        const subscription = this.optionService.getUomTypeOptions().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, UOM: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetOwnerOption() {
        const subscription = this.optionService.getOwner().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, TRADERKEY: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetLocationOption() {
        const subscription = this.optionService.getLocation().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, LOC: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetStatusOption() {
        // const subscription = this.optionService.getQcStatusOptions().subscribe({
        //     next: (data) => {
        //         this.optionsData.update((old) => ({ ...old, STATUS: data }));
        //     },
        //     error: (err) => {
        //         console.error('Error fetching item dropdown data:', err);
        //     },
        // });

        // this.destroyRef.onDestroy(() => subscription.unsubscribe());
        const additionalOptions = [
            { label: 'OK', value: 'OK' },
            { label: 'LOT Hold', value: 'LOT HOLD' },
            { label: 'LPN Hold', value: 'LPN HOLD' },
        ];

        this.optionsData.update((old) => ({
            ...old,
            STATUS: additionalOptions,
        }));
    }

    getInventories(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.selectedInventory.set([]), this.inventory.set([]);
        const subscription = this.inventoryService
            .getInventoryPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }

                    const pageSize = data?.rows ?? data?.PageSize ?? 15;
                    const first = data?.first ?? 0;

                    this.inventory.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: first + idx + 1,
                        })),
                    );

                    this.totalRecords.set(res.TotalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Inventory list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }

    // export(type: 'Excel' | 'CSV') {
    //     const event = this.loadEvent();
    //     event.rows = this.totalRecords();
    //     this.getInventoryForExcel(event, type);
    // }
    export(type: 'Excel' | 'CSV') {
        const event = this.loadEvent();

        const exportEvent = {
            ...event,
            Page: 1,
            PageSize: this.totalRecords(),
            rows: this.totalRecords(),
            first: 0,
        };

        this.getInventoryForExcel(exportEvent, type);
    }

    getInventoryForExcel(data: any, type: 'Excel' | 'CSV') {
        const subscription = this.inventoryService
            .getInventoryPage(data)
            .subscribe({
                next: (res: any) => {
                    const records = res?.Response ?? [];

                    console.log('Export request:', data);
                    console.log('Records received:', records.length);
                    console.log('Total records:', res?.TotalRecords);

                    this.inventoriesForExcel.set(records);

                    if (type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            'Inventory-List',
                            [],
                            records,
                        );
                    } else {
                        downloadCSVFile(records, 'Inventory-List');
                    }
                },
                error: (error: HttpErrorResponse) => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Inventory Export',
                        detail:
                            error?.error?.Message ||
                            error?.error?.message ||
                            'Failed to export inventory.',
                    });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.inventory().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedInventory().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedInventory().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    lpnHold() {
        const headertext = this.translate.instant('LPN Hold');
        const value = this.translate.instant('LPNHold');

        this.lpnCommonRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.lpnCommonRef.onClose.subscribe((data) => {
            if (data) {
                this.openLpnFinalizeDia();
            }
        });
    }

    openLpnFinalizeDia() {
        this.lpnFormRef = this.dialogService.open(ConfirmationNotesComponent, {
            header: 'LPN Hold',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });

        this.lpnFormRef.onClose.subscribe((data) => {
            this.loading.set(true);

            const FilterData = this.selectedInventory().map((x: any) => {
                return {
                    SerialKey: x.SERIALKEY,
                    Status: x.STATUS,
                    HoldNotes: data ? data : null,
                };
            });

            this.inventoryService
                .lpnHold(FilterData)
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.selectedInventory.set([]);
                        this.getInventories(this.loadEvent());
                    }),
                )
                .subscribe({
                    next: (data) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'LPN Hold',
                            detail: 'LPN Hold Successful',
                        });
                    },

                    error: (error) => {
                        const backendMessage =
                            error?.error?.message ||
                            error?.error?.Message ||
                            '';

                        // ✅ Handle multiple error dialog (existing logic)
                        if (backendMessage === 'One or more errors occurred!') {
                            this.ConfirmationRef = this.dialogService.open(
                                CommonErrorboxComponent,
                                {
                                    inputValues: {
                                        error: error,
                                    },
                                    header: 'Multiple Error',
                                    closable: true,
                                    modal: true,
                                    draggable: true,
                                    keepInViewport: true,
                                    width: '39rem',
                                    style: { maxHeight: '40rem' },
                                },
                            );
                        } else {
                            // ✅ Override message for LPN Hold failure
                            this.messageService.add({
                                severity: 'error',
                                summary: 'LPN Hold',
                                detail: 'Action failed. Please check if the supplied LPNs status is not already on Hold and have quantity available to put to hold',
                            });
                        }

                        this.loading.set(false);
                    },
                });
        });
    }
    lotHold() {
        const lotData = this.selectedInventory().map((x: any) => {
            return { Lot: x.LOT };
        });
        this.inventoryService
            .lotHoldVerify(lotData)
            .pipe()
            .subscribe({
                next: (data: any) => {
                    this.OpenLotHoldPopup(data.Message);
                },
                error: (error) => {
                    if (
                        error.error.Message ===
                            'One or more errors occurred!' ||
                        error.error.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: error,
                                },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                    } else {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'LOT Hold',
                            detail: error as string,
                        });
                    }
                },
            });
    }

    OpenLotHoldPopup(Data: any) {
        const headertext = this.translate.instant('LOT Hold');
        this.lotCommonRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: Data,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                // duplicate: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.lotCommonRef.onClose.subscribe((data) => {
            if (data) {
                this.openLotFinalizeDia();
            }
        });
    }

    openLotFinalizeDia() {
        this.lotFormRef = this.dialogService.open(ConfirmationNotesComponent, {
            header: 'LOT Hold',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });
        this.lotFormRef.onClose.subscribe((data) => {
            this.loading.set(true);
            const FilterData = this.selectedInventory().map((x: any) => {
                return {
                    Lot: x.LOT,
                    Status: x.STATUS,
                    HoldNotes: data ? data : null,
                };
            });
            this.inventoryService
                .lotHold(FilterData)
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.selectedInventory.set([]);
                        this.getInventories(this.loadEvent());
                    }),
                )
                .subscribe({
                    next: (data) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'LOT Hold',
                            detail: 'LOT Hold Successful',
                        });
                    },
                    error: (error) => {
                        if (
                            error.error.Message ===
                                'One or more errors occurred!' ||
                            error.error.message ===
                                'One or more errors occurred!'
                        ) {
                            this.ConfirmationRef = this.dialogService.open(
                                CommonErrorboxComponent,
                                {
                                    inputValues: {
                                        error: error,
                                    },
                                    header: 'Multiple Error',
                                    closable: true,
                                    modal: true,
                                    draggable: true,
                                    keepInViewport: true,
                                    width: '39rem',
                                    style: { maxHeight: '40rem' },
                                },
                            );
                        } else {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'LOT Hold',
                                detail: error.error.message as string,
                            });
                        }
                    },
                });
        });
    }

    OpenUpdateMoveForm() {
        const headertext = this.translate.instant('Move');
        this.moveFormRef = this.dialogService.open(MoveFormComponent, {
            inputValues: {
                moveData: this.selectedInventory()[0],
            },
            header: headertext,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });
        this.moveFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Move');
                const value = this.translate.instant('MoveInventory');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: { message: value },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.loading.set(true);
                        const moveItem = [
                            {
                                TraderKey: data.TRADERKEY,
                                WhseId: data.WHSEID,
                                FromLot: data.LOT,
                                FromLoc: data.LOC,
                                FromId: data.ID,
                                ToLoc: data.TOLOCATION,
                                ToId: data.TOLPN ? data.TOLPN : data.ID,
                                Qty: data.MOVEQTY,
                            },
                        ];
                        this.inventoryService
                            .updateMove(moveItem)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedInventory.set([]);
                                    this.getInventories(this.loadEvent());
                                }),
                            )
                            .subscribe({
                                next: (data) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Move Item',
                                        detail: 'Move Successful',
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Move Item',
                                            detail: error.error.message as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    OpenAdjustmentForm() {
        const headertext = this.translate.instant('Adjustment');
        this.adjFormRef = this.dialogService.open(AdjustmentFormComponent, {
            inputValues: {
                adjustData: this.selectedInventory()[0],
            },
            header: headertext,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '50rem' },
        });
        this.adjFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Adjustment');
                const value = this.translate.instant('AdjustInventory');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: { message: value },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.loading.set(true);

                        const AdjustItem: any = {
                            SerialKey: data.SERIALKEY,
                            TraderKey: data.TRADERKEY,
                            Sku: data.SKU,
                            Loc: data.LOC,
                            Lot: data.LOT,
                            qty: data.QTY,
                            AdjustmentQty: data.ADJUSTMENTQTY,
                            TareWgt: data.ADJTAREWGT - data.TAREWGT,
                            AdjNetWgt: data.ADJNETWGT - data.NETWGT,
                            AdjGrossWgt: data.ADJGROSSWGT - data.GROSSWGT,
                            ReasonCode: data.REASONCODE,
                            PackKey: data.PACKKEY,
                        };
                        console.log('ADJUSTMENT FORM DATA:', data);
                        console.log('ADJUSTMENT REQUEST:', AdjustItem);

                        this.inventoryService
                            .updateAdjustment(AdjustItem)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedInventory.set([]);
                                    this.getInventories(this.loadEvent());
                                }),
                            )
                            .subscribe({
                                next: (data) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Adjustment Item',
                                        detail: 'Adjustment Successful',
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Adjustment Item',
                                            detail: error.error.message as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
    refresh() {
        this.searchInput.set(undefined);
    }
}
