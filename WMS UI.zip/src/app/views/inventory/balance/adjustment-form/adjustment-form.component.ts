import { Component, DestroyRef, inject, input, signal } from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { markAllControlsAsDirty } from '../../../../common/functions';
import { selectOption } from '../../../../common/models';
import { OptionsService } from '../../../../common/services';
import { InputNumberComponent } from '../../../../common/components/input-number/input-number.component';
import { InputSelectComponent } from '../../../../common/components/input-select/input-select.component';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';

@Component({
    selector: 'app-adjustment-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        CheckboxModule,
        InputNumberComponent,
        InputSelectComponent,
        AppTranslatePipe,
    ],
    templateUrl: './adjustment-form.component.html',
    styleUrl: './adjustment-form.component.scss',
})
export class AdjustmentFormComponent {
    adjustData = input<any>();
    private ref = inject(DynamicDialogRef);
    private destoryRef = inject(DestroyRef);
    ReasonOptions = signal<selectOption[]>([]);
    private optionService = inject(OptionsService);

    adjustForm = new FormGroup({
        ID: new FormControl<number>(0),
        SKU: new FormControl<string>('', [Validators.required]),
        LOC: new FormControl<string>('', [Validators.required]),
        QTY: new FormControl<number>(0),
        LOT: new FormControl<string>(''),
        TOLPN: new FormControl<string>(''),
        TRADERKEY: new FormControl<string>(''),
        WHSEID: new FormControl<string>(''),
        SERIALKEY: new FormControl<string>(''),
        PACKKEY: new FormControl<string>(''),
        GROSSWGT: new FormControl<number>(0),
        NETWGT: new FormControl<number>(0),
        TAREWGT: new FormControl<number>(0),
        ADJGROSSWGT: new FormControl<number | null>(null, [
            Validators.required,
            Validators.min(0),
        ]),
        ADJNETWGT: new FormControl<number | null>(null, [
            Validators.required,
            Validators.min(0),
        ]),
        ADJTAREWGT: new FormControl<number>(0),
        ADJUSTMENTQTY: new FormControl<number>(0),
        TARGETQTY: new FormControl<number>(0, [
            Validators.required,
            Validators.min(0),
        ]),
        REASONCODE: new FormControl<string | null>(null, [Validators.required]),
    });
    ngOnInit() {
        if (this.adjustData()) {
            this.adjustForm.patchValue({
                ...this.adjustData(),
            });
        }
        this.GetReasonCodeOptions();
    }
    onSubmit() {
        if (this.adjustForm.valid) {
            this.ref.close(this.adjustForm.value);
            this.adjustForm.reset();
        } else {
            this.adjustForm.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.adjustForm.controls));
        }
    }
    onCancel() {
        this.adjustForm.reset();
        this.ref.close();
    }

    targetValue = this.adjustForm.controls['TARGETQTY'].valueChanges.subscribe(
        (value) => {
            var AdjQty =
                (value || 0) - (this.adjustForm.get('QTY')?.value || 0);
            this.adjustForm.get('ADJUSTMENTQTY')?.setValue(AdjQty);
        },
    );
    GrossWgt$ = this.adjustForm.controls['ADJGROSSWGT'].valueChanges.subscribe(
        (value) => {
            const netwgt = this.adjustForm.get('ADJNETWGT') as FormControl;
            netwgt.setValidators([
                Validators.required,
                Validators.max(value || 0),
            ]);
            netwgt.updateValueAndValidity();
            netwgt.markAsTouched();
            var TareQty = (value || 0) - (netwgt.value || 0);
            this.adjustForm.get('ADJTAREWGT')?.setValue(TareQty);
        },
    );
    NetWgt$ = this.adjustForm.controls['ADJNETWGT'].valueChanges.subscribe(
        (value) => {
            var TareQty =
                (this.adjustForm.get('ADJGROSSWGT')?.value || 0) - (value || 0);
            this.adjustForm.get('ADJTAREWGT')?.setValue(TareQty);
        },
    );

    GetReasonCodeOptions() {
        const subscription = this.optionService
            .getReasonCodeOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ReasonOptions.set(data);
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    ngOnDestroy() {
        this.GrossWgt$.unsubscribe();
        this.NetWgt$.unsubscribe();
        this.targetValue.unsubscribe();
    }
}
