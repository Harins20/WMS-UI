import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AuthService } from '../../../common/services';
import { ResponseDto } from '../../../common/models';
import { AppConfigService } from '../../../../app.config.service';
import { Inventories } from './inventory.model';

interface InventoryPage {
    InventoryDetail: Inventories[];
    totalRecords: number;
}

@Injectable({
    providedIn: 'root',
})
export class InventoryService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getInventory() {
        return this.httpClient.get<ResponseDto<Inventories[]>>(
            this.config.appConfig()?.InvUrl + 'balance',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getInventoryPage(data: any) {
        return this.httpClient.post<InventoryPage>(
            this.config.appConfig()?.InvUrl + 'Inventory/page',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    updateMove(moveItem: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InvUrl + 'move',
            moveItem,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    updateAdjustment(adjustItem: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InvUrl + 'Adjustments',
            adjustItem,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    lotHoldVerify(Item: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InvUrl + 'holds/lothold/verify',
            Item,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    lpnHold(Item: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InvUrl + 'holds/lpnhold',
            Item,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    lotHold(Item: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InvUrl + 'holds/lotholds',
            Item,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
