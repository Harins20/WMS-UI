import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { Component, inject, input, signal } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { TextareaModule } from 'primeng/textarea';

@Component({
    selector: 'app-user-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        TextareaModule,
        FormsModule,
        AppTranslatePipe, ],
    templateUrl: './confirmation-notes.component.html',
    styleUrl: './confirmation-notes.component.scss',
})
export class ConfirmationNotesComponent {
    message = input.required<string>();
    private ref = inject(DynamicDialogRef);
    notes = signal<string>('');

    onYes() {
        this.ref.close(this.notes());
    }
    onCancel() {
        this.ref.close(false);
    }
}
