import { Component, DestroyRef, inject, input, signal } from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { selectOption } from '../../../../common/models';
import { OptionsService } from '../../../../common/services';
import { InputNumberComponent } from '../../../../common/components/input-number/input-number.component';
import {
    InputSelectComponent,
    InputTextComponent,
} from '../../../../common/components';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';

@Component({
    selector: 'app-user-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        CheckboxModule,
        InputNumberComponent,
        InputTextComponent,
        InputSelectComponent,
        AppTranslatePipe, ],
    templateUrl: './move-form-component.html',
    styleUrl: './move-form.component.scss',
})
export class MoveFormComponent {
    moveData = input<any>();
    private ref = inject(DynamicDialogRef);
    private destoryRef = inject(DestroyRef);
    locationOptions = signal<selectOption[]>([]);
    private optionService = inject(OptionsService);

    moveForm = new FormGroup({
        ID: new FormControl<number>(0),
        SKU: new FormControl<string>('', [Validators.required]),
        LOC: new FormControl<string>('', [Validators.required]),
        QTY: new FormControl<number>(0),
        LOT: new FormControl<string>('', [Validators.required]),
        QTYPICKED: new FormControl<string>('', [Validators.required]),
        TOLOCATION: new FormControl<string>('', [Validators.required]),
        MOVEQTY: new FormControl<number>(0, [
            Validators.required,
            Validators.min(1),
        ]),
        TOLPN: new FormControl<string>(''),
        TRADERKEY: new FormControl<string>(''),
        WHSEID: new FormControl<string>(''),
    });
    ngOnInit() {
        if (this.moveData()) {
            this.moveForm.patchValue({
                ...this.moveData(),
            });
        }
        this.GetInvlocationOptions();
    }
    onSubmit() {
        if (this.moveForm.valid) {
            this.ref.close(this.moveForm.value);
            this.moveForm.reset();
        } else {
            this.moveForm.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.moveForm.controls));
        }
    }
    onCancel() {
        this.moveForm.reset();
        this.ref.close();
    }

    GetInvlocationOptions() {
        const subscription = this.optionService
            .getLocationOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.locationOptions.set(data);
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
}
