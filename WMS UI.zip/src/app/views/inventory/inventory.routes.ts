import { AdjustmentComponent } from './adjustments/adjustments.component';
import { InventoryComponent } from './balance/inventory.component';
import { KittingLinesComponent } from './kitting/kitting-lines/kitting-lines.component';
import { KittingComponent } from './kitting/kitting.component';
import { HoldsComponent } from './manage-holds/manage-holds.component';
import { ReplenishmentComponent } from './replenishment/replenishment.component';

export default [
    {
        data: { name: 'Adjustments' },
        path: 'adjustments',
        component: AdjustmentComponent,
    },
    {
        data: { name: 'Balance' },
        path: 'balance',
        component: InventoryComponent,
    },
    {
        data: { name: 'Manage Holds' },
        path: 'manage-holds',
        component: HoldsComponent,
    },
    {
        data: { name: 'Kitting' },
        path: 'kitting',
        component: KittingComponent,
    },
    {
        data: { name: 'Kitting Lines' },
        path: 'kittinglines',
        component: KittingLinesComponent,
    },
    {
        data: { name: 'Replenishment' },
        path: 'replenishment',
        component: ReplenishmentComponent,
    },
];
