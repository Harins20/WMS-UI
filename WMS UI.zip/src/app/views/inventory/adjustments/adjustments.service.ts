import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AdjustmentKey } from './adjustments.model';
import { AuthService } from '../../../common/services';
import { ResponseDto } from '../../../common/models';
import { AppConfigService } from '../../../../app.config.service';

interface AdjustmentPage {
    Adjustment: AdjustmentKey[];
    totalRecords: number;
}

@Injectable({
    providedIn: 'root',
})
export class AdjustmentService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getAdjustment() {
        return this.httpClient.get<ResponseDto<AdjustmentKey[]>>(
            this.config.appConfig()?.InvUrl + 'Adjustments',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getAdjustmentPages(data: any) {
        return this.httpClient.post<AdjustmentPage>(
            this.config.appConfig()?.InvUrl + 'Adjustments/Page',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
