export interface AdjustmentKey {
    AdjustmentKey: string;
    TRADERKEY: string;
    SKU: string;
    UOM: string;
    PACKKEY: string;
    QTY: Number;
    ITRNKEY: string;
    ACTUALGROSSWGT: Number;
    ACTUALNETWGT: Number;
    ACTUALTAREWGT: Number;
    ADJGROSSWGT: Number;
    ADJNETWGT: Number;
    AddWho: string;
    AddDate: Date;
    EditWho: string;
    EditDate: Date;
}
