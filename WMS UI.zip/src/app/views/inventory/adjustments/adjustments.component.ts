import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { MenuItem, MessageService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { finalize, first } from 'rxjs';
import { AdjustmentColumns } from './adjustments.columns';
import { AdjustmentKey } from './adjustments.model';
import { AdjustmentService } from './adjustments.service';
import { LoadingComponent } from '../../../common/components';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { filterQuery } from '../../../common/functions';
import { OptionsService } from '../../../common/services';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
@Component({
    selector: 'app-adjustment',
    standalone: true,
    imports: [CommonModule, LoadingComponent, CustomTablePaginationComponent],
    templateUrl: './adjustments.component.html',
    styleUrl: './adjustments.component.scss',
})
export class AdjustmentComponent {
    private translate = inject(TranslateService);
    private messageService = inject(MessageService);
    private adjustmentService = inject(AdjustmentService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    private optionService = inject(OptionsService);
    adjustment = signal<AdjustmentKey[]>([]);
    adjustmentForExcel = signal<AdjustmentKey[]>([]);
    loadEvent = signal<any>({});
    optionsData = signal<{ [key: string]: any[] }>({
        TRADERKEY: [],
        SKU: [],
        PACKKEY: [],
        UOM: [],
    });
    searchInput = signal<string | undefined>(undefined);
    OrginalColumns = signal(AdjustmentColumns);
    selectedColumns = linkedSignal(() => this.columns());
    loading = signal(false);
    rows = signal(20);
    totalRecords = signal(0);
    columns = signal(
        Object.values(AdjustmentColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x) => x.tableAlias && !x.tableHidden)
            .map((x) => x.field),
    );
    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    ngOnInit() {
        this.loadOptions();
    }

    refresh() {
        this.searchInput.set(undefined);
    }

    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     if (event.rows) {
    //         this.rows.set(event.rows);
    //     }
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         AdjustmentColumns,
    //         'rd.',
    //     );

    //     this.getAdjustmentsPage({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getAdjustmentsPage(event);
    }
    loadOptions() {
        // this.GetItemOptions();
        // this.GetPackkeyOptions();
        // this.GetUomOptions();
        // this.GetOwnerOptions();
    }

    GetItemOptions() {
        const subscription = this.optionService.getItems().subscribe({
            next: (data) =>
                this.optionsData.update((old) => ({ ...old, SKU: data })),
            error: (err) =>
                console.error('Error fetching item dropdown data:', err),
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPackkeyOptions() {
        const subscription = this.optionService.getPackkey().subscribe({
            next: (data) =>
                this.optionsData.update((old) => ({ ...old, PACKKEY: data })),
            error: (err) =>
                console.error('Error fetching packkey dropdown data:', err),
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetUomOptions() {
        const subscription = this.optionService.getUomTypeOptions().subscribe({
            next: (data) =>
                this.optionsData.update((old) => ({ ...old, UOM: data })),
            error: (err) =>
                console.error('Error fetching UOM dropdown data:', err),
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetOwnerOptions() {
        const subscription = this.optionService.getOwnerOptions().subscribe({
            next: (data) =>
                this.optionsData.update((old) => ({ ...old, TRADERKEY: data })),
            error: (err) =>
                console.error('Error fetching owner dropdown data:', err),
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    getAdjustmentsPage(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.adjustment.set([]);
        const subscription = this.adjustmentService
            .getAdjustmentPages(data)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res: any) => {
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }
                    const first = data?.first ?? 0;
                    this.adjustment.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: first + idx + 1,
                        })),
                    );
                    this.totalRecords.set(res.TotalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'adjustment list',
                            detail: 'Network error occured. Please check your internet connection.',
                        });
                    }
                    this.loading.set(false);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }

    export(type: string) {
        const event = this.loadEvent();
        const PageSize = this.totalRecords();
        const Page = 1;
        const { filter, orderBy } = filterQuery(
            event,
            this.globalFilterColumns(),
            AdjustmentColumns,
            'rd.',
        );

        this.getAdjustmentsPageForExcel(
            { Page, PageSize, Condition: filter, OrderBy: orderBy },
            type,
        );
    }
    getAdjustmentsPageForExcel(data: any, type: string) {
        this.loading.set(true);
        const subscription = this.adjustmentService
            .getAdjustmentPages(data)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res: any) => {
                    const records = res?.Response ?? [];
                    this.adjustmentForExcel.set(records);
                    if (type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            'Adjustments-List',
                            [],
                            records,
                        );
                    } else {
                        downloadCSVFile(records, 'Adjustments-List');
                    }
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
}
