import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../common/components';
import { ManageHolds } from './manage-holds.model';
import { ManageHoldsService } from './manage-holds.service';
import { HoldsColumns } from './manage-holds.columns';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { tableOptions } from '../../../common/constants';
import { TooltipModule } from 'primeng/tooltip';
import { Tag } from 'primeng/tag';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';

import { Dialog } from 'primeng/dialog';
import { RadioButtonModule } from 'primeng/radiobutton';
import { filterQuery } from '../../../common/functions';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-manage-holds',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        Tag,
        TooltipModule,
        AppTranslatePipe,
        Dialog,
        RadioButtonModule,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './manage-holds.component.html',
    styleUrl: './manage-holds.component.scss',
    providers: [DialogService],
})
export class HoldsComponent {
    private translate = inject(TranslateService);

    // ─── Table State ───────────────────────────────────────────────
    manageholds = signal<ManageHolds[]>([]);
    OrginalColumns = signal<any>(HoldsColumns);
    selectedManageHolds = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(15);
    columns = signal<any[]>([]);
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);

    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    // ─── Remove Hold Dialog State ───────────────────────────────────
    showRemoveHoldDialog = signal(false);
    selectedHoldType = signal<'LOT' | 'LPN' | 'LPNLOT' | null>(null);

    // Check if ALL selected rows are strictly 'LPN/Lot Hold'
    private isLPNLotHoldStatus(status: string): boolean {
        return status?.trim().toLowerCase() === 'lpn/lot hold';
    }

    showLpnDialog = false;
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    ngAfterViewInit() {
        this.columns.set(
            Object.values(HoldsColumns)
                .filter((column) => !column.tableHidden)
                .map((column: any) => {
                    if (column.field === 'STATUS') {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                }),
        );
    }
    removeLpnHold() {
        this.showLpnDialog = false;
    }

    openRemoveHoldDialog(): void {
        this.selectedHoldType.set(null);
        this.showRemoveHoldDialog.set(true);
    }

    cancelDialog(): void {
        this.showRemoveHoldDialog.set(false);
        this.selectedHoldType.set(null);
    }

    toggleHold(type: 'LOT' | 'LPN' | 'LPNLOT') {
        // Clicking the already-selected card deselects it; otherwise select it
        this.selectedHoldType.set(
            this.selectedHoldType() === type ? null : type,
        );
    }

    submitRemoveHold(): void {
        const holdType = this.selectedHoldType();

        if (!holdType) return;

        this.showRemoveHoldDialog.set(false);

        const headertext = this.translate.instant('Remove Hold');
        const value = this.translate.instant('RemoveHoldConfirmation');
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                this.loading.set(true);

                if (holdType === 'LPNLOT') {
                    // Make two calls — first remove LOT, then remove LPN
                    const filterDataLOT = this.selectedManageHolds().map((x: any) => ({
                        SERIALKEY: x.SERIALKEY,
                        STATUS: 'LOT Hold',
                        HoldNotes: x.HoldNotes,
                        HoldType: 'LOT',
                        LOT: x.LOT,
                    }));

                    const filterDataLPN = this.selectedManageHolds().map((x: any) => ({
                        SERIALKEY: x.SERIALKEY,
                        STATUS: 'LPN Hold',
                        HoldNotes: x.HoldNotes,
                        HoldType: 'LPN',
                        LOT: x.LOT,
                    }));
                    console.log(
                        filterDataLOT,
                        filterDataLPN,
                        this.selectedManageHolds(),
                    );

                    // First call — remove LOT Hold
                    this.adjustmentService
                        .removeHolds(filterDataLOT)
                        .pipe(
                            finalize(() => {
                                // Second call — remove LPN Hold
                                this.adjustmentService
                                    .removeHolds(filterDataLPN)
                                    .pipe(
                                        finalize(() => {
                                            this.loading.set(false);
                                            this.selectedManageHolds.set([]);
                                            this.selectedHoldType.set(null);
                                            this.getHoldsPage();
                                        }),
                                    )
                                    .subscribe({
                                        next: () => {
                                            this.messageService.add({
                                                severity: 'success',
                                                summary: 'Remove Hold',
                                                detail: 'All holds cleared successfully',
                                            });
                                        },
                                        error: (error) => {
                                            this.handleRemoveError(error);
                                        },
                                    });
                            }),
                        )
                        .subscribe({
                            error: (error) => {
                                this.handleRemoveError(error);
                                this.loading.set(false);
                            },
                        });
                } else {
                    // Single call for LOT or LPN
                    const filterData = this.selectedManageHolds().map((x: any) => ({
                        SERIALKEY: x.SERIALKEY,
                        STATUS: holdType === 'LOT' ? 'LOT Hold' : 'LPN Hold',
                        HoldNotes: x.HoldNotes,
                        HoldType: holdType,
                        Lot: x.LOT,
                    }));
                    console.log(filterData, this.selectedManageHolds());
                    this.adjustmentService
                        .removeHolds(filterData)
                        .pipe(
                            finalize(() => {
                                this.loading.set(false);
                                this.selectedManageHolds.set([]);
                                this.selectedHoldType.set(null);
                                this.getHoldsPage();
                            }),
                        )
                        .subscribe({
                            next: () => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Remove Hold',
                                    detail:
                                        holdType === 'LOT'
                                            ? 'LOT Hold removed successfully'
                                            : 'LPN Hold removed successfully',
                                });
                            },
                            error: (error) => {
                                this.handleRemoveError(error);
                            },
                        });
                }
            } else {
                this.selectedHoldType.set(null);
            }
        });
    }

    // ─── Reusable error handler ──────────────────────────────────────
    private handleRemoveError(error: any): void {
        if (
            error.error?.Message === 'One or more errors occurred!' ||
            error.error?.message === 'One or more errors occurred!'
        ) {
            this.ConfirmationRef = this.dialogService.open(
                CommonErrorboxComponent,
                {
                    inputValues: { error },
                    header: 'Multiple Error',
                    closable: true,
                    modal: true,
                    draggable: true,
                    keepInViewport: true,
                    width: '39rem',
                    style: { maxHeight: '40rem' },
                },
            );
        } else {
            this.messageService.add({
                severity: 'error',
                summary: 'Remove Hold',
                detail: error as string,
            });
        }
        this.loading.set(false);
    }

    // ─── Export ─────────────────────────────────────────────────────
    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    // ─── Injected Services ──────────────────────────────────────────
    private messageService = inject(MessageService);
    private adjustmentService = inject(ManageHoldsService);
    private excelDownloadService = inject(ExcelDownloadService);
    private destoryRef = inject(DestroyRef);
    private dialogService = inject(DialogService);

    ConfirmationRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;

    constructor() {}

    ngOnInit() {
        // this.getHoldsPage();
    }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getHoldsPage(event);
    }
    // loadData(event: any) {
    //     this.loadEvent.set(event);

    //     const Page = event.Page || 1;
    //     const PageSize = event.PageSize || this.rows();

    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         HoldsColumns,
    //         'vw.',
    //     );

    //     this.getHoldsPage({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    // loadData(event: any) {
    //     this.loadEvent.set(event);
    //     this.getHoldsPage();
    // }
    // loadData(event: TableLazyLoadEvent) {
    //     console.log(event);

    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         HoldsColumns,
    //         'vw.',
    //     );
    //     this.getHoldsPage({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    // ─── Data ────────────────────────────────────────────────────────
    // getHolds() {
    //     this.loading.set(true);
    //     this.manageholds.set([]);
    //     const subscription = this.adjustmentService
    //         .getManageHolds()
    //         .pipe(finalize(() => this.loading.set(false)))
    //         .subscribe({
    //             next: (res) => {
    //                 this.manageholds.set(
    //                     res.Response.Holds.map((x: any, idx: number) => ({
    //                         ...x,
    //                         rowId: idx + 1,
    //                     })),
    //                 );
    //             },
    //             error: (error: HttpErrorResponse) => {
    //                 if (error.status === 0) {
    //                     this.messageService.add({
    //                         severity: 'error',
    //                         summary: 'Holds list',
    //                         detail: 'Network error occurred. Please check your internet connection and contact the administrator if required.',
    //                     });
    //                 }
    //                 this.loading.set(false);
    //             },
    //         });

    //     this.destoryRef.onDestroy(() => subscription.unsubscribe());
    // }
    getHoldsPage(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.manageholds.set([]);
        const subscription = this.adjustmentService
            .getManageHoldsPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy?.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }
                    const first = data?.first ?? 0;
                    this.manageholds.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: first + idx + 1,
                        })),
                    );
                    this.totalRecords.set(res.TotalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Manage Holds',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    } else if (
                        error.error.Message ===
                            'One or more errors occurred!' ||
                        error.error.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: error,
                                },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                    } else {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Manage Holds',
                            detail:
                                error.error.message ||
                                (error.error.Message as string),
                        });
                    }
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    // ─── Table Helpers ───────────────────────────────────────────────
    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getHoldsPage();
    }

    refresh() {
        this.searchInput.set(undefined);
    }

    // exportExcel() {
    //     this.excelDownloadService.downloadExcelFile(
    //         'Manage-Holds-List',
    //         [],
    //         this.manageholds(),
    //     );
    // }

    // exportCSV() {
    //     downloadCSVFile(this.manageholds(), 'Manage-Holds-List');
    // }
    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }

    export(type: string) {
        const event = this.loadEvent();
        event.rows = this.totalRecords();

        this.getHoldsForExcel(event, type);
    }

    getHoldsForExcel(data: any = { Page: 1, PageSize: 20 }, type: string) {
        this.loading.set(true);

        const pageSize = 20;
        const allHolds: any[] = [];
        let totalRecords = 0;

        const fetchPage = (page: number) => {
            const subscription = this.adjustmentService
                .getManageHoldsPage({
                    ...data,
                    Page: page,
                    PageSize: pageSize,
                })
                .subscribe({
                    next: (res: any) => {
                        const holds = res?.Response ?? [];

                        allHolds.push(...holds);
                        totalRecords = res?.TotalRecords ?? totalRecords;

                        if (
                            allHolds.length < totalRecords &&
                            holds.length > 0
                        ) {
                            fetchPage(page + 1);
                            return;
                        }

                        this.loading.set(false);

                        if (type === 'Excel') {
                            this.excelDownloadService.downloadExcelFile(
                                'Manage-Holds-List',
                                [],
                                allHolds,
                            );
                        } else {
                            downloadCSVFile(allHolds, 'Manage-Holds-List');
                        }
                    },
                    error: (error: HttpErrorResponse) => {
                        this.loading.set(false);

                        this.messageService.add({
                            severity: 'error',
                            summary: 'Manage Holds Export',
                            detail:
                                error?.error?.Message ||
                                error?.error?.message ||
                                'Failed to export holds.',
                        });
                    },
                });

            this.destoryRef.onDestroy(() => subscription.unsubscribe());
        };

        fetchPage(1);
    }

    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.manageholds().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    // ─── Selection Computed ──────────────────────────────────────────
    enableButtonOnSingleSelection = computed(
        () => this.selectedManageHolds().length === 1,
    );

    enableButtonOnOneOrMoreSelection = computed(
        () => this.selectedManageHolds().length > 0,
    );

    // ─── Column Settings ─────────────────────────────────────────────
    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe(() => {});
    }

    onEditAction(holds: ManageHolds) {}

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
