import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AuthService } from '../../../common/services';
import { ResponseDto } from '../../../common/models';
import { AppConfigService } from '../../../../app.config.service';
import { ManageHolds } from './manage-holds.model';
import { map } from 'rxjs';
import { HoldsColumns } from './manage-holds.columns';
import { stringToDate } from '../../../common/functions';

interface HoldsPage {
    Response: {
        Holds: ManageHolds[];
        TotalRecords: number;
    };
    Message: string;
    Success: boolean;
}

@Injectable({
    providedIn: 'root',
})
export class ManageHoldsService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getManageHolds() {
        return this.httpClient.get<ResponseDto<ManageHolds[]>>(
            this.config.appConfig()?.InvUrl + 'holds',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getManageHoldsPage(data: any) {
        return this.httpClient
            .post<HoldsPage>(
                this.config.appConfig()?.InvUrl + 'Holds/page',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response) => {
                    if (response?.Response?.Holds) {
                        response.Response.Holds.forEach((hold: any) => {
                            Object.keys(hold).forEach((key) => {
                                if (HoldsColumns[key]?.type === 'date') {
                                    hold[key] = stringToDate(hold[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    removeHolds(adjustItem: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InvUrl + 'holds/remove',
            adjustItem,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
