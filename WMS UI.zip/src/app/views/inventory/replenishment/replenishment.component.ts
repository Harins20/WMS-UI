import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';

import { MessageService, MenuItem } from 'primeng/api';
import { DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';
import { TabService } from '../../../tabs';
import { Table, TableModule } from 'primeng/table';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { TagModule } from 'primeng/tag';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { ReplenishmentColumns } from './replenishment.columns';
import { ReplenishmentService } from './replenishment.service';
import { ColumnPicklistComponent } from '../../../common/components';
import { ExcelDownloadService } from '../../../common/services';

@Component({
    selector: 'app-replenishment',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        TagModule,
        AppTranslatePipe, ],
    templateUrl: './replenishment.component.html',
    styleUrl: './replenishment.component.scss',
})
export class ReplenishmentComponent {
    replenishment = signal<any[]>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    private replenishmentService = inject(ReplenishmentService);
    ref: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private tabService = inject(TabService);
    private excelDownloadService = inject(ExcelDownloadService);
    private destroyRef = inject(DestroyRef);
    columnPicklistRef: DynamicDialogRef | undefined;

    private dialogService = inject(DialogService);
    columns = signal(
        Object.values(ReplenishmentColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    private translate = inject(TranslateService);
    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    ngOnInit() {
        this.getreplenishmentList();
    }

    getreplenishmentList() {
        const subscription = this.replenishmentService
            .GetreplenishmentList()
            .subscribe({
                next: (res: any) => {
                    this.replenishment.set(
                        res.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getreplenishmentList();
    }

    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            'Replenishment',
            [],
            this.replenishment(),
        );
    }
    exportCSV() {
        this.dt().exportCSV();
    }
    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '45rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }
    options(field: string) {
        const uniqueValues = new Set(
            this.replenishment().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }
}
