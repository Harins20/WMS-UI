import { Validators } from '@angular/forms';
import { Columns } from '../../../common/models';

export const ReplenishmentColumns: Columns = {
    rowId: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
    },
    id: {
        label: 'Replenishment Id',
        field: 'id',
    },
    TraderKey: {
        label: 'Owner',
        field: 'TraderKey',
    },
    Sku: {
        label: 'Sku',
        field: 'Sku',
    },
    Description: {
        label: 'Description',
        field: 'Description',
    },
    Loc: {
        label: 'Location',
        field: 'Loc',
    },
    Suggested_Loc: {
        label: 'Suggested Location',
        field: 'Suggested_Loc',
    },
    RequiredQty: {
        label: 'Required Quantity',
        field: 'RequiredQty',
    },
    MovedQty: {
        label: 'Moved Quantity',
        field: 'MovedQty',
    },
    Status: {
        label: 'Status',
        field: 'Status',
    },
    AddWho: {
        label: 'Created By',
        field: 'AddWho',
        type: 'text',
        restrictInsert: true,
        restrictEdit: true,
    },
    AddDate: {
        label: 'Created At',
        field: 'AddDate',
        type: 'date',
    },
    EditWho: {
        label: 'Edit By',
        field: 'EditWho',
        type: 'text',
        restrictInsert: true,
        restrictEdit: true,
        tableHidden: true,
    },
    EditDate: {
        label: 'Edit At',
        field: 'EditDate',
        type: 'date',
        tableHidden: true,
    },
};
