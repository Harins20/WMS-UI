import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppConfigService } from '../../../../app.config.service';
import { AuthService } from '../../../common/services';

@Injectable({
    providedIn: 'root',
})
export class ReplenishmentService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    GetreplenishmentList() {
        return this.httpClient.get(
            this.config.appConfig()?.InvUrl + 'replenishment',
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
