import { Component, DestroyRef, inject, input, signal } from '@angular/core';
import { KittingColumns } from '../kitting.columns';
import {
    FormControl,
    FormGroup,
    FormsModule,
    ReactiveFormsModule,
} from '@angular/forms';
import {
    InputSelectComponent,
    InputTextComponent,
    InputNumberComponent,
} from '../../../../common/components';
import { OptionsService } from '../../../../common/services';
import { selectOption } from '../../../../common/models';
import { BomService } from '../../../masters/bom/bom.service';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { markAllControlsAsDirty } from '../../../../common/functions/validation';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-kitting-form',
    imports: [
        FormsModule,
        ReactiveFormsModule,
        InputTextComponent,
        InputNumberComponent,
        InputSelectComponent,
        ButtonModule,
    ],
    templateUrl: './kitting-form.component.html',
})
export class KittingFormComponent {
    kittingData = input<any>();
    private optionService = inject(OptionsService);
    private messageService = inject(MessageService);
    private BomService = inject(BomService);
    private destroyRef = inject(DestroyRef);
    private ref = inject(DynamicDialogRef);
    ownerOptions = signal<selectOption[]>([]);
    masterItemOptions = signal<selectOption[]>([]);
    recipeNameOptions = signal<selectOption[]>([]);
    formControls: any = Object.fromEntries(
        Object.values(KittingColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    form = new FormGroup(this.formControls);
    ngOnInit() {
        this.getOwnerOption();
        if (this.kittingData()) {
            this.form.patchValue({
                ...this.kittingData(),
            });
            Object.values(KittingColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.form.controls[column.field].disable();
            });
        } else {
            Object.values(KittingColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.form.controls[column.field].disable();
            });
        }
        this.handleRecipeId();
    }

    getOwnerOption() {
        const subscription = this.optionService.getTraderOptions().subscribe({
            next: (res: any) => {
                this.ownerOptions.set(res);
                console.log(res);
            },
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    masterItem = this.form.controls['TraderKey'].valueChanges.subscribe(
        (value) => {
            if (value) {
                this.getMasterItemOption(value);
                console.log(value);
            }
        },
    );
    receipeName = this.form.controls['MasterItem'].valueChanges.subscribe(
        (value) => {
            if (value) {
                this.getRecipeName(value);
                console.log(value);
            }
        },
    );
    handleRecipeId() {
        this.form
            .get('RecipeName')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;
                const recipe: any = this.recipeNameOptions().find(
                    (recipe) => recipe.value === selectedValue,
                );
                if (recipe) {
                    this.form.patchValue({
                        RecipeId: recipe.SerialKey,
                    });
                    this.form.updateValueAndValidity();
                }
            });
    }
    getMasterItemOption(data: any) {
        const subscription = this.BomService.getKittingList().subscribe({
            next: (res: any) => {
                if (res) {
                    this.masterItemOptions.set(
                        res.Response.filter((x: any) => x.StorerKey === data)
                            .filter(
                                (x: any, index: number, self: any[]) =>
                                    self.findIndex(
                                        (y: any) => y.Sku === x.Sku,
                                    ) === index,
                            )
                            .map((x: any) => ({
                                label: x.Sku,
                                value: x.Sku,
                            })),
                    );
                }
            },
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getRecipeName(data: any) {
        const subscription = this.BomService.getKittingList().subscribe({
            next: (res: any) => {
                if (res) {
                    console.log(data);
                    console.log(res);
                    this.recipeNameOptions.set(
                        res.Response.filter((x: any) => x.Sku === data).map(
                            (x: any) => ({
                                ...x,
                                label: x.KitName,
                                value: x.KitName,
                            }),
                        ),
                    );
                    console.log(this.masterItemOptions());
                }
            },
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    onSubmit() {
        if (this.form.valid) {
            this.ref.close(this.form.getRawValue());
            this.form.reset();
        } else {
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
    onCancel() {
        this.ref.close();
    }
}
