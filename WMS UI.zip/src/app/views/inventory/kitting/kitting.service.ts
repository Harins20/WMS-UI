import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppConfigService } from '../../../../app.config.service';
import { AuthService } from '../../../common/services';

@Injectable({
    providedIn: 'root',
})
export class KittingService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getKitting() {
        return this.httpClient.get(
            this.config.appConfig()?.InvUrl + 'kitting',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    createKitting(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InvUrl + 'kitting',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getKittingLines(Id: any) {
        return this.httpClient.get(
            this.config.appConfig()?.InvUrl + `kitting/${Id}`,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    allocateKitting(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InvUrl + `kitting/allocate`,
            {},
            { headers: this.authService.getAuthHeaders() },
        );
    }
    pickKitting(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InvUrl + `kitting/pick`,
            {},
            { headers: this.authService.getAuthHeaders() },
        );
    }
    assembleKitting(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InvUrl + `kitting/assemble`,
            {},
            { headers: this.authService.getAuthHeaders() },
        );
    }
    storeKitting(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InvUrl + `kitting/store`,
            {},
            { headers: this.authService.getAuthHeaders() },
        );
    }
    confirmKitting(Id: number) {
        return this.httpClient.put(
            this.config.appConfig()?.InvUrl + `kitting/${Id}/confirm`,
            {},
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
