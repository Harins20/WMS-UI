import { Validators } from '@angular/forms';
import { Columns } from '../../../../common/models';

export const KittingLinesColumns: Columns = {
    // rowId: {
    //     label: 'S/No',
    //     field: 'rowId',
    //     type: 'number',
    // },
    KitId: {
        label: 'Kit Id',
        field: 'KitId',
    },
    Id: {
        label: 'Id',
        field: 'Id',
    },
    TraderKey: {
        label: 'Owner',
        field: 'TraderKey',
        type: 'select',
        validators: [Validators.required],
    },
    MasterItem: {
        label: 'Master Item',
        field: 'MasterItem',
        validators: [Validators.required],
    },
    RecipeName: {
        label: 'Recipe Name',
        field: 'RecipeName',
        validators: [Validators.required],
    },
    RecipeId: {
        label: 'Recipe Id',
        field: 'RecipeId',
        restrictInsert: true,
        restrictEdit: true,
        validators: [Validators.required],
    },
    TargetQty: {
        label: 'Target Quantity',
        field: 'TargetQty',
        validators: [Validators.required],
    },
    AssembledQty: {
        label: 'Assembled Quantity',
        field: 'AssembledQty',
    },
    Status: {
        label: 'Status',
        field: 'Status',
    },
    CreatedBy: {
        label: 'Created By',
        field: 'CreatedBy',
        type: 'text',
        restrictInsert: true,
        restrictEdit: true,
    },
    CreatedAt: {
        label: 'Created At',
        field: 'CreatedAt',
        type: 'date',
        restrictInsert: true,
        restrictEdit: true,
        defaultValue: new Date(),
    },
    EditedBy: {
        label: 'Edited By',
        field: 'EditedBy',
        type: 'text',
        restrictInsert: true,
        restrictEdit: true,
    },
    EditedAt: {
        label: 'Edited At',
        field: 'EditedAt',
        type: 'date',
        restrictInsert: true,
        restrictEdit: true,
        defaultValue: new Date(),
    },
};
