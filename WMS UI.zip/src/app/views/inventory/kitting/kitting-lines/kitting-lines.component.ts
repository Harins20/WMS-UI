import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';

import { MessageService, MenuItem } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { TabService } from '../../../../tabs';
import { KittingService } from '../kitting.service';
import { KittingLinesColumns } from './kitting-lines.columns';
import { ExcelDownloadService } from '../../../../common/services/excel-download.service';
import { ColumnPicklistComponent } from '../../../../common/components/column-picklist/column-picklist.component';
import { LoadingComponent } from '../../../../common/components';

@Component({
    selector: 'app-kitting-lines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        TagModule,
        AppTranslatePipe, LoadingComponent,
    ],
    templateUrl: './kitting-lines.component.html',
    styleUrl: './kitting-lines.component.scss',
})
export class KittingLinesComponent {
    kittinglines = signal<any[]>([]);
    Id = input.required<string>();
    searchInput = signal<string | undefined>(undefined);
    exportFileName = 'Kittinglines-List';
    private excelDownloadService = inject(ExcelDownloadService);
    loading = signal(false);
    private destroyRef = inject(DestroyRef);
    dt = viewChild.required<Table>('dt');
    private kittingService = inject(KittingService);
    ref: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private tabService = inject(TabService);
    private dialogService = inject(DialogService);
    columns = signal(
        Object.values(KittingLinesColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    private translate = inject(TranslateService);
    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    ngOnInit() {
        if (this.Id()) {
            this.getKittingLines();
        }
    }

    getKittingLines() {
        const subscription = this.kittingService
            .getKittingLines(this.Id())
            .subscribe({
                next: (res: any) => {
                    this.kittinglines.set([res]);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getKittingLines();
    }

    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.kittinglines(),
        );
    }
    exportCSV() {
        this.dt().exportCSV();
    }
    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.ref = this.dialogService.open(ColumnPicklistComponent, {
            inputValues: {
                selectedColumns: this.selectedColumns(),
                unSelectedColumns: this.unSelectedColumns(),
            },
            header: headertext,
            closable: true,
            modal: true,
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {});
    }
    options(field: string) {
        const uniqueValues = new Set(
            this.kittinglines().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }
    allocate() {
        const data = '';
        const subscription = this.kittingService
            .allocateKitting(data)
            .subscribe({
                next: (res: any) => {},
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    pick() {
        const data = '';
        const subscription = this.kittingService.pickKitting(data).subscribe({
            next: (res: any) => {},
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    assemble() {
        const data = '';
        const subscription = this.kittingService
            .assembleKitting(data)
            .subscribe({
                next: (res: any) => {},
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    store() {
        const data = '';
        const subscription = this.kittingService.storeKitting(data).subscribe({
            next: (res: any) => {},
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
}
