import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';

import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { KittingColumns } from './kitting.columns';
import { MenuItem, MessageService } from 'primeng/api';
import { KittingService } from './kitting.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { KittingFormComponent } from './kitting-form/kitting-form.component';
import inventoryRoutes from '../inventory.routes';
import { Route } from '@angular/router';
import { TabService } from '../../../tabs/tab.service';
import { HttpErrorResponse } from '@angular/common/http';
import { finalize } from 'rxjs';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import {
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../common/components';

@Component({
    selector: 'app-kitting',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        TagModule,
        AppTranslatePipe,
        LoadingComponent,
    ],
    templateUrl: './kitting.component.html',
    styleUrl: './kitting.component.scss',
    providers: [DialogService],
})
export class KittingComponent {
    kitting = signal<any[]>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    private kittingService = inject(KittingService);
    private destroyRef = inject(DestroyRef);
    ref: DynamicDialogRef | undefined;
    ConfirmationRef: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private tabService = inject(TabService);
    exportFileName = 'Kitting-List';
    private dialogService = inject(DialogService);
    private excelDownloadService = inject(ExcelDownloadService);
    columns = signal(
        Object.values(KittingColumns).filter((column) => !column.tableHidden),
    );
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    private translate = inject(TranslateService);
    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    ngOnInit() {
        this.getKitting();
    }

    getKitting() {
        this.loading.set(true);
        this.kitting.set([]);
        const subscription = this.kittingService
            .getKitting()
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    this.kitting.set(
                        res.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Kitting list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    this.loading.set(false);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getKitting();
    }

    OpenCreateForm() {
        this.ref = this.dialogService.open(KittingFormComponent, {
            header: 'Create Kitting',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '65rem',
            style: { height: '45rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const headertext = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('KittingCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: headertext,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        const subscription = this.kittingService
                            .createKitting(data)
                            .pipe()
                            .subscribe({
                                next: (res: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Kitting Creation',
                                        detail: 'Kitting created successfully.',
                                    });
                                    this.getKitting();
                                },
                                error: (error) => {
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Kitting Creation',
                                        detail: error.error.Message,
                                    });
                                },
                            });
                        this.destroyRef.onDestroy(() => subscription.unsubscribe());
                    }
                });
            }
        });
    }

    openUpdateForm(data: any) {
        this.ref = this.dialogService.open(KittingFormComponent, {
            inputValues: {
                kittingData: data,
            },
            header: 'Update Kitting',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '65rem',
            style: { height: '45rem' },
        });
    }

    confrimKitting(data: any) {
        const headertext = this.translate.instant('Confirm Kitting');
        const value = this.translate.instant('KittingConfirmation');
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                const subscription = this.kittingService
                    .confirmKitting(data.Id)
                    .pipe(
                        finalize(() => {
                            this.getKitting();
                        }),
                    )
                    .subscribe({
                        next: () => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Kitting Confirmation',
                                detail: `Kitting #${data.Id} confirmed successfully`,
                            });
                        },
                        error: (error) => {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Kitting Confirmation',
                                detail: `Kitting #${data.Id} already confirmed `,
                            });
                            console.error(error);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.kitting(),
        );
    }
    exportCSV() {
        this.dt().exportCSV();
    }
    showColumnsSettingsDialog() {}
    options(field: string) {
        const uniqueValues = new Set(this.kitting().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }
    onClickKitId(event: any, row: any): void {
        event.preventDefault();
        const route = inventoryRoutes.find(
            (route) => route.data?.name === 'Kitting Lines',
        ) as Route;
        var params = [{ name: 'Id', value: row.Id }];
        this.tabService.addTabWithParams(
            route,
            '',
            'Kitting Lines - ' + row.KitId,
            params,
        );
    }
}
