import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AuthService } from '../../../common/services';
import { AppConfigService } from '../../../../app.config.service';
import { Configkey } from './configuration.model';
import { map } from 'rxjs';
import { formatDateObject } from '../../../common/functions';

@Injectable({
    providedIn: 'root',
})
export class ConfigurationService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getConfigList(owner: string = 'All') {
        return this.httpClient
            .get<
                Configkey[]
            >(this.config.appConfig()?.ConfigUrl + `seriesConfig?Owner=${owner}`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((configs) =>
                    configs.map((config, idx) => ({
                        ...formatDateObject(config),
                        rowId: idx + 1,
                    })),
                ),
            );
    }

    createConfig(data: any) {
        return this.httpClient.post<string>(
            this.config.appConfig()?.ConfigUrl + 'seriesConfig',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
