import { Validators } from '@angular/forms';
import { Columns } from '../../../common/models';

export const ConfigurationColumns: Columns = {
    rowId: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
    },
    ID: {
        label: 'ID',
        field: 'Id',
        type: 'select',
        validators: [Validators.maxLength(60)],
        restrictEdit: true,
        tableHidden: true,
    },
    Name: {
        label: 'Name',
        field: 'Name',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(50)],
        restrictEdit: true,
    },
    Owner: {
        label: 'Owner',
        field: 'Owner',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(50)],
        restrictEdit: true,
    },

    CreatedBy: {
        label: 'Created By',
        field: 'CreatedBy',
        type: 'text',
        restrictInsert: true,
        restrictEdit: true,
    },
    CreatedAt: {
        label: 'Created At',
        field: 'CreatedAt',
        type: 'date',
        validators: [Validators.maxLength(50)],
        restrictInsert: true,
        restrictEdit: true,
        defaultValue: new Date(),
    },
    CopyId: {
        label: 'Copy Template From',
        field: 'CopyId',
        validators: [Validators.maxLength(50)],
        restrictInsert: true,
        restrictEdit: true,
        tableHidden: true,
        defaultValue: 1,
    },
};
