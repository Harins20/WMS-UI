import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { TooltipModule } from 'primeng/tooltip';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
} from '../../../common/components';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { Configkey } from './configuration.model';
import { ConfigurationService } from './Configuration.service';
import { ConfigurationColumns } from './configuration.columns';
import { tableOptions } from '../../../common/constants';
import { ConfigurationFormComponent } from './configuration-form/configuration-form.component';
import configurationRoutes from '../configuration.routes';
import { Route } from '@angular/router';
import { TabService } from '../../../tabs';
import { TagModule } from 'primeng/tag';


@Component({
    selector: 'app-configuration',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TagModule,
        TooltipModule,
        AppTranslatePipe, ],
    templateUrl: './configuration.component.html',
    styleUrl: './configuration.component.scss',
    providers: [DialogService],
})
export class ConfigurationComponent {
    private translate = inject(TranslateService);
    configurations = signal<Configkey[]>([]);
    selectedConfiguration = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    tableOptions = signal(tableOptions);
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    exportFileName = 'Configurations';
    dt = viewChild.required<Table>('dt');
    tablePaginationMessage =
        'Showing {first} to {last} of {totalRecords} Configurations';
    columns = signal(
        Object.values(ConfigurationColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    ref: DynamicDialogRef | undefined;

    private messageService = inject(MessageService);
    private configurationService = inject(ConfigurationService);
    private destoryRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    private tabService = inject(TabService);

    columnPicklistRef: DynamicDialogRef | undefined;
    ConfirmationRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    constructor() {}
    ngOnInit() {
        this.getConfigs();
    }

    getConfigs() {
        this.loading.set(true);
        this.configurations.set([]);
        const subscription = this.configurationService
            .getConfigList()
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res) => {
                    this.configurations.set(res);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Configuration List',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getConfigs();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.configurations(),
        );
    }
    exportCSV() {
        this.dt().exportCSV();
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.configurations().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedConfiguration().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedConfiguration().length >= 1 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }
    onClickConfigName(event: any, row: Configkey) {
        event.preventDefault();
        const route = configurationRoutes.find(
            (route) => route.data?.name === 'ConfigLines',
        ) as Route;
        var params = [{ name: 'ConfigId', value: row.Id }];
        this.tabService.addTabWithParams(
            route,
            '',
            'Config Details - ' + row.Name,
            params,
        );
    }
    OpenCreateConfigForm() {
        const headertext = this.translate.instant('Create Config');
        this.ref = this.dialogService.open(ConfigurationFormComponent, {
            header: headertext,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '55rem',
            style: { height: '45rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('ConfigCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: { message: value },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.configurationService
                            .createConfig(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getConfigs();
                                }),
                            )
                            .subscribe({
                                next: (data) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Success',
                                        detail: data,
                                    });
                                },

                                error: (error) => {
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Failed',
                                        detail: 'Failed to create Config.' as string,
                                    });
                                },
                            });
                    }
                });
            }
        });
    }
}
