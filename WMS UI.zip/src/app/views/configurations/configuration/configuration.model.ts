export interface Configkey {
    Id: Number;
    Owner: string;
    Name: string;
    CreatedBy: string;
    CreatedAt: string;
    CopyId: Number;
}
