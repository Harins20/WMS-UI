import { Component, DestroyRef, inject, input, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import { selectOption } from '../../../../common/models';
import { OptionsService } from '../../../../common/services';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { ConfigurationColumns } from '../configuration.columns';
import { ConfigurationService } from '../Configuration.service';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';

@Component({
    selector: 'app-configuration-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        Select,
        ButtonModule,
        AppTranslatePipe, ],
    templateUrl: './configuration-form.component.html',
})
export class ConfigurationFormComponent {
    configData = input<any>();

    private destoryRef = inject(DestroyRef);
    private ref = inject(DynamicDialogRef);
    private optionService = inject(OptionsService);
    private configurationService = inject(ConfigurationService);

    private destroyRef = inject(DestroyRef);

    loading = signal(false);
    formControls: any = Object.fromEntries(
        Object.values(ConfigurationColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue || '', {
                validators: column.validators,
            }),
        ]),
    );
    form = new FormGroup(this.formControls);
    ownerOptions = signal<selectOption[]>([]);
    copyIdOptions = signal<selectOption[]>([]);

    ngOnInit() {
        if (this.configData()) {
            this.form.patchValue({
                ...this.configData(),
            });
        }

        this.GetOwnerOptions();
        this.GetCopyIdOptions();
    }

    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }

    GetCopyIdOptions() {
        const subscription = this.configurationService
            .getConfigList()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.copyIdOptions.set(
                        data.map((item) => {
                            return {
                                label: item.Name,
                                value: item.Id,
                            };
                        }),
                    );
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    onSubmit() {
        if (this.form.valid) {
            this.ref.close(this.form.value);
            this.form.reset();
        } else {
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
}
