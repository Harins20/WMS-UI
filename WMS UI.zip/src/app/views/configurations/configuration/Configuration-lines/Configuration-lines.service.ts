import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map } from 'rxjs';
import { AppConfigService } from '../../../../../app.config.service';
import { AuthService } from '../../../../common/services';
import { formatDateObject } from '../../../../common/functions';
import { ConfigLineskey } from './configuration-lines.model';

@Injectable({
    providedIn: 'root',
})
export class ConfigurationLinesService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getConfigLinesList(ConfigId: number) {
        return this.httpClient
            .get<
                ConfigLineskey[]
            >(this.config.appConfig()?.ConfigUrl + `seriesConfigDetail?ConfigId=${ConfigId}`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((configs) =>
                    configs.map((config, idx) => ({
                        ...formatDateObject(config),
                        rowId: idx + 1,
                    })),
                ),
            );
    }

    createConfigDetails(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.ConfigUrl + 'seriesConfigDetail',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
