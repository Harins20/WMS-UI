export interface ConfigLineskey {
    Id: Number;
    ConfigId: Number;
    Module: string;
    Prefix: string;
    PadWith: Number;
    PadLen: string;
    CurrentSeries: string;
    CreatedBy: string;
    CreatedAt: string;
    EditedBy: string;
    EditedAt: string;
}
