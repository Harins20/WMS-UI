import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ConfigurationLinesColumns } from './configuration-lines.columns';
import { tableOptions } from '../../../../common/constants';
import { ConfigLineskey } from './configuration-lines.model';
import { ConfigurationLinesService } from './Configuration-lines.service';
import { ExcelDownloadService } from '../../../../common/services/excel-download.service';
import { TabService } from '../../../../tabs';
import { ColumnPicklistComponent } from '../../../../common/components';
import { ConfigurationLinesFormComponent } from './configuration-line-form/configuration-lines-form.component';
import { TooltipModule } from 'primeng/tooltip';

@Component({
    selector: 'app-configuration',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        AppTranslatePipe, ],
    templateUrl: './configuration-lines.component.html',
    styleUrl: './configuration-lines.component.scss',
    providers: [DialogService],
})
export class ConfigurationLinesComponent {
    private translate = inject(TranslateService);
    ConfigId = input.required<number>();
    configurationLinesList = signal<ConfigLineskey[]>([]);
    selectedConfigurationLines = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    tableOptions = signal(tableOptions);
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    exportFileName = 'Configurations-Lines';
    dt = viewChild.required<Table>('dt');
    tablePaginationMessage =
        'Showing {first} to {last} of {totalRecords} Configurations-Lines';
    columns = signal(
        Object.values(ConfigurationLinesColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    ref: DynamicDialogRef | undefined;

    private messageService = inject(MessageService);
    private configurationService = inject(ConfigurationLinesService);
    private destoryRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    private tabService = inject(TabService);

    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    constructor() {}
    ngOnInit() {
        this.getConfigLinesList();
    }

    getConfigLinesList() {
        this.loading.set(true);
        this.configurationLinesList.set([]);
        const subscription = this.configurationService
            .getConfigLinesList(this.ConfigId())
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res) => {
                    const resultValue = res.map((x) => {
                        let serialNumber = 1;
                        let previewValue = '';
                        const prefix = x.Prefix || '';
                        const padWith = x.PadWith || '';
                        const padLengthInput = x.PadLen || '10';
                        const padLength = Math.max(
                            0,
                            parseInt(padLengthInput, 10),
                        ); // Ensure padLength is non-negative
                        const serialNumberStr = serialNumber.toString();
                        let totalLength = padLength; // Use the validated padLength

                        let generatedPreview = prefix;
                        const remainingLength =
                            totalLength -
                            prefix.length -
                            serialNumberStr.length;
                        if (remainingLength > 0) {
                            generatedPreview += padWith.repeat(remainingLength);
                        }
                        generatedPreview += serialNumberStr;
                        previewValue = generatedPreview;
                        return { ...x, Preview: previewValue };
                    });

                    this.configurationLinesList.set(resultValue);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Configuration List',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getConfigLinesList();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.configurationLinesList(),
        );
    }
    exportCSV() {
        this.dt().exportCSV();
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.configurationLinesList().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedConfigurationLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedConfigurationLines().length >= 1 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    OpenEditForm(data: ConfigLineskey) {
        const headertext = this.translate.instant('Update Config Detail');
        this.ref = this.dialogService.open(ConfigurationLinesFormComponent, {
            inputValues: {
                configData: data,
            },
            header: headertext,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '55rem',
            style: { height: '45rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
            }
        });
    }
}
