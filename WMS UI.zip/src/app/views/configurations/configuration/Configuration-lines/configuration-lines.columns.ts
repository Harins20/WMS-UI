import { Validators } from '@angular/forms';
import { Columns } from '../../../../common/models';

export const ConfigurationLinesColumns: Columns = {
    rowId: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
    },
    ID: {
        label: 'Id',
        field: 'Id',
        type: 'text',
        validators: [Validators.maxLength(60)],
        restrictEdit: true,
        tableHidden: true,
    },
    ConfigId: {
        label: 'Config Id',
        field: 'ConfigId',
        type: 'text',
        validators: [Validators.maxLength(60)],
        restrictEdit: true,
    },
    Module: {
        label: 'Module',
        field: 'Module',
        type: 'text',
        validators: [Validators.maxLength(60)],
    },
    Preview: {
        label: 'Preview',
        field: 'Preview',
        type: 'text',
        validators: [Validators.maxLength(60)],
    },
    Prefix: {
        label: 'Prefix',
        field: 'Prefix',
        type: 'text',
        validators: [Validators.maxLength(60)],
    },
    PadWith: {
        label: 'Pad With',
        field: 'PadWith',
        type: 'text',
        validators: [Validators.maxLength(60)],
    },
    PadLen: {
        label: 'Pad Length',
        field: 'PadLen',
        type: 'text',
        validators: [Validators.maxLength(2)],
    },
    EditedBy: {
        label: 'Edited By',
        field: 'EditedBy',
        type: 'text',
        validators: [Validators.maxLength(60)],
        restrictEdit: true,
        tableHidden: true,
    },
    EditedAt: {
        label: 'Edited At',
        field: 'EditedAt',
        type: 'text',
        validators: [Validators.maxLength(60)],
        restrictEdit: true,
        tableHidden: true,
    },
};
