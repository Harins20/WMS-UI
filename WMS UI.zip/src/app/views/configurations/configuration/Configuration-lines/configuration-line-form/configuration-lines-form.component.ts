import { Component, DestroyRef, inject, input, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../../common/functions';
import { ConfigurationLinesColumns } from '../configuration-lines.columns';
import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';

@Component({
    selector: 'app-configuration-lines-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        AppTranslatePipe, ],
    templateUrl: './configuration-lines-form.component.html',
})
export class ConfigurationLinesFormComponent {
    configData = input<any>();

    private ref = inject(DynamicDialogRef);
    private destroyRef = inject(DestroyRef);

    loading = signal(false);
    formControls: any = Object.fromEntries(
        Object.values(ConfigurationLinesColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue || '', {
                validators: column.validators,
            }),
        ]),
    );
    form = new FormGroup(this.formControls);

    ngOnInit() {
        if (this.configData()) {
            this.form.patchValue({
                ...this.configData(),
            });
            this.changesOn();
        }
        this.form.valueChanges.subscribe(() => {
            this.changesOn();
        });
    }

    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    private serialNumber: number = 1; // This can be modified to accept user input if needed
    previewValue: string = '';

    changesOn() {
        const prefix = this.form.get('Prefix')?.value || '';
        const padWith = this.form.get('PadWith')?.value || '';
        const padLengthInput = this.form.get('PadLen')?.value || '10';
        const padLength = Math.max(0, parseInt(padLengthInput, 10)); // Ensure padLength is non-negative
        const serialNumberStr = this.serialNumber.toString();

        let totalLength = padLength; // Use the validated padLength

        let generatedPreview = prefix;

        const remainingLength =
            totalLength - prefix.length - serialNumberStr.length;

        if (remainingLength > 0) {
            generatedPreview += padWith.repeat(remainingLength);
        }

        generatedPreview += serialNumberStr;
        this.previewValue = generatedPreview;
        this.form.get('Preview')?.setValue(this.previewValue);
    }

    onCancel() {
        this.ref.close();
    }

    onSubmit() {
        if (this.form.valid) {
            this.ref.close(this.form.value);
            this.form.reset();
        } else {
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
}
