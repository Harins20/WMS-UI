import { ConfigurationLinesComponent } from './configuration/Configuration-lines/configuration-lines.component';
import { ConfigurationComponent } from './configuration/configuration.component';

export default [
    {
        data: { name: 'Configuration' },
        path: 'Config',
        component: ConfigurationComponent,
    },
    {
        data: { name: 'ConfigLines' },
        path: 'ConfigLines',
        component: ConfigurationLinesComponent,
    },
];
