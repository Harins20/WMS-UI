import { Component, DestroyRef, inject, signal } from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { RippleModule } from 'primeng/ripple';
import { AuthService } from '../../common/services';
import { markAllControlsAsDirty } from '../../common/functions/validation';
import { AppFloatingConfigurator } from '../../layout/component/app.floatingconfigurator';
import { MessageService } from 'primeng/api';
import { finalize } from 'rxjs';

@Component({
    selector: 'app-login',
    imports: [
        ButtonModule,
        CheckboxModule,
        InputTextModule,
        PasswordModule,
        ReactiveFormsModule,
        RouterModule,
        RippleModule,
        AppFloatingConfigurator,
    ],
    templateUrl: './login.component.html',
    styleUrl: './login.component.scss',
})
export class LoginComponent {
    private destoryRef = inject(DestroyRef);
    private authservice = inject(AuthService);
    private router = inject(Router);
    private messageService = inject(MessageService);
    loading = signal(false);
    loginForm = new FormGroup({
        username: new FormControl<string>('', [
            Validators.required,
            Validators.maxLength(100),
        ]),
        password: new FormControl<string>('', [Validators.required]),
    });

    constructor() {
        // sessionStorage.clear();
    }

    onSubmit() {
        if (this.loginForm.valid) {
            this.loading.set(true);

            const subscription = this.authservice
                .login(this.loginForm.value)
                .pipe(finalize(() => this.loading.set(false)))
                .subscribe({
                    next: (res: any) => {
                        const username =
                            this.loginForm?.getRawValue()?.username;

                        const encodedUsername = username ? btoa(username) : '';

                        sessionStorage.setItem('Username', encodedUsername);
                        if (res.mfaEnabled) {
                            const encodedmfaEnabled = btoa(res.mfaEnabled);
                            const encodedMfaToken = btoa(res.MfaToken);
                            const encodedMfaSetup = btoa(res.mfaSetup);

                            sessionStorage.setItem(
                                'MfaEnabled',
                                encodedmfaEnabled,
                            );
                            sessionStorage.setItem('MfaSetup', encodedMfaSetup);

                            sessionStorage.setItem(
                                'TempToken',
                                encodedMfaToken,
                            );
                            this.router.navigate([`/mfa`]);
                        } else {
                            this.authservice.token.set(
                                JSON.stringify(res.Token),
                            );
                            this.authservice
                                .loginAP(this.loginForm.value)
                                .pipe(finalize(() => this.loading.set(false)))
                                .subscribe({
                                    next: (resAp: any) => {
                                        this.authservice.tokenAp.set(
                                            JSON.stringify(resAp.Token),
                                        );
                                        const encodedTokenAP = btoa(
                                            resAp.Token,
                                        );
                                        sessionStorage.setItem(
                                            'TokenAp',
                                            encodedTokenAP,
                                        );
                                    },
                                });

                            const encodedToken = btoa(res.Token);

                            sessionStorage.setItem('Token', encodedToken);
                            this.router.navigate(['']);
                        }
                    },
                    error: (error: any) => {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Login failed',
                            detail: error.error as string,
                        });
                    },
                });
            this.destoryRef.onDestroy(() => subscription.unsubscribe());
        } else {
            this.loginForm.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.loginForm.controls));
        }
    }
}
