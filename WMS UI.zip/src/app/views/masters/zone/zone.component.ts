import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../common/components';
import { ZoneFormComponent } from './zone-form/zone-form.component';
import { ZoneColumns } from './zone.columns';
import { Zone } from './zone.model';
import { ZoneService } from './zone.service';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { tableOptions } from '../../../common/constants';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';

import { FileUpload } from 'primeng/fileupload';
import * as XLSX from 'xlsx';
import { convertExcelDate } from '../../../common/functions/numberToDate';
import { OptionsService } from '../../../common/services/options.service';
import { filterQuery } from '../../../common/functions';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
@Component({
    selector: 'app-zone',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        FileUpload,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        TooltipModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './zone.component.html',
    styleUrl: './zone.component.scss',
    providers: [DialogService],
})
export class ZoneComponent {
    zone = signal<Zone[]>([]);
    selectedZone = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    private translate = inject(TranslateService);
    tableOptions = signal(tableOptions);
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    exportFileName = 'Zones';
    dt = viewChild.required<Table>('dt');
    excelData: any = [];
    tablePaginationMessage =
        'Showing {first} to {last} of {totalRecords} Zones';
    columns = signal<any>([]);
    totalRecords = signal(0);
    rows = signal(15);
    loadEvent = signal<any>({});
    OrginalColumns = signal<any>(ZoneColumns);
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x: any) => x.tableAlias && !x.tableHidden)
            .map((x: any) => x.field),
    );

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    userFormRef: DynamicDialogRef | undefined;
    private router = inject(Router);
    private messageService = inject(MessageService);
    private zoneService = inject(ZoneService);
    private destoryRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    ConfirmationRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private optionService = inject(OptionsService);
    constructor() {}
    ngOnInit() {
        // this.getZone(this.loadEvent);
        this.getColumns();
    }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getZone(event);
    }
    getColumns() {
        this.optionService.getColumns(ZoneColumns, 'ZONE').subscribe({
            next: (data) => {
                const FilterField = data.map((x: any) => x.field);
                const GetFilterFields = Object.values(ZoneColumns).filter(
                    (x: any) => {
                        return !FilterField.includes(x.field);
                    },
                );
                const columns = [...GetFilterFields, ...data];
                this.columns.set(
                    columns.filter((column: any) => !column.tableHidden),
                );
            },
        });
    }
    getZone(data: any) {
        this.loading.set(true);
        this.zone.set([]);
        const subscription = this.zoneService
            .getZonePage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy?.toLowerCase().includes('serialkey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }
                    this.zone.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                    this.totalRecords.set(res.TotalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Zone list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    this.loading.set(false);
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getZone(this.loadEvent());
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getZone(this.loadEvent());
    }
    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }
    getZoneForExcel(
        data: any = {
            Page: 1,
            PageSize: this.totalRecords(),
        },
        type: string,
    ) {
        this.loading.set(true);

        const subscription = this.zoneService
            .getZonePage(data)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res: any) => {
                    const zones = res?.vw_zones || [];

                    if (type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            this.zone(),
                        );
                    } else {
                        downloadCSVFile(zones, this.exportFileName);
                    }
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    export(type: string) {
        const event = this.loadEvent();
        event.rows = this.totalRecords();
        this.getZoneForExcel(event, type);
    }
    exportExcelTemplate() {
        const Column = ['ZONEID', 'ZONE', 'DESCR'];
        this.excelDownloadService.downloadExcelFile(
            'Zone-Template',
            Column,
            null,
        );
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(this.zone().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedZone().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedZone().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '45rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    onEditAction(zone: Zone) {}

    OpenCreateZoneForm() {
        const headerText = this.translate.instant('Create Zone');
        const header = this.translate.instant('Confirm Creation');
        const value = this.translate.instant('ZoneCreation');
        this.userFormRef = this.dialogService.open(ZoneFormComponent, {
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                console.log('data', data);

                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        Object.values(ZoneColumns).forEach((x) => {
                            if (
                                data[x.field] === undefined ||
                                data[x.field] === null ||
                                data[x.field] === ''
                            ) {
                                data[x.field] = x.defaultValue;
                            }
                        });
                        const ignoredFields = Object.values(ZoneColumns)
                            .filter((col: any) => col.ignoreInRequest)
                            .map((col: any) => col.field);

                        const copy = { ...data };
                        ignoredFields.forEach((field) => {
                            delete copy[field];
                        });
                        this.loading.set(true);
                        this.zoneService
                            .createZone(copy)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getZone(this.loadEvent());
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Zone creation',
                                        detail: data as string,
                                    });
                                },
                                error: (error: any) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New Zone creation',
                                            detail: error.error as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateZoneForm(Data: any) {
        const headerText = this.translate.instant('Update Zone');
        const header = this.translate.instant('Confirm Update');
        const value = this.translate.instant('ZoneUpdate');
        this.userFormRef = this.dialogService.open(ZoneFormComponent, {
            inputValues: {
                ZoneData: Data,
            },
            // header: 'Update Receipt - ' + selectedAsn.RECEIPTKEY,
            // closable: true,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });

        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );

                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        const ignoredFields = Object.values(ZoneColumns)
                            .filter((col: any) => col.ignoreInRequest)
                            .map((col: any) => col.field);

                        const copy = { ...data };
                        ignoredFields.forEach((field) => {
                            delete copy[field];
                        });
                        this.loading.set(true);
                        this.zoneService
                            .updateZone(copy)
                            .pipe(
                                finalize(() => {
                                    this.getZone(this.loadEvent());
                                    this.loading.set(false);
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Zone Updation',
                                        detail: data as string,
                                    });
                                },
                                error: (error: any) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Zone Updation',
                                            detail: error.error as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }
    onFileUpload(event: any) {
        const file = event.files[0];
        const reader = new FileReader();
        reader.onload = async (e: any) => {
            const workbook = XLSX.read(e.target.result, { type: 'binary' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            this.excelData = XLSX.utils.sheet_to_json(worksheet, { raw: true });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const sheetData: any[][] = XLSX.utils.sheet_to_json(sheet, {
                header: 1,
            });
            if (this.excelData.length > 0) {
                const dataRows = sheetData.slice(1);
                const FinalData = dataRows.map(
                    (row: any[], rowIndex: number) => {
                        return {
                            ZONE: row[0] ? row[0].toString() : null,
                            DESCR: row[1],
                            TYPE: row[2] ? row[2].toString() : '0',
                            MAXLOCLIMIT: row[3] ? row[3].toString() : null,
                            PICKLOCLIMIT: row[4],
                            PICKTOLOCLIMIT: row[5],
                            MAXWEIGHT: row[6],
                            MAXCUBE: row[7],
                            MAXCASECNT: row[8],
                            INLOCLIMIT: row[9],
                            OUTLOC: row[10],
                            AISLESTART: row[11],
                            AISLEEND: row[12],
                            SLOTSTART: row[13],
                            SLOTEND: row[14],
                            UDFSTR1: row[15],
                            UDFSTR2: row[16],
                            UDFSTR3: row[17],
                            UDFSTR4: row[18],
                            UDFSTR5: row[19],
                            UDFDATETIME1: row[20]
                                ? convertExcelDate(row[20])
                                : null,
                            UDFDATETIME2: row[21]
                                ? convertExcelDate(row[21])
                                : null,
                            UDFDATETIME3: row[22]
                                ? convertExcelDate(row[22])
                                : null,
                            UDFDATETIME4: row[23]
                                ? convertExcelDate(row[23])
                                : null,
                            UDFDATETIME5: row[24]
                                ? convertExcelDate(row[24])
                                : null,
                            UDFFLOAT1: row[25],
                            UDFFLOAT2: row[26],
                            UDFFLOAT3: row[27],
                            UDFFLOAT4: row[28],
                            UDFFLOAT5: row[29],
                            ISACTIVE: row[30] ? row[30] : 'Active',
                            WHSEID: '',
                        };
                    },
                );
                this.loading.set(true);
                this.zoneService
                    .createZoneEdi(FinalData)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.getZone(this.loadEvent());
                        }),
                    )
                    .subscribe({
                        next: (data) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Zone Upload',
                                detail: data as string,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Zone Upload',
                                    detail: error?.error?.Message as string,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            } else {
                this.loading.set(false);
                this.messageService.add({
                    severity: 'warn',
                    summary: 'Zone Upload',
                    detail: 'The file contains no data rows. Please add data below the header row and try again.',
                });
            }
        };
        reader.readAsArrayBuffer(file);
    }

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
