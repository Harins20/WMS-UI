import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { selectOption } from '../../../../common/models';
import { AuthService, OptionsService } from '../../../../common/services';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import {
    upperCaseArray,
    upperCaseObject,
} from '../../../../shared/utils/case-conversion.util';
import { ZoneColumns } from '../zone.columns';
import { TabsModule } from 'primeng/tabs';
import { Checkbox } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import {
    ZoneLocationFormComponent,
    ZoneLocationService,
} from '../zone-location-form';
import { MessageService } from 'primeng/api';
import { InputTextComponent } from '../../../../common/components/input-text/input-text.component';
import { InputSelectComponent } from '../../../../common/components/input-select/input-select.component';
import { InputDatepickerComponent } from '../../../../common/components/input-datepicker/input-datepicker.component';
import { InputNumberComponent } from '../../../../common/components';

import { CommonModule } from '@angular/common';

@Component({
    selector: 'zone-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        TabsModule,
        Checkbox,
        DatePickerModule,
        InputNumberComponent,
        InputTextComponent,
        InputSelectComponent,
        InputDatepickerComponent,
        AppTranslatePipe,
        CommonModule,
    ],
    templateUrl: './zone-form.component.html',
    styleUrl: './zone-form.component.scss',
})
export class ZoneFormComponent {
    private translate = inject(TranslateService);
    ZoneData = input<any>();
    params = computed(() => {
        const rawZone = this.ZoneData()
            ? upperCaseObject(this.ZoneData())
            : null;
        if (rawZone?.ZONE) return `zone=${rawZone.ZONE}`;
        return 'NZone=true';
    });
    private optionService = inject(OptionsService);
    private destroyRef = inject(DestroyRef);
    private authservice = inject(AuthService);
    private locationService = inject(ZoneLocationService);
    private router = inject(Router);
    zoneColumns: any[] = [];
    private ref = inject(DynamicDialogRef);
    private dialogService = inject(DialogService);
    // ✅ Single signal for tab validation warning
    setViewTAb = signal<boolean>(true);
    // ✅ Single signal for active tab
    activeTab = signal<number>(0);
    statusOptions = signal<selectOption[]>(
        ZoneColumns['ISACTIVE'].options || [],
    );
    loading = signal(false);
    formControls: any = Object.fromEntries(
        Object.values(ZoneColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    form = new FormGroup(this.formControls);
    locationOptions = signal<selectOption[]>([]);
    inLocOption = signal<selectOption[]>([]);
    outLocOption = signal<selectOption[]>([]);
    zoneTypeOptions = signal<selectOption[]>([]);
    private messageService = inject(MessageService);

    ngOnInit() {
        // this.GetLocationOptions();
        this.GetZoneTypeOptions();
        this.GetInOutLocationOptions();
        this.form.valueChanges.subscribe(() => {
            this.filterLoc();
        });
        if (this.ZoneData()) {
            const rawZone = upperCaseObject(this.ZoneData());
            this.form.patchValue({
                ...rawZone,
                UDFDATETIME1: rawZone?.UDFDATETIME1
                    ? new Date(rawZone.UDFDATETIME1)
                    : null,
                UDFDATETIME2: rawZone?.UDFDATETIME2
                    ? new Date(rawZone.UDFDATETIME2)
                    : null,
                UDFDATETIME3: rawZone?.UDFDATETIME3
                    ? new Date(rawZone.UDFDATETIME3)
                    : null,
                UDFDATETIME4: rawZone?.UDFDATETIME4
                    ? new Date(rawZone.UDFDATETIME4)
                    : null,
                UDFDATETIME5: rawZone?.UDFDATETIME5
                    ? new Date(rawZone.UDFDATETIME5)
                    : null,
            });
            Object.values(ZoneColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.form.controls[column.field]?.disable();
            });
        } else {
            Object.values(ZoneColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.form.controls[column.field]?.disable();
            });
        }
        this.getColumns();
    }
    // ✅ Navigate to tab
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    closePanel() {
        this.ref.close();
    }
    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }
    filterLoc() {
        let data = [
            this.form.get('INLOC')?.value,
            this.form.get('OUTLOC')?.value,
        ];

        const filteredOptions = (Data: any) =>
            this.locationOptions().filter(
                (x: any) => !data.includes(x.value) || x.value === Data,
            );
        this.inLocOption.set(filteredOptions(this.form.get('INLOC')?.value));
        this.outLocOption.set(filteredOptions(this.form.get('OUTLOC')?.value));
    }
    GetInOutLocationOptions() {
        const subscription = this.locationService
            .getLocation(this.params())
            .subscribe({
                next: (data: any) => {
                    const upperData = upperCaseArray(data);
                    this.locationOptions.set(
                        upperData.map((x: any) => ({
                            label: x.LOC,
                            value: x.LOC,
                        })),
                    );
                    this.inLocOption.set(
                        upperData.map((x: any) => ({
                            label: x.LOC,
                            value: x.LOC,
                        })),
                    );
                    this.outLocOption.set(
                        upperData.map((x: any) => ({
                            label: x.LOC,
                            value: x.LOC,
                        })),
                    );
                },
                error: (err) => {
                    console.error(
                        'Error fetching Location dropdown data:',
                        err,
                    );
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetZoneTypeOptions() {
        const subscription = this.optionService.getZoneTypeOptions().subscribe({
            next: (data) => {
                this.zoneTypeOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching Zone Type dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    onClickLocations() {
        const header = this.translate.instant('Manage Zone Locations');
        const rawZone = this.ZoneData()
            ? upperCaseObject(this.ZoneData())
            : null;

        // ✅ use separate variable (DO NOT use this.ref)
        const locationRef = this.dialogService.open(ZoneLocationFormComponent, {
            inputValues: {
                zone: rawZone?.ZONE,
            },
            header: header,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '55rem',
            style: { height: '45rem' },
        });

        locationRef.onClose.subscribe((data) => {
            if (data) {
                // handle if needed
            }
        });
    }

    onSubmit() {
        if (this.form.valid) {
            this.setViewTAb.set(true);
            this.ref.close(this.form.getRawValue());
            this.form.reset();
        } else {
            this.setViewTAb.set(false);
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
    getColumns() {
        this.optionService.getColumns(ZoneColumns, 'ZONE').subscribe({
            next: (data) => {
                this.zoneColumns = data;
            },
        });
    }
}
