import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { Zone } from './zone.model';
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';
import { map } from 'rxjs';
import { ZoneColumns } from './zone.columns';
import {
    lowerCaseArray,
    lowerCaseObject,
    upperCaseArray,
} from '../../../shared/utils/case-conversion.util';
import { stringToDate } from '../../../common/functions';

@Injectable({
    providedIn: 'root',
})
export class ZoneService {
    SetActive = signal(false);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getZone() {
        return this.httpClient
            .get<
                Zone[]
            >(this.config.appConfig()?.MasterUrl + 'zones', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((response: any) => {
                    return upperCaseArray(response);
                }),
            );
    }
    getZonePage(data: any) {
        return this.httpClient
            .post<any>(
                this.config.appConfig()?.MasterUrl + 'zones/Page',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response) => {
                    if (response?.Response) {
                        response.Response = upperCaseArray(response.Response);
                        response.Response.forEach((x: any) => {
                            Object.keys(x).forEach((key) => {
                                if (ZoneColumns[key]?.type === 'date') {
                                    x[key] = stringToDate(x[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    createZone(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + 'zones',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    updateZone(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.MasterUrl + 'zones',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    createZoneEdi(data: any) {
        this.SetActive.set(true);
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + 'zones/upload',
            Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
