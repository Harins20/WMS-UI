import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';

import { ZoneLocation } from './zone-location.model';
import { map } from 'rxjs';
import { AppConfigService } from '../../../../../app.config.service';
import { AuthService } from '../../../../common/services';
import {
    lowerCaseArray,
    lowerCaseObject,
    upperCaseArray,
} from '../../../../shared/utils/case-conversion.util';

@Injectable({
    providedIn: 'root',
})
export class ZoneLocationService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getLocation(params: string) {
        return this.httpClient
            .get<
                ZoneLocation[]
            >(this.config.appConfig()?.MasterUrl + 'locations?' + params, { headers: this.authService.getAuthHeaders() })
            .pipe(map((response: any) => upperCaseArray(response)));
    }
    addLocationsToZone(data: any, zone: string) {
        return this.httpClient.put(
            this.config.appConfig()?.MasterUrl +
                `zones/locations/add?zone=${zone}`,
            Array.isArray(data) ? data : lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    removeLocationsFromZone(data: any, zone: string) {
        return this.httpClient.put(
            this.config.appConfig()?.MasterUrl +
                `zones/locations/remove?zone=${zone}`,
            Array.isArray(data) ? data : lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    getLocationType() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocType',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.LABEL ?? x.Label,
                        value: x.VALUE ?? x.Value,
                    })),
                ),
            );
    }
    getLocationFlag() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocFlag',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.LABEL ?? x.Label,
                        value: x.VALUE ?? x.Value,
                    })),
                ),
            );
    }
    getLocationHandling() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocHandling',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.LABEL ?? x.Label,
                        value: x.VALUE ?? x.Value,
                    })),
                ),
            );
    }
    getLocationCategory() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocCategory',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.LABEL ?? x.Label,
                        value: x.VALUE ?? x.Value,
                    })),
                ),
            );
    }
    getPutawayZone() {
        return this.httpClient
            .get(this.config.appConfig()?.MasterUrl + 'zones', {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.ZONE ?? x.Zone,
                        value: x.ZONE ?? x.Zone,
                    })),
                ),
            );
    }
}
