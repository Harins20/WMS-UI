import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { tableOptions } from '../../../../common/constants';
import { ExcelDownloadService } from '../../../../common/services';
import { zoneLocationColumns } from './zone-location.columns';
import { ZoneLocationService } from './zone-location.service';
import {
    ConfirmationDialogComponent,
    CustomTableComponent,
} from '../../../../common/components';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';

import { TooltipModule } from 'primeng/tooltip';

@Component({
    selector: 'app-zone-location-form',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        AppTranslatePipe,
        TooltipModule,
        CustomTableComponent,
    ],
    templateUrl: './zone-location-form.component.html',
    styleUrl: './zone-location-form.component.scss',
    providers: [DialogService],
})
export class ZoneLocationFormComponent {
    private translate = inject(TranslateService);
    location = signal<Location[]>([]);
    zone = input<string | undefined>();
    params = computed(() => {
        if (this.zone()) return `zone=${this.zone()}`;
        return 'NZone=true';
    });
    selectedLocation = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    tableOptions = signal(tableOptions);
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    exportFileName = 'Locations';
    dt = viewChild.required<Table>('dt');
    tablePaginationMessage =
        'Showing {first} to {last} of {totalRecords} Locations';
    columns = signal(
        Object.values(zoneLocationColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    userFormRef: DynamicDialogRef | undefined;
    private ref = inject(DynamicDialogRef);

    private messageService = inject(MessageService);
    private locationService = inject(ZoneLocationService);
    private excelDownloadService = inject(ExcelDownloadService);
    private destoryRef = inject(DestroyRef);
    ConfirmationRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    constructor() {}
    ngOnInit() {
        this.getLocation();
    }

    getLocation() {
        this.loading.set(true);
        this.location.set([]);
        const subscription = this.locationService
            .getLocation(this.params())
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    this.location.set(
                        res.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Location list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getLocation();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.location(),
        );
    }
    exportCSV() {
        this.dt().exportCSV();
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(this.location().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedLocation().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedLocation().length > 0 ? true : false,
    );

    onEditAction(location: Location) {}
    onAdd() {
        const locData = this.selectedLocation().map((x: any) => {
            return x.LOC || x.Loc;
        });

        this.ref?.close(locData);
    }
    OpenAvailLocationForm() {
        const header = this.translate.instant('Add Zone Locations');
        const value = this.translate.instant('AssignLocation');
          const confirmHeader = this.translate.instant('Confirm Location Addition');
        this.userFormRef = this.dialogService.open(ZoneLocationFormComponent, {
            header: header,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '55rem',
            style: { height: '45rem' },
        });

        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: confirmHeader,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );

                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.locationService
                            .addLocationsToZone(data, this.zone()!)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getLocation();
                                }),
                            )
                            .subscribe({
                                next: (Data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Location Creation',
                                        detail: Data as string,
                                    });
                                },
                                error: (error: any) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New Location Creation',
                                            detail: error.error as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    RemoveZoneLocation() {
        const header = this.translate.instant('Confirm Location Removal');
        const value = this.translate.instant('RemoveLocation');
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: header,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
            if (confirmed) {
                this.loading.set(true);
                const locData = this.selectedLocation().map(
                    (x: any) => x.LOC || x.Loc,
                );
                this.locationService
                    .removeLocationsFromZone(locData, this.zone()!)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.getLocation();
                        }),
                    )
                    .subscribe({
                        next: (data: any) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Zone Location',
                                detail: data as string,
                            });
                        },
                        error: (error: any) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Zone Location',
                                    detail: error.error as string,
                                });
                            }
                        },
                    });
            }
        });
    }
}
