import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';
import { Packkey } from './packkey.model';
import { map } from 'rxjs';
import {
    lowerCaseArray,
    lowerCaseObject,
    stringToDate,
    upperCaseArray,
    upperCaseObject,
} from '../../../common/functions';
import { PackKeyColumns } from './packkey.columns';

@Injectable({
    providedIn: 'root',
})
export class PackkeyService {
    SetActive = signal(false);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getPackkey() {
        return this.httpClient
            .get<
                Packkey[]
            >(this.config.appConfig()?.MasterUrl + 'packs', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((res: any) => {
                    return upperCaseArray(res);
                }),
            );
    }
    getPackkeyPage(data: any) {
        return this.httpClient
            .post<any>(
                this.config.appConfig()?.MasterUrl + 'packsPaged',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response) => {
                    if (response?.vw_pack) {
                        response.vw_pack = upperCaseArray(response.vw_pack);
                        response.vw_pack.forEach((x: any) => {
                            Object.keys(x).forEach((key) => {
                                if (PackKeyColumns[key]?.type === 'date') {
                                    x[key] = stringToDate(x[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    createPackkey(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + 'packs',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    updatePackkey(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.MasterUrl + 'packs',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    getUomList() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                'codes/options?ListName=UomType',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.LABEL,
                        value: x.VALUE,
                    })),
                ),
            );
    }
    createPacckkeyEdi(data: any) {
        this.SetActive.set(true);
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + 'packs/upload',
            Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
