import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../common/components';
import { PackkeyFormComponent } from '../packkey/packkey-form/packkey-form.component';
import { PackKeyColumns } from './packkey.columns';
import { Packkey } from './packkey.model';
import { PackkeyService } from './packkey.service';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { tableOptions } from '../../../common/constants';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';

import { FileUploadModule } from 'primeng/fileupload';
import * as XLSX from 'xlsx';
import { filterQuery } from '../../../common/functions';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
@Component({
    selector: 'app-packkey',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        FileUploadModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        // LoadingComponent,
        TooltipModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './packkey.component.html',
    styleUrl: './packkey.component.scss',
    providers: [DialogService],
})
export class PackkeyComponent {
    packkey = signal<Packkey[]>([]);
    selectedPackkey = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    tableOptions = signal(tableOptions);
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    exportFileName = 'Packs';
    excelData: any = [];
    dt = viewChild.required<Table>('dt');
    tablePaginationMessage =
        'Showing {first} to {last} of {totalRecords} Packs';
    columns = signal(
        Object.values(PackKeyColumns).filter((column) => !column.tableHidden),
    );
    OriginalColumns = signal<any>(PackKeyColumns);
    totalRecords = signal(0);
    rows = signal(10);
    loadEvent = signal<any>({});

    private translate = inject(TranslateService);

    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x: any) => x.tableAlias && !x.tableHidden)
            .map((x: any) => x.field),
    );
    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    userFormRef: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private packkeyService = inject(PackkeyService);
    private destoryRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    ConfirmationRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);

    form: any;
    constructor() {}
    ngOnInit() {
        this.getPackkey();
    }

    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         PackKeyColumns,
    //         'vw.',
    //     );
    //     this.getPackkey({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getPackkey(event);
    }

    getPackkey(
        data: any = {
            Page: this.loadEvent()?.Page || 1,
            PageSize: this.loadEvent()?.PageSize || this.rows(),
        },
    ) {
        this.loading.set(true);
        this.packkey.set([]);
        const subscription = this.packkeyService
            .getPackkeyPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy?.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }

                    this.packkey.set(
                        res.vw_pack.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                    this.totalRecords.set(res.totalcount);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Packkey list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getPackkey();
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getPackkey();
    }
    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }
    getPackkeyForExcel(
        data: any = {
            Page: 1,
            PageSize: this.totalRecords(),
        },
        type: string,
    ) {
        this.loading.set(true);

        const subscription = this.packkeyService
            .getPackkeyPage(data)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res: any) => {
                    const packkeys = res?.vw_pack || [];

                    const columns = [
                        'SerialKey',
                        'rowId',
                        'WhseId',
                        'PackKey',
                        'PackDescr',
                        'PackUom1',
                        'CaseCnt',
                        'PackUom2',
                        'InnerPack',
                        'PackUom3',
                        'Qty',
                        'PackUom4',
                        'Pallet',
                        'AddDate',
                        'EditDate',
                        'Edit Who',
                        'IsActive',
                    ];

                    if (type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            columns,
                            packkeys,
                        );
                    } else {
                        downloadCSVFile(packkeys, this.exportFileName);
                    }
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    export(type: string) {
        const event = this.loadEvent();

        const { filter, orderBy } = filterQuery(
            event,
            this.globalFilterColumns(),
            PackKeyColumns,
            'vw.',
        );

        this.getPackkeyForExcel(
            {
                Page: 1,
                PageSize: this.totalRecords(),
                Condition: filter,
                OrderBy: orderBy,
            },
            type,
        );
    }
    exportExcelTemplate() {
        const Column = [''];
        this.excelDownloadService.downloadExcelFile(
            'Packkey Template',
            Column,
            null,
        );
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(this.packkey().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedPackkey().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedPackkey().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '45rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    onEditAction(packkey: Packkey) {}

    OpenCreatePackkeyForm() {
        const headerText = this.translate.instant('Create Pack');
        this.userFormRef = this.dialogService.open(PackkeyFormComponent, {
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('PackkeyCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.packkeyService
                            .createPackkey(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getPackkey();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Packkey creation',
                                        detail: data as string,
                                    });
                                    this.loading.set(false);
                                },
                                error: (error: any) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New Packkey creation',
                                            detail: error.error as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdatePackkeyForm(Data: any) {
        const headerText = this.translate.instant('Update Pack');
        this.userFormRef = this.dialogService.open(PackkeyFormComponent, {
            inputValues: {
                UomData: Data,
            },
            // header: 'Update Receipt - ' + selectedAsn.RECEIPTKEY,
            // closable: true,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('PackkeyUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.packkeyService
                            .updatePackkey(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getPackkey();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Packkey Updation',
                                        detail: data as string,
                                    });
                                    this.loading.set(false);
                                },
                                error: (error: any) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Packkey Updation',
                                            detail: error.error as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }
    onFileUpload(event: any) {
        const file = event.files[0];
        const reader = new FileReader();
        reader.onload = async (e: any) => {
            const workbook = XLSX.read(e.target.result, { type: 'binary' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            this.excelData = XLSX.utils.sheet_to_json(worksheet, { raw: true });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const sheetData: any[][] = XLSX.utils.sheet_to_json(sheet, {
                header: 1,
            });
            if (this.excelData.length > 0) {
                const dataRows = sheetData.slice(1);
                const FinalData = dataRows.map(
                    (row: any[], rowIndex: number) => {
                        return {
                            PackKey: row[0] ? row[0].toString() : null,
                            PackDescr: row[1] ? row[1].toString() : null,
                            PackUom1: row[2] ? row[2].toString() : null,
                            CaseCnt: row[3],
                            PackUom2: row[4] ? row[4].toString() : null,
                            InnerPack: row[5],
                            PackUom3: row[6] ? row[6].toString() : null,
                            Qty: row[7],
                            PackUom4: row[8] ? row[8].toString() : null,
                            Pallet: row[9],
                            IsActive: row[10] ? row[10] : 'Active',
                        };
                    },
                );
                this.loading.set(true);
                this.packkeyService
                    .createPacckkeyEdi(FinalData)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.getPackkey();
                        }),
                    )
                    .subscribe({
                        next: (data) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Pack Upload',
                                detail: data as string,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Pack Upload',
                                    detail: error?.error?.Message as string,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            } else {
                this.loading.set(false);
                this.messageService.add({
                    severity: 'warn',
                    summary: 'Pack Upload',
                    detail: 'The file contains no data rows. Please add data below the header row and try again.',
                });
            }
        };
        reader.readAsArrayBuffer(file);
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
