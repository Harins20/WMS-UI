import { Component, DestroyRef, inject, input, signal } from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { Router } from '@angular/router';
import { PackKeyColumns } from '../packkey.columns';
import { selectOption } from '../../../../common/models';
import { AuthService } from '../../../../common/services';
import {
    getErrorMessages,
    markAllControlsAsDirty,
    upperCaseObject,
} from '../../../../common/functions';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { Select } from 'primeng/select';
import { PackkeyService } from '../packkey.service';
import { InputNumberComponent } from '../../../../common/components/input-number/input-number.component';
import { InputSelectComponent } from '../../../../common/components/input-select/input-select.component';
import { InputTextComponent } from '../../../../common/components/input-text/input-text.component';
import { MessageService } from 'primeng/api';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'packkey-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        InputNumberComponent,
        InputSelectComponent,
        InputTextComponent,
        AppTranslatePipe,
        CommonModule,
    ],
    templateUrl: './packkey-form.component.html',
    styleUrl: './packkey-form.component.scss',
})
export class PackkeyFormComponent {
    UomData = input<any>();
    private destoryRef = inject(DestroyRef);
    private authservice = inject(AuthService);
    private router = inject(Router);
    private ref = inject(DynamicDialogRef);
    private PackkeyService = inject(PackkeyService);
    private messageService = inject(MessageService);

    statusOptions = signal<selectOption[]>(
        PackKeyColumns['ISACTIVE'].options || [],
    );

    // ✅ Single signal for tab validation warning
    setViewTAb = signal<boolean>(true);
    // ✅ Single signal for active tab
    activeTab = signal<number>(0);

    loading = signal(false);
    uomList = signal<any>([]);
    uomList1 = signal<any>([]);
    uomList2 = signal<any>([]);
    uomList3 = signal<any>([]);
    uomList4 = signal<any>([]);
    uomList5 = signal<any>([]);
    uomList6 = signal<any>([]);
    uomList7 = signal<any>([]);
    uomList8 = signal<any>([]);
    uomList9 = signal<any>([]);

    formControls: any = Object.fromEntries(
        Object.values(PackKeyColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue || '', {
                validators: column.validators,
            }),
        ]),
    );
    form = new FormGroup(this.formControls);

    ngOnInit() {
        this.getUomList();

        if (this.UomData()) {
            const rawPackkey = upperCaseObject(this.UomData());
            this.form.patchValue({
                ...rawPackkey,
            });
            Object.values(PackKeyColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.form.controls[column.field]?.disable();
            });
        } else {
            Object.values(PackKeyColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.form.controls[column.field]?.disable();
            });
        }
        this.form.valueChanges.subscribe(() => {
            this.filterfun();
        });
    }

    // ✅ Navigate to tab
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    closePanel() {
        this.ref.close();
    }

    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }

    filterfun() {
        let data = [
            this.form.get('PACKUOM1')?.value,
            this.form.get('PACKUOM2')?.value,
            this.form.get('PACKUOM3')?.value,
            this.form.get('PACKUOM4')?.value,
            this.form.get('PACKUOM8')?.value,
            this.form.get('PACKUOM9')?.value,
        ];

        const filteredOptions = (Data: any) =>
            this.uomList().filter(
                (x: any) => !data.includes(x.value) || x.value === Data,
            );

        this.uomList1.set(filteredOptions(this.form.get('PACKUOM1')?.value));
        this.uomList2.set(filteredOptions(this.form.get('PACKUOM2')?.value));
        this.uomList3.set(filteredOptions(this.form.get('PACKUOM3')?.value));
        this.uomList4.set(filteredOptions(this.form.get('PACKUOM4')?.value));
        this.uomList5.set(this.uomList());
        this.uomList6.set(this.uomList());
        this.uomList7.set(this.uomList());
        this.uomList8.set(filteredOptions(this.form.get('PACKUOM8')?.value));
        this.uomList9.set(filteredOptions(this.form.get('PACKUOM9')?.value));
    }

    getUomList() {
        const subscription = this.PackkeyService.getUomList().subscribe({
            next: (data: any) => {
                this.uomList.set(data);
                this.uomList1.set(data);
                this.uomList2.set(data);
                this.uomList3.set(data);
                this.uomList4.set(data);
                this.uomList5.set(data);
                this.uomList6.set(data);
                this.uomList7.set(data);
                this.uomList8.set(data);
                this.uomList9.set(data);
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    onSubmit() {
        if (this.form.valid) {
            this.ref.close(this.form.getRawValue());
            this.form.reset();
        } else {
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
}
