import { ItemComponent } from '../masters/item';
import { BomComponent, BomLinesComponent } from './bom';
import { LocationComponent } from './location';
import { PackkeyComponent } from './packkey';
import { TradersComponent } from './traders';
import { ZoneComponent } from './zone';
import { AreaComponent } from './area';

export default [
    {
        data: { name: 'Carriers', formName: 'Carrier', type: 4 },
        path: 'carrier',
        component: TradersComponent,
    },
    {
        data: { name: 'Owners', formName: 'Owner', type: 1 },
        path: 'owner',
        component: TradersComponent,
    },
    {
        data: { name: 'Ship From', formName: 'Ship From', type: 3 },
        path: 'shipfrom',
        component: TradersComponent,
    },
    {
        data: { name: 'Ship To', formName: 'Ship To', type: 8 },
        path: 'shipto',
        component: TradersComponent,
    },
    {
        data: { name: 'Suppliers', formName: 'Supplier', type: 2 },
        path: 'supplier',
        component: TradersComponent,
    },
    {
        data: { name: 'Bill To', formName: 'Bill To', type: 10 },
        path: 'billto',
        component: TradersComponent,
    },

    { data: { name: 'Items' }, path: 'item', component: ItemComponent },
    {
        data: { name: 'Locations' },
        path: 'location',
        component: LocationComponent,
    },
    { data: { name: 'Packs' }, path: 'packkey', component: PackkeyComponent },
    { data: { name: 'Zones' }, path: 'zone', component: ZoneComponent },
    { data: { name: 'Area' }, path: 'area', component: AreaComponent },
    { data: { name: 'BOM' }, path: 'BOM', component: BomComponent },
    {
        data: { name: 'Kit Lines' },
        path: 'kitlines',
        component: BomLinesComponent,
    },
];
