import { Columns } from '../../../../common/models';
import { Validators } from '@angular/forms';

export const bomLinesColumns: Columns = {
    StorerKey: {
        label: 'Owner',
        field: 'StorerKey',
        type: 'text',
        validators: [Validators.maxLength(15)],
        restrictEdit: true,
        restrictInsert: true,
    },
    KitID: {
        label: 'Kit ID',
        field: 'KitID',
        type: 'text',
        validators: [Validators.maxLength(20)],
    },
    Sku: {
        label: 'Sku',
        field: 'Sku',
        type: 'text',
        validators: [Validators.maxLength(50)],
    },
    Qty: {
        label: 'Quantity',
        field: 'Qty',
        type: 'number',
        // validators: [Validators.required],
    },
    AddWho: {
        label: 'Add Who',
        field: 'AddWho',
        type: 'text',
        validators: [Validators.maxLength(20)],
    },
    AddDate: {
        label: 'Add Date',
        field: 'AddDate',
        type: 'date',
    },
    EditWho: {
        label: 'Edit Who',
        field: 'EditWho',
        type: 'text',
        validators: [Validators.maxLength(20)],
    },
    EditDate: {
        label: 'Edit Date',
        field: 'EditDate',
        type: 'date',
    },
};
