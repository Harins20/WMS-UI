import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../../../../../app.config.service';
import { ResponseDto } from '../../../../common/models';
import { AuthService } from '../../../../common/services';
import { BomLines } from './bom-line.models';

@Injectable({
    providedIn: 'root',
})
export class BomLinesService {
    reload() {
        throw new Error('Method not implemented.');
    }
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getBomLines(kitId: string) {
        const params = new HttpParams().set('kitId', kitId);
        return this.httpClient.get<ResponseDto<[]>>(
            this.config.appConfig()?.InvUrl + 'kits/items',
            {
                headers: this.authService.getAuthHeaders(),
                params,
            },
        );
    }

    createBomLines(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InvUrl + 'kits/items',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    UpdateBomLines(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InvUrl + 'kits/items',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
