export interface BomLines {
    StorerKey: string;
    KitID: string;
    Sku: string;
    Qty: number;
    AddWho: string;
    AddDate: string;
    EditWho: string;
    EditDate: string;
}
