import { bomLinesColumns } from './../bom-line.columns';
import {
    Component,
    DestroyRef,
    Inject,
    inject,
    Input,
    input,
    linkedSignal,
    signal,
} from '@angular/core';

import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';

import { ButtonModule } from 'primeng/button';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { StepperModule } from 'primeng/stepper';
import { TabsModule } from 'primeng/tabs';
import { selectOption } from '../../../../../common/models';
import { OptionsService } from '../../../../../common/services';
import { InputNumberComponent } from '../../../../../common/components/input-number/input-number.component';
import { InputSelectComponent } from '../../../../../common/components/input-select/input-select.component';
import { InputTextComponent } from '../../../../../common/components/input-text/input-text.component';
import { markAllControlsAsDirty } from '../../../../../common/functions';
import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';

@Component({
    selector: 'kit-form',
    imports: [
        ReactiveFormsModule,
        ButtonModule,
        TabsModule,
        StepperModule,
        InputSelectComponent,
        InputNumberComponent, AppTranslatePipe
    ],
    templateUrl: './bom-line-form.component.html',
})
export class BomLinesFormComponent {
    KitId = input<string>();
    MasterSku = input.required<string>();
    BomLines = input<any>();
    StorerKey = input<string>();
    private destroyRef = inject(DestroyRef);
    private optionService = inject(OptionsService);
    private ref = inject(DynamicDialogRef);
    form = new FormGroup<any>({
        SerialKey: new FormControl<string | undefined>(undefined),
        KitID: new FormControl<string | undefined>(undefined),
        StorerKey: new FormControl<string | undefined>(undefined, {
            validators: [Validators.required],
        }),
        Sku: new FormControl<string | undefined>(undefined, {
            validators: [Validators.required],
        }),
        Qty: new FormControl<number | undefined>(undefined, {
            validators: [Validators.required, Validators.min(1)],
        }),
    });
    childItemOptions = signal<selectOption[]>([]);

    ownerOptions = signal<selectOption[]>([]);
    ngOnInit() {
        this.GetOwnerOptions();
        if (this.BomLines()) {
            this.form.patchValue(this.BomLines());
            this.GetChildItemOptions(
                this.BomLines().StorerKey,
                this.MasterSku(),
            );
        } else {
            this.form.patchValue({
                StorerKey: this.StorerKey(),
                KitID: this.KitId(),
            });

            this.GetChildItemOptions(this.StorerKey()!, this.MasterSku());
        }

        this.form.controls['StorerKey']?.disable();
    }

    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetChildItemOptions(StorerKey: string, ExcludeSku: string) {
        const subscription = this.optionService
            .getChildItemOptions(StorerKey, ExcludeSku)
            .subscribe({
                next: (data) => {
                    this.childItemOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    onCancel() {
        this.ref.close();
    }
    onSubmit() {
        if (this.form.valid) {
            const formData = {
                ...this.form.getRawValue(),
            };
            this.ref.close(formData);
        } else {
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
}
