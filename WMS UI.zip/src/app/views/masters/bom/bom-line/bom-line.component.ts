import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
    Input,
    input,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../../common/components';
import { ExcelDownloadService } from '../../../../common/services/excel-download.service';
import { bomLinesColumns } from './bom-line.columns';
import { BomLines } from './bom-line.models';
import { BomLinesService } from './bom-line.service';
import masterRoutes from '../../master.routes';
import { Route } from '@angular/router';
import { tableOptions } from '../../../../common/constants';
import { TagModule } from 'primeng/tag';
import { BomLinesFormComponent } from './bom-line-form/bom-line-form.component';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';

@Component({
    selector: 'app-kittinglines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        TagModule,
        AppTranslatePipe, LoadingComponent,
    ],
    templateUrl: './bom-line.component.html',
    styleUrl: './bom-line.component.scss',
    providers: [DialogService],
})
export class BomLinesComponent {
    KitId = input.required<string>();
    private translate = inject(TranslateService);
    StorerKey = input.required<string>();
    MasterSku = input.required<string>();

    BomLines = signal<BomLines[]>([]);
    selectedKittingLine = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    columns = signal(
        Object.values(bomLinesColumns).filter((column) => !column.tableHidden),
    );

    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    userFormRef: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private bomlinesservice = inject(BomLinesService);
    private destroyRef = inject(DestroyRef);
    ConfirmationRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private excelDownloadService = inject(ExcelDownloadService);
    tabService: any;

    constructor() {}
    ngOnInit() {
        this.getBomLines();
    }
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    getBomLines() {
        this.loading.set(true);
        this.BomLines.set([]);
        const subscription = this.bomlinesservice
            .getBomLines(this.KitId())
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res) => {
                    this.BomLines.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Load list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getBomLines();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            'Kitting-list',
            [],
            this.kittingList(),
        );
    }
    kittingList(): any {
        throw new Error('Method not implemented.');
    }
    exportCSV() {
        this.dt().exportCSV();
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.kittingList().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedKittingLine().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedKittingLine().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headerText = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headerText,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    OpenCreatekitLinesForm() {
        const headerText = this.translate.instant('Create Bom Line');
        this.userFormRef = this.dialogService.open(BomLinesFormComponent, {
            inputValues: {
                KitId: this.KitId(),
                StorerKey: this.StorerKey(),
                MasterSku: this.MasterSku(),
            },
            header: headerText,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '55rem',
            style: { height: '45rem' },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('BomLineCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.bomlinesservice
                            .createBomLines(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getBomLines();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New BOM Line creation',
                                        detail: 'BOM line created successfully',
                                    });
                                },
                                error: (err) => {
                                    console.error('Error Order creation', err);
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'New BOM Line creation',
                                        detail: 'Failed to Create Bom Lines.',
                                    });
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateBomLinesForm(BomLinesData: any) {
        const headerText = this.translate.instant('Update Bom Lines');
        this.userFormRef = this.dialogService.open(BomLinesFormComponent, {
            inputValues: {
                BomLines: BomLinesData,
                MasterSku: this.MasterSku(),
            },
            header: headerText,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '55rem',
            style: { height: '45rem' },
        });

        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('BomLineUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        const updatedData: BomLines = {
                            ...BomLinesData,
                            ...data,
                        };

                        this.bomlinesservice
                            .UpdateBomLines(updatedData)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedKittingLine.set([]);
                                    this.getBomLines();
                                }),
                            )
                            .subscribe({
                                next: (response) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Bom Lines',
                                        detail: 'Bom Line Updated Successfully.',
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Bom Lines Update Failed',
                                            detail:
                                                error.error?.Message ||
                                                'Failed to update BOM line. Please check the input and try again.',
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    getKittingList() {
        throw new Error('Method not implemented.');
    }
}
