import { Validators } from '@angular/forms';
import { Columns } from '../../../common/models';

export const bomColumns: Columns = {
    rowId: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
    },
    // SerialKey: {
    //     label: ' SerialKey',
    //     field: 'SerialKey',
    //     type: 'text',
    //     validators: [Validators.required, Validators.maxLength(50)],
    //     restrictEdit: true,
    // },
    KitID: {
        label: 'Kit Id',
        field: 'KitID',
        type: 'text',
        validators: [Validators.maxLength(20)],
        // restrictEdit: true,
    },
    StorerKey: {
        label: ' Owner',
        field: 'StorerKey',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(15)],
        tableHidden: true,
    },
    Sku: {
        label: 'Kit Sku',
        field: 'Sku',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(50)],
        restrictEdit: false,
    },
    KitName: {
        label: 'Kit Name',
        field: 'KitName',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(50)],
        restrictEdit: false,
    },
    Comment: {
        label: 'Comment',
        field: 'Comment',
        type: 'text',
        validators: [Validators.maxLength(100)],
        restrictEdit: false,
        tableHidden: true,
    },
    KitItemSku1: {
        label: 'KitI item Sku',
        field: 'KitItemSku1',
        validators: [Validators.required, Validators.maxLength(200)],
        type: 'text',
        restrictEdit: false,
        tableHidden: true,
    },
    KitItemSkuQty1: {
        label: 'Qty',
        field: 'KitItemSkuQty1',
        validators: [Validators.required, Validators.maxLength(200)],
        type: 'number',
        restrictEdit: false,
        tableHidden: true,
    },

    KitItemSku2: {
        label: 'KitI item Sku',
        field: 'KitItemSku2',
        validators: [Validators.required, Validators.maxLength(200)],
        type: 'text',
        restrictEdit: false,
        tableHidden: true,
    },
    KitItemSkuQty2: {
        label: 'Qty',
        field: 'KitItemSkuQty2',
        validators: [Validators.required, Validators.maxLength(200)],
        type: 'number',
        restrictEdit: false,
        tableHidden: true,
    },
    AddDate: {
        label: 'Add Date',
        field: 'AddDate',
        type: 'date',
        restrictEdit: false,
    },
};
