export interface Bom {
    C: string;
    SerialKey: Number;
    StorerKey: string;
    KitID: string;
    KitName: string;
    Sku: string;
    Comment: string;
    AddWho: string;
    AddDate: string;
    EditWho: string;
    EditDate: string;
}
