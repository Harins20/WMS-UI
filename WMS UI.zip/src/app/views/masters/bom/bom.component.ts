import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../common/components';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { BomFormComponent } from './bom-form/bom-form.component';
import { bomColumns } from './bom.columns';
import { Bom } from './bom.model';
import { BomService } from './bom.service';
import masterRoutes from '../master.routes';
import { Route } from '@angular/router';
import { TagModule } from 'primeng/tag';
import { TabService } from '../../../tabs/tab.service';

@Component({
    selector: 'app-Kitting',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        TagModule,
        AppTranslatePipe, LoadingComponent,
    ],
    templateUrl: './bom.component.html',
    styleUrl: './bom.component.scss',
    providers: [DialogService],
})
export class BomComponent {
    private translate = inject(TranslateService);
    kittingList = signal<Bom[]>([]);
    selectedKitting = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    columns = signal(
        Object.values(bomColumns).filter((column) => !column.tableHidden),
    );
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    userFormRef: DynamicDialogRef | undefined;
    ConfirmationRef: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private kittingService = inject(BomService);
    private destroyRef = inject(DestroyRef);
    private tabService = inject(TabService);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);

    private excelDownloadService = inject(ExcelDownloadService);
    form: any;

    constructor() {}
    ngOnInit() {
        this.getKittingList();
    }
    selectedLoad(): any {
        throw new Error('Method not implemented.');
    }

    getKittingList() {
        this.loading.set(true);
        this.kittingList.set([]);
        const subscription = this.kittingService
            .getKittingList()
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res) => {
                    this.kittingList.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Load list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getKittingList();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            'Kitting-list',
            [],
            this.kittingList(),
        );
    }
    exportCSV() {
        this.dt().exportCSV();
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.kittingList().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedKitting().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedKitting().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    OpenCreatekitForm() {
        const headerText = this.translate.instant('Create Bom');
        this.userFormRef = this.dialogService.open(BomFormComponent, {
            header: headerText,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '55rem',
            style: { height: '45rem' },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('BomCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.kittingService
                            .createKitting(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getKittingList();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Bill of Material creation',
                                        detail: 'Bill of Material created successfully',
                                    });
                                },
                                error: (err) => {
                                    console.error('Error Order creation', err);
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'New Bom Line creation',
                                        detail: 'Failed to Create Bill of Material.',
                                    });
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    onClickKitId(event: any, row: Bom): void {
        event.preventDefault();
        const route = masterRoutes.find(
            (route) => route.data?.name === 'Kit Lines',
        ) as Route;
        var params = [
            { name: 'KitId', value: row.KitID },
            { name: 'StorerKey', value: row.StorerKey },
            { name: 'MasterSku', value: row.Sku },
        ];
        this.tabService.addTabWithParams(
            route,
            '',
            'Kit Lines - ' + row.KitID,
            params,
        );
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
