import {
    Component,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
} from '@angular/core';

import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';

import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { StepperModule } from 'primeng/stepper';
import { TabsModule } from 'primeng/tabs';
import { selectOption } from '../../../../common/models';
import { OptionsService } from '../../../../common/services';

import { InputNumberComponent } from '../../../../common/components/input-number/input-number.component';
import { InputSelectComponent } from '../../../../common/components/input-select/input-select.component';
import { InputTextComponent } from '../../../../common/components/input-text/input-text.component';
import { InputTextareaComponent } from '../../../../common/components/input-textarea/input-textarea.component';
import { markAllControlsAsDirty } from '../../../../common/functions';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';

@Component({
    selector: 'kit-form',
    imports: [
        ReactiveFormsModule,
        ButtonModule,
        TabsModule,
        StepperModule,
        InputSelectComponent,
        InputTextComponent,
        InputTextareaComponent,
        InputNumberComponent,
        AppTranslatePipe, ],
    templateUrl: './bom-form.component.html',
})
export class BomFormComponent {
    KittingData = input<any>();
    private destroyRef = inject(DestroyRef);
    private optionService = inject(OptionsService);
    private ref = inject(DynamicDialogRef);

    loading = signal(false);

    form = new FormGroup<any>({
        StorerKey: new FormControl(
            {
                value: sessionStorage.getItem('TraderKey') || '',
                disabled: true,
            },
            {
                validators: [Validators.required],
            },
        ),
        Sku: new FormControl<string | undefined>(undefined, {
            validators: [Validators.required],
        }),
        KitName: new FormControl<string | undefined>(undefined, {
            validators: [Validators.required],
        }),
        IsActive: new FormControl<string | undefined>('Active', {
            validators: [Validators.required],
        }),
        Comment: new FormControl<string | undefined>(undefined),
    });

    lineForm = new FormGroup<any>({
        KitItemSku1: new FormControl<string | undefined>(undefined, {
            validators: [Validators.required],
        }),
        KitItemSkuQty1: new FormControl<number | undefined>(undefined, {
            validators: [Validators.required, Validators.min(1)],
        }),
        KitItemSku2: new FormControl<string | undefined>(undefined, {
            validators: [Validators.required],
        }),
        KitItemSkuQty2: new FormControl<number | undefined>(undefined, {
            validators: [Validators.required, Validators.min(1)],
        }),
    });

    statusOptions = [
        { label: 'Active', value: 'Active' },
        { label: 'In Active', value: 'In Active' },
    ];

    ownerOptions = signal<selectOption[]>([]);
    itemOptions = signal<selectOption[]>([]);
    childItemOptions = signal<selectOption[]>([]);
    usableChildItemOptions = linkedSignal<{ [key: number]: selectOption[] }>(
        () => {
            return { 0: this.childItemOptions(), 1: this.childItemOptions() };
        },
    );

    kitItemsAddonId = signal<number>(3);
    kitItemsAddon = signal<{ id: number; item: string; qty: string }[]>([]);

    steps = ['Kit Details', 'Kit Line Details'];
    currentStep = this.steps[0];
    isNextPage: boolean = false;

    ngOnInit() {
        this.GetOwnerOptions();

        const storerKey = this.form.get('StorerKey')?.getRawValue();

        if (storerKey) {
            this.GetItemOptions(storerKey);
        }

        this.form.get('Sku')?.valueChanges.subscribe((selectedParentSku) => {
            if (selectedParentSku) {
                if (storerKey) {
                    this.GetChildItemOptions(storerKey, selectedParentSku);
                }
            }
        });

        this.lineForm.valueChanges.subscribe(() => {
            this.populateItemSkuOptions();
        });
    }
    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetItemOptions(StorerKey: string) {
        const subscription = this.optionService
            .getParentItemOptions(StorerKey)
            .subscribe({
                next: (data) => {
                    this.itemOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetChildItemOptions(StorerKey: string, ExcludeSku: string) {
        const subscription = this.optionService
            .getChildItemOptions(StorerKey, ExcludeSku)
            .subscribe({
                next: (data) => {
                    this.childItemOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    addKitItem() {
        const newSkuControlName = `KitItemSku${this.kitItemsAddonId()}`;
        this.lineForm.addControl(
            newSkuControlName,
            new FormControl<string | undefined>(undefined, [
                Validators.required,
            ]),
        );

        const newQtyControlName = `KitItemSkuQty${this.kitItemsAddonId()}`;
        this.lineForm.addControl(
            newQtyControlName,
            new FormControl<number | undefined>(undefined, [
                Validators.required,
                Validators.min(1),
            ]),
        );

        this.kitItemsAddon.update((prev) => [
            ...prev,
            {
                id: this.kitItemsAddonId(),
                item: newSkuControlName,
                qty: newQtyControlName,
            },
        ]);
        this.kitItemsAddonId.set(this.kitItemsAddonId() + 1);
        this.lineForm.updateValueAndValidity();
        this.populateItemSkuOptions();
    }

    onNext(activateCallback: (number: number) => void) {
        if (this.form.valid) {
            this.isNextPage = true;
            activateCallback(2);
        } else {
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }

    onCancel() {
        this.ref.close();
    }
    onSubmit() {
        if (this.form.valid && this.lineForm.valid) {
            const Kit = this.form.getRawValue();
            const LineItems = this.lineForm.value;
            const kitItems: { StorerKey: number; Sku: string; Qty: number }[] =
                [];
            var ids = Object.keys(LineItems)
                .filter((x) => x.includes('KitItemSkuQty'))
                .map((x) => parseInt(x.replace('KitItemSkuQty', '')));
            // Loop through the input object keys
            ids.forEach((i) => {
                const skuKey = `KitItemSku${i}`;
                const qtyKey = `KitItemSkuQty${i}`;

                // Push the {sku, qty} object to the result array
                kitItems.push({
                    StorerKey: Kit['StorerKey'],
                    Sku: LineItems[skuKey],
                    Qty: LineItems[qtyKey],
                });
            });

            const KitCreate = {
                Kit,
                kitItems,
            };
            this.ref.close(KitCreate);
            this.form.reset();
            this.lineForm.reset();
        } else {
            this.lineForm.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.lineForm.controls));
        }
    }

    removeKitItem(id: number) {
        // Remove controls from the form
        this.lineForm.removeControl(`KitItemSku${id}`);
        this.lineForm.removeControl(`KitItemSkuQty${id}`);

        // Remove from additionalKitItems array
        this.kitItemsAddon.update((prev) =>
            prev.filter((item) => item.id !== id),
        );
        this.usableChildItemOptions.update((prev) => ({
            ...prev,
            [id]: [],
        }));
        this.lineForm.updateValueAndValidity();
        this.populateItemSkuOptions();
    }

    populateItemSkuOptions() {
        const item = this.lineForm.value;
        const kitItemSkuNames = Object.keys(item)
            .filter((x) => x.includes('KitItemSku') && !x.includes('Qty'))
            .map((x) => x);

        kitItemSkuNames.forEach((name) => {
            let values: any = [];
            var otherItemSkuNames = kitItemSkuNames.filter((x) => x !== name);

            otherItemSkuNames.forEach((otherName) => {
                values.push(item[otherName]);
            });

            var tempItemSkuOptions = this.childItemOptions().filter(
                (x) => !values.includes(x.value),
            );

            if (name === 'KitItemSku1') {
                this.usableChildItemOptions.update((prev) => ({
                    ...prev,
                    [0]: tempItemSkuOptions,
                }));
            } else if (name === 'KitItemSku2') {
                this.usableChildItemOptions.update((prev) => ({
                    ...prev,
                    [1]: tempItemSkuOptions,
                }));
            } else {
                var tempItem = this.kitItemsAddon().find(
                    (x) => x.item === name,
                );
                if (tempItem) {
                    this.usableChildItemOptions.update((prev) => ({
                        ...prev,
                        [tempItem!.id]: tempItemSkuOptions,
                    }));
                }
            }
        });
    }
}
