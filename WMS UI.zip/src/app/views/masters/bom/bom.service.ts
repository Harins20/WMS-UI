import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';
import { Location } from '../location/location.model';

@Injectable({
    providedIn: 'root',
})
export class BomService {
    getDynamicOptions() {
        throw new Error('Method not implemented.');
    }
    addTabWithParams(arg0: { id: string }) {
        throw new Error('Method not implemented.');
    }
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getKittingList() {
        return this.httpClient.get<ResponseDto<[]>>(
            this.config.appConfig()?.InvUrl + 'kits',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    createKitting(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InvUrl + 'kits',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    UpdateKitting(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InvUrl + 'kits',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
