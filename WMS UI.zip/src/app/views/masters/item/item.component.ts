import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    effect,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize, forkJoin, map, of } from 'rxjs';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    ViewImageDialogComponent,
    LoadingComponent,
} from '../../../common/components';
import { ItemFormComponent } from '../item/item-form/item-form.component';
import { ItemColumns } from './item.columns';
import { Item } from './item.model';
import { ItemService } from './item.service';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { tableOptions } from '../../../common/constants';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';

import { FileUploadModule } from 'primeng/fileupload';
import { convertExcelDate } from '../../../common/functions/numberToDate';
import * as XLSX from 'xlsx';
import { OptionsService } from '../../../common/services/options.service';
import { filterQuery } from '../../../common/functions';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-item',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        AppTranslatePipe,
        FileUploadModule,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './item.component.html',
    styleUrl: './item.component.scss',
    providers: [DialogService],
})
export class ItemComponent {
    private translate = inject(TranslateService);
    item = signal<Item[]>([]);
    itemExcel = signal<Item[]>([]);
    selectedItem = signal<any>([]);
    excelData: any = [];
    searchInput = signal<string | undefined>(undefined);
    tableOptions = signal(tableOptions);
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    exportFileName = 'Items';
    tablePaginationMessage =
        'Showing {first} to {last} of {totalRecords} Items';
    dt = viewChild.required<Table>('dt');
    columns = signal<any>([]);
    selectedColumns = linkedSignal(() => this.columns());
    OrginalColumns = signal<any>(ItemColumns);
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x: any) => x.tableAlias && !x.tableHidden)
            .map((x: any) => x.field),
    );
    totalRecords = signal(0);
    rows = signal(15);
    loadEvent = signal<any>({});

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    ref: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private itemService = inject(ItemService);
    private destoryRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    ConfirmationRef: DynamicDialogRef | undefined;

    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private optionService = inject(OptionsService);
    constructor() {}
    ngOnInit() {
        // this.getItem();
        this.getColumns();
    }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getItem(event);
    }
    getColumns() {
        this.optionService.getColumns(ItemColumns, 'ITEM').subscribe({
            next: (data) => {
                const FilterField = data.map((x: any) => x.field);
                const GetFilterFields = Object.values(ItemColumns).filter(
                    (x: any) => {
                        return !FilterField.includes(x.field);
                    },
                );
                const columns = [...GetFilterFields, ...data];
                this.columns.set(
                    columns.filter((column: any) => !column.tableHidden),
                );
            },
        });
    }
    getItemImage = effect(() => {
        this.item()?.forEach((x: any) => {
            const attachmentId = x.ATTACHMENTID ?? x.AttachmentId;
            if (attachmentId) {
                this.itemService.GetItemsAttachment(attachmentId).subscribe({
                    next: (res: any) => {
                        x.FILEDATA = res;
                        x.FileData = res;
                    },
                });
            } else {
                x.FILEDATA = 'assets/img/noImage.png';
                x.FileData = 'assets/img/noImage.png';
            }
        });
    });

    getItem(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.item.set([]);

        const subscription = this.itemService
            .getItemPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    console.log('Item API response:', res);

                    const items = Array.isArray(res?.Response)
                        ? res.Response
                        : [];

                    const mappedItems = items.map(
                        (item: any, index: number) => ({
                            ...item,
                            rowId: index + 1,
                        }),
                    );

                    this.itemExcel.set(mappedItems);
                    this.item.set(mappedItems);
                    this.totalRecords.set(res?.TotalRecords ?? items.length);
                },
                error: (error: HttpErrorResponse) => {
                    console.error('Item API error:', error);

                    this.messageService.add({
                        severity: 'error',
                        summary: 'Item list',
                        detail:
                            error.status === 0
                                ? 'Network error occurred. Please check your internet connection.'
                                : 'Failed to load items.',
                    });
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getItem();
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getItem();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.itemExcel(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.itemExcel(), this.exportFileName);
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(this.item().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedItem().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedItem().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '45rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    onEditAction(item: Item) {}

    OpenImage(item: any) {
        this.ref = this.dialogService.open(ViewImageDialogComponent, {
            inputValues: {
                image: item?.FILEDATA ?? item?.FileData,
                fileName: item?.ATTACHMENTFILENAME ?? item?.AttachmentFileName,
            },
            header: 'Image',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '55rem',
            style: { height: '45rem' },
        });
        this.ref.onClose.subscribe((data) => {});
    }
    OpenCreateItemForm() {
        const headerText = this.translate.instant('Create Item');
        this.ref = this.dialogService.open(ItemFormComponent, {
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });

        this.ref.onClose.subscribe((data) => {
            const headertext = this.translate.instant('Confirm Creation');
            const value = this.translate.instant('ItemCreation');
            if (data) {
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: headertext,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );

                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        Object.values(ItemColumns).forEach((x) => {
                            if (
                                data[x.field] === undefined ||
                                data[x.field] === null ||
                                data[x.field] === ''
                            ) {
                                data[x.field] = x.defaultValue;
                            }
                        });
                        const ignoredFields = Object.values(ItemColumns)
                            .filter((col: any) => col.ignoreInRequest)
                            .map((col: any) => col.field);

                        const copy = { ...data };
                        ignoredFields.forEach((field) => {
                            delete copy[field];
                        });
                        this.loading.set(true);
                        this.itemService
                            .createItem(copy)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getItem();
                                }),
                            )
                            .subscribe({
                                next: (response: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Item Created',
                                        detail: response as string,
                                    });
                                },
                                error: (error: any) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Creation Failed',
                                            detail: `${error.error as string} Please try with a different name`,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateItemForm(item: any) {
        const headerText = this.translate.instant('Update Item');
        const header = this.translate.instant('Confirm Update');
        const value = this.translate.instant('ItemUpdate');
        this.ref = this.dialogService.open(ItemFormComponent, {
            inputValues: {
                ItemData: item,
            },

            // header: 'Update Receipt - ' + selectedAsn.RECEIPTKEY,
            // closable: true,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });

        this.ref.onClose.subscribe((data) => {
            if (data) {
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );

                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        const ignoredFields = Object.values(ItemColumns)
                            .filter((col: any) => col.ignoreInRequest)
                            .map((col: any) => col.field);

                        const copy = { ...data };
                        ignoredFields.forEach((field) => {
                            delete copy[field];
                        });
                        this.loading.set(true);
                        this.itemService
                            .updateItem(copy)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getItem();
                                }),
                            )
                            .subscribe({
                                next: (response: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Item Updated',
                                        detail: response as string,
                                    });
                                },
                                error: (error: any) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Update Failed',
                                            detail: error.error as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }
    onFileSelect(event: any) {
        const file = event.files[0];
        const reader = new FileReader();
        reader.onload = async (e: any) => {
            const workbook = XLSX.read(e.target.result, { type: 'binary' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            this.excelData = XLSX.utils.sheet_to_json(worksheet, { raw: true });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const sheetData: any[][] = XLSX.utils.sheet_to_json(sheet, {
                header: 1,
            });
            if (this.excelData.length > 0) {
                const dataRows = sheetData.slice(1);
                const FinalData = dataRows.map(
                    (row: any[], rowIndex: number) => {
                        return {
                            TRADERKEY: row[0] ? row[0].toString() : null,
                            SKU: row[1] ? row[1].toString() : null,
                            ALTSKU: row[2] ? row[2].toString() : null,
                            DESCR: row[3] ? row[3].toString() : null,
                            TYPE: row[4] ? row[4].toString() : '0',
                            TYPEDESC: row[5],
                            PRICE: row[6] ? row[6].toString() : null,
                            COST: row[7] ? row[7].toString() : null,
                            PACKKEY: row[8] ? row[8].toString() : null,
                            STDUOM: row[9] ? row[9].toString() : null,
                            STDGROSSWGT: row[10] ? row[10].toString() : 0,
                            STDNETWGT: row[11] ? row[11].toString() : 0,
                            GROSSWGT: row[12] ? row[12].toString() : 0,
                            NETWGT: row[13] ? row[13].toString() : 0,
                            TAREWEIGHT: row[14] ? row[14].toString() : 0,
                            NEWALLOCATIONSTRATEGY: row[15]
                                ? row[15].toString()
                                : null,

                            SHELFLIFE: row[16] ? row[16] : null,
                            ATTACHMENTID: row[17] ? row[17].toString() : null,
                            ATTACHMENTFILENAME: row[18]
                                ? row[18].toString()
                                : null,
                            UDFSTR1: row[19],
                            UDFSTR2: row[20],
                            UDFSTR3: row[21],
                            UDFSTR4: row[22],
                            UDFSTR5: row[23],
                            UDFDATETIME1: row[24]
                                ? convertExcelDate(row[24])
                                : null,
                            UDFDATETIME2: row[25]
                                ? convertExcelDate(row[25])
                                : null,
                            UDFDATETIME3: row[26]
                                ? convertExcelDate(row[26])
                                : null,
                            UDFDATETIME4: row[27]
                                ? convertExcelDate(row[27])
                                : null,
                            UDFDATETIME5: row[28]
                                ? convertExcelDate(row[28])
                                : null,
                            UDFFLOAT1: row[29],
                            UDFFLOAT2: row[30],
                            UDFFLOAT3: row[31],
                            UDFFLOAT4: row[32],
                            UDFFLOAT5: row[33],
                            HEIGHT: row[34] ? row[34] : null,
                            WIDTH: row[35] ? row[35] : null,
                            LENGTH: row[36] ? row[36] : null,
                            DEPTH: row[37] ? row[37] : null,
                            SEASONALPRICE: row[38] ? row[38].toString() : null,

                            ISACTIVE: row[39] ? row[39].toString() : 'Active',
                        };
                    },
                );

                this.loading.set(true);
                this.itemService

                    .createItemsEdi(FinalData)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.getItem();
                        }),
                    )
                    .subscribe({
                        next: (data) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Items Upload',
                                detail: data as string,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Item',
                                    detail: error?.error as string,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            } else {
                this.loading.set(false);
                this.messageService.add({
                    severity: 'warn',
                    summary: 'Items Upload',
                    detail: 'The file contains no data rows. Please add data below the header row and try again.',
                });
            }
        };
        reader.readAsArrayBuffer(file);
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
