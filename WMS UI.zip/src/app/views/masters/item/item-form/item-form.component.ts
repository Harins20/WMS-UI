import {
    Component,
    DestroyRef,
    effect,
    inject,
    input,
    signal,
} from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputNumber } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import { selectOption } from '../../../../common/models';
import {
    AuthService,
    Base64ConvertService,
    OptionsService,
    safeAtob,
} from '../../../../common/services';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import {
    upperCaseArray,
    upperCaseObject,
} from '../../../../shared/utils/case-conversion.util';
import { ItemColumns } from '../item.columns';
import { FileUpload } from 'primeng/fileupload';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { finalize } from 'rxjs';
import { TabsModule } from 'primeng/tabs';
import { DatePickerModule } from 'primeng/datepicker';
import { Image } from 'primeng/image';
import { KeyFilterModule } from 'primeng/keyfilter';
import { MessageService } from 'primeng/api';
import {
    InputSelectComponent,
    InputTextComponent,
} from '../../../../common/components';
import { InputDatepickerComponent } from '../../../../common/components/input-datepicker/input-datepicker.component';
import { InputNumberComponent } from '../../../../common/components/input-number/input-number.component';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { CommonModule } from '@angular/common';
import { ItemService } from '../item.service';

@Component({
    selector: 'item-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        FileUpload,
        ToggleButtonModule,
        TabsModule,
        DatePickerModule,
        Image,
        KeyFilterModule,
        InputTextComponent,
        InputSelectComponent,
        InputDatepickerComponent,
        InputNumberComponent,
        AppTranslatePipe,
        CommonModule,
    ],
    templateUrl: './item-form.component.html',
    styleUrl: './item-form.component.scss',
})
export class ItemFormComponent {
    ItemData = input<any>();
    VerifyItemData = input<any>();

    private ref = inject(DynamicDialogRef);
    private optionService = inject(OptionsService);
    private destroyRef = inject(DestroyRef);
    private base64convert = inject(Base64ConvertService);
    private itemService = inject(ItemService);

    // ✅ Single signal for tab validation warning
    setViewTAb = signal<boolean>(true);
    // ✅ Single signal for active tab
    activeTab = signal<number>(0);
    private messageService = inject(MessageService);
    private authService = inject(AuthService);
    statusOptions = signal<selectOption[]>(
        ItemColumns['IsActive'].options || [],
    );
    EnableReplenishmentOptions = signal<selectOption[]>(
        ItemColumns['EnableReplenishment'].options || [],
    );

    loading = signal({
        owner: false,
        pack: false,
        location: false,
        Type: false,
    });
    formControls: any = Object.fromEntries(
        Object.values(ItemColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    form = new FormGroup(this.formControls);
    ownerOptions = signal<selectOption[]>([]);
    uomOptions = signal<selectOption[]>([]);
    packOptions = signal<selectOption[]>([]);
    TypeOptions = signal<selectOption[]>([]);
    attachmentData = signal<string | null>(null);
    pickLocationOptions = signal<selectOption[]>([]);
    itemColumns = signal<any[]>([]);
    getItemImage = effect(() => {
        const rawItem = this.ItemData()
            ? upperCaseObject(this.ItemData())
            : null;
        const attachmentId = rawItem?.ATTACHMENTID;

        if (!attachmentId) {
            return;
        }

        this.itemService.GetItemsAttachment(attachmentId).subscribe({
            next: (res: any) => {
                if (this.ItemData()) {
                    this.ItemData().FILEDATA = res;
                    this.ItemData().FileData = res;
                }
                this.form.get('FILEDATA')?.setValue(res);
            },
        });
    });

    ngOnInit() {
        if (this.ItemData()) {
            const rawItem = this.ItemData();
            this.form.patchValue({
                ...rawItem,
                FILENAME: rawItem?.ATTACHMENTFILENAME || rawItem?.FILENAME,
                UdfDateTime1: rawItem?.UDFDATETIME1
                    ? new Date(rawItem.UDFDATETIME1)
                    : null,
                UdfDateTime2: rawItem?.UDFDATETIME2
                    ? new Date(rawItem.UDFDATETIME2)
                    : null,
                UdfDateTime3: rawItem?.UDFDATETIME3
                    ? new Date(rawItem.UDFDATETIME3)
                    : null,
                UdfDateTime4: rawItem?.UDFDATETIME4
                    ? new Date(rawItem.UDFDATETIME4)
                    : null,
                UdfDateTime5: rawItem?.UDFDATETIME5
                    ? new Date(rawItem.UDFDATETIME5)
                    : null,
                UdfDateTime6: rawItem?.UDFDATETIME6
                    ? new Date(rawItem.UDFDATETIME6)
                    : null,
                UdfDateTime7: rawItem?.UDFDATETIME7
                    ? new Date(rawItem.UDFDATETIME7)
                    : null,
                UdfDateTime8: rawItem?.UDFDATETIME8
                    ? new Date(rawItem.UDFDATETIME8)
                    : null,
                UdfDateTime9: rawItem?.UDFDATETIME9
                    ? new Date(rawItem.UDFDATETIME9)
                    : null,
                UdfDateTime10: rawItem?.UDFDATETIME10
                    ? new Date(rawItem.UDFDATETIME10)
                    : null,
            });
            this.GetUOMOptions(rawItem?.PACKKEY);
        }
        this.GetOwnerOptions();
        this.GetItemTypeOptions();

        this.GetPackOptions();
        this.GetPickLocation();
        if (this.ItemData()) {
            Object.values(ItemColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.form.controls[column.field]?.disable();
            });
        } else {
            Object.values(ItemColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.form.controls[column.field]?.disable();
            });
            this.form.patchValue({
                TRADERKEY: safeAtob(sessionStorage.getItem('TraderKey')),
            });
        }
        this.getColumns();
    }

    // ✅ Navigate to tab
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    closePanel() {
        this.ref.close();
    }
    SkuValue = this.form.controls['Sku']?.valueChanges.subscribe((value) => {
        if (value) {
            const items = this.VerifyItemData()
                ? upperCaseArray(this.VerifyItemData())
                : [];
            const exists = items?.some((item: any) => item.SKU === value);
            if (exists) {
                this.messageService.add({
                    severity: 'error',
                    summary: 'New Item creation',
                    detail: 'Please use different SKU, already exists',
                });
            }
        }
    });

    PackKeyValue = this.form.controls['PackKey']?.valueChanges.subscribe(
        (value) => {
            if (value) {
                this.GetUOMOptions(value);
            }
        },
    );

    grossWeight = this.form.controls['StdGrossWgt']?.valueChanges.subscribe(
        (value) => {
            const netwgt = this.form.get('StdNetWgt') as FormControl;
            netwgt?.setValidators([Validators.max(value || 0)]);
            const TareQty = (value || 0) - (netwgt?.value || 0);
            const tareControl = this.form.get('TareWeight');
            tareControl?.setValue(TareQty);
        },
    );
    netWeight = this.form.controls['StdNetWgt']?.valueChanges.subscribe(
        (value) => {
            const TareQty =
                (this.form.get('StdGrossWgt')?.value || 0) - (value || 0);
            const tareControl = this.form.get('TareWeight');
            tareControl?.setValue(TareQty);
        },
    );

    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
        this.GetPackOptions();
    }

    GetUOMOptions(Packkey: string) {
        if (!Packkey) return;
        const subscription = this.optionService
            .getUomOptions(Packkey)
            .subscribe({
                next: (data) => {
                    this.uomOptions.set(
                        upperCaseArray(data).map((x: any) => ({
                            label: x.LABEL ?? x.label,
                            value: x.VALUE ?? x.value,
                        })),
                    );
                },
                error: (err) => {
                    console.error('Error fetching UOM dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetItemTypeOptions() {
        this.loading.update((old) => ({ ...old, Type: true }));
        const subscription = this.optionService
            .getItemTypeOptions()
            .pipe(
                finalize(() =>
                    this.loading.update((old) => ({ ...old, Type: false })),
                ),
            )
            .subscribe({
                next: (data) => {
                    this.TypeOptions.set(
                        upperCaseArray(data).map((x: any) => ({
                            label: x.LABEL ?? x.label,
                            value: x.VALUE ?? x.value,
                        })),
                    );
                },
                error: (err) => {
                    console.error(
                        'Error fetching Item Type dropdown data:',
                        err,
                    );
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetOwnerOptions() {
        this.loading.update((old) => ({ ...old, owner: true }));
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe(
                finalize(() =>
                    this.loading.update((old) => ({ ...old, owner: false })),
                ),
            )
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(
                        upperCaseArray(data).map((x: any) => ({
                            label: x.LABEL ?? x.label,
                            value: x.VALUE ?? x.value,
                        })),
                    );
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPackOptions() {
        this.loading.update((old) => ({ ...old, pack: true }));
        const subscription = this.optionService
            .getPackOptions()
            .pipe(
                finalize(() =>
                    this.loading.update((old) => ({ ...old, pack: false })),
                ),
            )
            .subscribe({
                next: (data) => {
                    this.packOptions.set(
                        upperCaseArray(data).map((x: any) => ({
                            label: x.LABEL ?? x.label,
                            value: x.VALUE ?? x.value,
                        })),
                    );
                },
                error: (err) => {
                    // console.error('Error fetching pack dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    async onFileSelect(event: any) {
        const file = event.files[0];
        const fileName = file.name;

        const base64: string = (await this.base64convert.baseConverFile(
            file,
        )) as string;
        this.form.get('FILENAME')?.setValue(fileName);
        if (base64) {
            this.form.get('FILEDATA')?.setValue(base64);
            this.attachmentData.set(base64);
        }
    }
    GetPickLocation() {
        this.loading.update((old) => ({ ...old, location: true }));
        const subscription = this.optionService
            .getPickLocationOptions()
            .pipe(
                finalize(() =>
                    this.loading.update((old) => ({ ...old, location: false })),
                ),
            )
            .subscribe({
                next: (data) => {
                    this.pickLocationOptions.set(
                        upperCaseArray(data).map((x: any) => ({
                            label: x.LABEL ?? x.label,
                            value: x.VALUE ?? x.value,
                        })),
                    );
                },
                error: (err) => {
                    console.error('Error fetching Loc dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    onSubmit() {
        if (this.form.valid) {
            this.setViewTAb.set(true);
            this.ref.close({
                ...this.form.getRawValue(),
                FILEDATA:
                    this.attachmentData() || this.form.get('FILEDATA')?.value,
            });

            this.form.reset();
        } else {
            this.setViewTAb.set(false);
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
    getColumns() {
        this.optionService.getColumns(ItemColumns, 'ITEM').subscribe({
            next: (data) => {
                console.log('Item Columns:', data);
                this.itemColumns.set(data);
            },
        });
    }
}
