import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { AppConfigService } from '../../../../app.config.service';
import { AuthService } from '../../../common/services';
import { Item } from '../item/item.model';
import { map } from 'rxjs';
import { stringToDate } from '../../../common/functions';
import {
    lowerCaseArray,
    lowerCaseObject,
    upperCaseArray,
} from '../../../shared/utils/case-conversion.util';
import { ItemColumns } from './item.columns';

@Injectable({
    providedIn: 'root',
})
export class ItemService {
    SetActive = signal(false);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getItem() {
        return this.httpClient
            .get<
                Item[]
            >(this.config.appConfig()?.MasterUrl + 'items', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((Response) => {
                    const upperData = upperCaseArray(Response);
                    return upperData.map((item, idx) => ({
                        ...item,
                        rowId: idx + 1,
                    }));
                }),
            );
    }
    getItemPage(data: any) {
        return this.httpClient
            .post<any>(
                this.config.appConfig()?.MasterUrl + 'items/Page',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response) => {
                    if (response?.vw_item) {
                        response.vw_item = upperCaseArray(response.vw_item);
                        response.vw_item.forEach((x: any) => {
                            Object.keys(x).forEach((key) => {
                                if (ItemColumns[key]?.type === 'date') {
                                    x[key] = stringToDate(x[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    GetItemsAttachment(Id: any) {
        return this.httpClient.get(
            this.config.appConfig()?.MasterUrl +
                `items/attachment?Facility=DEV&Id=${Id}`,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    createItem(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + 'items',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    updateItem(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.MasterUrl + 'items',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    createItemsEdi(data: any) {
        this.SetActive.set(true);
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + 'items/upload',
            Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
