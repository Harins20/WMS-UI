import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../common/components';
import { AreaFormComponent } from './area-form/area-form.component';
import { AreaColumns } from './area.columns';
import { Area } from './area.model';
import { AreaService } from './area.service';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { tableOptions } from '../../../common/constants';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';
import { TranslateService } from '@ngx-translate/core';
import { FileUpload } from 'primeng/fileupload';
import { OptionsService } from '../../../common/services/options.service';
import { AppTranslatePipe } from '../../../common/pipes';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { filterQuery } from '../../../common/functions';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';

@Component({
    selector: 'app-area',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        FileUpload,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        TooltipModule,
        LoadingComponent,
        CustomTablePaginationComponent,
        AppTranslatePipe,
    ],
    templateUrl: './area.component.html',
    styleUrl: './area.component.scss',
    providers: [DialogService],
})
export class AreaComponent {
    area = signal<Area[]>([]);
    selectedArea = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    private translate = inject(TranslateService);
    tableOptions = signal(tableOptions);
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    exportFileName = 'Areas';
    dt = viewChild.required<Table>('dt');
    excelData: any = [];
    selectedAreas = signal<any>([]);
    tablePaginationMessage =
        'Showing {first} to {last} of {totalRecords} Areas';
    columns = signal<any>(
        Object.values(AreaColumns).filter((column) => column.field),
    );
    OrginalColumns = signal<any>(AreaColumns);

    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    globalcolumns = signal(
        Object.values(AreaColumns).filter((column) => column.field),
    );
    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x: any) => x.tableAlias && !x.tableHidden)
            .map((x: any) => x.field),
    );

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    userFormRef: DynamicDialogRef | undefined;
    private router = inject(Router);
    private messageService = inject(MessageService);
    private areaService = inject(AreaService);
    private destoryRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    ConfirmationRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private optionService = inject(OptionsService);
    areaExcel = signal<Area[]>([]);
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(15);
    constructor() {}

    ngOnInit() {
        this.getAreaPage();
        this.getColumns();
    }

    // loadData(event: TableLazyLoadEvent) {
    //     console.log(event);

    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         AreaColumns,
    //         'vw.',
    //     );
    //     this.getAreaPage({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getAreaPage(event);
    }
    getColumns() {
        this.optionService.getColumns(AreaColumns, 'AREA').subscribe({
            next: (data) => {
                console.log(data);
                if (data.length === 0) {
                    this.columns.set(
                        Object.values(AreaColumns).filter(
                            (column) => column.field,
                        ),
                    );
                } else {
                    const FilterField = data.map((x: any) => x.field);
                    const GetFilterFields = Object.values(AreaColumns).filter(
                        (x: any) => {
                            return !FilterField.includes(x.field);
                        },
                    );
                    const columns = [...GetFilterFields, ...data];
                    this.columns.set(
                        columns.filter((column: any) => !column.tableHidden),
                    );
                }
            },
        });
    }

    // getArea() {
    //     this.loading.set(true);
    //     this.area.set([]);
    //     const subscription = this.areaService
    //         .getArea()
    //         .pipe(
    //             finalize(() => {
    //                 this.loading.set(false);
    //             }),
    //         )
    //         .subscribe({
    //             next: (res: any) => {
    //                 this.area.set(
    //                     res.map((x: any, idx: number) => ({
    //                         ...x,
    //                         rowId: idx + 1,
    //                     })),
    //                 );
    //             },
    //             error: (error: HttpErrorResponse) => {
    //                 if (error.status === 0)
    //                     this.messageService.add({
    //                         severity: 'error',
    //                         summary: 'Area list',
    //                         detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
    //                     });
    //                 this.loading.set(false);
    //             },
    //         });

    //     this.destoryRef.onDestroy(() => subscription.unsubscribe());
    // }
    getAreaPage(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.area.set([]);
        const subscription = this.areaService
            .getAreaPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    console.log(res);

                    this.area.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                    this.totalRecords.set(res.TotalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Area list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    } else if (
                        error.error.Message ===
                            'One or more errors occurred!' ||
                        error.error.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: error,
                                },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                    } else {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Area list',
                            detail:
                                error.error.message ||
                                (error.error.Message as string),
                        });
                    }
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getAreaPage();
    }

    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getAreaPage();
    }

    getAreaForExcel(
        data: any = { Page: 1, PageSize: this.totalRecords },
        type: string,
    ) {
        this.areaExcel.set([]);
        const subscription = this.areaService
            .getAreaPage(data)
            .pipe()
            .subscribe({
                next: (res: any) => {
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }

                    this.areaExcel.set(res.Area);
                    if (res.Area && type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            res.PO,
                        );
                    } else {
                        downloadCSVFile(res.PO, this.exportFileName);
                    }
                },
            });
    }
    export(type: string) {
        const event = this.loadEvent();
        const PageSize = this.totalRecords();
        const Page = (event.first || 0) / PageSize + 1;
        const { filter, orderBy } = filterQuery(
            event,
            this.globalFilterColumns(),
            AreaColumns,
            'vw.',
        );

        this.getAreaForExcel(
            {
                Page,
                PageSize,
                Condition: filter,
                OrderBy: orderBy,
            },
            type,
        );
    }
    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }

    exportExcelTemplate() {
        const Column = ['AreaId', 'Area', 'Descr'];
        this.excelDownloadService.downloadExcelFile(
            'Area-Template',
            Column,
            null,
        );
    }

    options(field: string) {
        const uniqueValues = new Set(this.area().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedArea().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedArea().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '45rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    OpenCreateAreaForm() {
        const headerText = this.translate.instant('Create Area');
        const header = this.translate.instant('Confirm Creation');
        const value = this.translate.instant('AreaCreation');
        this.userFormRef = this.dialogService.open(AreaFormComponent, {
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',
            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },
            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },
            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );

                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.areaService
                            .createArea(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getAreaPage();
                                }),
                            )
                            .subscribe({
                                next: (resData: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Area creation',
                                        detail: resData as string,
                                    });
                                    this.loading.set(false);
                                },
                                error: (error: any) => {
                                    if (
                                        error.error?.Message ===
                                            'One or more errors occurred!' ||
                                        error.error?.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New Area creation',
                                            detail: error.error as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateAreaForm(Data: any) {
        const headerText = this.translate.instant('Update Area');
        const header = this.translate.instant('Confirm Update');
        const value = this.translate.instant('AreaUpdate');
        console.log('Area Update Data: ', Data);
        this.userFormRef = this.dialogService.open(AreaFormComponent, {
            inputValues: {
                AreaData: Data,
            },
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',
            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },
            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },
            breakpoints: {
                '960px': '100vw',
            },
        });

        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );

                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.areaService
                            .updateArea(data)
                            .pipe(
                                finalize(() => {
                                    this.getAreaPage();
                                    this.loading.set(false);
                                }),
                            )
                            .subscribe({
                                next: (resData: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Area Updation',
                                        detail: resData as string,
                                    });
                                },
                                error: (error: any) => {
                                    if (
                                        error.error?.Message ===
                                            'One or more errors occurred!' ||
                                        error.error?.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Area Updation',
                                            detail: error.error as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
