import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { selectOption } from '../../../../common/models';
import { AuthService, OptionsService } from '../../../../common/services';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { AreaColumns } from '../area.columns';
import { Checkbox } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { MessageService } from 'primeng/api';
import { InputTextComponent } from '../../../../common/components/input-text/input-text.component';
import { InputSelectComponent } from '../../../../common/components/input-select/input-select.component';
import { InputDatepickerComponent } from '../../../../common/components/input-datepicker/input-datepicker.component';
import { InputNumberComponent } from '../../../../common/components';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { AreaService } from '../area.service';
import { AreaLocationFormComponent } from '../area-location-form';
import { AppTranslatePipe } from '../../../../common/pipes';

@Component({
    selector: 'area-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        Checkbox,
        DatePickerModule,
        InputNumberComponent,
        InputTextComponent,
        InputSelectComponent,
        InputDatepickerComponent,
        AppTranslatePipe,
        CommonModule,
    ],
    templateUrl: './area-form.component.html',
    styleUrl: './area-form.component.scss',
})
export class AreaFormComponent {
    private translate = inject(TranslateService);
    AreaData = input<any>();
    tempData = signal<any>({});

    params = computed(() => {
        if (this.AreaData()?.Area) return `area=${this.AreaData()?.Area}`;
        return 'NArea=true';
    });
    private optionService = inject(OptionsService);
    private destroyRef = inject(DestroyRef);
    private areaService = inject(AreaService);
    private router = inject(Router);
    areaColumns: any[] = [];
    private ref = inject(DynamicDialogRef);
    private dialogService = inject(DialogService);
    setViewTAb = signal<boolean>(true);
    activeTab = signal<number>(0);
    statusOptions = signal<selectOption[]>(
        AreaColumns['IsActive'].options || [],
    );
    areaTypeOptions = signal<selectOption[]>([]);
    loading = signal(false);
    formControls: any = Object.fromEntries(
        Object.values(AreaColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    form = new FormGroup(this.formControls);
    private messageService = inject(MessageService);

    ngOnInit() {
        this.GetAreaTypeOptions();
        if (this.AreaData()) {
            this.tempData.set(this.AreaData());
            console.log(this.AreaData());

            this.form.patchValue({
                ...this.AreaData(),
                UdfDateTime1: this.AreaData()?.UdfDateTime1
                    ? new Date(this.AreaData().UdfDateTime1)
                    : null,
                UdfDateTime2: this.AreaData()?.UdfDateTime2
                    ? new Date(this.AreaData().UdfDateTime2)
                    : null,
                UdfDateTime3: this.AreaData()?.UdfDateTime3
                    ? new Date(this.AreaData().UdfDateTime3)
                    : null,
                UdfDateTime4: this.AreaData()?.UdfDateTime4
                    ? new Date(this.AreaData().UdfDateTime4)
                    : null,
                UdfDateTime5: this.AreaData()?.UdfDateTime5
                    ? new Date(this.AreaData().UdfDateTime5)
                    : null,
            });
            if (this.AreaData()) {
                Object.values(AreaColumns).forEach((column) => {
                    if (column.restrictEdit)
                        this.form.controls[column.field].disable();
                });
            } else {
                Object.values(AreaColumns).forEach((column) => {
                    if (column.restrictInsert)
                        this.form.controls[column.field].disable();
                });
            }
        }
        this.getColumns();
    }

    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    closePanel() {
        this.ref.close();
    }
    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        if (formControl && formControl.invalid) {
            return getErrorMessages(
                formControl.errors,
                title || AreaColumns[formControlName]?.label,
            );
        }
        return [];
    }

    GetAreaTypeOptions() {
        const subscription = this.areaService.getAreaOptions().subscribe({
            next: (data: any) => {
                this.areaTypeOptions.set(data);
            },
            error: (err: any) => {
                console.error('Error fetching Area Type dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    onClickArea() {
        const header = this.translate.instant('Manage Area');

        const locationRef = this.dialogService.open(AreaLocationFormComponent, {
            inputValues: {
                area: this.tempData(),
            },
            header: header,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '55rem',
            style: { height: '45rem' },
        });

        locationRef.onClose.subscribe((data) => {
            if (data) {
                // handle if needed
            }
        });
    }

    getColumns() {
        this.optionService.getColumns(AreaColumns, 'AREA').subscribe({
            next: (data) => {
                const FilterField = data.map((x: any) => x.field);
                const GetFilterFields = Object.values(AreaColumns).filter(
                    (x: any) => {
                        return !FilterField.includes(x.field);
                    },
                );
                const columns = [...GetFilterFields, ...data];
                this.areaColumns = columns;
            },
        });
    }

    onSubmit() {
        markAllControlsAsDirty(Object.values(this.form.controls));
        if (this.form.valid) {
            const formData = this.form.getRawValue();
            this.ref.close(formData);
        } else {
            this.setViewTAb.set(false);
            const firstInvalidControl = Object.keys(this.form.controls).find(
                (key) => this.form.controls[key].invalid,
            );
            if (firstInvalidControl) {
                const element = document.querySelector(
                    `[formcontrolname="${firstInvalidControl}"]`,
                );
                if (element) {
                    element.scrollIntoView({
                        behavior: 'smooth',
                        block: 'center',
                    });
                }
            }
        }
    }
}
