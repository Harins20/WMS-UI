import { HttpClient } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { Area } from './area.model';
import { AppConfigService } from '../../../../app.config.service';
import { AuthService } from '../../../common/services';
import { map } from 'rxjs';
import { AreaColumns } from './area.columns';
import { stringToDate } from '../../../common/functions';

@Injectable({
    providedIn: 'root',
})
export class AreaService {
    SetActive = signal(false);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getArea() {
        return this.httpClient.get<Area[]>(
            this.config.appConfig()?.MasterUrl + 'areas',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getAreaOptions() {
        return this.httpClient
            .get<
                any[]
            >(this.config.appConfig()?.MasterUrl + 'areas/options', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x) => ({
                        ...x,
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }
    getAreaPage(data: any) {
        return this.httpClient
            .post<any>(
                this.config.appConfig()?.MasterUrl + 'areas/page',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response) => {
                    if (response?.Response) {
                        response.Response.forEach((x: any) => {
                            Object.keys(x).forEach((key) => {
                                if (AreaColumns[key]?.type === 'date') {
                                    x[key] = stringToDate(x[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    createArea(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + 'areas',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    updateArea(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.MasterUrl + 'areas',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
