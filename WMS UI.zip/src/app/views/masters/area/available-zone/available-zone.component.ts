import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { finalize } from 'rxjs';
import {
    ConfirmationDialogComponent,
    CustomTableComponent,
} from '../../../../common/components';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';
import { tableOptions } from '../../../../common/constants';
import { ExcelDownloadService } from '../../../../common/services';
import {
    areaLocationColumns,
    AreaLocationService,
    AreaLocationFormComponent,
} from '../area-location-form';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-available-zone',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TranslatePipe,
        TooltipModule,
        CustomTableComponent,
    ],
    templateUrl: './available-zone.component.html',
    styleUrl: './available-zone.component.scss',
})
export class AvailableZoneComponent {
    private translate = inject(TranslateService);
    location = signal<any[]>([]);
    tempData = signal<any>([]);
    area = input<any | undefined>();

    // FIX 1: carries the parent's area into the "Add" dialog.
    // Kept separate from `area` so `params` still returns 'available-zones' in the dialog.
    selectedArea = input<any | undefined>();

    params = computed(() => {
        if (this.area())
            return 'assigned-zones?AreaSerialKey=' + this.area()?.SerialKey;
        return `available-zones`;
    });
    selectedLocation = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    tableOptions = signal(tableOptions);
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    exportFileName = 'Locations';
    dt = viewChild.required<Table>('dt');
    tablePaginationMessage =
        'Showing {first} to {last} of {totalRecords} Locations';
    columns = signal(
        Object.values(areaLocationColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    userFormRef: DynamicDialogRef | undefined;
    private ref = inject(DynamicDialogRef);

    private messageService = inject(MessageService);
    private locationService = inject(AreaLocationService);
    private excelDownloadService = inject(ExcelDownloadService);
    private destoryRef = inject(DestroyRef);
    ConfirmationRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    facility = signal<string | null>(
        atob(sessionStorage.getItem('Facility') ?? ''),
    );
    constructor() {}

    ngOnInit() {
        if (this.area()) {
            console.log(this.area);

            this.tempData.set(this.area());
        }
        this.getAvailableZone();
    }
    globalcolumns = computed(() => this.columns().map((x) => x.field));
    getAvailableZone() {
        console.log(this.area());

        this.loading.set(true);
        this.location.set([]);
        const subscription = this.locationService
            .getAvailableZone()
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    this.location.set(
                        res.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Location list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getAvailableZone();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.location(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.location(), this.exportFileName);
    }

    options(field: string) {
        const uniqueValues = new Set(this.location().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedLocation().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedLocation().length > 0 ? true : false,
    );

    onAdd() {
        const header = this.translate.instant('Confirm Location Addition');
        const value = this.translate.instant('AssignAreaLocation');
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: header,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
            if (confirmed) {
                this.loading.set(true);
                const encodedFacility = sessionStorage.getItem('Facility');

                const facility = encodedFacility ? atob(encodedFacility) : null;

                const selectedLocation = this.selectedLocation().map(
                    (x: any) => x.Value,
                );

                // FIX 2: read the area from selectedArea (passed in by the parent),
                // and fall back to area() in case this is called from the parent screen.
                const areaSerialKey =
                    this.selectedArea()?.SerialKey ?? this.area()?.SerialKey;
                const zoneSerialKeys = selectedLocation;

                console.log('Facility:', facility);
                console.log('AreaSerialKey:', areaSerialKey);
                console.log('ZoneSerialKeys:', zoneSerialKeys);

                this.locationService
                    .addLocationsToArea({
                        Facility: facility,
                        AreaSerialKey: areaSerialKey,
                        ZoneSerialKeys: zoneSerialKeys,
                    })
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                        }),
                    )
                    .subscribe({
                        next: (Data: any) => {
                            this.ref.close();
                            this.messageService.add({
                                severity: 'success',
                                summary: 'New Location Creation',
                                detail: 'New location Creation Successfully',
                            });
                        },

                error: (error: any) => {
                    if (
                        error.error?.Message ===
                            'One or more errors occurred!' ||
                        error.error?.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: error,
                                },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: {
                                    maxHeight: '40rem',
                                },
                            },
                        );
                    } else {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'New Location Creation',
                            detail: 'New location Creation Unsuccessfully',
                        });
                    }
                },
            });
            }
        });
    }
}
