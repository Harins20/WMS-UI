import { Validators } from '@angular/forms';
import { Columns } from '../../../../common/models';

export const areaLocationColumns: Columns = {
    rowId: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
    },
    Label: {
        label: 'Zone',
        field: 'Label',
        type: 'text',
        defaultValue: '',
        validators: [Validators.maxLength(30)],
    },


};
