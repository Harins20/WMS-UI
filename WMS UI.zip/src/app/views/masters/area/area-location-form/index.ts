export * from './area-location.columns';
export * from './area-location-form.component';
export * from './area-location.model';
export * from './area-location.service';
