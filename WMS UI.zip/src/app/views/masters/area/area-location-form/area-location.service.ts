import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map } from 'rxjs';
import { AppConfigService } from '../../../../../app.config.service';
import { AuthService } from '../../../../common/services';
import { AreaLocation } from './area-location.model';

@Injectable({
    providedIn: 'root',
})
export class AreaLocationService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getAssignedZone(params: string) {
        return this.httpClient.get<AreaLocation[]>(
            this.config.appConfig()?.MasterUrl + 'areas/assigned-zones?AreaSerialKey=' + params,
            { headers: this.authService.getAuthHeaders() },
        );
    }
  
    getAvailableZone() {
        return this.httpClient.get<AreaLocation[]>(
            this.config.appConfig()?.MasterUrl + 'areas/available-zones',
            { headers: this.authService.getAuthHeaders() },
        );
    }
  
    addLocationsToArea(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.MasterUrl +
                `areas/add-zone`,
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    removeLocationsFromArea(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.MasterUrl + 'areas/remove-zone',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    getLocationType() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocType',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    value.map((x: any) => ({
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }
    getLocationFlag() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocFlag',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    value.map((x: any) => ({
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }
    getLocationHandling() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocHandling',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    value.map((x: any) => ({
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }
    getLocationCategory() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocCategory',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    value.map((x: any) => ({
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }
    getPutawayZone() {
        return this.httpClient
            .get(this.config.appConfig()?.MasterUrl + 'zones', {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe(
                map((value: any) =>
                    value.map((x: any) => ({
                        label: x.Zone,
                        value: x.Zone,
                    })),
                ),
            );
    }
}
