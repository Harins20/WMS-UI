import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';
import { Trader } from './trader.model';
import { map } from 'rxjs';
import {
    lowerCaseArray,
    lowerCaseObject,
    upperCaseArray,
} from '../../../shared/utils/case-conversion.util';

@Injectable({
    providedIn: 'root',
})
export class TraderService {
    isPanelOpen = false;
    FormType = signal<string>('');
    SetUpdateData = signal<any>({});
    SetActive = signal(false);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);
    TraderKey = this.safeAtob(sessionStorage.getItem('TraderKey'));

    safeAtob(val: string | null): string | null {
        if (!val) return null;
        try {
            return atob(val);
        } catch {
            return null;
        }
    }
    getTraders(event: any, type: any) {
        return this.httpClient
            .post<
                Trader[]
            >(this.config.appConfig()?.MasterUrl + `traders/Page?type=${type}`, event, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((traders: any) => {
                    const upperData = upperCaseArray(traders?.Response);
                    return upperData?.map((x, idx: number) => ({
                        ...x,
                        rowId: idx + 1,
                    }));
                }),
            );
    }
    traderCreation(data: any, type: any) {
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + `traders?type=${type}`,
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    traderUpdate(data: any, type: any) {
        return this.httpClient.put(
            this.config.appConfig()?.MasterUrl + `traders?type=${type}`,
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    createTraders(data: any, type: any) {
        this.SetActive.set(true);
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + `traders/upload?type=${type}`,
            Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
