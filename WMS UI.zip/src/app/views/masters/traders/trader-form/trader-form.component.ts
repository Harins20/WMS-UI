import { Component, inject, input, signal } from '@angular/core';
import {
    FormControl,
    FormGroup,
    FormsModule,
    ReactiveFormsModule,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';

import { CheckboxModule } from 'primeng/checkbox';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { KeyFilterModule } from 'primeng/keyfilter';
import { TabsModule } from 'primeng/tabs';
import { finalize, Subscription } from 'rxjs';
import {
    InputDatepickerComponent,
    InputNumberComponent,
    InputSelectComponent,
    InputTextComponent,
} from '../../../../common/components';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { selectOption } from '../../../../common/models';
import { ConfigurationService } from '../../../configurations';
import { TraderColumns } from '../trader.columns';
import { MessageService } from 'primeng/api';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { CommonModule } from '@angular/common';
import {
    upperCaseArray,
    upperCaseObject,
} from '../../../../shared/utils/case-conversion.util';

@Component({
    selector: 'trader-form',
    imports: [
        ReactiveFormsModule,
        ButtonModule,
        TabsModule,
        CheckboxModule,
        InputTextComponent,
        InputSelectComponent,
        InputDatepickerComponent,
        InputNumberComponent,
        AppTranslatePipe, CommonModule,
    ],
    templateUrl: './trader-form.component.html',
    styleUrl: './trader-form.component.scss',
    providers: [DialogService],
})
export class TraderFormComponent {
    traderData = input<any>();
    traderType = input<any>();
    traderName = input<any>();
    loading = signal({ config: false });
    copyAddress = new FormControl(false);
    configs = signal<selectOption[]>([]);
    statusOptions = signal<selectOption[]>(
        TraderColumns['STATUS'].options || [],
    );
    private ref = inject(DynamicDialogRef);
    setViewTAb = signal(true);
    private messageService = inject(MessageService);
    formControls: any = Object.fromEntries(
        Object.values(TraderColumns).map((column) => [
            column.field,
            new FormControl<string>(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );

    form = new FormGroup(this.formControls);
    copyAddressSubscription: Subscription[] = [];

    activeTab = signal<number>(0);

    private configService = inject(ConfigurationService);

    goToTab(index: number): void {
        this.activeTab.set(index);
    }

    ngOnInit() {
        if (this.traderData()) {
            const rawTrader = upperCaseObject(this.traderData());
            Object.values(TraderColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.form.controls[column.field].disable();
            });
            this.form.patchValue({
                ...rawTrader,
                UDFDATETIME1: rawTrader?.UDFDATETIME1
                    ? new Date(rawTrader.UDFDATETIME1)
                    : null,
                UDFDATETIME2: rawTrader?.UDFDATETIME2
                    ? new Date(rawTrader.UDFDATETIME2)
                    : null,
                UDFDATETIME3: rawTrader?.UDFDATETIME3
                    ? new Date(rawTrader.UDFDATETIME3)
                    : null,
                UDFDATETIME4: rawTrader?.UDFDATETIME4
                    ? new Date(rawTrader.UDFDATETIME4)
                    : null,
                UDFDATETIME5: rawTrader?.UDFDATETIME5
                    ? new Date(rawTrader.UDFDATETIME5)
                    : null,
            });
            this.getConfig(rawTrader?.TRADERKEY);
        } else {
            Object.values(TraderColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.form.controls[column.field].disable();
                this.form.patchValue({
                    TYPE: this.traderType(),
                });
            });
            this.getConfig();
        }
        this.copyAddress.valueChanges.subscribe((selectedValue) => {
            if (selectedValue) {
                this.form.patchValue({
                    B_COMPANY: this.form.value.COMPANY,
                    B_ADDRESS1: this.form.value.ADDRESS1,
                    B_ADDRESS2: this.form.value.ADDRESS2,
                    B_ADDRESS3: this.form.value.ADDRESS3,
                    B_ADDRESS4: this.form.value.ADDRESS4,
                    B_CITY: this.form.value.CITY,
                    B_STATE: this.form.value.STATE,
                    B_ZIP: this.form.value.ZIP,
                    B_COUNTRY: this.form.value.COUNTRY,
                    B_PHONE1: this.form.value.PHONE1,
                    B_EMAIL1: this.form.value.EMAIL1,
                    B_CONTACT1: this.form.value.CONTACT1,
                });
                this.syncAddressFields();
            } else {
                this.copyAddressSubscription.forEach((sub) =>
                    sub.unsubscribe(),
                );
                this.copyAddressSubscription = [];
            }
        });
    }

    syncAddressFields() {
        const fieldsToSync = [
            'COMPANY',
            'ADDRESS1',
            'ADDRESS2',
            'ADDRESS3',
            'ADDRESS4',
            'CITY',
            'STATE',
            'ZIP',
            'COUNTRY',
            'PHONE1',
            'EMAIL1',
            'CONTACT1',
        ];

        fieldsToSync.forEach((field) => {
            const sub = this.form.get(field)?.valueChanges.subscribe((val) => {
                this.form
                    .get(`B_${field}`)
                    ?.setValue(val, { emitEvent: false });
            });
            if (sub) {
                this.copyAddressSubscription.push(sub);
            }
        });
    }
    getConfig(owner?: string) {
        this.loading.update((old) => ({ ...old, config: true }));
        this.configService
            .getConfigList(owner)
            .pipe(
                finalize(() =>
                    this.loading.update((old) => ({ ...old, config: false })),
                ),
            )
            .subscribe({
                next: (res) => {
                    const converted = upperCaseArray(res) || [];
                    const configOptions = converted.map((x: any) => ({
                        label: x.NAME ?? x.Name,
                        value: x.ID ?? x.Id,
                        Owner: x.OWNER ?? x.Owner,
                    }));
                    this.configs.set(configOptions);
                },
                error: (error: any) => {},
            });
    }

    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }
    closePanel() {
        this.ref.close();
    }
    onSubmit() {
        if (this.form.valid) {
            this.setViewTAb.set(true);
            this.ref.close(this.form.getRawValue());
            this.form.reset();
        } else {
            this.setViewTAb.set(false);
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
}
