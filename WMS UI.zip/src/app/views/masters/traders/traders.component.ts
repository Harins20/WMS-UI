import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    CustomTableComponent,
    LoadingComponent,
} from '../../../common/components';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { TraderFormComponent } from './trader-form/trader-form.component';
import { TraderColumns } from './trader.columns';
import { Trader } from './trader.model';
import { TraderService } from './trader.service';
import { tableOptions } from '../../../common/constants';
import { TooltipModule } from 'primeng/tooltip';
import { TagModule } from 'primeng/tag';
import { PDFDownloadService } from '../../../common/services';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';

import { FileUploadModule } from 'primeng/fileupload';
import { convertExcelDate } from '../../../common/functions/numberToDate';
import * as XLSX from 'xlsx';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';

@Component({
    selector: 'app-traders',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        // LoadingComponent,
        TooltipModule,
        TagModule,
        AppTranslatePipe,
        FileUploadModule,
        TraderFormComponent,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './traders.component.html',
    styleUrl: './traders.component.scss',
    providers: [DialogService, DynamicDialogRef],
})
export class TradersComponent {
    private translate = inject(TranslateService);
    traderType = input.required<number>();
    traderName = input.required<string>();
    traderFormName = input.required<string>();
    traders = signal<Trader[]>([]);
    selectedTraders = signal<Trader[]>([]);
    searchInput = signal<string | undefined>(undefined);
    tableOptions = signal(tableOptions);
    excelData: any = [];
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    tablePaginationMessage = signal<string>('');
    totalRecords = signal<any>(0);
    dt = viewChild.required<Table>('dt');
    [key: string]: any;
    columns = signal(
        Object.values(TraderColumns).filter((column) => !column.tableHidden),
    );
    OrginalColumns = signal<any>(TraderColumns);

    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
        // {
        //     label: 'PDF',
        //     command: () => this.exportPDF(),
        // },
    ];
    userFormRef: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    public traderService = inject(TraderService);
    private destoryRef = inject(DestroyRef);
    ConfirmationRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private excelDownloadService = inject(ExcelDownloadService);
    private PDFDownloadService = inject(PDFDownloadService);
    tooltipText: string = '';

    isEditMode = false;
    loadEvent = signal<any>({});

    constructor() {}
    ngOnInit() {}
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getTraders(event);
    }

    getTraders(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.traders.set([]);
        const subscription = this.traderService
            .getTraders(data, this.traderType())
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    this.traders.set(res);
                    this.totalRecords.set(res?.totalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Carrier list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    exportPDF() {
        this.PDFDownloadService.exportToPdf(
            this.traderFormName(),
            [
                'TraderKey',
                'Company',
                'Description',
                'Status',
                'Address1',
                'Address2',
                'City',
                'State',
                'Contact1',
                'Phone1 ',
                'B_Company:',
                'B_Address1',
                'B_Address2',
                'B_City',
                'B_State',
                'B_Phone1',
            ],
            this.traders(),
        );
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getTraders();
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getTraders();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.traderName(),
            [],
            this.traders(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.traders(), this.traderName());
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(this.traders().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedTraders().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedTraders().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    isPanelOpen = signal(false);

    openPanel() {
        this.traderService.SetUpdateData.set(null);
        this.traderService.FormType.set('Create');
        this.traderService.isPanelOpen = true;
    }
    closePanel() {
        this.traderService.isPanelOpen = false;
        this.isEditMode = false;
    }

    OpenCreateTraderForm() {
        // const headerText =
        //     this.translate.instant('Create') +
        //     ' ' +
        //     this.translate.instant(this.traderFormName()) +
        //     ' ' +
        //     this.translate.instant('Data');
        this.userFormRef = this.dialogService.open(TraderFormComponent, {
            inputValues: {
                traderType: this.traderType(),
                traderName: this.traderName(),
            },
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('TraderCreation', {
                    name: this.traderFormName(),
                });
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        // Ensure Phone1 is treated as a string
                        data.COOLDOWNTIMER = data.COOLDOWNTIMER ?? 0;

                        data.PHONE1 = data.PHONE1.toString();
                        data.B_PHONE1 = data.B_PHONE1.toString();
                        this.traderService
                            .traderCreation(data, this.traderType())
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getTraders();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Success',
                                        detail: `${this.traderFormName()} Created successfully` as string,
                                    });
                                    this.loading.set(false);
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Failed',
                                            detail: error.error as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateTraderForm(trader: Trader) {
        const headertext = this.translate.instant('Update Trader');
        const selectedTraders: Trader = Array.isArray(trader)
            ? trader[0]
            : trader;
        // this.traderService.FormType.set('Update');
        // this.traderService.SetUpdateData.set(selectedTraders);
        // this.traderService.isPanelOpen = true;
        const headerText =
            this.translate.instant('Update') +
            ' ' +
            this.translate.instant(this.traderFormName()) +
            ' ' +
            this.translate.instant('Data');
        this.userFormRef = this.dialogService.open(TraderFormComponent, {
            inputValues: {
                traderName: this.traderName(),
                traderData: trader,
                CoolDownTimer: trader.COOLDOWNTIMER,
            },
            // header: 'Update Receipt - ' + selectedAsn.RECEIPTKEY,
            // closable: true,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('TraderUpdate', {
                    name: this.traderFormName(),
                });
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        data.COOLDOWNTIMER = data.COOLDOWNTIMER ?? 0;

                        this.traderService
                            .traderUpdate(data, this.traderType())
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getTraders();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Success',
                                        detail: `${this.traderFormName()} updated successfully.`,
                                    });
                                    this.loading.set(false);
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Failed',
                                            detail: error.error as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }
    onFileSelect(event: any) {
        const file = event.files[0];
        const reader = new FileReader();
        reader.onload = async (e: any) => {
            const workbook = XLSX.read(e.target.result, { type: 'binary' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            this.excelData = XLSX.utils.sheet_to_json(worksheet, { raw: true });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const sheetData: any[][] = XLSX.utils.sheet_to_json(sheet, {
                header: 1,
            });
            if (this.excelData.length > 0) {
                const dataRows = sheetData.slice(1);
                const FinalData = dataRows.map(
                    (row: any[], rowIndex: number) => {
                        return {
                            TraderKey: row[0] ? row[0].toString() : null,
                            Type: this.traderType(),
                            GST: row[43],
                            Company: row[1],
                            Description: row[2],
                            Vat: row[3],
                            Address1: row[4] ? row[4].toString() : null,
                            Address2: row[5] ? row[5].toString() : null,
                            Address3: row[6] ? row[6].toString() : null,
                            Address4: row[7] ? row[7].toString() : null,
                            Phone1: row[8] ? row[8].toString() : null,
                            City: row[9],
                            State: row[10],
                            Zip: row[11] ? row[11].toString() : null,
                            Country: row[12],
                            Contact1: row[13],

                            Email1: row[14],
                            B_Contact1: row[15],
                            B_Company: row[16],
                            B_Address1: row[17] ? row[17].toString() : null,
                            B_Address2: row[18] ? row[18].toString() : null,
                            B_Address3: row[19] ? row[19].toString() : null,
                            B_Address4: row[20] ? row[20].toString() : null,
                            B_City: row[21],
                            B_State: row[22],
                            B_Zip: row[23] ? row[23].toString() : null,
                            B_Country: row[24],
                            B_Phone1: row[25] ? row[25].toString() : null,
                            B_Email1: row[26],
                            ConfigId: 1,
                            Status: row[27] ? row[27] : 'Active',
                            UdfStr1: row[28],
                            UdfStr2: row[29],
                            UdfStr3: row[30],
                            UdfStr4: row[31],
                            UdfStr5: row[32],
                            UdfDateTime1: row[33]
                                ? convertExcelDate(row[33])
                                : null,
                            UdfDateTime2: row[34]
                                ? convertExcelDate(row[34])
                                : null,
                            UdfDateTime3: row[35]
                                ? convertExcelDate(row[35])
                                : null,
                            UdfDateTime4: row[36]
                                ? convertExcelDate(row[36])
                                : null,
                            UdfDateTime5: row[37]
                                ? convertExcelDate(row[37])
                                : null,
                            UdfFloat1: row[38],
                            UdfFloat2: row[39],
                            UdfFloat3: row[40],
                            UdfFloat4: row[41],
                            UdfFloat5: row[42],
                        };
                    },
                );
                this.loading.set(true);
                this.traderService
                    .createTraders(FinalData, this.traderType())
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.getTraders();
                        }),
                    )
                    .subscribe({
                        next: (data) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Traders',
                                detail: data as string,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Traders',
                                    detail: error?.error?.Message as string,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            } else {
                this.messageService.add({
                    severity: 'error',
                    summary: 'Traders Upload',
                    detail: 'No data available.',
                });
                this.loading.set(false);
            }
        };
        reader.readAsArrayBuffer(file);
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
