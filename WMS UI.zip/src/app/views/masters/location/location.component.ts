import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { Putaway } from './../../inbound/asns/putaway/putaway.model';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    LoadingComponent,
    ConfirmationDialogComponent,
} from '../../../common/components';
import { LocationFormComponent } from './location-form/location-form.component';
import { LocationColumns } from './location.columns';
import { Location } from './location.model';
import { LocationService } from './location.service';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { tableOptions } from '../../../common/constants';
import { TooltipModule } from 'primeng/tooltip';
import { ConfigurationService } from '../../configurations';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';

import { FileUploadModule } from 'primeng/fileupload';
import * as XLSX from 'xlsx';
import { OptionsService } from '../../../common/services';
import {
    filterQuery,
    upperCaseArray,
    uppercasecolumn,
    upperCaseObject,
} from '../../../common/functions';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-zone-location-form',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        AppTranslatePipe,
        FileUploadModule,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './location.component.html',
    styleUrl: './location.component.scss',
    providers: [DialogService],
})
export class LocationComponent {
    location = signal<Location[]>([]);
    private translate = inject(TranslateService);
    selectedLocation = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    tableOptions = signal(tableOptions);
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    exportFileName = 'Locations';
    excelData: any = [];
    dt = viewChild.required<Table>('dt');
    totalRecords = signal(0);
    rows = signal(15);
    loadEvent = signal<any>({});
    OrginalColumns = signal<any>(LocationColumns);
    tablePaginationMessage =
        'Showing {first} to {last} of {totalRecords} Locations';
    columns = signal(
        Object.values(LocationColumns).filter((column) => !column.tableHidden),
    );
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x: any) => x.tableAlias && !x.tableHidden)
            .map((x: any) => x.field),
    );
    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    userFormRef: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private locationService = inject(LocationService);
    private excelDownloadService = inject(ExcelDownloadService);
    private destoryRef = inject(DestroyRef);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    ConfirmationRef: DynamicDialogRef | undefined;
    private optionsService = inject(OptionsService);

    constructor() {}
    ngOnInit() {
        // this.getLocation();
        this.getColumns();
    }

    loadData(event: any) {
        this.loadEvent.set(event);
        this.getLocation(event);
    }
    getColumns() {
        this.optionsService.getColumns(LocationColumns, 'LOCATION').subscribe({
            next: (data) => {
                const upperData = data;
                const FilterField = upperData.map((x: any) => x.field);
                const GetFilterFields = Object.values(LocationColumns).filter(
                    (x: any) => {
                        return !FilterField.includes(x.field);
                    },
                );
                const columns = [...GetFilterFields, ...upperData];
                this.columns.set(
                    columns.filter((column: any) => !column.tableHidden),
                );
            },
        });
    }
    getLocation(data: any) {
        this.loading.set(true);
        const subscription = this.locationService
            .getLocationsPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    const u = res?.Response;
                    const l = uppercasecolumn(u);
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy?.toLowerCase().includes('serialkey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }

                    this.location.set(
                        l.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                    this.totalRecords.set(res.TotalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    console.log(
                        error.status,
                        error.error?.message,
                        error.error,
                        'error for 500',
                    );
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Location list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getLocation(this.loadEvent());
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getLocation(this.loadEvent());
    }
    export(type: string) {
        const event = this.loadEvent();
        event.rows = this.totalRecords();
        this.getLocationForExcel(event, type);
    }
    getLocationForExcel(
        data: any = {
            Page: 1,
            PageSize: this.totalRecords(),
        },
        type: string,
    ) {
        this.loading.set(true);

        const subscription = this.locationService
            .getLocationsPage(data)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res: any) => {
                    const locations = res?.vw_bin || [];
                    if (type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            locations,
                        );
                    } else {
                        downloadCSVFile(locations, this.exportFileName);
                    }
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }
    exportExcelTemplate() {
        const Column = [''];
        this.excelDownloadService.downloadExcelFile(
            'Location Template',
            Column,
            null,
        );
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(this.location().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedLocation().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedLocation().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    onEditAction(location: Location) {}
    OpenCreateLocationForm() {
        const headerText = this.translate.instant('Create Location');
        const header = this.translate.instant('Confirm Creation');
        const value = this.translate.instant('LocationCreation');
        this.userFormRef = this.dialogService.open(LocationFormComponent, {
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });

        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                console.log('data', data);
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        Object.values(LocationColumns).forEach((x) => {
                            if (
                                data[x.field] === undefined ||
                                data[x.field] === null ||
                                data[x.field] === ''
                            ) {
                                data[x.field] = x.defaultValue;
                            }
                        });
                        const ignoredFields = Object.values(LocationColumns)
                            .filter((col: any) => col.ignoreInRequest)
                            .map((col: any) => col.field);

                        const copy = { ...data };
                        ignoredFields.forEach((field) => {
                            delete copy[field];
                        });
                        this.loading.set(true);
                        this.locationService
                            .createLocation(copy)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getLocation(this.loadEvent());
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Location Creation',
                                        detail: data as string,
                                    });
                                },
                                error: (error: any) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New Location Creation',
                                            detail: error.error as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateLocationForm(Data: any) {
        const headerText = this.translate.instant('Update Location');
        const header = this.translate.instant('Confirm Update');
        const value = this.translate.instant('LocationUpdate');
        this.userFormRef = this.dialogService.open(LocationFormComponent, {
            inputValues: {
                LocationData: Data,
            },
            // header: 'Update Receipt - ' + selectedAsn.RECEIPTKEY,
            // closable: true,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });

        this.userFormRef.onClose.subscribe((formData) => {
            if (formData) {
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );

                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        const ignoredFields = Object.values(LocationColumns)
                            .filter((col: any) => col.ignoreInRequest)
                            .map((col: any) => col.field);

                        const copy = { ...formData };
                        ignoredFields.forEach((field) => {
                            delete copy[field];
                        });
                        this.loading.set(true);
                        this.locationService
                            .updateLocation(copy)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getLocation(this.loadEvent());
                                }),
                            )
                            .subscribe({
                                next: (response: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Location Updated',
                                        detail: response as string,
                                    });
                                },
                                error: (error: any) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Update Failed',
                                            detail: error.error as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }
    onFileUpload(event: any) {
        const file = event.files[0];
        const reader = new FileReader();
        reader.onload = async (e: any) => {
            const workbook = XLSX.read(e.target.result, { type: 'binary' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            this.excelData = XLSX.utils.sheet_to_json(worksheet, { raw: true });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const sheetData: any[][] = XLSX.utils.sheet_to_json(sheet, {
                header: 1,
            });
            if (this.excelData.length > 0) {
                const dataRows = sheetData.slice(1);
                const FinalData = dataRows.map(
                    (row: any[], rowIndex: number) => {
                        return {
                            WHSEID: '',
                            LOC: row[0] ? row[0].toString() : null,
                            LOCATIONTYPE: row[1] ? row[1].toString() : '0',
                            LOCATIONTYPEDESC: row[2],
                            LOCATIONFLAG: row[3] ? row[3].toString() : '0',
                            LOCATIONFLAGDESC: row[4],
                            LOCATIONHANDLING: row[5] ? row[5].toString() : '0',
                            LOCATIONHANDLINGDESC: row[6],
                            LOCATIONCATEGORY: row[7] ? row[7].toString() : '0',
                            LOCATIONCATEGORYDESC: row[8],

                            CUBE: row[9],
                            LENGTH: row[10],
                            WIDTH: row[11],
                            HEIGHT: row[12],
                            CUBICCAPACITY: row[13],
                            WEIGHTCAPACITY: row[14],
                            PUTAWAYZONE: row[15] ? row[15].toString() : null,
                            COMMINGLESKU: row[16] ? row[16].toString() : '0',
                            COMMINGLELOT: row[17] ? row[17].toString() : '0',
                            STACKLIMIT: row[18],
                            FOOTPRINT: row[19],
                            MAXQTY: row[20],
                            ISACTIVE: row[21] ? row[21].toString() : 'Active',
                            UDFSTR1: row[22],
                            UDFSTR2: row[23],
                            UDFSTR3: row[24],
                            UDFSTR4: row[25],
                            UDFSTR5: row[26],
                            UDFDATETIME1: row[27],
                            UDFDATETIME2: row[28],
                            UDFDATETIME3: row[29],
                            UDFDATETIME4: row[30],
                            UDFDATETIME5: row[31],
                            UDFFLOAT1: row[32],
                            UDFFLOAT2: row[33],
                            UDFFLOAT3: row[34],
                            UDFFLOAT4: row[35],
                            UDFFLOAT5: row[36],
                        };
                    },
                );
                this.loading.set(true);
                this.locationService
                    .createLocationEdi(FinalData)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.getLocation(this.loadEvent());
                        }),
                    )
                    .subscribe({
                        next: (data) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Location Upload',
                                detail: data as string,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Location Upload',
                                    detail: error.error as string,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            } else {
                this.loading.set(false);
                this.messageService.add({
                    severity: 'warn',
                    summary: 'Location Upload',
                    detail: 'The file contains no data rows. Please add data below the header row and try again.',
                });
            }
        };
        reader.readAsArrayBuffer(file);
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
