import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';
import { Location } from '../location/location.model';
import { map } from 'rxjs';
import { LocationColumns } from './location.columns';
import {
    lowerCaseArray,
    lowerCaseObject,
    stringToDate,
    upperCaseArray,
    upperCaseObject,
} from '../../../common/functions';

@Injectable({
    providedIn: 'root',
})
export class LocationService {
    SetActive = signal(false);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getLocation() {
        return this.httpClient
            .get<
                Location[]
            >(this.config.appConfig()?.MasterUrl + 'locations', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((res: any) => {
                    return upperCaseArray(res);
                }),
            );
    }
    getLocationsPage(data: any) {
        return this.httpClient
            .post<any>(
                this.config.appConfig()?.MasterUrl + 'locations/Page',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response) => {
                    if (response?.Response) {
                        response.Response = upperCaseArray(response?.Response);
                        response?.Response.forEach((x: any) => {
                            Object.keys(x).forEach((key) => {
                                if (LocationColumns[key]?.type === 'date') {
                                    x[key] = stringToDate(x[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    createLocation(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + 'locations',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    updateLocation(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.MasterUrl + 'locations',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    getLocationType() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocType',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.LABEL,
                        value: x.VALUE,
                    })),
                ),
            );
    }
    getLocationFlag() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocFlag',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.LABEL,
                        value: x.VALUE,
                    })),
                ),
            );
    }
    getLocationHandling() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocHandling',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.LABEL,
                        value: x.VALUE,
                    })),
                ),
            );
    }
    getLocationCategory() {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    'codes/options?ListName=LocCategory',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.LABEL,
                        value: x.VALUE,
                    })),
                ),
            );
    }
    getPutawayZone() {
        return this.httpClient
            .get(this.config.appConfig()?.MasterUrl + 'zones', {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe(
                map((value: any) =>
                    upperCaseArray(value).map((x: any) => ({
                        label: x.ZONE,
                        value: x.ZONE,
                    })),
                ),
            );
    }
    createLocationEdi(data: any) {
        this.SetActive.set(true);
        return this.httpClient.post(
            this.config.appConfig()?.MasterUrl + 'locations/upload',
            Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
