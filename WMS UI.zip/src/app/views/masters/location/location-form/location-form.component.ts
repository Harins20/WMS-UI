import {
    Component,
    input,
    inject,
    DestroyRef,
    signal,
    effect,
} from '@angular/core';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputNumber } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import {
    getErrorMessages,
    markAllControlsAsDirty,
    upperCaseArray,
    upperCaseObject,
} from '../../../../common/functions';
import { LocationColumns } from '../location.columns';
import { LocationService } from '../location.service';
import { TabsModule } from 'primeng/tabs';
import { DatePickerModule } from 'primeng/datepicker';
import { MessageService } from 'primeng/api';
import { selectOption } from '../../../../common/models';
import {
    InputSelectComponent,
    InputTextComponent,
} from '../../../../common/components';
import { InputDatepickerComponent } from '../../../../common/components/input-datepicker/input-datepicker.component';
import { InputNumberComponent } from '../../../../common/components/input-number/input-number.component';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { CommonModule } from '@angular/common';
import { OptionsService } from '../../../../common/services';

@Component({
    selector: 'location-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        TabsModule,
        DatePickerModule,
        InputNumberComponent,
        InputSelectComponent,
        InputDatepickerComponent,
        AppTranslatePipe,
        InputTextComponent,
        CommonModule,
    ],
    templateUrl: './location-form.component.html',
    styleUrl: './location-form.component.scss',
})
export class LocationFormComponent {
    LocationData = input<any>();

    private destroyRef = inject(DestroyRef);
    private locationService = inject(LocationService);
    private router = inject(Router);
    private ref = inject(DynamicDialogRef);
    private messageService = inject(MessageService);
    private optionService = inject(OptionsService);
    locationColumns: any[] = [];
    loading = signal(false);
    locationTypeOptions = signal<any[]>([]);
    locationFlagOptions = signal<any[]>([]);
    locationHandlingOptions = signal<any[]>([]);
    locationCategoryOptions = signal<any[]>([]);
    putawayZoneOptions = signal<any[]>([]);
    statusOptions = signal<selectOption[]>(
        LocationColumns['ISACTIVE'].options || [],
    );
    // ✅ Single signal for tab validation warning
    setViewTAb = signal<boolean>(true);
    // ✅ Single signal for active tab
    activeTab = signal<number>(0);
    formControls: any = Object.fromEntries(
        Object.values(LocationColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    form = new FormGroup(this.formControls);

    ngOnInit() {
        this.getLocationType();
        this.getLocationFlag();
        this.getLocationHandling();
        this.getLocationCategory();
        this.getPutawayZone();

        if (this.LocationData()) {
            const rawLocation = upperCaseObject(this.LocationData());
            this.form.patchValue({
                ...rawLocation,
                UDFDATETIME1: rawLocation?.UDFDATETIME1
                    ? new Date(rawLocation.UDFDATETIME1)
                    : null,
                UDFDATETIME2: rawLocation?.UDFDATETIME2
                    ? new Date(rawLocation.UDFDATETIME2)
                    : null,
                UDFDATETIME3: rawLocation?.UDFDATETIME3
                    ? new Date(rawLocation.UDFDATETIME3)
                    : null,
                UDFDATETIME4: rawLocation?.UDFDATETIME4
                    ? new Date(rawLocation.UDFDATETIME4)
                    : null,
                UDFDATETIME5: rawLocation?.UDFDATETIME5
                    ? new Date(rawLocation.UDFDATETIME5)
                    : null,
            });
            Object.values(LocationColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.form.controls[column.field]?.disable();
            });
        } else {
            Object.values(LocationColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.form.controls[column.field]?.disable();
            });
        }
        this.getColumns();
    }

    // ✅ Navigate to tab
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    closePanel() {
        this.ref.close();
    }
    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }
    getLocationType() {
        const subscription = this.locationService.getLocationType().subscribe({
            next: (data: any) => {
                this.locationTypeOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getLocationFlag() {
        const subscription = this.locationService.getLocationFlag().subscribe({
            next: (data: any) => {
                this.locationFlagOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getLocationHandling() {
        const subscription = this.locationService
            .getLocationHandling()
            .subscribe({
                next: (data: any) => {
                    this.locationHandlingOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getLocationCategory() {
        const subscription = this.locationService
            .getLocationCategory()
            .subscribe({
                next: (data: any) => {
                    this.locationCategoryOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getPutawayZone() {
        const subscription = this.locationService.getPutawayZone().subscribe({
            next: (data: any) => {
                this.putawayZoneOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    onCancel() {
        this.ref.close();
    }
    onSubmit() {
        if (this.form.valid) {
            this.setViewTAb.set(true);
            this.ref.close(this.form.getRawValue());
            this.form.reset();
        } else {
            this.setViewTAb.set(false);
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }

    getColumns() {
        this.optionService.getColumns(LocationColumns, 'LOCATION').subscribe({
            next: (data) => {
                this.locationColumns = data;
            },
        });
    }
}
