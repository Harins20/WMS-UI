import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../../../../../app.config.service';
import { AuthService } from '../../../../common/services';

@Injectable({
    providedIn: 'root',
})
export class AccessService {
    private http = inject(HttpClient);
    private configService = inject(AppConfigService);
    private authService = inject(AuthService);
    headers = this.authService.getAuthHeadersAp();

    GetUserAccesses(userId: number) {
        return this.http.get(
            this.configService.AuthUrl + `users/access?Userid=${userId}`,
            {
                headers: this.headers,
            },
        );
    }
    CreateUserAccess(accessData: any) {
        return this.http.post(
            this.configService.AuthUrl + 'users/access',
            accessData,
            {
                headers: this.headers,
            },
        );
    }
    UpdateUserAccess(accessData: any) {
        return this.http.put(
            this.configService.AuthUrl + 'users/access',
            accessData,
            {
                headers: this.headers,
            },
        );
    }
    DeleteUserAccess(id: any) {
        return this.http.delete(
            this.configService.AuthUrl + `users/access?AccessId=${id}`,
            {
                headers: this.headers,
            },
        );
    }
}
