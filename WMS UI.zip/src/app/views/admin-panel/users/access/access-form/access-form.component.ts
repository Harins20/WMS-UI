import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { FacilityService } from '../../../facility/facility.service';
import { RoleService } from '../../../role/role.service';
import { finalize, Subscription } from 'rxjs';

import { DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { Select } from 'primeng/select';
import { ButtonModule } from 'primeng/button';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../../common/functions';

interface Option {
    label: string;
    value: number;
}
interface Access {
    Id?: number;
    UserId: number;
    FacilityId?: number;
    RoleId?: number;
}
@Component({
    selector: 'app-access-form',
    imports: [ReactiveFormsModule, Select, ButtonModule],
    templateUrl: './access-form.component.html',
    styleUrl: './access-form.component.scss',
})
export class AccessFormComponent {
    loading = signal({ roles: false, facilities: false });
    access = input.required<Access>();
    existingFacilities = input<string[]>([]);

    roleOptions = signal<Option[]>([]);
    facilityOptions = signal<Option[]>([]);
    availFacilityOptions = computed(() =>
        this.facilityOptions().filter((option) => {
            if (this.access().FacilityId) {
                return (
                    option.value === this.access().FacilityId ||
                    !this.existingFacilities().includes(option.label)
                );
            } else {
                return !this.existingFacilities().includes(option.label);
            }
        }),
    );

    accessForm = new FormGroup({
        Id: new FormControl<number | undefined>(undefined, [
            Validators.required,
        ]),
        UserId: new FormControl<number | undefined>(undefined, [
            Validators.required,
        ]),
        FacilityId: new FormControl<number | undefined>(undefined, [
            Validators.required,
        ]),
        RoleId: new FormControl<number | undefined>(undefined, [
            Validators.required,
        ]),
    });

    private roleService = inject(RoleService);
    private facilityService = inject(FacilityService);
    private destoryRef = inject(DestroyRef);
    private ref = inject(DynamicDialogRef);

    ngOnInit() {
        this.accessForm.patchValue({
            ...this.access(),
        });
        if (!this.access().Id) {
            const IdControl = this.accessForm.get('Id') as FormControl;
            IdControl.setValidators([]);
        }
        this.GetRoleOptions();
        this.GetFaciltyOptions();
    }

    GetRoleOptions() {
        this.loading.update((currentValue) => ({
            ...currentValue,
            roles: true,
        }));
        const subscription = this.roleService
            .getRoles()
            .pipe(
                finalize(() =>
                    this.loading.update((currentValue) => ({
                        ...currentValue,
                        roles: false,
                    })),
                ),
            )
            .subscribe({
                next: (data: any) => {
                    const result = data.map((x: any) => ({
                        label: x.Name,
                        value: x.Id,
                    }));
                    this.roleOptions.set(result);
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    GetFaciltyOptions() {
        this.loading.update((currentValue) => ({
            ...currentValue,
            facilities: true,
        }));
        const subscription = this.facilityService
            .getFacility()
            .pipe(
                finalize(() =>
                    this.loading.update((currentValue) => ({
                        ...currentValue,
                        facilities: false,
                    })),
                ),
            )
            .subscribe({
                next: (data: any) => {
                    const result = data.map((x: any) => ({
                        label: x.Name,
                        value: x.Id,
                    }));
                    this.facilityOptions.set(result);
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    hasError(formControlName: string) {
        const formControl = this.accessForm.get(formControlName)!;
        return (
            (formControl.touched || formControl.dirty) && formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.accessForm.get(formControlName)!;
        return getErrorMessages(formControl.errors, title);
    }
    onCancel() {
        this.ref.close();
    }
    onSubmit() {
        if (this.accessForm.valid) {
            this.ref.close(this.accessForm.value);
        } else {
            this.accessForm.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.accessForm.controls));
        }
    }
}
