import { CommonModule, DatePipe } from '@angular/common';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { SkeletonModule } from 'primeng/skeleton';
import { TableModule } from 'primeng/table';
import { finalize } from 'rxjs';
import { AccessService } from './access.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { AccessFormComponent } from './access-form/access-form.component';
import { TranslateService } from '@ngx-translate/core';
import {
    ConfirmationDialogComponent,
    CustomTableComponent,
} from '../../../../common/components';

@Component({
    selector: 'app-users',
    templateUrl: './access.component.html',
    styleUrls: ['./access.component.scss'],
    imports: [
        ButtonModule,
        TableModule,
        TableModule,
        InputIconModule,
        InputTextModule,
        DatePipe,
        ButtonModule,
        IconFieldModule,
        SkeletonModule,
        CustomTableComponent,
    ],
    providers: [DialogService],
})
export class AccessComponent {
    UserId = input.required<number>();
    userAccess = signal<any>([]);
    loading = signal<boolean>(false);
    selectedAccess = signal<any>([]);
    private destroyRef = inject(DestroyRef);
    ConfirmationRef: DynamicDialogRef | undefined;

    existingFacilites = computed(() =>
        this.userAccess().map((x: any) => x.FacilityName),
    );

    ref: DynamicDialogRef | undefined;
    private translate = inject(TranslateService);
    public dialogService = inject(DialogService);
    private messageService = inject(MessageService);
    private accessService = inject(AccessService);
    private destoryRef = inject(DestroyRef);

    ngOnInit() {
        this.GetUserAccesses();
    }
    accessColumns = signal([
        { label: 'Facility', field: 'FacilityName', type: 'text' },
        { label: 'Role', field: 'RoleName', type: 'text' },
        { label: 'Created By', field: 'CreatedBy', type: 'text' },
        { label: 'Created At', field: 'CreatedAt', type: 'date' },
    ]);

    selectedColumns = signal(this.accessColumns());

    globalcolumns = signal(this.accessColumns().map((column) => column.field));
    GetUserAccesses() {
        this.loading.set(true);
        this.userAccess.set([]);
        const Subscription = this.accessService
            .GetUserAccesses(this.UserId())
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (data: any) => {
                    data.forEach(
                        (access: any) =>
                            (access.CreatedAt = new Date(
                                <Date>access.CreatedAt,
                            )),
                    );
                    this.userAccess.set(data);
                },
                error: (error: any) => {},
            });
        this.destoryRef.onDestroy(() => Subscription.unsubscribe());
    }

    showAccessForm() {
        const data: { UserId: number } = {
            UserId: parseInt(this.UserId().toString()),
        };
        this.ref = this.dialogService.open(AccessFormComponent, {
            inputValues: {
                access: data,
                existingFacilities: this.existingFacilites(),
            },
            header: 'New Access',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('AccessCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: { message: value },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.OnAddNewAccess(data);
                    }
                });
            }
        });
    }

    showUpdateAccessForm(access: any) {
        this.ref = this.dialogService.open(AccessFormComponent, {
            inputValues: {
                access: access,
                existingFacilities: this.existingFacilites(),
            },
            header: 'New Access',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('AccessUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: { message: value },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.onUpdateAccess(data);
                    }
                });
            }
        });
    }
    OnAddNewAccess(access: any) {
        this.accessService
            .CreateUserAccess(access)
            .pipe(
                finalize(() => {
                    this.GetUserAccesses();
                }),
            )
            .subscribe({
                next: (data) => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: data as string,
                    });
                },
                error: (error) => {
                    console.error('Error while adding role.', error);
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Failed',
                        detail: error.error as string,
                    });
                },
            });
    }

    onUpdateAccess(access: any) {
        this.accessService
            .UpdateUserAccess(access)
            .pipe(
                finalize(() => {
                    this.GetUserAccesses();
                }),
            )
            .subscribe({
                next: (data) => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: data as string,
                    });
                },
                error: (error) => {
                    console.error('Error while adding role.', error);
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Failed',
                        detail: error.error as string,
                    });
                },
            });
    }

    DeleteAccessConfirmation(access: any) {
        const id = access?.Id;
        const headertext = this.translate.instant('Confirm Deletion');
        const value = this.translate.instant('Delete', {
            no: 1,
            name: this.translate.instant('Access'),
        });

        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
            if (!confirmed) return;
            const subscription = this.accessService
                .DeleteUserAccess(id)
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.GetUserAccesses();
                    }),
                )
                .subscribe({
                    next: () => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Deleted',
                            detail: 'Access deleted successfully.',
                        });
                    },
                    error: (error) => {
                        console.error('Delete error:', error);
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Delete Error',
                            detail:
                                error?.error?.message ||
                                'Failed to delete Access.',
                        });
                        this.loading.set(true);
                    },
                });

            this.destroyRef.onDestroy(() => subscription.unsubscribe());
        });
    }
}
