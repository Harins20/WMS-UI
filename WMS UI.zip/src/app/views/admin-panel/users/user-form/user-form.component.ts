import { Component, inject, input } from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';

import { CheckboxModule } from 'primeng/checkbox';
import {
    markAllControlsAsDirty,
    getErrorMessages,
} from '../../../../common/functions';

@Component({
    selector: 'app-user-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        CheckboxModule,
    ],
    templateUrl: './user-form.component.html',
    styleUrl: './user-form.component.scss',
})
export class UserFormComponent {
    user = input<any>();
    private ref = inject(DynamicDialogRef);
    emailRegEx = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
    userForm = new FormGroup({
        Id: new FormControl<number>(0),
        FirstName: new FormControl<string>('', [Validators.required]),
        LastName: new FormControl<string>('', [Validators.required]),
        UserName: new FormControl<string>('', [Validators.required]),
        Password: new FormControl<string>('', [Validators.required]),
        Email: new FormControl<string>('', [
            Validators.required,
            Validators.email,
            Validators.pattern(this.emailRegEx),
        ]),
        MobileNo: new FormControl<string>(''),
        IsActive: new FormControl<boolean>(true, [Validators.required]),
        IsLocked: new FormControl<boolean>(false, [Validators.required]),
        IsOtpEnabled: new FormControl<boolean>(false, [Validators.required]),
        IsMfaEnabled: new FormControl<boolean>(false, [Validators.required]),
        ForceRest: new FormControl<boolean>(false, [Validators.required]),
        AdminPortalAccess: new FormControl<boolean>(false, [
            Validators.required,
        ]),
    });
    ngOnInit() {
        if (this.user()) {
            const passwordControl = this.userForm.get(
                'Password',
            ) as FormControl;
            passwordControl.setValidators([]);
            this.userForm.patchValue({
                ...this.user(),
            });
        }
    }
    onSubmit() {
        if (this.userForm.valid) {
            this.ref.close(this.userForm.value);
            this.userForm.reset();
        } else {
            this.userForm.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.userForm.controls));
        }
    }
    onCancel() {
        this.userForm.reset();
        this.ref.close();
    }
    hasError(formControlName: string) {
        const formControl = this.userForm.get(formControlName)!;
        return (
            (formControl.touched || formControl.dirty) && formControl.invalid
        );
    }
    getErrors(formControlName: string, title?: string) {
        const formControl = this.userForm.get(formControlName)!;
        return getErrorMessages(formControl.errors, title);
    }
}
