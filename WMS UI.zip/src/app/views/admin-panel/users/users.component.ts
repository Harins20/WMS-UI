import {
    Component,
    DestroyRef,
    inject,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { SkeletonModule } from 'primeng/skeleton';
import { Table, TableModule } from 'primeng/table';
import { UsersService } from './users.service';
import { finalize } from 'rxjs';
import { DatePipe } from '@angular/common';
import { TagModule } from 'primeng/tag';
import { DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';
import { UserFormComponent } from './user-form/user-form.component';
import { Route, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import adminPanelRoutes from '../admin-panel.routes';
import { TabService } from '../../../tabs';
import { TranslateService } from '@ngx-translate/core';
import {
    LoadingComponent,
    CustomTableComponent,
    ConfirmationDialogComponent,
} from '../../../common/components';

@Component({
    selector: 'app-users',
    imports: [
        SkeletonModule,
        TableModule,
        ButtonModule,
        InputIconModule,
        IconFieldModule,
        InputTextModule,
        TagModule,
        DatePipe,
        LoadingComponent,
        CustomTableComponent,
    ],
    templateUrl: './users.component.html',
    styleUrl: './users.component.scss',
    providers: [DialogService],
})
export class UsersComponent {
    users = signal<any>([]);
    private tabService = inject(TabService);
    loading = signal<boolean>(false);
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    userColumns = signal<any>([
        {
            label: 'First Name',
            field: 'FirstName',
            dataType: 'text',
        },
        {
            label: 'Last Name',
            field: 'LastName',
            dataType: 'text',
        },
        {
            label: 'User Name',
            field: 'UserName',
            dataType: 'text',
        },
        {
            label: 'Status',
            field: 'IsActive',
            dataType: 'boolean',
        },
        {
            label: 'Email',
            field: 'Email',
            dataType: 'text',
        },
        {
            label: 'Mobile No',
            field: 'MobileNo',
            dataType: 'text',
        },
        {
            label: 'Lock Status',
            field: 'IsLocked',
            dataType: 'boolean',
        },
        {
            label: 'Admin Portal Access',
            field: 'AdminPortalAccess',
            dataType: 'boolean',
        },
        {
            label: 'Created By',
            field: 'CreatedBy',
            dataType: 'text',
        },
        {
            label: 'Created At',
            field: 'CreatedAt',
            type: 'date',
        },
    ]);
    globalcolumns = signal(
        this.userColumns().map((column: any) => column.field),
    );

    private userService = inject(UsersService);
    private destoryRef = inject(DestroyRef);
    private router = inject(Router);
    private messageService = inject(MessageService);
    private translate = inject(TranslateService);

    userFormRef: DynamicDialogRef | undefined;
    ConfirmationRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    ngOnInit() {
        this.GetUsers();
    }
    ngAfterViewInit() {
        this.userColumns.update((columns) =>
            columns.map((column: any) => {
                if (column.field === 'IsActive') {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }
                if (column.field === 'IsLocked') {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }
                if (column.field === 'AdminPortalAccess') {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }

                return column;
            }),
        );
    }
    GetUsers() {
        this.loading.set(true);
        this.users.set([]);
        const Subscription = this.userService
            .GetUsers()
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (data: any) => {
                    data.forEach(
                        (user: any) =>
                            (user.CreatedAt = new Date(<Date>user.CreatedAt)),
                    );
                    this.users.set(data);
                },
                error: (error: any) => {},
            });
        this.destoryRef.onDestroy(() => Subscription.unsubscribe());
    }
    OpenUpdateUserForm(data: any) {
        this.userFormRef = this.dialogService.open(UserFormComponent, {
            inputValues: {
                user: data,
            },
            header: 'Update user',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('UserUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: { message: value },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.userService
                            .updateUser(data)
                            .pipe(
                                finalize(() => {
                                    this.GetUsers();
                                }),
                            )
                            .subscribe({
                                next: (data) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Success',
                                        detail: data as string,
                                    });
                                },
                                error: (error) => {
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Failed',
                                        detail: error as string,
                                    });
                                },
                            });
                    }
                });
            }
        });
    }
    OpenAddUserForm() {
        this.userFormRef = this.dialogService.open(UserFormComponent, {
            header: 'New user',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('UserCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: { message: value },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.userService
                            .addUser(data)
                            .pipe(
                                finalize(() => {
                                    this.GetUsers();
                                }),
                            )
                            .subscribe({
                                next: (data) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Success',
                                        detail: data as string,
                                    });
                                },
                                error: (error) => {
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Failed',
                                        detail: error as string,
                                    });
                                },
                            });
                    }
                });
            }
        });
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal(
            (event.target as HTMLInputElement).value,
            'contains',
        );
    }

    editAccess(event: Event, user: any): void {
        event.preventDefault();
        const route = adminPanelRoutes.find(
            (route) => route.data?.name === 'access',
        ) as Route;
        var params = [{ name: 'UserId', value: user.Id }];
        this.tabService.addTabWithParams(
            route,
            '',
            'Access - ' + user.Id,
            params,
        );
    }
}
