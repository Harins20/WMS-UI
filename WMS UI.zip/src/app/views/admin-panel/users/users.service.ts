import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AuthService } from '../../../common/services';
import { AppConfigService } from '../../../../app.config.service';

@Injectable({
    providedIn: 'root',
})
export class UsersService {
    private http = inject(HttpClient);
    private configService = inject(AppConfigService);
    private authService = inject(AuthService);
    headers = this.authService.getAuthHeadersAp();

    GetUsers() {
        return this.http.get(this.configService.AuthUrl + 'users', {
            headers: this.headers,
        });
    }
    addUser(users: any) {
        return this.http.post(this.configService.AuthUrl + 'users', users, {
            headers: this.headers,
        });
    }
    updateUser(users: any) {
        return this.http.put(this.configService.AuthUrl + 'users', users, {
            headers: this.headers,
        });
    }
}
