import { DatePipe } from '@angular/common';
import { Component, inject, signal, viewChild } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { SkeletonModule } from 'primeng/skeleton';
import { Table, TableModule } from 'primeng/table';
import { finalize } from 'rxjs';
import { FacilityService } from './facility.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FacilityFormComponent } from './facility-form/facility-form.component';
import { TranslateService } from '@ngx-translate/core';
import {
    LoadingComponent,
    CustomTableComponent,
    ConfirmationDialogComponent,
} from '../../../common/components';
import { TagModule } from 'primeng/tag';
import adminPanelRoutes from '../admin-panel.routes';
import { Route } from '@angular/router';
import { TabService } from '../../../tabs';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { ExcelDownloadService } from '../../../common/services';

@Component({
    selector: 'app-facility',
    templateUrl: './facility.component.html',
    styleUrls: ['./facility.component.scss'],
    imports: [
        ReactiveFormsModule,
        ButtonModule,
        InputIconModule,
        TableModule,
        IconFieldModule,
        InputTextModule,
        SkeletonModule,
        DatePipe,
        LoadingComponent,
        TagModule,
        CustomTableComponent,
    ],
    providers: [DialogService],
})
export class FacilityComponentAdmin {
    loading = signal<boolean>(false);
    facilities = signal<any>([]);
    dt = viewChild.required<Table>('dt');
    private facilityService = inject(FacilityService);
    private messageService = inject(MessageService);
    ref: DynamicDialogRef | undefined;
    ConfirmationRef: DynamicDialogRef | undefined;
    private translate = inject(TranslateService);
    private dialogService = inject(DialogService);
    private excelDownloadService = inject(ExcelDownloadService);
    private tabService = inject(TabService);
    columns = signal([
        {
            field: 'Name',
            label: 'Facility Name',
            type: 'text',
        },
        {
            field: 'CreatedBy',
            label: 'Created By',
            type: 'text',
        },
        {
            field: 'CreatedAt',
            label: 'Created At',
            type: 'date',
        },
    ]);

    selectedColumns = signal(this.columns());

    globalcolumns = signal(this.columns().map((column) => column.field));
    exportCSV() {
        downloadCSVFile(this.facilities(), 'Facilities');
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            'UDF executive Field',
            [],
            this.facilities(),
        );
    }
    ngOnInit() {
        this.getFacility();
    }

    async getFacility() {
        this.loading.set(true);
        this.facilities.set([]);
        this.facilityService
            .getFacility()
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (data: any) => {
                    data.forEach(
                        (facility: any) =>
                            (facility.CreatedAt = new Date(
                                <Date>facility.CreatedAt,
                            )),
                    );
                    this.facilities.set(data);
                },
                error: (error) => {
                    console.error('Error fetching roles', error);
                },
            });
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal(
            (event.target as HTMLInputElement).value,
            'contains',
        );
    }

    openNewForm() {
        this.ref = this.dialogService.open(FacilityFormComponent, {
            header: 'New Facility',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('FacilityCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: { message: value },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.onNewFormSubmit(data);
                    }
                });
            }
        });
    }

    onNewFormSubmit(data: any) {
        this.facilityService
            .addFacility(data)
            .pipe(
                finalize(() => {
                    this.getFacility();
                }),
            )
            .subscribe({
                next: (data) => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'New Facility',
                        detail: data as string,
                    });
                },
                error: (error) => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'New Facility',
                        detail: error as string,
                    });
                },
            });
    }

    onDataKeyClick(row: any): void {
        // event.preventDefault();
        const route = adminPanelRoutes.find(
            (route) => route.data?.name === 'Allocation Based Owners',
        ) as Route;
        var params = [
            { name: 'Facility', value: row.Name },
            { name: 'Id', value: row.Id },
        ];
        this.tabService.addTabWithParams(
            route,
            '',
            'Facility - ' + row.Name,
            params,
        );
    }
}
