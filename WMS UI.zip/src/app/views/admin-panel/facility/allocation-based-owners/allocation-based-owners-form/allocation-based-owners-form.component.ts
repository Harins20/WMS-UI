import { Component, inject, input, signal } from '@angular/core';
import { FacilityService } from '../../facility.service';
import {
    FormControl,
    FormGroup,
    FormsModule,
    ReactiveFormsModule,
} from '@angular/forms';
import { AllocationBasedOwnersColumns } from '../allocation-based-owners.columns';
import { InputSelectComponent } from '../../../../../common/components';
import { CommonModule } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { markAllControlsAsDirty } from '../../../../../common/functions';

@Component({
    selector: 'app-allocation-based-owners-form',
    imports: [
        InputSelectComponent,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        ButtonModule,
    ],
    templateUrl: './allocation-based-owners-form.component.html',
    styleUrl: './allocation-based-owners-form.component.scss',
})
export class AllocationBasedOwnersFormComponent {
    formData = input.required<any>();
    RotationOrderOptions = signal<any[]>([]);
    AllocationType = signal<any[]>([]);
    private facilityService = inject(FacilityService);
    private ref = inject(DynamicDialogRef);

    formControls: any = Object.fromEntries(
        AllocationBasedOwnersColumns.map((column) => [
            column.field,
            new FormControl<string | number>(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    form = new FormGroup(this.formControls);

    ngOnInit() {
        if (this.formData()) {
            const data = this.formData();

            AllocationBasedOwnersColumns.forEach((column) => {
                if (column.restrictEdit) {
                    this.form.controls[column.field].disable();
                }
            });

            this.form.patchValue({
                ...data,
            });
        } else {
            AllocationBasedOwnersColumns.forEach((column) => {
                if (column.restrictInsert) {
                    this.form.controls[column.field].disable();
                }
            });
        }
        this.GetAllocationRotationOrder();
        this.GetAllocationType();
    }
    GetAllocationRotationOrder() {
        this.facilityService.getAllocationRotationOrder().subscribe({
            next: (data: any[]) => {
                if (data) {
                    this.RotationOrderOptions.set(data);
                }
            },
        });
    }
    GetAllocationType() {
        this.facilityService.getAllocationType().subscribe({
            next: (data: any[]) => {
                if (data) {
                    this.AllocationType.set(data);
                }
            },
        });
    }

    onClearData() {
        this.form.reset();
    }
    onSubmit() {
        if (this.form.valid) {
            let RotationOrderOption = this.RotationOrderOptions().find(
                (option) =>
                    option.value ===
                    this.form.getRawValue()?.AllocationRotationOrder,
            );
            let AllocationType = this.AllocationType().find(
                (option) =>
                    option.value ===
                    this.form.getRawValue()?.AllocationRotationType,
            );

            let jsonObject = {
                Id: this.form.getRawValue()?.SerialKey,
                Traderkey: this.form.getRawValue()?.TraderKey,
                AllocationRotationType: RotationOrderOption?.Id
                    ? RotationOrderOption?.Id.toString()
                    : null,
                AllocationRotationOrder: AllocationType?.Id
                    ? AllocationType?.Id?.toString()
                    : null,
            };

            this.ref.close(jsonObject);
        } else {
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
}
