import { Column } from '../../../../common/models';

export const AllocationBasedOwnersColumns: Column[] = [
    {
        field: 'rowId',
        label: 'S/No',
        type: 'number',
    },
    {
        field: 'SerialKey',
        label: 'SerialKey',
        type: 'text',
        tableHidden: true,
    },
    {
        field: 'TraderKey',
        label: 'TraderKey',
        type: 'text',
    },
    {
        field: 'Company',
        label: 'Company',
        type: 'text',
    },
    {
        field: 'AllocationRotationType',
        label: 'AllocationRotationType',
        type: 'number',
        tableHidden: true,
    },
    {
        field: 'AllocationRotationOrder',
        label: 'AllocationRotationOrder',
        type: 'number',
        tableHidden: true,
    },
];
