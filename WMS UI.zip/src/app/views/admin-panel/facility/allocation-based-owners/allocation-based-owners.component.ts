import { Component, inject, input, linkedSignal, signal } from '@angular/core';
import { FacilityService } from '../facility.service';
import { CustomTableComponent } from '../../../../common/components';
import { ExcelDownloadService } from '../../../../common/services';
import { AllocationBasedOwnersColumns } from './allocation-based-owners.columns';
import { AllocationBasedOwnersFormComponent } from './allocation-based-owners-form/allocation-based-owners-form.component';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize } from 'rxjs';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-allocation-based-owners',
    imports: [CustomTableComponent],
    templateUrl: './allocation-based-owners.component.html',
    styleUrl: './allocation-based-owners.component.scss',
})
export class AllocationBasedOwnersComponent {
    Facility = input.required<string>();
    Id = input.required<string>();
    ref: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private facilityService = inject(FacilityService);
    private readonly excelDownloadService = inject(ExcelDownloadService);
    columns = signal(
        AllocationBasedOwnersColumns.filter((column) => !column.tableHidden),
    );
    unSelectedColumns = linkedSignal(() => {
        if (this.columns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.columns().some((x: any) => x.field === column.field),
            );
        } else {
            return this.columns().filter((column: any) => column.tableHidden);
        }
    });
    listData = signal<any>([]);
    ngOnInit() {
        if (this.Facility()) {
            this.GetAllocationBasedOwners(this.Facility());
        }
    }
    GetAllocationBasedOwners(facility: any) {
        this.facilityService.getAllocationBasedOwners(facility).subscribe({
            next: (data: any) => {
                this.listData.set(
                    data.map((x: any, idx: number) => ({
                        ...x,
                        rowId: idx + 1,
                    })),
                );
            },
            error: (err) => {
                console.error(
                    'Error fetching allocation-based owners data:',
                    err,
                );
            },
        });
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            'Allocation Based Owners',
            [],
            this.listData(),
        );
    }
    private messageService = inject(MessageService);

    onClickPOKey(row: any): void {
        this.ref = this.dialogService.open(AllocationBasedOwnersFormComponent, {
            header: 'Allocation By Owners Form',
            inputValues: {
                formData: row,
            },

            closable: true,
            modal: true,
            draggable: false,
            dismissableMask: false,
            width: '39rem',
            style: { maxHeight: '40rem' },
        });

        this.ref.onClose.subscribe((data) => {
            if (data) {
                this.facilityService
                    .updateAllocationBasedOwners(data)
                    .pipe(
                        finalize(() => {
                            this.GetAllocationBasedOwners(this.Facility());
                        }),
                    )
                    .subscribe({
                        next: (data: any) => {
                            if (data) {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Allocation Configuration',
                                    detail: 'Allocation configuration updated successfully.',
                                });
                            }
                        },
                        error: (error) => {
                            if (error) {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Allocation Configuration',
                                    detail: 'Allocation configuration updated failed.',
                                });
                            }
                        },
                    });
            }
        });
    }
}
