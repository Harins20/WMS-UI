import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../../../../app.config.service';
import { AuthService } from '../../../common/services';
import { map } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class FacilityService {
    private http = inject(HttpClient);
    private authService = inject(AuthService);
    private configService = inject(AppConfigService);

    getFacility() {
        return this.http.get(this.configService.AuthUrl + 'facilities', {
            headers: this.authService.getAuthHeadersAp(),
        });
    }
    addFacility(facility: any) {
        return this.http.post(
            this.configService.AuthUrl + 'facilities',
            facility,
            {
                headers: this.authService.getAuthHeadersAp(),
            },
        );
    }

    getAllocationBasedOwners(facility: any) {
        const encodedToken = sessionStorage.getItem('Token');
        const token = encodedToken ? atob(encodedToken) : null;
        const headers = new HttpHeaders({
            accept: 'application/json',
            Authorization: `Bearer ${token}`,
            Facility: facility,
        });

        return this.http.get(
            this.configService.AuthUrl + 'preference/traders',
            {
                headers,
            },
        );
    }
    getAllocationRotationOrder() {
        return this.http
            .get(
                this.configService.AuthUrl +
                    'preference/allocationrotationorder',
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((value: any) =>
                    value.map((x: any) => ({
                        ...x,
                        label: x.Name,
                        value: x.Name,
                    })),
                ),
            );
    }
    getAllocationType() {
        return this.http
            .get(this.configService.AuthUrl + 'preference/allocationtype', {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe(
                map((value: any) =>
                    value.map((x: any) => ({
                        ...x,
                        label: x.Name,
                        value: x.Name,
                    })),
                ),
            );
    }
    updateAllocationBasedOwners(data: any) {
        return this.http.put(
            this.configService.appConfig()?.AuthUrl +
                'preference/allocationtype',
            { Preference: data },
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
