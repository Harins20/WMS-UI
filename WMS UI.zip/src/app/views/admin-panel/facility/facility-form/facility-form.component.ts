import { Component, inject } from '@angular/core';
import {
    FormGroup,
    FormControl,
    Validators,
    ReactiveFormsModule,
} from '@angular/forms';

import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';

@Component({
    selector: 'app-facility-form',
    imports: [ReactiveFormsModule, ButtonModule, InputTextModule],
    templateUrl: './facility-form.component.html',
    styleUrl: './facility-form.component.scss',
})
export class FacilityFormComponent {
    private ref = inject(DynamicDialogRef);
    facilityForm = new FormGroup({
        Name: new FormControl<string>('', [Validators.required]),
    });
    hasError(formControlName: string) {
        const formControl = this.facilityForm.get(formControlName)!;
        return (
            (formControl.touched || formControl.dirty) && formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.facilityForm.get(formControlName)!;
        return getErrorMessages(formControl.errors, title);
    }
    onCancel() {
        this.ref.close();
    }
    onSubmit() {
        if (this.facilityForm.valid) {
            this.ref.close(this.facilityForm.value);
        } else {
            this.facilityForm.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.facilityForm.controls));
        }
    }
}
