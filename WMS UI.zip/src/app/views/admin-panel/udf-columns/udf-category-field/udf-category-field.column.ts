import { Columns } from '../../../../common/models';

export const UdfCategoryFieldColumns: Columns = {
    rowId: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
    },

    Table: {
        label: 'Table',
        field: 'Table',
        type: 'text',
    },

    Field: {
        label: 'Field',
        field: 'Field',
        type: 'text',
    },

    Label: {
        label: 'Label',
        field: 'Label',
        type: 'text',
    },

    Custom_Label: {
        label: 'Custom Label',
        field: 'Custom_Label',
        type: 'text',
    },

    CreatedBy: {
        label: 'Created By',
        field: 'CreatedBy',
        type: 'number',
    },

    CreatedAt: {
        label: 'Created At',
        field: 'CreatedAt',
        type: 'date',
    },

    // EditedBy: {
    //     label: 'Edited By',
    //     field: 'EditedBy',
    //     type: 'number',
    // },

    EditedAt: {
        label: 'Edited At',
        field: 'EditedAt',
        type: 'date',
    },
};
