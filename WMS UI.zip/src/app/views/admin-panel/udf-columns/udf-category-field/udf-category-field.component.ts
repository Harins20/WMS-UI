import { Component, inject, input, signal } from '@angular/core';
import { finalize } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import {
    CustomTableComponent,
    LoadingComponent,
    ConfirmationDialogComponent,
} from '../../../../common/components';
import { UdfColumnsService } from '../udf-columns.service';
import { UdfCategoryFieldColumns } from './udf-category-field.column';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { UdfFormComponent } from '../udf-form/udf-form.component';
import { MessageService } from 'primeng/api';
import { ExcelDownloadService } from '../../../../common/services';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-udf-category-field',
    imports: [CustomTableComponent, LoadingComponent],
    providers: [DialogService],
    templateUrl: './udf-category-field.component.html',
    styleUrl: './udf-category-field.component.scss',
})
export class UdfCategoryFieldComponent {
    storerKey = input.required<string>();
    facilityId = input.required<number>();
    tableName = input.required<string>();
    loading = signal(false);
    details = signal<any[]>([]);
    columns = signal(Object.values(UdfCategoryFieldColumns));
    private udfColumnsService = inject(UdfColumnsService);
    private dialogService = inject(DialogService);
    private messageService = inject(MessageService);
    private excelDownloadService = inject(ExcelDownloadService);
    private translate = inject(TranslateService);
    ref: DynamicDialogRef | undefined;
    ConfirmationRef: DynamicDialogRef | undefined;

    ngOnInit() {
        this.getDetails();
    }

    getDetails() {
        this.loading.set(true);
        this.udfColumnsService
            .getDetails(this.storerKey(), this.facilityId(), this.tableName())
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (data: any) => {
                    data.forEach((x: any, index: number) => {
                        x.rowId = index + 1;
                    });
                    this.details.set(data);
                },
                error: (error) => {
                    console.error(error);
                },
            });
    }

    onEditAction(row: any) {
        this.ref = this.dialogService.open(UdfFormComponent, {
            inputValues: {
                udfData: row,
            },
            header: 'Update UDF Field',
            closable: true,
            modal: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });

        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('UdfFieldUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: { message: value },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        const payload = {
                            StorerId: Number(this.storerKey()),
                            FacilityId: this.facilityId(),
                            Table: this.tableName(),
                            Custom_Label: row.Custom_Label,
                            NewCustomLabel: data.Custom_Label,
                            EditedBy: 1,
                            EditedAt: new Date(),
                        };

                        this.loading.set(true);

                        this.udfColumnsService
                            .updateField(payload)
                            .pipe(finalize(() => this.loading.set(false)))
                            .subscribe({
                                next: () => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Success',
                                        detail: 'UDF Field Updated Successfully',
                                    });
                                    this.getDetails();
                                },
                                error: (error) => {
                                    console.error(error);
                                },
                            });
                    }
                });
            }
        });
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            'UDF Column Fields',
            [],
            this.details(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.details(), 'UDF Column Fields');
    }
}
