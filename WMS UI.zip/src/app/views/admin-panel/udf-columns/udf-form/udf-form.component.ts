import { Component, inject, input } from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
@Component({
    selector: 'app-udf-form',
    imports: [ReactiveFormsModule, ButtonModule, InputTextModule],
    templateUrl: './udf-form.component.html',
    styleUrl: './udf-form.component.scss',
})
export class UdfFormComponent {
    private ref = inject(DynamicDialogRef);

    udfData = input<any>();

    udfForm = new FormGroup({
        Label: new FormControl<string>({ value: '', disabled: true }),
        Custom_Label: new FormControl<string>('', [Validators.required]),
    });

    ngOnInit() {
        if (this.udfData()) {
            this.udfForm.patchValue({
                Label: this.udfData().Label,
                Custom_Label: this.udfData().Custom_Label,
            });
        }
    }
    hasError(formControlName: string) {
        const formControl = this.udfForm.get(formControlName)!;

        return (
            (formControl.touched || formControl.dirty) && formControl.invalid
        );
    }
    getErrors(formControlName: string, title?: string) {
        const formControl = this.udfForm.get(formControlName)!;
        return getErrorMessages(formControl.errors, title);
    }

    onCancel() {
        this.ref.close();
    }

    onSubmit() {
        if (this.udfForm.valid) {
            this.ref.close({
                ...this.udfData(),
                ...this.udfForm.value,
            });
        } else {
            this.udfForm.markAllAsTouched();

            markAllControlsAsDirty(Object.values(this.udfForm.controls));
        }
    }
}
