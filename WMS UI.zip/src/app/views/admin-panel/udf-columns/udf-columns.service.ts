import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../../../../app.config.service';
import { AuthService } from '../../../common/services';

@Injectable({ providedIn: 'root' })
export class UdfColumnsService {
    private http = inject(HttpClient);
    private authService = inject(AuthService);
    private headers = this.authService.getAuthHeadersAp();
    private configService = inject(AppConfigService);
    // getFacility() {
    //     return this.http.get(this.configService.AuthUrl + 'facilities', {
    //         headers: this.headers,
    //     });
    // }
    // addFacility(facility: any) {
    //     return this.http.post(
    //         this.configService.AuthUrl + 'facilities',
    //         facility,
    //         {
    //             headers: this.headers,
    //         },
    //     );
    // }
    getStorers() {
        return this.http.get(
            this.configService.AuthUrl + 'WmsFields/wmsstorerfields',
            {
                headers: this.headers,
            },
        );
    }

    // getTables(storerId: number | string) {
    //     return this.http.get(
    //         this.configService.AuthUrl +
    //             `WmsFields/tables?StorerId=${storerId}`,
    //         {
    //             headers: this.headers,
    //         },
    //     );
    // }
    getTables(storerId: number | string, facilityId: number | string) {
        return this.http.get(
            this.configService.AuthUrl +
                `WmsFields/tables?StorerId=${storerId}&FacilityId=${facilityId}`,
            {
                headers: this.headers,
            },
        );
    }
    getDetails(
        storerId: number | string,
        facilityId: number | string,
        tableName: string,
    ) {
        return this.http.get(
            this.configService.AuthUrl +
                `WmsFields/details?StorerId=${storerId}&FacilityId=${facilityId}&table=${tableName}`,
            {
                headers: this.headers,
            },
        );
    }

    updateField(payload: any) {
        return this.http.put(
            this.configService.AuthUrl + 'WmsFields/WmsieldsUpdate',
            payload,
            {
                headers: this.headers,
            },
        );
    }

    addWmsFields(payload: any) {
        return this.http.post(
            this.configService.AuthUrl + 'AddWmsFields',
            payload,
            {
                headers: this.headers,
            },
        );
    }
}
