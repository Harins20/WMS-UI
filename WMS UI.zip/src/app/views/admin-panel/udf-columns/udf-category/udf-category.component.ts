import { Component, inject, input, signal } from '@angular/core';
import { finalize } from 'rxjs';
import { Table, TableModule } from 'primeng/table';
import { UdfColumnsService } from '../udf-columns.service';
import { TabService } from '../../../../tabs/tab.service';
import { InputIconModule } from 'primeng/inputicon';
import { ButtonModule } from 'primeng/button';
import { IconFieldModule } from 'primeng/iconfield';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { SkeletonModule } from 'primeng/skeleton';
import { TagModule } from 'primeng/tag';
import {
    LoadingComponent,
    CustomTableComponent,
} from '../../../../common/components';
import adminPanelRoutes from '../../admin-panel.routes';
import { Route } from '@angular/router';
import { ExcelDownloadService } from '../../../../common/services';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-udf-category',
    imports: [
        ReactiveFormsModule,
        ButtonModule,
        InputIconModule,
        TableModule,
        IconFieldModule,
        InputTextModule,
        SkeletonModule,
        LoadingComponent,
        TagModule,
        CommonModule,
        FormsModule,
        CustomTableComponent,
    ],
    templateUrl: './udf-category.component.html',
    styleUrl: './udf-category.component.scss',
})
export class UdfCategoryComponent {
    loading = signal(false);
    details = signal<any[]>([]);
    searchInput = signal<string | undefined>(undefined);
    private udfColumnsService = inject(UdfColumnsService);
    private excelDownloadService = inject(ExcelDownloadService);
    private tabService = inject(TabService);
    storerKey = input.required<string>();
    facilityId = input.required<number>();
    ngOnInit() {
        this.getTables();
    }
    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal(
            (event.target as HTMLInputElement).value,
            'contains',
        );
    }
    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    onClickPOKey(row: any): void {
        const route = adminPanelRoutes.find(
            (route) => route.data?.name === 'UdfCategoryFieldComponent',
        ) as Route;

        const params = [
            { name: 'storerKey', value: this.storerKey() },
            { name: 'facilityId', value: this.facilityId() },
            { name: 'tableName', value: row.TableName },
        ];

        this.tabService.addTabWithParams(
            route,
            '',
            'Udf Category Field',
            params,
        );
    }
    getTables() {
        this.loading.set(true);
        this.udfColumnsService
            .getTables(this.storerKey(), this.facilityId())
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (data: any) => {
                    data.forEach((x: any, index: number) => {
                        x.rowId = index + 1;
                    });
                    this.details.set(data);
                },
                error: (error) => {
                    console.error(error);
                },
            });
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            'UDF executive Field',
            [],
            this.details(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.details(), 'UDF executive Field');
    }
}
