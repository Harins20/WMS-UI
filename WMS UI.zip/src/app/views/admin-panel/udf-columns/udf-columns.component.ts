import { DatePipe } from '@angular/common';
import { Component, inject, signal, viewChild, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { SkeletonModule } from 'primeng/skeleton';
import { Table, TableModule } from 'primeng/table';
import { finalize } from 'rxjs';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    LoadingComponent,
    CustomTableComponent,
} from '../../../common/components';
import { UdfFormComponent } from './udf-form/udf-form.component';
import { UdfColumnsService } from './udf-columns.service';
import { copyToClipboardText } from '../../../common/functions/clickToCopy';
import { TagModule } from 'primeng/tag';
import adminPanelRoutes from '../admin-panel.routes';
import { Route } from '@angular/router';
import { TabService } from '../../../tabs';
import { ExcelDownloadService } from '../../../common/services';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-udf-columns',
    templateUrl: './udf-columns.component.html',
    styleUrls: ['./udf-columns.component.scss'],
    imports: [
        ReactiveFormsModule,
        ButtonModule,
        InputIconModule,
        TableModule,
        IconFieldModule,
        InputTextModule,
        SkeletonModule,
        DatePipe,
        LoadingComponent,
        TagModule,
        CustomTableComponent,
    ],
    providers: [DialogService],
})
export class UdfColumnsComponent implements OnInit {
    hoveredRow: string | null = null;
    loading = signal<boolean>(false);
    storers = signal<any>([]);
    dt = viewChild.required<Table>('dt');
    private readonly udfcolumnService = inject(UdfColumnsService);
    private readonly messageService = inject(MessageService);
    ref: DynamicDialogRef | undefined;
    private readonly dialogService = inject(DialogService);
    private readonly excelDownloadService = inject(ExcelDownloadService);
    private readonly tabService = inject(TabService);

    ngOnInit() {
        this.getStorers();
    }
    getStorers() {
        this.loading.set(true);

        this.udfcolumnService
            .getStorers()
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (data: any) => {
                    this.storers.set(
                        data.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error) => {
                    console.error('Error fetching storers', error);
                },
            });
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal(
            (event.target as HTMLInputElement).value,
            'contains',
        );
    }

    onClickPOKey(row: any): void {
        const route = adminPanelRoutes.find(
            (route) => route.data?.name === 'UdfCategoryComponent',
        ) as Route;

        const params = [
            { name: 'storerKey', value: row.StorerId },
            { name: 'facilityId', value: row.FacilityId },
        ];

        this.tabService.addTabWithParams(
            route,
            '',
            'Udf Category' + '-' + row.StorerName,
            params,
        );
    }
    copyToClipboard(text: string) {
        copyToClipboardText(text, this.messageService);
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            'UDF Storers',
            [],
            this.storers(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.storers(), 'UDF Storers');
    }
    // openNewForm() {
    //     this.ref = this.dialogService.open(UdfFormComponent, {
    //         header: 'New Facility',
    //         closable: true,
    //         modal: true,
    //         draggable: true,
    //         keepInViewport: true,
    //         // duplicate: true,
    //         width: '35rem',
    //         style: { maxHeight: '40rem' },
    //     });
    //     this.ref.onClose.subscribe((data) => {
    //         if (data) {
    //             this.onNewFormSubmit(data);
    //         }
    //     });
    // }

    // onNewFormSubmit(data: any) {
    //     this.udfcolumnService
    //         .addFacility(data)
    //         .pipe(
    //             finalize(() => {
    //                 this.getStorers();
    //             }),
    //         )
    //         .subscribe({
    //             next: (data) => {
    //                 this.messageService.add({
    //                     severity: 'success',
    //                     summary: 'New Facility',
    //                     detail: data as string,
    //                 });
    //             },
    //             error: (error) => {
    //                 this.messageService.add({
    //                     severity: 'error',
    //                     summary: 'New Facility',
    //                     detail: error as string,
    //                 });
    //             },
    //         });
    // }
}
