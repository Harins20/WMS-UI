import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConfigService } from '../../../../app.config.service';
import { AuthService } from '../../../common/services';
import {
    AddStorerLanguagesRequest,
    AddStorerLanguagesResponse,
    DeactivateLanguageRequest,
    DeactivateLanguageResponse,
    Storer,
    StorerAllLanguageItem,
    StorerFormData,
} from './storer.model';
import { OptionMenu } from '../../../layout/service/action.service';

function safeAtob(val: string | null): string | null {
    if (!val) return null;
    try {
        return atob(val);
    } catch {
        return val;
    }
}

@Injectable({
    providedIn: 'root',
})
export class StorerService {
    private http = inject(HttpClient);
    private authService = inject(AuthService);
    private configService = inject(AppConfigService);

    private toFormData(data: StorerFormData | FormData): FormData {
        if (data instanceof FormData) {
            return data;
        }

        const formData = new FormData();
        const storerName = (
            data.Name ||
            data.name ||
            data.storer ||
            (data as any).Storer ||
            ''
        ).trim();
        formData.append('Name', storerName);
        formData.append('Storer', storerName);

        let facilityId = data.FacilityId ?? data.facilityId;
        if (
            facilityId === undefined ||
            facilityId === null ||
            isNaN(Number(facilityId))
        ) {
            const storedFacilityId = sessionStorage.getItem('FacilityId');
            if (storedFacilityId && !isNaN(Number(storedFacilityId))) {
                facilityId = Number(storedFacilityId);
            }
        }

        if (
            facilityId !== undefined &&
            facilityId !== null &&
            !isNaN(Number(facilityId))
        ) {
            formData.append('FacilityId', String(facilityId));
        }

        if (data.file instanceof File) {
            formData.append(
                'Image',
                data.file,
                data.fileName || data.file.name,
            );
        } else if (data.fileData && typeof data.fileData === 'string') {
            const file = this.base64ToFile(
                data.fileData,
                data.fileName || 'storer-image.png',
            );
            if (file) {
                formData.append('Image', file, file.name);
            }
        }

        return formData;
    }

    private base64ToFile(base64: string, filename: string): File | null {
        try {
            let mime = 'image/png';
            let b64Data = base64;
            if (base64.includes(',')) {
                const parts = base64.split(',');
                const mimeMatch = parts[0].match(/:(.*?);/);
                mime = mimeMatch ? mimeMatch[1] : 'image/png';
                b64Data = parts[parts.length - 1];
            }
            const bstr = atob(b64Data);
            let n = bstr.length;
            const u8arr = new Uint8Array(n);
            while (n--) {
                u8arr[n] = bstr.charCodeAt(n);
            }
            return new File([u8arr], filename, { type: mime });
        } catch {
            return null;
        }
    }

    getStorers(): Observable<Storer[]> {
        return this.http.get<Storer[]>(
            this.configService.AuthUrl + `Storer/Allstorers`,
            {
                headers: this.authService.getAuthHeadersAp(),
            },
        );
    }

    getStorerById(id: number | string): Observable<Storer> {
        return this.http.get<Storer>(
            this.configService.AuthUrl + `Storer/${id}`,
            {
                headers: this.authService.getAuthHeadersAp(),
            },
        );
    }

    createStorer(data: StorerFormData | FormData): Observable<any> {
        const payload = data instanceof FormData ? data : this.toFormData(data);

        return this.http.post(this.configService.AuthUrl + `Storer`, payload, {
            headers: this.authService.getAuthHeadersAp(),
        });
    }
    getLanguages(facilityId: any, storerId: any): Observable<any> {
        return this.http.get(
            this.configService.AuthUrl +
                `Storer/Language?FacilityId=${facilityId}&StorerId=${storerId}`,
            {
                headers: this.authService.getAuthHeadersAp(),
            },
        );
    }
    updateStorer(
        id: number | string,
        data: StorerFormData | FormData,
    ): Observable<any> {
        const payload = this.toFormData(data);
        return this.http.put(
            this.configService.AuthUrl + `Storer/${id}`,
            payload,
            {
                headers: this.authService.getAuthHeadersAp(),
            },
        );
    }

    addLanguages(
        data: AddStorerLanguagesRequest,
    ): Observable<AddStorerLanguagesResponse> {
        return this.http.post<AddStorerLanguagesResponse>(
            this.configService.AuthUrl + `Storer/Language`,
            data,
            {
                headers: this.authService.getAuthHeadersAp(),
            },
        );
    }

    deactivateLanguage(
        data: DeactivateLanguageRequest,
    ): Observable<DeactivateLanguageResponse> {
        return this.http.put<DeactivateLanguageResponse>(
            this.configService.AuthUrl + `Storer/DeactivateLanguage`,
            data,
            {
                headers: this.authService.getAuthHeadersAp(),
            },
        );
    }

    getAllLanguages(): Observable<StorerAllLanguageItem[] | any> {
        return this.http.get<StorerAllLanguageItem[] | any>(
            this.configService.AuthUrl + `Storer/Alllanguages`,
            {
                headers: this.authService.getAuthHeadersAp(),
            },
        );
    }

    getTopbarlogo() {
        return this.http.get<OptionMenu[]>(
            this.configService.AuthUrl + `Storer/headerstorerlogo`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
