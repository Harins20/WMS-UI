import { CommonModule } from '@angular/common';
import {
    Component,
    computed,
    inject,
    input,
    OnInit,
    signal,
    viewChild,
    ElementRef,
} from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import { MultiSelect } from 'primeng/multiselect';
import { AVAILABLE_LANGUAGES, LanguageOption } from '../../../../languages';
import { acceptedImageTypes } from '../../../../common/constants';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { Base64ConvertService } from '../../../../common/services';
import { FacilityService } from '../../facility/facility.service';
import { StorerColumns } from '../storer.columns';
import { Storer, StorerFormData } from '../storer.model';
import { StorerService } from '../storer.service';
import { finalize, forkJoin, of } from 'rxjs';
import { formatBase64Image } from '../../../../common/functions/formatBase64Image';

@Component({
    selector: 'app-storer-form',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        Select,
        MultiSelect,
    ],
    templateUrl: './storer-form.component.html',
    styleUrl: './storer-form.component.scss',
})
export class StorerFormComponent implements OnInit {
    storer = input<Storer | null>(null);

    private ref = inject(DynamicDialogRef);
    private config = inject(DynamicDialogConfig, { optional: true });
    private storerService = inject(StorerService);
    private facilityService = inject(FacilityService);
    private messageService = inject(MessageService);
    private base64ConvertService = inject(Base64ConvertService);

    readonly fileInput = viewChild<ElementRef<HTMLInputElement>>('fileInput');

    // Resolved active storer data (from signal input or dialog config)
    resolvedStorer = signal<Storer | null>(null);
    isEditMode = computed(() => !!this.resolvedStorer());

    // Facility dropdown options and loading state
    facilityOptions = signal<{ label: string; value: number }[]>([]);
    loadingFacilities = signal<boolean>(false);
    loadingLanguages = signal<boolean>(false);
    loadingAllLanguages = signal<boolean>(false);
    initialLanguageCodes = signal<string[]>([]);

    // Available languages for multi-selection dropdown fetched from Storer/Alllanguages
    availableLanguages = signal<LanguageOption[]>(AVAILABLE_LANGUAGES);

    // Form controls: FacilityId, Storer name, and Languages
    storerForm = new FormGroup({
        FacilityId: new FormControl<number | null>(null, [Validators.required]),
        Storer: new FormControl<string>('', [Validators.required]),
        Languages: new FormControl<string[] | null>(null),
    });

    // Image preview and file state
    selectedImage = signal<string | null>(null);
    selectedFile = signal<File | null>(null);
    fileName = signal<string | null>(null);
    imageError = signal<string | null>(null);
    isSaving = signal<boolean>(false);

    // Max allowed image size: 5MB
    readonly maxFileSizeBytes = 5 * 1024 * 1024;

    ngOnInit(): void {
        this.loadAllLanguages();
        this.loadFacilities();

        const initialData =
            this.storer() ||
            this.config?.data?.storer ||
            this.config?.inputValues?.storer ||
            null;
        if (initialData) {
            this.resolvedStorer.set(initialData);

            const storerName =
                initialData.Storer ||
                initialData.storer ||
                initialData.StorerName ||
                initialData.storerName ||
                initialData.Name ||
                initialData.name ||
                '';

            this.storerForm.patchValue({
                Storer: storerName,
            });

            // Populate existing languages in edit mode
            const existingLanguages =
                initialData.Languages ??
                initialData.languages ??
                initialData.Language ??
                initialData.language ??
                initialData.LanguageCodes ??
                initialData.languageCodes ??
                null;

            if (existingLanguages) {
                let selectedCodes: string[] = [];
                if (Array.isArray(existingLanguages)) {
                    selectedCodes = existingLanguages.map((item: any) => {
                        if (typeof item === 'string') {
                            const matched = AVAILABLE_LANGUAGES.find(
                                (l) =>
                                    l.code.toLowerCase() ===
                                    item.toLowerCase() ||
                                    l.label.toLowerCase() ===
                                    item.toLowerCase(),
                            );
                            return matched ? matched.code : item;
                        }
                        return item?.code || item?.value || String(item);
                    });
                } else if (typeof existingLanguages === 'string') {
                    const parts = existingLanguages.includes(',')
                        ? existingLanguages.split(',').map((s) => s.trim())
                        : [existingLanguages.trim()];
                    selectedCodes = parts.map((item) => {
                        const matched = AVAILABLE_LANGUAGES.find(
                            (l) =>
                                l.code.toLowerCase() === item.toLowerCase() ||
                                l.label.toLowerCase() === item.toLowerCase(),
                        );
                        return matched ? matched.code : item;
                    });
                }
                this.initialLanguageCodes.set(selectedCodes);
                this.storerForm.patchValue({
                    Languages: selectedCodes,
                });
            }

            // Restrict editing of Storer identifier in edit mode
            if (this.isEditMode() || StorerColumns['Storer']?.restrictEdit) {
                this.storerForm.controls.Storer.disable();
                this.storerForm.controls.FacilityId.disable();
            }

            const existingImage =
                initialData.Image ||
                initialData.image ||
                initialData.ImageData ||
                initialData.imageData ||
                initialData.FileData ||
                initialData.fileData ||
                initialData.File ||
                initialData.file ||
                null;

            if (existingImage) {
                const formatted = formatBase64Image(existingImage);
                this.selectedImage.set(formatted);
                this.fileName.set(
                    initialData.FileName ||
                    initialData.fileName ||
                    'Current Image',
                );
            }

            this.loadStorerLanguages();
        }
    }

    /**
     * Loads available facilities and auto-selects the currently active facility
     */
    loadFacilities(): void {
        this.loadingFacilities.set(true);
        this.facilityService
            .getFacility()
            .pipe(finalize(() => this.loadingFacilities.set(false)))
            .subscribe({
                next: (data: any) => {
                    const list = Array.isArray(data) ? data : [];
                    const options = list.map((f: any) => ({
                        label: f.Name || f.FacilityName || `Facility ${f.Id}`,
                        value: Number(f.Id),
                    }));
                    this.facilityOptions.set(options);

                    const existingFacilityId =
                        this.resolvedStorer()?.FacilityId ??
                        this.resolvedStorer()?.facilityId;

                    if (
                        existingFacilityId !== undefined &&
                        existingFacilityId !== null &&
                        !isNaN(Number(existingFacilityId))
                    ) {
                        this.storerForm.controls.FacilityId.setValue(
                            Number(existingFacilityId),
                        );
                        sessionStorage.setItem(
                            'FacilityId',
                            String(existingFacilityId),
                        );
                        if (this.isEditMode()) {
                            this.loadStorerLanguages();
                        }
                        return;
                    }

                    // For new storer, default to currently active facility in session
                    const activeFacilityName = safeAtob(
                        sessionStorage.getItem('Facility'),
                    )
                        ?.trim()
                        .toLowerCase();
                    const matched = list.find(
                        (f: any) =>
                            f.Name?.trim().toLowerCase() === activeFacilityName,
                    );

                    if (matched && matched.Id !== undefined) {
                        this.storerForm.controls.FacilityId.setValue(
                            Number(matched.Id),
                        );
                        sessionStorage.setItem(
                            'FacilityId',
                            String(matched.Id),
                        );
                    } else if (options.length > 0) {
                        this.storerForm.controls.FacilityId.setValue(
                            options[0].value,
                        );
                        sessionStorage.setItem(
                            'FacilityId',
                            String(options[0].value),
                        );
                    }

                    if (this.isEditMode()) {
                        this.loadStorerLanguages();
                    }
                },
                error: (error) => {
                    console.error('Failed to load facilities', error);
                },
            });
    }

    loadAllLanguages(): void {
        this.loadingAllLanguages.set(true);
        this.storerService
            .getAllLanguages()
            .pipe(finalize(() => this.loadingAllLanguages.set(false)))
            .subscribe({
                next: (data: any) => {
                    let list: any[] = [];
                    if (Array.isArray(data)) {
                        list = data;
                    } else if (Array.isArray(data?.data)) {
                        list = data.data;
                    } else if (Array.isArray(data?.Languages ?? data?.languages)) {
                        list = data.Languages ?? data.languages;
                    }

                    if (list.length > 0) {
                        const mapped: LanguageOption[] = list.map((item: any) => {
                            const code = (
                                item?.LanguageCode ??
                                item?.languageCode ??
                                item?.code ??
                                ''
                            ).trim();
                            const label =
                                item?.LanguageName ??
                                item?.languageName ??
                                item?.name ??
                                code;
                            const matchedFlag =
                                AVAILABLE_LANGUAGES.find(
                                    (l) =>
                                        l.code.toLowerCase() ===
                                        code.toLowerCase(),
                                )?.flag || '🌐';
                            return {
                                code,
                                label,
                                flag: matchedFlag,
                            };
                        });
                        this.availableLanguages.set(mapped);
                    }
                },
                error: (err) => {
                    console.error(
                        '[loadAllLanguages] Failed to load languages from Storer/Alllanguages',
                        err,
                    );
                    this.availableLanguages.set(AVAILABLE_LANGUAGES);
                },
            });
    }

    loadStorerLanguages(): void {
        if (!this.isEditMode()) {
            return;
        }

        const facilityId =
            this.storerForm.controls.FacilityId.value ??
            this.resolvedStorer()?.FacilityId ??
            this.resolvedStorer()?.facilityId ??
            (sessionStorage.getItem('FacilityId')
                ? Number(sessionStorage.getItem('FacilityId'))
                : null);

        const storerId =
            this.resolvedStorer()?.StorerId ??
            this.resolvedStorer()?.storerId ??
            this.resolvedStorer()?.Id ??
            this.resolvedStorer()?.id ??
            this.resolvedStorer()?.StorerKey ??
            this.resolvedStorer()?.storerKey ??
            this.resolvedStorer()?.Storer ??
            this.resolvedStorer()?.storer ??
            this.resolvedStorer()?.Name ??
            this.resolvedStorer()?.name ??
            this.storerForm.controls.Storer.value;

        // Ensure we only query when both parameters exist
        if (!facilityId || !storerId) {
            console.warn('[loadStorerLanguages] Skipping: missing facilityId or storerId', {
                facilityId,
                storerId,
                formFacilityId: this.storerForm.controls.FacilityId.value,
                storer: this.resolvedStorer(),
            });
            return;
        }

        if (this.loadingLanguages()) {
            return;
        }

        this.loadingLanguages.set(true);
        console.log(`[loadStorerLanguages] Requesting languages for FacilityId=${facilityId}, StorerId=${storerId}`);

        this.storerService
            .getLanguages(facilityId, storerId)
            .pipe(finalize(() => this.loadingLanguages.set(false)))
            .subscribe({
                next: (data: any) => {
                    console.log('[loadStorerLanguages] API response:', data);
                    let rawList: any[] = [];
                    if (Array.isArray(data)) {
                        rawList = data;
                    } else if (Array.isArray(data?.data)) {
                        rawList = data.data;
                    } else if (Array.isArray(data?.Languages ?? data?.languages)) {
                        rawList = data.Languages ?? data.languages;
                    } else if (Array.isArray(data?.LanguageCodes ?? data?.languageCodes)) {
                        rawList = data.LanguageCodes ?? data.languageCodes;
                    } else if (typeof data === 'string') {
                        rawList = data.includes(',')
                            ? data.split(',').map((s: string) => s.trim())
                            : [data.trim()];
                    } else if (typeof (data?.Languages ?? data?.languages) === 'string') {
                        const str = data.Languages ?? data.languages;
                        rawList = str.includes(',')
                            ? str.split(',').map((s: string) => s.trim())
                            : [str.trim()];
                    }

                    const selectedCodes = rawList
                        .map((item: any) => {
                            if (!item) return null;
                            const raw =
                                typeof item === 'string'
                                    ? item
                                    : item?.LanguageCode ||
                                      item?.languageCode ||
                                      item?.code ||
                                      item?.Code ||
                                      item?.Language ||
                                      item?.language ||
                                      '';
                            const rawStr = String(raw).trim();
                            if (!rawStr) return null;

                            const matched = AVAILABLE_LANGUAGES.find(
                                (l) =>
                                    l.code.toLowerCase() ===
                                        rawStr.toLowerCase() ||
                                    l.label.toLowerCase() ===
                                        rawStr.toLowerCase(),
                            );
                            return matched ? matched.code : rawStr;
                        })
                        .filter((code): code is string => !!code);

                    console.log('[loadStorerLanguages] Extracted language codes:', selectedCodes);
                    this.initialLanguageCodes.set(selectedCodes);
                    if (selectedCodes.length > 0) {
                        this.storerForm.controls.Languages.setValue(selectedCodes);
                        this.storerForm.controls.Languages.markAsPristine();
                    }
                },
                error: (error) => {
                    console.error('[loadStorerLanguages] Failed to load storer languages', error);
                },
            });
    }


    hasError(controlName: string): boolean {
        const control = this.storerForm.get(controlName);
        return !!(
            control &&
            (control.touched || control.dirty) &&
            control.invalid
        );
    }

    getErrors(controlName: string, title?: string): string[] {
        const control = this.storerForm.get(controlName);
        return control ? getErrorMessages(control.errors, title) : [];
    }

    /**
     * Trigger the hidden file input when "Image Upload" button is clicked
     */
    triggerImageUpload(): void {
        const inputEl = this.fileInput()?.nativeElement;
        if (inputEl) {
            // Reset value so selecting the same file triggers change event
            inputEl.value = '';
            inputEl.click();
        }
    }

    /**
     * Handles file selection with validation for file type and size
     */
    async onFileSelected(event: Event): Promise<void> {
        this.imageError.set(null);
        const input = event.target as HTMLInputElement;
        const file = input.files?.[0];

        if (!file) {
            return;
        }

        // Validate file type
        const extension = file.name.split('.').pop()?.toLowerCase() || '';
        const isImageType =
            file.type.startsWith('image/') ||
            acceptedImageTypes.includes(extension);

        if (!isImageType) {
            this.imageError.set(
                `Invalid file format (.${extension || 'unknown'}). Please choose an image file (PNG, JPG, JPEG, WEBP, SVG).`,
            );
            return;
        }

        // Validate file size
        if (file.size > this.maxFileSizeBytes) {
            const sizeInMb = (file.size / (1024 * 1024)).toFixed(1);
            this.imageError.set(
                `File size (${sizeInMb} MB) exceeds maximum limit of 5 MB.`,
            );
            return;
        }

        try {
            const base64Data = (await this.base64ConvertService.baseConverFile(
                file,
            )) as string;
            if (base64Data) {
                this.selectedImage.set(base64Data);
                this.selectedFile.set(file);
                this.fileName.set(file.name);
            }
        } catch (error) {
            this.imageError.set(
                'Failed to read image file. Please try another file.',
            );
        }
    }

    /**
     * Remove the current preview (allows resetting to no image or placeholder)
     */
    clearImage(event: Event): void {
        event.stopPropagation();
        this.selectedImage.set(null);
        this.selectedFile.set(null);
        this.fileName.set(null);
        this.imageError.set(null);
        const inputEl = this.fileInput()?.nativeElement;
        if (inputEl) {
            inputEl.value = '';
        }
    }

    /**
     * Cancel: Closes the form and discards unsaved changes
     */
    onCancel(): void {
        this.ref.close(null);
    }

    /**
     * Submit: Validates the single Storer field and executes Create or Update
     */
    onSubmit(): void {
        if (this.storerForm.invalid && !this.storerForm.disabled) {
            this.storerForm.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.storerForm.controls));
            return;
        }

        // Prevent duplicate submissions
        if (this.isSaving()) {
            return;
        }

        const rawValue = this.storerForm.getRawValue();
        const storerName = (
            rawValue.Storer ||
            this.resolvedStorer()?.Name ||
            this.resolvedStorer()?.name ||
            this.resolvedStorer()?.Storer ||
            this.resolvedStorer()?.storer ||
            ''
        ).trim();

        const id =
            this.resolvedStorer()?.StorerId ??
            this.resolvedStorer()?.storerId ??
            this.resolvedStorer()?.Id ??
            this.resolvedStorer()?.id ??
            this.resolvedStorer()?.StorerKey ??
            this.resolvedStorer()?.storerKey;

        const facilityId =
            rawValue.FacilityId ??
            this.resolvedStorer()?.FacilityId ??
            this.resolvedStorer()?.facilityId ??
            (sessionStorage.getItem('FacilityId')
                ? Number(sessionStorage.getItem('FacilityId'))
                : undefined);

        const selectedFacility = this.facilityOptions().find(
            (f) => f.value === Number(facilityId),
        );
        const facilityName =
            selectedFacility?.label ||
            safeAtob(sessionStorage.getItem('Facility')) ||
            '';

        if (
            this.isEditMode() &&
            (id === undefined || id === null || id === '')
        ) {
            this.messageService.add({
                severity: 'error',
                summary: 'Update Storer Failed',
                detail: 'Missing Storer ID for update.',
            });
            return;
        }

        const payload: StorerFormData = {
            id,
            storer: storerName,
            Name: storerName,
            facilityId:
                facilityId !== undefined && facilityId !== null
                    ? Number(facilityId)
                    : undefined,
            FacilityId:
                facilityId !== undefined && facilityId !== null
                    ? Number(facilityId)
                    : undefined,
            facility: facilityName,
            Facility: facilityName,
            fileName: this.fileName(),
            fileData: this.selectedImage(),
            file: this.selectedFile(),
            Languages: rawValue.Languages ?? undefined,
            languages: rawValue.Languages ?? undefined,
        };

        this.isSaving.set(true);

        if (!this.isEditMode()) {
            this.storerService
                .createStorer(payload)
                .pipe(finalize(() => this.isSaving.set(false)))
                .subscribe({
                    next: (response) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Storer Created',
                            detail:
                                typeof response === 'string'
                                    ? response
                                    : `Storer "${storerName}" successfully created.`,
                        });
                        this.ref.close({ success: true, data: payload });
                    },
                    error: (error) => {
                        const errorDetail =
                            error?.error?.message ||
                            error?.error?.detail ||
                            (typeof error?.error === 'string'
                                ? error.error
                                : null) ||
                            error?.message ||
                            'Failed to create Storer record.';

                        this.messageService.add({
                            severity: 'error',
                            summary: 'Create Storer Failed',
                            detail: errorDetail,
                        });
                    },
                });
            return;
        }

        // Edit mode: Execute updateStorer and sync languages (POST new, deactivate removed)
        const updateStorer$ = this.storerService.updateStorer(id!, payload);

        const currentCodes: string[] = rawValue.Languages || [];
        const originalCodes: string[] = this.initialLanguageCodes();

        // New languages to add via POST /Storer/Language
        const addedCodes = currentCodes.filter((c) => !originalCodes.includes(c));

        // Removed languages to deactivate via PUT /Storer/DeactivateLanguage
        const removedCodes = originalCodes.filter((c) => !currentCodes.includes(c));

        const hasValidIds =
            facilityId !== undefined &&
            facilityId !== null &&
            !isNaN(Number(facilityId)) &&
            id !== undefined &&
            id !== null;

        const addLanguages$ =
            hasValidIds && addedCodes.length > 0
                ? this.storerService.addLanguages({
                    FacilityId: Number(facilityId),
                    StorerId: Number(id),
                    Languages: addedCodes.map((code, idx) => {
                        const matched =
                            this.availableLanguages().find(
                                (l) =>
                                    l.code.toLowerCase() === code.toLowerCase(),
                            ) ||
                            AVAILABLE_LANGUAGES.find(
                                (l) =>
                                    l.code.toLowerCase() === code.toLowerCase(),
                            );
                        return {
                            LanguageCode: matched ? matched.code : code,
                            LanguageName: matched ? matched.label : code,
                            IsDefault:
                                code.toLowerCase() === 'en' ||
                                (originalCodes.length === 0 && idx === 0),
                        };
                    }),
                })
                : of(null);

        const deactivateLanguages$ =
            hasValidIds && removedCodes.length > 0
                ? this.storerService.deactivateLanguage({
                    FacilityId: Number(facilityId),
                    StorerId: Number(id),
                    LanguageCodes: removedCodes,
                })
                : of(null);

        forkJoin({
            storer: updateStorer$,
            added: addLanguages$,
            removed: deactivateLanguages$,
        })
            .pipe(finalize(() => this.isSaving.set(false)))
            .subscribe({
                next: (results) => {
                    const addMessage = results.added?.Message;
                    const removeMessage = results.removed?.Message;
                    const langDetails = [addMessage, removeMessage]
                        .filter(Boolean)
                        .join(' ');

                    const detail = langDetails
                        ? `Storer "${storerName}" updated. ${langDetails}`
                        : `Storer "${storerName}" successfully updated.`;

                    this.messageService.add({
                        severity: 'success',
                        summary: 'Storer Updated',
                        detail,
                    });
                    this.ref.close({
                        success: true,
                        data: {
                            ...payload,
                            languageAddResponse: results.added,
                            languageDeactivateResponse: results.removed,
                        },
                    });
                },
                error: (error) => {
                    const errorDetail =
                        error?.error?.message ||
                        error?.error?.Message ||
                        error?.error?.detail ||
                        (typeof error?.error === 'string'
                            ? error.error
                            : null) ||
                        error?.message ||
                        'Failed to update Storer record.';

                    this.messageService.add({
                        severity: 'error',
                        summary: 'Update Storer Failed',
                        detail: errorDetail,
                    });
                },
            });
    }
}
function safeAtob(val: string | null): string | null {
    if (!val) return null;
    try {
        return atob(val);
    } catch {
        return null;
    }
}
