import { CommonModule, DatePipe } from '@angular/common';
import {
    AfterViewInit,
    Component,
    effect,
    inject,
    OnInit,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ImageModule } from 'primeng/image';
import { TooltipModule } from 'primeng/tooltip';
import { finalize } from 'rxjs';
import {
    CustomTableComponent,
    LoadingComponent,
} from '../../../common/components';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { ExcelDownloadService } from '../../../common/services';
import { StorerColumns } from './storer.columns';
import { StorerFormComponent } from './storer-form/storer-form.component';
import { Storer } from './storer.model';
import { StorerService } from './storer.service';
import { formatBase64Image } from '../../../common/functions/formatBase64Image';

@Component({
    selector: 'app-storer',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        ButtonModule,
        TooltipModule,
        DatePipe,
        ImageModule,
        LoadingComponent,
        CustomTableComponent,
    ],
    providers: [DialogService],
    templateUrl: './storer.component.html',
    styleUrl: './storer.component.scss',
})
export class StorerComponent implements OnInit, AfterViewInit {
    private storerService = inject(StorerService);
    private dialogService = inject(DialogService);
    private messageService = inject(MessageService);
    private excelDownloadService = inject(ExcelDownloadService);

    ref: DynamicDialogRef | undefined;

    // Component state
    storers = signal<Storer[]>([]);
    loading = signal<boolean>(false);

    // Custom cell template for image column
    imageCellTemplate = viewChild<TemplateRef<any>>('imageCellTemplate');

    // Columns configuration from storer.columns.ts
    columns = signal<any[]>([
        { ...StorerColumns['rowId'] },
        { ...StorerColumns['Storer'] },
        { ...StorerColumns['CreatedBy'] },
        { ...StorerColumns['CreatedAt'] },
        { ...StorerColumns['EditedBy'] },
        { ...StorerColumns['EditedAt'] },
        { ...StorerColumns['Image'] },
    ]);

    selectedColumns = signal(this.columns());
    globalcolumns = signal(this.columns().map((column) => column.field));

    constructor() {
        effect(() => {
            const tpl = this.imageCellTemplate();
            if (tpl) {
                this.attachImageTemplate(tpl);
            }
        });
    }

    ngOnInit(): void {
        this.getStorers();
    }

    ngAfterViewInit(): void {
        const tpl = this.imageCellTemplate();
        if (tpl) {
            this.attachImageTemplate(tpl);
        }
    }

    private attachImageTemplate(tpl: TemplateRef<any>): void {
        this.columns.update((cols) =>
            cols.map((col) =>
                col.field === 'Image'
                    ? { ...col, customCellTemplate: tpl }
                    : col,
            ),
        );
        this.selectedColumns.set(this.columns());
    }

    /**
     * Fetch Storer records using the StorerService
     */
    getStorers(): void {
        this.loading.set(true);
        this.storers.set([]);

        this.storerService
            .getStorers()
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (data: any) => {
                    const list = Array.isArray(data)
                        ? data
                        : Array.isArray(data?.data)
                          ? data.data
                          : [];

                    const processed = list.map((item: any, index: number) => {
                        const rawImage =
                            item.Image ??
                            item.image ??
                            item.ImageData ??
                            item.imageData ??
                            item.FileData ??
                            item.fileData ??
                            item.File ??
                            item.file ??
                            item.Logo ??
                            item.logo ??
                            item.Attachment ??
                            item.attachment ??
                            null;

                        const formattedImage = formatBase64Image(rawImage);

                        return {
                            ...item,
                            rowId: index + 1,
                            Storer:
                                item.Storer ||
                                item.storer ||
                                item.StorerName ||
                                item.storerName ||
                                item.Name ||
                                item.name ||
                                '-',
                            CreatedBy: item.CreatedBy || item.createdBy || '-',
                            CreatedAt:
                                item.CreatedAt ||
                                item.createdAt ||
                                item.CreatedTime ||
                                null,
                            EditedBy:
                                item.EditedBy ||
                                item.editedBy ||
                                item.UpdatedBy ||
                                item.updatedBy ||
                                '-',
                            EditedAt:
                                item.EditedAt ||
                                item.editedAt ||
                                item.EditedTime ||
                                item.UpdatedAt ||
                                null,
                            Image: formattedImage,
                        };
                    });

                    this.storers.set(processed);
                },
                error: (error: any) => {
                    console.error('Error fetching storers', error);
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Storer',
                        detail:
                            error?.error?.message ||
                            error?.message ||
                            'Error fetching storers',
                    });
                },
            });
    }

    /**
     * Open form in Create mode
     */
    openCreateForm(): void {
        this.ref = this.dialogService.open(StorerFormComponent, {
            header: 'New Storer',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });

        this.ref.onClose.subscribe((result) => {
            if (result?.success) {
                this.getStorers();
            }
        });
    }

    /**
     * Open form in Edit mode with existing record data
     */
    openEditForm(storer: Storer): void {
        this.ref = this.dialogService.open(StorerFormComponent, {
            inputValues: {
                storer: storer,
            },
            data: {
                storer: storer,
            },
            header: 'Edit Storer',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });

        this.ref.onClose.subscribe((result) => {
            if (result?.success) {
                this.getStorers();
            }
        });
    }

    /**
     * Export data to CSV
     */
    exportCSV(): void {
        const exportData = this.storers().map((item: any, idx: number) => ({
            'S/No.': idx + 1,
            Storer: item.Storer,
            'Created By': item.CreatedBy,
            'Created Time': item.CreatedAt
                ? new Date(item.CreatedAt).toLocaleString()
                : '-',
            'Edited By': item.EditedBy,
            'Edited Time': item.EditedAt
                ? new Date(item.EditedAt).toLocaleString()
                : '-',
        }));
        downloadCSVFile(exportData, 'Storers');
    }

    /**
     * Export data to Excel
     */
    exportExcel(): void {
        const exportData = this.storers().map((item: any, idx: number) => ({
            'S/No.': idx + 1,
            Storer: item.Storer,
            'Created By': item.CreatedBy,
            'Created Time': item.CreatedAt
                ? new Date(item.CreatedAt).toLocaleString()
                : '-',
            'Edited By': item.EditedBy,
            'Edited Time': item.EditedAt
                ? new Date(item.EditedAt).toLocaleString()
                : '-',
        }));
        this.excelDownloadService.downloadExcelFile('Storers', [], exportData);
    }
}
