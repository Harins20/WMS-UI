import { Columns } from '../../../common/models';

export const StorerColumns: Columns = {
    rowId: {
        label: 'S/No.',
        field: 'rowId',
        type: 'number',
    },
    Storer: {
        label: 'Storer',
        field: 'Storer',
        type: 'text',
        restrictEdit: true,
    },
    CreatedBy: {
        label: 'Created By',
        field: 'CreatedBy',
        type: 'text',
    },
    CreatedAt: {
        label: 'Created Time',
        field: 'CreatedAt',
        type: 'date',
    },
    EditedBy: {
        label: 'Edited By',
        field: 'EditedBy',
        type: 'text',
    },
    EditedAt: {
        label: 'Edited Time',
        field: 'EditedAt',
        type: 'date',
    },
    Image: {
        label: 'Image',
        field: 'Image',
        type: 'image',
    },
};
