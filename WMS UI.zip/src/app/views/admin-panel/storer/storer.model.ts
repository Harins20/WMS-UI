export interface Storer {
    id?: number | string;
    Id?: number | string;
    storer?: string;
    Storer?: string;
    storerName?: string;
    StorerName?: string;
    name?: string;
    Name?: string;
    storerId?: number | string;
    StorerId?: number | string;
    storerKey?: number | string;
    StorerKey?: number | string;
    facilityId?: number;
    FacilityId?: number;
    createdBy?: string;
    CreatedBy?: string;
    createdAt?: Date | string;
    CreatedAt?: Date | string;
    createdTime?: Date | string;
    CreatedTime?: Date | string;
    editedBy?: string;
    EditedBy?: string;
    updatedBy?: string;
    UpdatedBy?: string;
    editedAt?: Date | string;
    EditedAt?: Date | string;
    editedTime?: Date | string;
    EditedTime?: Date | string;
    updatedAt?: Date | string;
    UpdatedAt?: Date | string;
    image?: string | null;
    Image?: string | null;
    imageData?: string | null;
    ImageData?: string | null;
    fileData?: string | null;
    FileData?: string | null;
    fileName?: string | null;
    FileName?: string | null;
    languages?: string[] | string | null;
    Languages?: string[] | string | null;
    [key: string]: any;
}

export interface StorerFormData {
    id?: number | string;
    storer?: string;
    name?: string;
    Name?: string;
    facilityId?: number;
    FacilityId?: number;
    facility?: string;
    Facility?: string;
    fileName?: string | null;
    fileData?: string | null;
    file?: File | null;
    languages?: string[] | string | null;
    Languages?: string[] | string | null;
}

export interface DeactivateLanguageRequest {
    FacilityId: number;
    StorerId: number | string;
    LanguageCodes: string[];
}

export interface DeactivateLanguageResponse {
    Message?: string;
    FacilityId?: number;
    StorerId?: number;
    UpdatedCount?: number;
    [key: string]: any;
}

export interface StorerLanguageItem {
    LanguageCode: string;
    LanguageName?: string;
    IsDefault?: boolean;
}

export interface AddStorerLanguagesRequest {
    FacilityId: number;
    StorerId: number | string;
    Languages: StorerLanguageItem[];
}

export interface AddStorerLanguagesResponse {
    Message?: string;
    FacilityId?: number;
    StorerId?: number;
    InsertedCount?: number;
    [key: string]: any;
}

export interface StorerAllLanguageItem {
    LanguageCode: string;
    LanguageName: string;
}
