import { RoleComponent } from './role/role.component';
import { AccessComponent } from './users/access/access.component';
import { FacilityComponentAdmin } from './facility/facility.component';
import { UsersComponent } from './users';
import { UdfColumnsComponent } from './udf-columns/udf-columns.component';
import { UdfCategoryComponent } from './udf-columns/udf-category/udf-category.component';
import { UdfCategoryFieldComponent } from './udf-columns/udf-category-field/udf-category-field.component';
import { AllocationBasedOwnersComponent } from './facility/allocation-based-owners/allocation-based-owners.component';
import { StorerComponent } from './storer/storer.component';
import { RfConfigComponent } from './role/rf-config/rf-config.component';

export default [
    {
        path: 'storer',
        data: { name: 'Storer' },
        component: StorerComponent,
    },

    {
        path: 'access/:UserId',
        data: { name: 'access' },
        component: AccessComponent,
    },
    {
        path: 'users',
        data: { name: 'User Management' },
        component: UsersComponent,
    },
    {
        path: 'role',
        data: { name: 'Role' },
        component: RoleComponent,
    },
    {
        path: 'facility',
        data: { name: 'Facility' },
        component: FacilityComponentAdmin,
    },
    {
        path: 'columns',
        data: { name: 'Columns' },
        component: UdfColumnsComponent,
    },
    {
        path: 'UdfCategoryComponent',
        data: { name: 'UdfCategoryComponent' },
        component: UdfCategoryComponent,
    },
    {
        path: 'UdfCategoryFieldComponent',
        data: { name: 'UdfCategoryFieldComponent' },
        component: UdfCategoryFieldComponent,
    },
    {
        path: 'allocationbasedowners',
        data: { name: 'Allocation Based Owners' },
        component: AllocationBasedOwnersComponent,
    },
    {
        path: 'rf-config',
        data: { name: 'RF Config' },
        component: RfConfigComponent,
    },
];
