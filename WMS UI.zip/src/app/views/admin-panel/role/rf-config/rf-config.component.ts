import {
    Component,
    computed,
    inject,
    signal,
    OnInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { TagModule } from 'primeng/tag';
import { TreeNode, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { finalize, forkJoin, take } from 'rxjs';
import { RoleService } from '../role.service';
import {
    RfFieldControlOption,
    RfMenuNode,
    RfRoleFieldItem,
} from '../rf-roles.models';
import { OptionsService } from '../../../../common/services';
import { SelectModule } from 'primeng/select';

interface RfSection {
    Id: number;
    Name: string;
    IconClass: string;
    Children: RfMenuNode[];
}

interface AccessMode {
    code: string;
    label: string;
}

@Component({
    selector: 'app-rf-config',
    templateUrl: './rf-config.component.html',
    styleUrls: ['./rf-config.component.scss'],
    standalone: true,
    imports: [
        CommonModule,
        RouterModule,
        FormsModule,
        ButtonModule,
        ToastModule,
        TagModule,
        CheckboxModule,
        SelectModule,
    ],
})
export class RfConfigComponent implements OnInit {
    roleId = signal<number>(1);

    private roleService = inject(RoleService);
    private optionsService = inject(OptionsService);
    private messageService = inject(MessageService);
    private router = inject(Router);

    loading = signal(false);
    saving = signal(false);

    facilityOptions = signal<any[]>([]);
    storerOptions = signal<any[]>([]);

    selectedFacilityName = signal<string | null>(null);
    selectedStorerName = signal<string | null>(null);

    applyToAllRoles = signal(true);

    menuTree = signal<RfMenuNode[]>([]);
    fieldControls = signal<RfFieldControlOption[]>([]);

    // key = `${menuId}:${fieldId}` → access code 'S' | 'H' | 'R' | 'D'
    grantedFields = signal<Map<string, string>>(new Map());
    selectedNodes = signal<TreeNode[]>([]);
    selectedCount = computed(() => this.selectedNodes().length);

    private openSectionId = signal<number | null>(null);
    private expandedCards = signal<Set<number>>(new Set());

    private restoreInProgress = false;
    private lastLoadedKey = '';
    private loadAllInFlight = false;

    readonly accessModes: AccessMode[] = [
        { code: 'S', label: 'Show' },
        { code: 'H', label: 'Hidden' },
        { code: 'R', label: 'Readonly' },
        { code: 'D', label: 'Disabled' },
    ];

    tree = computed<TreeNode[]>(() => {
        const menus = this.menuTree();
        const map: Record<string, TreeNode> = {};

        for (const m of menus) {
            map[m.Id.toString()] = {
                key: m.Id.toString(),
                label: m.Name,
                icon: m.IconClass,
                data: m,
                children: [],
                selectable: true,
            };
        }

        const roots: TreeNode[] = [];
        for (const m of menus) {
            if (m.ParentId === 0) {
                roots.push(map[m.Id.toString()]);
            } else {
                map[m.ParentId.toString()]?.children?.push(
                    map[m.Id.toString()],
                );
            }
        }
        return roots;
    });

    sections = computed<RfSection[]>(() => {
        const menus = this.menuTree();
        if (!menus.length) return [];

        const result: RfSection[] = [];
        const orphans: RfMenuNode[] = [];

        for (const root of menus.filter(m => m.ParentId === 0)) {
            const children = menus.filter(m => m.ParentId === root.Id);
            if (children.length) {
                result.push({
                    Id: root.Id,
                    Name: root.Name,
                    IconClass: root.IconClass || 'pi pi-folder',
                    Children: children.sort((a, b) => a.SortOrder - b.SortOrder),
                });
            } else {
                orphans.push(root);
            }
        }

        if (orphans.length) {
            result.push({
                Id: -1,
                Name: 'General',
                IconClass: 'pi pi-list',
                Children: orphans.sort((a, b) => a.SortOrder - b.SortOrder),
            });
        }

        return result;
    });

    isSectionOpen(sectionId: number): boolean {
        return this.openSectionId() === sectionId;
    }

    toggleSection(sectionId: number) {
        const current = this.openSectionId();
        this.openSectionId.set(current === sectionId ? null : sectionId);
    }

    isCardExpanded(menuId: number): boolean {
        return this.expandedCards().has(menuId);
    }

    toggleCard(menuId: number) {
        const set = new Set(this.expandedCards());
        if (set.has(menuId)) set.delete(menuId);
        else set.add(menuId);
        this.expandedCards.set(set);
    }

    private expandCard(menuId: number) {
        const set = new Set(this.expandedCards());
        set.add(menuId);
        this.expandedCards.set(set);
    }

    sectionSelectedCount(section: RfSection): number {
        return section.Children.filter(m => this.isNodeSelected(m.Id)).length;
    }

    isSectionFullySelected(section: RfSection): boolean {
        if (!section.Children.length) return false;
        return section.Children.every(m => this.isNodeSelected(m.Id));
    }

    onSectionToggle(section: RfSection, checked: boolean) {
        const nodes = this.tree();
        const current = new Map<number, TreeNode>();
        for (const n of this.selectedNodes()) current.set(Number(n.key), n);

        for (const menu of section.Children) {
            const target = this.findNode(nodes, menu.Id);
            if (!target) continue;

            const affected = [target, ...(target.children ?? [])];
            if (checked) {
                for (const n of affected) current.set(Number(n.key), n);
            } else {
                for (const n of affected) current.delete(Number(n.key));
            }
        }

        this.selectedNodes.set([...current.values()]);
    }

    ngOnInit() {
        this.loadInitialData();
    }

    loadInitialData() {
        this.loading.set(true);

        const encodedFacility = sessionStorage.getItem('Facility');
        const encodedTraderKey = sessionStorage.getItem('TraderKey');

        const storedFacilityName = encodedFacility ? atob(encodedFacility) : null;
        const storedStorerName = encodedTraderKey ? atob(encodedTraderKey) : null;

        forkJoin({
            tree: this.roleService.getRfMenuTree(),
            facilities: this.optionsService.getFacilityOptions(),
        }).subscribe({
            next: ({ tree, facilities }) => {
                this.menuTree.set(tree?.Menus ?? []);
                this.fieldControls.set(tree?.FieldControls ?? []);
                this.facilityOptions.set(facilities ?? []);

                if (!storedFacilityName) {
                    this.loading.set(false);
                    return;
                }

                this.restoreInProgress = true;

                this.selectedFacilityName.set(storedFacilityName);
                this.selectedStorerName.set(storedStorerName);

                this.optionsService.getStorerOptions(storedFacilityName).subscribe({
                    next: (storers) => {
                        this.storerOptions.set(storers ?? []);

                        if (!storedStorerName) {
                            this.restoreInProgress = false;
                            this.loading.set(false);
                            return;
                        }

                        const facilityObj = this.facilityOptions().find(
                            (f) => f.value === storedFacilityName ||
                                f.label === storedFacilityName ||
                                f.Name === storedFacilityName,
                        );
                        const storerObj = (storers ?? []).find(
                            (s) => s.value === storedStorerName ||
                                s.label === storedStorerName ||
                                s.Name === storedStorerName,
                        );

                        const fId = facilityObj?.Id;
                        const sId = storerObj?.Id;

                        if (!fId || !sId) {
                            this.restoreInProgress = false;
                            this.loading.set(false);
                            return;
                        }

                        if (!this.roleId()) {
                            this.restoreInProgress = false;
                            this.loading.set(false);
                            return;
                        }

                        forkJoin({
                            menus: this.roleService.getRoleRfMenus(this.roleId(), fId, sId),
                            fields: this.roleService.getRoleRfFields(this.roleId(), fId, sId),
                        })
                            .pipe(finalize(() => {
                                this.restoreInProgress = false;
                                this.lastLoadedKey = `${fId}|${sId}`;
                                this.loading.set(false);
                            }))
                            .subscribe({
                                next: ({ menus, fields }) => {
                                    this.applyRoleData(menus, fields);
                                },
                                error: (err) => this.handleError(
                                    'Failed to load RF configuration.', err,
                                ),
                            });
                    },
                    error: (err) => {
                        this.restoreInProgress = false;
                        this.loading.set(false);
                        this.handleError('Failed to load storers.', err);
                    },
                });
            },
            error: (err) => {
                this.loading.set(false);
                this.handleError('Failed to load initial data.', err);
            },
        });
    }

    onFacilityChange(facilityName: string | null) {
        if (this.restoreInProgress) return;

        this.selectedFacilityName.set(facilityName || null);
        this.selectedStorerName.set(null);
        this.storerOptions.set([]);

        this.selectedNodes.set([]);
        this.grantedFields.set(new Map());
        this.openSectionId.set(null);
        this.expandedCards.set(new Set());
        this.lastLoadedKey = '';

        if (facilityName) {
            this.loading.set(true);
            this.optionsService.getStorerOptions(facilityName).subscribe({
                next: (storers) => {
                    this.storerOptions.set(storers ?? []);
                    this.loading.set(false);
                },
                error: (err) => {
                    this.loading.set(false);
                    this.handleError('Failed to load storers.', err);
                },
            });
        }
    }

    onStorerChange(storerName: string | null) {
        if (this.restoreInProgress) return;

        this.selectedStorerName.set(storerName || null);

        if (storerName) {
            this.loadAll();
        } else {
            this.selectedNodes.set([]);
            this.grantedFields.set(new Map());
            this.lastLoadedKey = '';
        }
    }

    loadAll() {
        const fName = this.selectedFacilityName();
        const sName = this.selectedStorerName();
        const rid = this.roleId();

        if (!fName || !sName) return;
        if (!rid) return;

        const facilityObj = this.facilityOptions().find(
            (f) => f.value === fName || f.label === fName || f.Name === fName,
        );
        const storerObj = this.storerOptions().find(
            (s) => s.value === sName || s.label === sName || s.Name === sName,
        );

        const fId = facilityObj?.Id;
        const sId = storerObj?.Id;

        if (!fId || !sId) {
            this.handleError('Could not resolve Facility/Storer IDs.', null);
            return;
        }

        const key = `${rid}|${fId}|${sId}`;
        if (this.loadAllInFlight) return;
        if (this.lastLoadedKey === key) return;

        this.loadAllInFlight = true;
        this.loading.set(true);

        forkJoin({
            menus: this.roleService.getRoleRfMenus(rid, fId, sId),
            fields: this.roleService.getRoleRfFields(rid, fId, sId),
        })
            .pipe(finalize(() => {
                this.loading.set(false);
                this.loadAllInFlight = false;
            }))
            .subscribe({
                next: ({ menus, fields }) => {
                    this.lastLoadedKey = key;
                    this.applyRoleData(menus, fields);
                },
                error: (err) => {
                    this.lastLoadedKey = '';
                    this.handleError('Failed to load RF configuration.', err);
                },
            });
    }

    private applyRoleData(
        menus: number[] | null | undefined,
        fields: RfRoleFieldItem[] | null | undefined,
    ) {
        const grantedKeys = new Set<string>(
            (menus ?? []).map((id) => id.toString()),
        );

        const fieldMap = new Map<string, string>();
        for (const f of fields ?? []) {
            // Backend returns both FieldId and FieldName; prefer FieldId.
            const fieldId = f.FieldId;
            if (fieldId == null || fieldId <= 0) continue;

            fieldMap.set(this.fieldKey(f.MenuId, fieldId), f.Access);
        }
        this.grantedFields.set(fieldMap);

        this.selectedNodes.set(
            this.collectSelectedNodes(this.tree(), grantedKeys),
        );
    }

    private collectSelectedNodes(
        nodes: TreeNode[],
        grantedKeys: Set<string>,
    ): TreeNode[] {
        const selected: TreeNode[] = [];
        for (const n of nodes) {
            if (n.key && grantedKeys.has(n.key)) selected.push(n);
            if (n.children?.length) {
                selected.push(
                    ...this.collectSelectedNodes(n.children, grantedKeys),
                );
            }
        }
        return selected;
    }

    onMenuToggle(menuId: number, checked: boolean) {
        const nodes = this.tree();
        const target = this.findNode(nodes, menuId);
        if (!target) return;

        const affected: TreeNode[] = [target, ...(target.children ?? [])];
        const current = new Map<number, TreeNode>();
        for (const n of this.selectedNodes()) current.set(Number(n.key), n);

        if (checked) {
            for (const n of affected) current.set(Number(n.key), n);
            const hasFields = (target.data?.Fields?.length ?? 0) > 0;
            if (hasFields) this.expandCard(menuId);
        } else {
            for (const n of affected) current.delete(Number(n.key));
        }

        this.selectedNodes.set([...current.values()]);
    }

    private findNode(nodes: TreeNode[], id: number): TreeNode | undefined {
        for (const n of nodes) {
            if (Number(n.key) === id) return n;
            if (n.children?.length) {
                const hit = this.findNode(n.children, id);
                if (hit) return hit;
            }
        }
        return undefined;
    }

    /** key = `${menuId}:${fieldId}` */
    fieldKey(menuId: number, fieldId: number) {
        return `${menuId}:${fieldId}`;
    }

    getFieldAccess(menuId: number, fieldId: number): string {
        return this.grantedFields().get(this.fieldKey(menuId, fieldId)) ?? 'S';
    }

    setFieldAccess(menuId: number, fieldId: number, code: string) {
        const copy = new Map(this.grantedFields());
        copy.set(this.fieldKey(menuId, fieldId), code);
        this.grantedFields.set(copy);
    }

    /**
     * Field-level select change.
     * Auto-grants the parent menu so the field setting persists on save.
     */
    onFieldAccessChange(
        menu: RfMenuNode,
        field: { Id: number },
        code: string,
    ) {
        if (!this.isNodeSelected(menu.Id)) {
            this.onMenuToggle(menu.Id, true);
        }
        this.setFieldAccess(menu.Id, field.Id, code);
    }

    isNodeSelected(key: string | number | undefined): boolean {
        if (key == null) return false;
        const target = Number(key);
        return this.selectedNodes().some((n) => Number(n.key) === target);
    }

    onSave() {
        if (this.saving()) return;

        const fName = this.selectedFacilityName();
        const sName = this.selectedStorerName();
        const rid = this.roleId();

        if (!fName || !sName) return;
        if (!rid) {
            this.messageService.add({
                severity: 'warn',
                summary: 'RF Configuration',
                detail: 'Select a role before saving.',
            });
            return;
        }

        const facilityObj = this.facilityOptions().find(
            (f) => f.value === fName || f.label === fName || f.Name === fName,
        );
        const storerObj = this.storerOptions().find(
            (s) => s.value === sName || s.label === sName || s.Name === sName,
        );

        const fId = facilityObj?.Id;
        const sId = storerObj?.Id;

        if (!fId || !sId) return;

        const menuIds: number[] = this.selectedNodes()
            .map((n) => Number(n.key))
            .filter((id) => !Number.isNaN(id));

        const allowedPrefixes = menuIds.map((id) => `${id}:`);

        // Build payload: send FieldId AND FieldName (belt-and-braces).
        const fields: RfRoleFieldItem[] = [];
        for (const [key, access] of this.grantedFields().entries()) {
            const allowed = allowedPrefixes.some((p) => key.startsWith(p));
            if (!allowed) continue;

            const [menuIdStr, fieldIdStr] = key.split(':');
            fields.push({
                MenuId: Number(menuIdStr),
                FieldId: Number(fieldIdStr),
                FieldName: null,             // not needed once FieldId is present
                Access: access,
            });
        }

        const applyAll = this.applyToAllRoles();
        const roleIdSnapshot = rid;

        this.saving.set(true);

        this.roleService
            .setRoleRfMenus(roleIdSnapshot, menuIds, fId, sId, true)
            // .setRoleRfMenus(roleIdSnapshot, menuIds, fId, sId, applyAll)
            .pipe(take(1))
            .subscribe({
                next: () => {
                    this.roleService
                        .setRoleRfFields(roleIdSnapshot, fields, fId, sId, true)
                        // .setRoleRfFields(roleIdSnapshot, fields, fId, sId, applyAll)
                        .pipe(take(1), finalize(() => this.saving.set(false)))
                        .subscribe({
                            next: () => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'RF Configuration',
                                    detail: applyAll
                                        ? 'Saved for all roles in this facility + storer.'
                                        : 'RF settings saved successfully.',
                                });

                                // this.router.navigate(['/admin/role']);
                                // this.lastLoadedKey = '';
                                // this.loadAll();
                            },
                            error: (err) =>
                                this.handleError('Failed to save RF fields.', err),
                        });
                },
                error: (err) => {
                    this.saving.set(false);
                    this.handleError('Failed to save RF menus.', err);
                },
            });
    }

    onCancel() {
        this.router.navigate(['/admin/role']);
    }

    private handleError(message: string, err: any) {
        console.error(message, err);
        this.messageService.add({
            severity: 'error',
            summary: 'RF Configuration',
            detail: message,
        });
    }

    toggleApplyToAll() {
        this.applyToAllRoles.set(!this.applyToAllRoles());
    }
}