import { DatePipe } from '@angular/common';
import { Component, inject, signal, viewChild } from '@angular/core';
import { MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { SkeletonModule } from 'primeng/skeleton';
import { Table, TableModule } from 'primeng/table';
import { finalize } from 'rxjs';
import { RoleFormComponent } from './role-form/role-form.component';
import { RoleService } from './role.service';

import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { TranslateService } from '@ngx-translate/core';
import {
    ConfirmationDialogComponent,
    CustomTableComponent,
    LoadingComponent,
} from '../../../common/components';
import { RfConfigComponent } from './rf-config/rf-config.component';
@Component({
    selector: 'app-role',
    templateUrl: './role.component.html',
    styleUrls: ['./role.component.scss'],
    imports: [
        DatePipe,
        SkeletonModule,
        TableModule,
        ButtonModule,
        InputTextModule,
        InputIconModule,
        IconFieldModule,
        LoadingComponent,
        CustomTableComponent,
    ],
    providers: [DialogService],
})
export class RoleComponent {
    Roles = signal<any>([]);
    RoleMenus = signal<any>([]);
    loading = signal<boolean>(false);
    roleFormVisible = signal<boolean>(false);
    private roleService = inject(RoleService);
    dt = viewChild.required<Table>('dt');
    columns = signal([
        { field: 'Name', label: 'Role Name', type: 'text' },
        { field: 'Description', label: 'Description', type: 'text' },
        { field: 'CreatedBy', label: 'Created By', type: 'text' },
        { field: 'CreatedAt', label: 'Created At', type: 'date' },
    ]);

    selectedColumns = signal(this.columns());

    globalcolumns = signal(this.columns().map((column) => column.field));
    ref: DynamicDialogRef | undefined;
    ConfirmationRef: DynamicDialogRef | undefined;
    private translate = inject(TranslateService);
    public dialogService = inject(DialogService);
    private messageService = inject(MessageService);
    showRoleMenuForm(roleId: number) {
        this.ref = this.dialogService.open(RoleFormComponent, {
            inputValues: {
                roleId: roleId,
                formType: 'Menus',
            },
            header: 'Role Menus',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                this.onRoleMenuChanges(data.roleId, data.menus);
            }
        });
    }
    showRoleActionForm(roleId: number) {
        this.ref = this.dialogService.open(RoleFormComponent, {
            inputValues: {
                roleId: roleId,
                formType: 'Actions',
            },
            header: 'Role Actions',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                this.onRoleActionChanges(data.roleId, data.actions);
            }
        });
    }

    showRoleForm() {
        this.ref = this.dialogService.open(RoleFormComponent, {
            header: 'New Role',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '35rem',
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('RoleCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: { message: value },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                    if (confirmed) {
                        this.onRoleFormSubmit(data);
                    }
                });
            }
        });

        // this.roleFormVisible.set(true);
    }
    exportCSV() {
        this.dt().exportCSV();
    }

    ngOnInit() {
        this.getRoles();
    }

    ngOnDestroy() {
        if (this.ref) {
            this.ref.close();
        }
        // if (this.roleMenuFormRef) this.roleMenuFormRef.close();
    }

    getRoles() {
        this.Roles.set([]);
        this.loading.set(true);
        this.roleService
            .getRoles()
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (data: any) => {
                    data.forEach(
                        (role: any) =>
                            (role.CreatedAt = new Date(<Date>role.CreatedAt)),
                    );
                    this.Roles.set(data);
                },
                error: (error) => {
                    console.error('Error fetching roles', error);
                },
            });
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal(
            (event.target as HTMLInputElement).value,
            'contains',
        );
    }

    onRoleFormSubmit(role: any) {
        this.roleService
            .addRoles(role)
            .pipe(
                finalize(() => {
                    this.getRoles();
                }),
            )
            .subscribe({
                next: (data) => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'New role addition',
                        detail: data as string,
                    });
                },
                error: (error) => {
                    console.error('Error while adding role.', error);
                    this.messageService.add({
                        severity: 'error',
                        summary: 'New role addition',
                        detail: error as string,
                    });
                },
            });
    }

    onRoleMenuChanges(roleId: number, menus: number[]) {
        this.roleService
            .setRoleMenus(roleId, menus)
            .pipe(
                finalize(() => {
                    this.getRoles();
                }),
            )
            .subscribe({
                next: (data) => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Role menus update',
                        detail: data as string,
                    });
                },
                error: (error) => {
                    console.error('Error while adding role.', error);
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Role menus update',
                        detail: error as string,
                    });
                },
            });
    }
    onRoleActionChanges(roleId: number, actions: number[]) {
        this.roleService
            .setRoleActions(roleId, actions)
            .pipe(
                finalize(() => {
                    this.getRoles();
                }),
            )
            .subscribe({
                next: (data) => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Role actions update',
                        detail: data as string,
                    });
                },
                error: (error) => {
                    console.error('Error while adding role.', error);
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Role actions update',
                        detail: error as string,
                    });
                },
            });
    }


    // showRfConfigForm(roleId: number) {
    //     this.ref = this.dialogService.open(RfConfigComponent, {
    //         inputValues: { roleId },
    //         header: 'RF Configuration',
    //         closable: true,
    //         modal: true,
    //         draggable: true,
    //         keepInViewport: true,
    //         width: '55rem',
    //         style: { maxHeight: '45rem' },
    //     });
    //     this.ref.onClose.subscribe((data) => {
    //         if (data) {
    //             // this.messageService.add({
    //             //     severity: 'success',
    //             //     summary: 'RF Configuration',
    //             //     detail: 'RF menus updated.',
    //             // });
    //         }
    //     });
    // }

}
