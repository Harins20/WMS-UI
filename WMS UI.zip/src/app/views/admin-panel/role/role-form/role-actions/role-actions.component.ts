import {
    Component,
    computed,
    inject,
    input,
    linkedSignal,
    signal,
} from '@angular/core';
import { TreeModule } from 'primeng/tree';
import { finalize } from 'rxjs';
import { RoleService } from '../../role.service';

@Component({
    selector: 'app-role-actions',
    templateUrl: './role-actions.component.html',
    imports: [TreeModule],
})
export class RoleActionsComponent {
    roleId = input<number>();
    Menus = signal<any>([]);
    RoleMenus = signal<any>([]);
    loading = signal<boolean>(false);
    private roleService = inject(RoleService);
    selectedTreeValue = linkedSignal(() => {
        const mapped: { [key: number]: any } = {};

        // Initialize the mapped object with all data items
        this.Menus().forEach((item: any) => {
            mapped[item.Id] = {
                key: item.Id,
                label: item.Name,
                data: item,
                children: [],
            };
        });

        const tree: any[] = [];
        this.RoleMenus().forEach((item: any) => {
            tree.push(mapped[item]);
        });
        return tree;
    });

    ngOnInit() {
        this.getActions();
        this.getRoleActions();
    }

    getActions() {
        this.loading.set(true);
        this.roleService
            .getActions()
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (data: any) => {
                    this.Menus.set(data);
                },
                error: (error) => {
                    console.error('Error fetching menus', error);
                },
            });
    }

    treeMenus = computed(() => {
        const mapped: { [key: number]: any } = {};

        // Initialize the mapped object with all data items
        this.Menus().forEach((item: any) => {
            mapped[item.Id] = {
                key: item.Id,
                label: item.Name,
                data: item,
                children: [],
            };
        });

        // Build tree by assigning children to parents
        const tree: any[] = [];
        this.Menus().forEach((item: any) => {
            tree.push(mapped[item.Id]);
        });
        return tree;
    });

    getRoleActions() {
        if (!this.roleId()) {
            this.RoleMenus.set([]);
            return;
        }
        this.loading.set(true);
        this.roleService
            .getRoleActions(this.roleId()!)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (data) => {
                    this.RoleMenus.set(data);
                },
                error: (error) => {
                    console.error('Error fetching role menus', error);
                },
            });
    }

    selectedMenus = computed(() => this.selectedTreeValue().map((x) => x.key));
}
