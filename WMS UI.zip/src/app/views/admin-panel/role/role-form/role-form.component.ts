import {
    Component,
    inject,
    input,
    model,
    output,
    viewChild,
} from '@angular/core';
import {
    AbstractControl,
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { TextareaModule } from 'primeng/textarea';

import { RoleMenusComponent } from './role-menus/role-menus.component';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';

import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { RoleActionsComponent } from './role-actions/role-actions.component';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';

@Component({
    selector: 'app-role-form',
    templateUrl: './role-form.component.html',
    imports: [
        DialogModule,
        InputTextModule,
        ButtonModule,
        TextareaModule,
        ReactiveFormsModule,
        RoleMenusComponent,
        ToastModule,
        RoleActionsComponent,
    ],
})
export class RoleFormComponent {
    roleMenus = viewChild.required<RoleMenusComponent>('RoleMenu');
    roleActions = viewChild.required<RoleActionsComponent>('RoleAction');
    formType = input<'Menus' | 'Actions'>();
    roleId = input<number>();
    submit = output<any>();
    messageService = inject(MessageService);
    private ref = inject(DynamicDialogRef);
    roleForm = new FormGroup({
        Name: new FormControl<string>('', [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(50),
        ]),
        Description: new FormControl<string>('', [Validators.maxLength(250)]),
    });
    hasError(formControlName: string) {
        const formControl = this.roleForm.get(formControlName)!;
        return (
            (formControl.touched || formControl.dirty) && formControl.invalid
        );
    }
    getErrors(formControlName: string, title?: string) {
        const formControl = this.roleForm.get(formControlName)!;
        return getErrorMessages(formControl.errors, title);
    }

    onCancel() {
        this.ref.close();
        // this.visible.set(false);
    }
    onSubmit() {
        if (!this.roleId()) {
            if (this.roleForm.valid) {
                if (this.checkSubFormValidity()) {
                    const data = {
                        Role: this.roleForm.value,
                        menuIds: this.roleMenus()?.selectedMenus() ?? [],
                        actionIds: this.roleActions()?.selectedMenus() ?? [],
                    };
                    this.ref.close(data);
                }
            } else {
                this.roleForm.markAllAsTouched();
                markAllControlsAsDirty(Object.values(this.roleForm.controls));
            }
        } else {
            if (this.formType() === 'Menus') {
                if (this.checkMenusValidity()) {
                    const data = {
                        roleId: this.roleId(),
                        menus: this.roleMenus()?.selectedMenus() ?? [],
                    };
                    this.ref.close(data);
                }
            } else if (this.formType() === 'Actions') {
                if (this.checkActionsValidity()) {
                    const data = {
                        roleId: this.roleId(),
                        actions: this.roleActions()?.selectedMenus() ?? [],
                    };
                    this.ref.close(data);
                }
            }
        }
    }

    checkMenusValidity() {
        const selected = this.roleMenus()?.selectedMenus() ?? [];
        if (selected.length === 0) {
            this.messageService.add({
                severity: 'error',
                summary: 'Role Menus',
                detail: 'Please select at least one menu.',
            });
            return false;
        }
        return true;
    }

    checkActionsValidity() {
        const selected = this.roleActions()?.selectedMenus() ?? [];
        if (selected.length === 0) {
            this.messageService.add({
                severity: 'error',
                summary: 'Role Actions',
                detail: 'Please select at least one action.',
            });
            return false;
        }
        return true;
    }

    checkSubFormValidity() {
        if (!this.roleId()) {
            return this.checkMenusValidity() && this.checkActionsValidity();
        }
        if (this.roleId() && this.formType() === 'Menus') {
            return this.checkMenusValidity();
        }
        return this.checkActionsValidity();
    }
}
