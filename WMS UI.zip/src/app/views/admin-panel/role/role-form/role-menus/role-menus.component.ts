import {
    Component,
    computed,
    inject,
    input,
    linkedSignal,
    signal,
} from '@angular/core';
import { TreeModule } from 'primeng/tree';
import { finalize } from 'rxjs';
import { RoleService } from '../../role.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'app-role-menus',
    templateUrl: './role-menus.component.html',
    imports: [TreeModule],
})
export class RoleMenusComponent {
    roleId = input<number>();
    Menus = signal<any>([]);
    RoleMenus = signal<any>([]);
    loading = signal<boolean>(false);
    private roleService = inject(RoleService);
    selectedTreeValue = linkedSignal(() => {
        const mapped: { [key: number]: any } = {};

        // Initialize the mapped object with all data items
        this.Menus().forEach((item: any) => {
            mapped[item.Id] = {
                key: item.Id,
                label: item.Name,
                icon: item.CssClass,
                data: item,
                children: [],
            };
        });

        const tree: any[] = [];
        this.RoleMenus().forEach((item: any) => {
            tree.push(mapped[item]);
        });
        return tree;
    });

    ngOnInit() {
        this.getMenus();
        this.getRoleMenus();
    }

    getMenus() {
        this.loading.set(true);
        this.roleService
            .getMenus()
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (data: any) => {
                    this.Menus.set(data);
                },
                error: (error) => {
                    console.error('Error fetching menus', error);
                },
            });
    }

    treeMenus = computed(() => {
        const mapped: { [key: number]: any } = {};

        // Initialize the mapped object with all data items
        this.Menus().forEach((item: any) => {
            mapped[item.Id] = {
                key: item.Id,
                label: item.Name,
                icon: item.CssClass,
                data: item,
                children: [],
            };
        });

        // Build tree by assigning children to parents
        const tree: any[] = [];
        this.Menus().forEach((item: any) => {
            if (item.ParentId === 0) {
                tree.push(mapped[item.Id]);
            } else {
                mapped[item.ParentId]?.children?.push(mapped[item.Id]);
            }
        });
        return tree;
    });

    getRoleMenus() {
        if (!this.roleId()) {
            this.RoleMenus.set([]);
            return;
        }
        this.loading.set(true);
        this.roleService
            .getRoleMenus(this.roleId()!)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (data) => {
                    this.RoleMenus.set(data);
                },
                error: (error) => {
                    console.error('Error fetching role menus', error);
                },
            });
    }

    selectedMenus = computed(() => this.selectedTreeValue().map((x) => x.key));
}
