export interface RfFieldControlOption {
    Id: number;
    Code: string;           // S / R / H / D
    Name: string;           // Show / Readonly / Hidden / Disabled
    Description?: string;
}

export interface RfFieldNode {
    Id: number;             // wms_rf_fields.id  ← NEW
    Code: string;           // 'Lottable01', 'ReceiptKey', ...   ← NEW (was FieldName)
    Label: string;          // 'Lottable 01', 'Receipt Key', ... ← NEW
    FieldControlId: number;
    AccessCode: string;     // S / R / H / D   ← NEW (was Code, renamed for clarity)
    DefaultValue?: string | null;
}

export interface RfMenuNode {
    Id: number;
    MenuCode: string;
    Name: string;
    Route?: string;
    ParentId: number;
    IsParent: boolean;
    IsClickable: boolean;
    IconClass?: string;
    SortOrder: number;
    IsActive: boolean;
    Fields: RfFieldNode[];
}

export interface RfMenuTreeResponse {
    Menus: RfMenuNode[];
    FieldControls: RfFieldControlOption[];
}

export interface RfRoleFieldItem {
    MenuId: number;
    FieldId?: number | null;   
    FieldName?: string | null;   
    Access: string;             // S / R / H / D
}