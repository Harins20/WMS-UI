import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AuthService } from '../../../common/services';
import { AppConfigService } from '../../../../app.config.service';
import { RfMenuTreeResponse, RfRoleFieldItem } from './rf-roles.models';

@Injectable({ providedIn: 'root' })
export class RoleService {
    private http = inject(HttpClient);
    private authService = inject(AuthService);
    private headers = this.authService.getAuthHeadersAp();
    private configService = inject(AppConfigService);

    private baseUrl = this.configService.AuthUrl;
    private rfUrl = this.configService.RFUrl;

    // ---------------- Roles ----------------
    getRoles() {
        return this.http.get(this.baseUrl + 'roles', {
            headers: this.headers,
        });
    }

    addRoles(role: any) {
        return this.http.post(this.baseUrl + 'roles', role, {
            headers: this.headers,
        });
    }

    // ---------------- Menus ----------------
    getMenus() {
        return this.http.get(this.baseUrl + 'menus', {
            headers: this.headers,
        });
    }

    getRoleMenus(roleId: number) {
        return this.http.get<number[]>(
            this.baseUrl + 'roles/menus?RoleId=' + roleId,
            { headers: this.headers },
        );
    }

    setRoleMenus(roleId: number, menus: number[]) {
        return this.http.post(
            this.baseUrl + 'roles/menus?RoleId=' + roleId,
            menus,
            { headers: this.headers },
        );
    }

    // ---------------- Actions ----------------
    getActions() {
        return this.http.get(this.baseUrl + 'actions', {
            headers: this.headers,
        });
    }

    getRoleActions(roleId: number) {
        return this.http.get<number[]>(
            this.baseUrl + 'roles/actions?RoleId=' + roleId,
            { headers: this.headers },
        );
    }

    setRoleActions(roleId: number, menus: number[]) {
        return this.http.post(
            this.baseUrl + 'roles/actions?RoleId=' + roleId,
            menus,
            { headers: this.headers },
        );
    }

    // ---------------- RF Configuration ----------------
    getRfMenuTree() {
        return this.http.get<RfMenuTreeResponse>(
            this.rfUrl + 'rf/menus/tree',
            { headers: this.headers },
        );
    }

    getRoleRfMenus(roleId: number, facilityId?: number | null, storerId?: number | null) {
        let params: any = { RoleId: roleId };
        if (facilityId) params.FacilityId = facilityId;
        if (storerId) params.StorerId = storerId;

        return this.http.get<number[]>(
            this.rfUrl + 'roles/rf-menus',
            { headers: this.headers, params },
        );
    }

    setRoleRfMenus(
        roleId: number,
        menuIds: number[],
        facilityId?: number | null,
        storerId?: number | null,
        applyToAllRoles?: boolean,
    ) {
        const payload = {
            roleId,
            menuIds,
            facilityId: facilityId || null,
            storerId: storerId || null,
            applyToAllRoles: !!applyToAllRoles,
        };
        return this.http.post<string>(
            this.rfUrl + 'roles/rf-menus',
            payload,
            { headers: this.headers },
        );
    }

    getRoleRfFields(roleId: number, facilityId?: number | null, storerId?: number | null) {
        let params: any = { RoleId: roleId };
        if (facilityId) params.FacilityId = facilityId;
        if (storerId) params.StorerId = storerId;

        return this.http.get<RfRoleFieldItem[]>(
            this.rfUrl + 'roles/rf-fields',
            { headers: this.headers, params },
        );
    }

    setRoleRfFields(
        roleId: number,
        fields: RfRoleFieldItem[],
        facilityId?: number | null,
        storerId?: number | null,
        applyToAllRoles?: boolean,
    ) {
        const payload = {
            roleId,
            fields,
            facilityId: facilityId || null,
            storerId: storerId || null,
            applyToAllRoles: !!applyToAllRoles,
        };
        return this.http.post<string>(
            this.rfUrl + 'roles/rf-fields',
            payload,
            { headers: this.headers },
        );
    }
}