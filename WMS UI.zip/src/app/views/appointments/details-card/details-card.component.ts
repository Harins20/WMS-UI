import {
    Component,
    computed,
    DestroyRef,
    effect,
    inject,
    input,
    Input,
    signal,
} from '@angular/core';
import {
    DynamicDialogRef,
    DynamicDialogConfig,
    DialogService,
} from 'primeng/dynamicdialog';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DividerModule } from 'primeng/divider';
import { AppointmentOrderService } from '../appointment-order.service';
import { AvatarModule } from 'primeng/avatar';
import { MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { TooltipModule } from 'primeng/tooltip';
import { TimelineModule } from 'primeng/timeline';
import { SelectModule } from 'primeng/select';
import { finalize } from 'rxjs';
import { InputTextModule } from 'primeng/inputtext';
import { AddKey } from '../AddKey';
import { RescheduleAppointment } from '../Reschedule-appointment';
import { LoadingComponent } from '../../../common/components';

@Component({
    selector: 'app-details-card',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        DividerModule,
        AvatarModule,
        ButtonModule,
        TooltipModule,
        TimelineModule,
        SelectModule,
        InputTextModule,
        LoadingComponent,
    ],
    templateUrl: './details-card.component.html',
    styleUrl: './details-card.component.scss',
})
export class DetailsCardComponent {
    private ref = inject(DynamicDialogRef);
    private dialogService = inject(DialogService);
    private messageService = inject(MessageService);
    type = input.required();
    private destroyRef = inject(DestroyRef);
    docks = signal<any>([]);
    key = signal<string>('');
    details = signal<any>([]);
    private config = inject(DynamicDialogConfig);
    private AppointmentService = inject(AppointmentOrderService);
    selectedCardId: any;
    currentIndex = 0;
    showCancelPopup = false;
    cancelComment = '';
    rescheduleComment: string = '';
    @Input() cards: any[] = [];
    asnListdisplay = signal<boolean>(false);
    selectedKey = signal<any>([]);
    selectedIndex = 0;
    statuses = signal<any>([]);
    selectedStatus: any;
    loading = signal(false);

    ngOnInit() {
        this.selectedCardId = this.config.data.selectedCard;

        this.getKeyValue(this.selectedCardId);
        if (this.type() === 'Inbound') {
            this.key.set('Receipt');
        } else {
            this.key.set('Order');
        }
        if (this.selectedCardId) {
            this.getDetails(this.selectedCardId);
            this.getStatus();
        }
    }
    statusUpdate = effect(() => {
        if (this.details() && this.statuses()) {
            this.selectedStatus = this.details().map((x: any) => x.DESCR);
            this.statuses().map((x: any, index: number) => {
                const Status = this.details()[0]?.DESCR;
                const FindIndexValue = this.statuses().findIndex(
                    (x: any) => x.Description === Status,
                );
                if (Status !== 'Cancelled') {
                    if (FindIndexValue >= 0) {
                        for (let i = 0; i <= FindIndexValue; i++) {
                            this.statuses()[i].color = 'var(--primary-color)';
                        }
                    }
                } else {
                    if (FindIndexValue >= 0) {
                        for (let i = 0; i <= FindIndexValue; i++) {
                            this.statuses()[i].color = 'var(--p-red-500)';
                        }
                    }
                }
            });
        }
    });

    Rescheduled = computed(() => {
        return this.details()[0]?.DESCR === 'Rescheduled';
    });
    Scheduled = computed(() => {
        return this.details()[0]?.DESCR === 'Scheduled';
    });
    ASNButton = computed(() => {
        return (
            this.selectedKey().length === 0 &&
            (this.details()[0]?.DESCR === 'Rescheduled' ||
                this.details()[0]?.DESCR === 'Scheduled')
        );
    });
    Cancelled = computed(() => {
        return this.details()[0]?.DESCR === 'Cancelled';
    });
    getStatus() {
        const subscription = this.AppointmentService.getStatus()
            .pipe()
            .subscribe({
                next: (res: any) => {
                    this.statuses.set(
                        res.map((x: any) => {
                            return {
                                ...x,
                                color: '',
                            };
                        }),
                    );
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    getDetails(id: any) {
        this.loading.set(true);
        const subscription = this.AppointmentService.getAppointmentDetail(id)
            .pipe()
            .subscribe({
                next: (data) => {
                    this.details.set(data);
                    this.loading.set(false);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getKeyValue(id: any) {
        const subscription = this.AppointmentService.getAppointmentLines(id)
            .pipe()
            .subscribe({
                next: (res: any) => {
                    this.selectedKey.set(res.Data.map((x: any) => x.Key));
                    if (this.selectedKey().length !== 0) {
                    }
                    this.asnListdisplay.set(true);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    updateStatus(value: any): void {
        if (value === 'Cancelled' || value?.Description === 'Cancelled') {
            this.messageService.add({
                severity: 'error',
                summary: 'Failed to update status',
                detail: 'Cancel the Appointment to change the status.',
            });
            return;
        }

        // Intercept "Rescheduled" selection → open popup instead
        if (
            value?.Description === 'Rescheduled' ||
            value?.Code === 'Rescheduled'
        ) {
            this.openReschedulePopup();
            return; // Do NOT call the status update API
        }

        const data = {
            AppointmentId: this.selectedCardId,
            Status: value.Code,
        };

        const subscription = this.AppointmentService.updateStatus(data)
            .pipe(
                finalize(() => {
                    this.getDetails(this.selectedCardId);
                    this.getKeyValue(this.selectedCardId);
                    this.getStatus();
                }),
            )
            .subscribe({
                next: (res: any) => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Appointment status updated successfully',
                        detail: res.Message as string,
                    });
                },
                error: (error: any) => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Failed to update status',
                        detail: error.error.Message as string,
                    });
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    nextStatus() {
        if (this.currentIndex < this.statuses.length - 1) {
            this.currentIndex++;
        }
    }

    prevStatus() {
        if (this.currentIndex > 0) {
            this.currentIndex--;
        }
    }
    openCancelPopup() {
        this.showCancelPopup = true;
    }
    closeCancelPopup() {
        this.showCancelPopup = false;
        this.cancelComment = '';
    }
    confirmCancel() {
        const data = { Appointmentid: this.selectedCardId };

        const subscription = this.AppointmentService.cancelAppointment(data)
            .pipe(
                finalize(() => {
                    this.getDetails(this.selectedCardId);
                    this.getKeyValue(this.selectedCardId);
                    this.getStatus();
                }),
            )
            .subscribe({
                next: (res: any) => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Appointment Cancelled successfully',
                        detail: res.Data as string,
                    });
                },
                error: (error: any) => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Cancelled Failed',
                        detail: error.error.Message as string,
                    });
                },
            });
        this.closeCancelPopup();
    }

    openReschedulePopup() {
        this.ref = this.dialogService.open(RescheduleAppointment, {
            inputValues: {
                type: this.type(),
            },
            width: '70rem',
            style: { height: '42rem' },
            closable: true,
            modal: true,
            draggable: true,
        });
        this.ref.onClose.subscribe((data) => {
            const response = {
                AppointmentId: this.selectedCardId,
                NewSlotId: data.NewSlotId,
                ToSlotDate: data.ToSlotDate,
                RequestedDock: data.RequestedDock,
            };

            const subscription = this.AppointmentService.rescheduleAppointment(
                response,
            )
                .pipe(
                    finalize(() => {
                        this.getDetails(this.selectedCardId);
                        this.getKeyValue(this.selectedCardId);
                        this.getStatus();
                    }),
                )
                .subscribe({
                    next: (res: any) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Rescheduled Successfully',
                            detail: res.Message as string,
                        });
                    },
                    error: (error: any) => {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Rescheduled Failed',
                            detail: error.error.Message as string,
                        });
                    },
                });
        });
    }

    openAsnPopup() {
        this.ref = this.dialogService.open(AddKey, {
            inputValues: {
                type: this.type(),
            },
            header: 'Add ' + this.key(),
            width: '25rem',
            style: { height: '30rem' },
            closable: true,
            modal: true,
            draggable: true,
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const response = 
                    {
                        AppointmentId: this.selectedCardId,
                        Keys: data,
                    }
                                const name = this.key();
                const subscription = this.AppointmentService.updateKey(response)
                    .pipe(
                        finalize(() => {
                            this.getDetails(this.selectedCardId);
                            this.getKeyValue(this.selectedCardId);
                            this.getStatus();
                        }),
                    )
                    .subscribe({
                        next: (res: any) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: `${name} added successfully`,
                                detail: res.Message as string,
                            });
                        },
                        error: (error: any) => {
                            this.messageService.add({
                                severity: 'error',
                                summary: `${name} Failed add.`,
                                detail: error.Message as string,
                            });
                        },
                    });
            }
        });
    }
}
