import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    effect,
    ViewChild,
    ElementRef,
    AfterViewInit,
    HostListener,
} from '@angular/core';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { CommonModule } from '@angular/common';
import { DividerModule } from 'primeng/divider';
import { FormsModule } from '@angular/forms';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { DetailsCardComponent } from './details-card/details-card.component';
import { AppointmentSlotComponent } from './appointment-slot/appointment-slot.component';
import { AppointmentOrderService } from './appointment-order.service';
import { MegaMenuItem, MessageService } from 'primeng/api';
import { CommonErrorboxComponent } from '../../common/components/common-errorbox/common-errorbox.component';
import { finalize } from 'rxjs';
import { AvatarModule } from 'primeng/avatar';
import { DataViewModule } from 'primeng/dataview';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { TooltipModule } from 'primeng/tooltip';
import { MenubarModule } from 'primeng/menubar';
import { InputTextModule } from 'primeng/inputtext';
import { LoadingComponent } from '../../common/components';
import { TableLazyLoadEvent } from 'primeng/table';
import { filterQuery } from '../../common/functions';
import { AppointmentColumns } from './appointment.columns';

@Component({
    selector: 'app-outbound-pickups',
    imports: [
        CardModule,
        ButtonModule,
        CommonModule,
        DividerModule,
        FormsModule,
        AvatarModule,
        DataViewModule,
        IconFieldModule,
        InputIconModule,
        TooltipModule,
        MenubarModule,
        InputTextModule,
        LoadingComponent,
        DialogModule,
        SelectModule,
    ],
    templateUrl: './appointment.component.html',
    styleUrl: './appointment.component.scss',
    providers: [DynamicDialogRef],
})
export class OutboundPickupsComponent implements AfterViewInit {
    @ViewChild('calendarCanvas') calendarCanvas!: ElementRef;

    dates: Date[] = [];
    Name = input.required<string>();
    type = signal<number>(2);
    loading = signal(false);
    private AppointmentService = inject(AppointmentOrderService);
    private destroyRef = inject(DestroyRef);
    private dialogService = inject(DialogService);
    private messageService = inject(MessageService);
    private ConfirmationRef = inject(DynamicDialogRef);
    private ref = inject(DynamicDialogRef);

    appointmentData = signal<any>([]);
    appointmentTempData = signal<any>([]);
    tabs: MegaMenuItem[] = [];

    columns = signal(
        Object.values(AppointmentColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    totalRecords = signal(0);
    rows = signal(10);
    loadEvent = signal<any>({});

    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x: any) => x.tableAlias && !x.tableHidden)
            .map((x: any) => x.field),
    );
    SearchValue: any = '';

    // Calendar UI signals
    currentDate = signal<Date>(new Date());
    viewMode = signal<'Today' | 'Week' | 'Month' | 'Agenda'>('Today');
    miniMonth = signal<Date>(new Date());
    selectedStatuses = signal<string[]>([]);
    statuses = signal<any[]>([]);
    currentTime = signal<Date>(new Date());
    isFullscreen = signal<boolean>(false);
    private timerId: any;

    // Drag-and-drop scheduling signals & state
    draggedTicket = signal<any>(null);
    isDragging = signal<boolean>(false);
    activeDropHour = signal<{ dayStr: string; hour: number } | null>(null);
    activeDropMonthDay = signal<string | null>(null);
    activeDropMiniDay = signal<string | null>(null);
    justFinishedDrag = false;

    // Reschedule Confirmation Dialog signals
    showRescheduleDialog = signal<boolean>(false);
    rescheduleLoading = signal<boolean>(false);
    rescheduleSaving = signal<boolean>(false);
    rescheduleTicket = signal<any>(null);
    rescheduleTargetDate = signal<Date>(new Date());
    rescheduleTargetTime = signal<string>('09:00');
    rescheduleAvailableSlots = signal<any[]>([]);
    rescheduleAvailableDocks = signal<any[]>([]);
    rescheduleSelectedSlotId = signal<number | null>(null);
    rescheduleSelectedDock = signal<string | null>(null);

    toggleFullscreen() {
        this.isFullscreen.update((v) => !v);
    }

    @HostListener('window:keydown.escape')
    handleEscapeKey() {
        if (this.isFullscreen()) {
            this.isFullscreen.set(false);
        }
    }

    private hourLayoutCache: { [key: number]: { top: number; height: number } } = {};
    private lastWeekKey = '';
    private lastAppointmentsHash = '';

    hours = Array.from({ length: 24 }, (_, i) => i);

    ngOnInit() {
        this.generateDates();
        this.getStatus();
        this.syncMiniMonthWithCurrentDate();
        this.fetchAppointmentsForCurrentView();

        this.timerId = setInterval(() => {
            this.currentTime.set(new Date());
        }, 60000);

        this.destroyRef.onDestroy(() => {
            if (this.timerId) clearInterval(this.timerId);
        });
    }

    loadData(event: TableLazyLoadEvent) {
        this.loadEvent.set(event);
        this.fetchAppointmentsForCurrentView();
    }

    getStatus() {
        const subscription = this.AppointmentService.getStatus()
            .pipe()
            .subscribe({
                next: (res: any) => {
                    this.statuses.set(res);
                    // Initially check all statuses
                    this.selectedStatuses.set(res.map((x: any) => x.Description));

                    this.tabs = [
                        {
                            label: 'All',
                            command: () => {
                                this.onMenuClick('All');
                            },
                        },
                        ...res.map((x: any) => ({
                            ...x,
                            label: x.Description,
                            command: () => {
                                this.onMenuClick(x.Description);
                            },
                        })),
                    ];
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    generateDates() {
        const today = new Date();
        this.dates = [];
        for (let i = -7; i <= 50; i++) {
            const date = new Date(today);
            date.setDate(today.getDate() + i);
            this.dates.push(date);
        }
    }

    get apiType(): string {
        const name = this.Name() || '';
        if (name.toLowerCase().includes('inbound')) {
            return 'Inbound';
        }
        if (name.toLowerCase().includes('outbound')) {
            return 'Outbound';
        }
        return name;
    }

    GetAppointmentOrder(data: any = { Page: 1, PageSize: 1000 }) {
        this.loading.set(true);
        const subscription = this.AppointmentService.getAppointmentPage(
            data,
            this.apiType,
        )
            .pipe()
            .subscribe({
                next: (res) => {
                    this.appointmentData.set(res.Appointments);
                    this.appointmentTempData.set(res.Appointments);
                    this.totalRecords.set(res.TotalCount);
                    this.loading.set(false);
                },
                error: () => {
                    this.loading.set(false);
                }
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    // Calendar Range and Rendering Helpers
    getStartOfWeek(d: Date): Date {
        const date = new Date(d);
        const day = date.getDay();
        const diff = date.getDate() - day; // Sunday start
        const start = new Date(date.setDate(diff));
        start.setHours(0, 0, 0, 0);
        return start;
    }

    getEndOfWeek(d: Date): Date {
        const start = this.getStartOfWeek(d);
        const end = new Date(start);
        end.setDate(start.getDate() + 6);
        end.setHours(23, 59, 59, 999);
        return end;
    }

    getStartOfMonth(d: Date): Date {
        const start = new Date(d.getFullYear(), d.getMonth(), 1);
        start.setHours(0, 0, 0, 0);
        return start;
    }

    getEndOfMonth(d: Date): Date {
        const end = new Date(d.getFullYear(), d.getMonth() + 1, 0);
        end.setHours(23, 59, 59, 999);
        return end;
    }

    getDaysOfWeek(d: Date): Date[] {
        const start = this.getStartOfWeek(d);
        const days = [];
        for (let i = 0; i < 7; i++) {
            const dayOfW = new Date(start);
            dayOfW.setDate(start.getDate() + i);
            days.push(dayOfW);
        }
        return days;
    }

    viewDays = computed(() => {
        if (this.viewMode() === 'Today') {
            return [this.currentDate()];
        }
        return this.getDaysOfWeek(this.currentDate());
    });

    getDaysForView(): Date[] {
        return this.viewDays();
    }

    getDaysOfMiniMonthGrid(): Date[] {
        const d = this.miniMonth();
        const year = d.getFullYear();
        const month = d.getMonth();
        const firstDay = new Date(year, month, 1);
        let startDayOfWeek = firstDay.getDay(); // 0 is Sunday, 1 is Monday...
        // Adjust for Monday start: Sunday becomes 6, others shift left by 1
        startDayOfWeek = startDayOfWeek === 0 ? 6 : startDayOfWeek - 1;

        const gridStart = new Date(firstDay);
        gridStart.setDate(firstDay.getDate() - startDayOfWeek);

        const days = [];
        for (let i = 0; i < 42; i++) {
            const day = new Date(gridStart);
            day.setDate(gridStart.getDate() + i);
            days.push(day);
        }
        return days;
    }

    getDaysOfMonthGrid(d: Date): Date[] {
        const year = d.getFullYear();
        const month = d.getMonth();
        const firstDay = new Date(year, month, 1);
        let startDayOfWeek = firstDay.getDay();
        startDayOfWeek = startDayOfWeek === 0 ? 6 : startDayOfWeek - 1;

        const gridStart = new Date(firstDay);
        gridStart.setDate(firstDay.getDate() - startDayOfWeek);

        const days = [];
        for (let i = 0; i < 42; i++) {
            const day = new Date(gridStart);
            day.setDate(gridStart.getDate() + i);
            days.push(day);
        }
        return days;
    }

    prevMiniMonth() {
        const current = this.miniMonth();
        this.miniMonth.set(new Date(current.getFullYear(), current.getMonth() - 1, 1));
    }

    nextMiniMonth() {
        const current = this.miniMonth();
        this.miniMonth.set(new Date(current.getFullYear(), current.getMonth() + 1, 1));
    }

    next() {
        const current = this.currentDate();
        if (this.viewMode() === 'Today') {
            const nextD = new Date(current);
            nextD.setDate(current.getDate() + 1);
            this.currentDate.set(nextD);
        } else if (this.viewMode() === 'Week') {
            const nextW = new Date(current);
            nextW.setDate(current.getDate() + 7);
            this.currentDate.set(nextW);
        } else {
            const nextM = new Date(current.getFullYear(), current.getMonth() + 1, 1);
            this.currentDate.set(nextM);
        }
        this.syncMiniMonthWithCurrentDate();
        this.fetchAppointmentsForCurrentView();
    }

    prev() {
        const current = this.currentDate();
        if (this.viewMode() === 'Today') {
            const prevD = new Date(current);
            prevD.setDate(current.getDate() - 1);
            this.currentDate.set(prevD);
        } else if (this.viewMode() === 'Week') {
            const prevW = new Date(current);
            prevW.setDate(current.getDate() - 7);
            this.currentDate.set(prevW);
        } else {
            const prevM = new Date(current.getFullYear(), current.getMonth() - 1, 1);
            this.currentDate.set(prevM);
        }
        this.syncMiniMonthWithCurrentDate();
        this.fetchAppointmentsForCurrentView();
    }

    today() {
        this.currentDate.set(new Date());
        this.syncMiniMonthWithCurrentDate();
        this.fetchAppointmentsForCurrentView();
        this.scrollToCurrentTime();
    }

    selectDate(d: Date) {
        this.currentDate.set(d);
        this.fetchAppointmentsForCurrentView();
        this.scrollToCurrentTime();
    }

    setViewMode(mode: 'Today' | 'Week' | 'Month' | 'Agenda') {
        if (mode === 'Today') {
            this.currentDate.set(new Date());
        }
        this.viewMode.set(mode);
        this.syncMiniMonthWithCurrentDate();
        this.fetchAppointmentsForCurrentView();
        if (mode === 'Today' || mode === 'Week') {
            this.scrollToCurrentTime();
        }
    }

    ngAfterViewInit() {
        this.scrollToCurrentTime();
    }

    scrollToCurrentTime() {
        setTimeout(() => {
            if (this.calendarCanvas) {
                const now = new Date();
                const startMinute = now.getHours() * 60 + now.getMinutes();
                // grid height is 960px
                const top = (startMinute / 1440) * 960;
                const container = this.calendarCanvas.nativeElement;
                container.scrollTop = Math.max(0, top - 150);
            }
        }, 100);
    }

    syncMiniMonthWithCurrentDate() {
        this.miniMonth.set(new Date(this.currentDate().getFullYear(), this.currentDate().getMonth(), 1));
    }

    formatDateToYYYYMMDD(d: Date): string {
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    fetchAppointmentsForCurrentView() {
        const date = this.currentDate();
        let startDate: Date;
        let endDate: Date;
        if (this.viewMode() === 'Today') {
            startDate = new Date(date);
            startDate.setHours(0, 0, 0, 0);
            endDate = new Date(date);
            endDate.setHours(23, 59, 59, 999);
        } else if (this.viewMode() === 'Week') {
            startDate = this.getStartOfWeek(date);
            endDate = this.getEndOfWeek(date);
        } else {
            startDate = this.getStartOfMonth(date);
            endDate = this.getEndOfMonth(date);
        }

        const startStr = this.formatDateToYYYYMMDD(startDate) + 'T00:00:00';
        const endStr = this.formatDateToYYYYMMDD(endDate) + 'T23:59:59';

        let condition = `vw.AppointmentDate >= '${startStr}' and vw.AppointmentDate <= '${endStr}'`;

        if (this.SearchValue) {
            condition += ` and (vw.DriverName like '%${this.SearchValue}%' or vw.VehicleNumber like '%${this.SearchValue}%' or vw.AppointmentID like '%${this.SearchValue}%' or vw.Door like '%${this.SearchValue}%')`;
        }

        this.GetAppointmentOrder({
            Page: 1,
            PageSize: 1000,
            Condition: condition,
            OrderBy: 'vw.AppointmentDate asc',
        });
    }

    toggleStatusFilter(statusDesc: string) {
        const current = this.selectedStatuses();
        if (current.includes(statusDesc)) {
            this.selectedStatuses.set(current.filter(s => s !== statusDesc));
        } else {
            this.selectedStatuses.set([...current, statusDesc]);
        }
    }

    isStatusSelected(statusDesc: string): boolean {
        return this.selectedStatuses().includes(statusDesc);
    }

    getStatusCount(statusDesc: string): number {
        const appointments = this.appointmentData() || [];
        if (this.viewMode() === 'Today') {
            return appointments.filter((x: any) => x.DESCR === statusDesc && this.isSameDay(x.AppointmentDate, this.currentDate())).length;
        }
        return appointments.filter((x: any) => x.DESCR === statusDesc).length;
    }

    filteredAppointments = computed(() => {
        const appointments = this.appointmentData() || [];
        const checkedStatuses = this.selectedStatuses();
        if (checkedStatuses.length === 0 && this.statuses().length === 0) {
            return appointments;
        }
        return appointments.filter((app: any) => checkedStatuses.includes(app.DESCR));
    });

    formatTime12h(dateInput: Date | string | null | undefined): string {
        if (!dateInput) return '';
        const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
        if (isNaN(date.getTime())) return '';
        let hours = date.getHours();
        const minutes = date.getMinutes();
        const ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        const hoursStr = String(hours).padStart(2, '0');
        const minutesStr = String(minutes).padStart(2, '0');
        return `${hoursStr}:${minutesStr} ${ampm}`;
    }

    getAgendaDotColor(status: string): string {
        switch (status) {
            case 'Completed':
                return 'bg-emerald-500';
            case 'Scheduled':
                return 'bg-sky-500';
            case 'InProgress':
                return 'bg-amber-500';
            case 'Cancelled':
                return 'bg-rose-500';
            case 'Rescheduled':
                return 'bg-purple-500';
            case 'Arrived':
                return 'bg-teal-500';
            default:
                return 'bg-sky-500';
        }
    }

    getAgendaEventTimes(ticket: any): { startTime: string; endTime: string; isAllDay: boolean } {
        if (!ticket.AppointmentDate) {
            return { startTime: 'All Day', endTime: '', isAllDay: true };
        }
        const start = new Date(ticket.AppointmentDate);
        if (isNaN(start.getTime())) {
            return { startTime: 'All Day', endTime: '', isAllDay: true };
        }

        const isMidnight = start.getHours() === 0 && start.getMinutes() === 0;

        let end: Date | null = null;
        if (ticket.ArrivalDate) {
            const arrDate = new Date(ticket.ArrivalDate);
            if (!isNaN(arrDate.getTime()) && arrDate.getTime() > start.getTime()) {
                end = arrDate;
            }
        }

        if (isMidnight && !end) {
            return { startTime: 'All Day', endTime: '', isAllDay: true };
        }

        if (!end) {
            end = new Date(start.getTime() + 60 * 60 * 1000);
        }

        return {
            startTime: this.formatTime12h(start),
            endTime: this.formatTime12h(end),
            isAllDay: false,
        };
    }

    agendaGroupedAppointments = computed(() => {
        const appointments = [...this.filteredAppointments()];
        if (!appointments || appointments.length === 0) {
            return [];
        }

        appointments.sort((a: any, b: any) => {
            const timeA = a.AppointmentDate ? new Date(a.AppointmentDate).getTime() : 0;
            const timeB = b.AppointmentDate ? new Date(b.AppointmentDate).getTime() : 0;
            return timeA - timeB;
        });

        const groupsMap = new Map<string, { date: Date; events: any[] }>();

        for (const app of appointments) {
            if (!app.AppointmentDate) continue;
            const d = new Date(app.AppointmentDate);
            if (isNaN(d.getTime())) continue;

            const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
            if (!groupsMap.has(key)) {
                groupsMap.set(key, {
                    date: new Date(d.getFullYear(), d.getMonth(), d.getDate()),
                    events: [],
                });
            }

            const times = this.getAgendaEventTimes(app);
            const dotColor = this.getAgendaDotColor(app.DESCR);

            const appointmentId = app.Appointmentid || app.AppointmentID;
            const driverName = app.Drivername || app.DriverName || '';
            const carrierName = app.CarrierName || app.Carriername || '';
            const vehicleNumber = app.Vehiclenumber || app.VehicleNumber || '';
            const door = app.Door || '';
            const driverContact = app.Drivercontactnumber || app.DriverContactNumber || '';
            const initial = ((carrierName || driverName || 'A').trim().charAt(0)).toUpperCase();

            let title = carrierName || driverName || `Appointment #${appointmentId}`;
            let subtitle = '';
            if (carrierName && driverName) {
                subtitle = driverName;
            } else if (vehicleNumber) {
                subtitle = `Vehicle: ${vehicleNumber}`;
            }

            groupsMap.get(key)!.events.push({
                raw: app,
                startTime: times.startTime,
                endTime: times.endTime,
                isAllDay: times.isAllDay,
                id: appointmentId,
                driverName: driverName,
                driverContact: driverContact,
                carrierName: carrierName,
                vehicleNumber: vehicleNumber,
                door: door,
                title: title,
                subtitle: subtitle,
                status: app.DESCR,
                dotColorClass: dotColor,
                avatarInitial: initial,
            });
        }

        return Array.from(groupsMap.values());
    });

    agendaMetrics = computed(() => {
        const apps = this.filteredAppointments() || [];
        const todayApps = apps.filter((a: any) => this.isSameDay(a.AppointmentDate, this.currentDate()));
        return {
            total: apps.length,
            todayCount: todayApps.length,
            scheduled: apps.filter((a: any) => a.DESCR === 'Scheduled').length,
            inProgress: apps.filter((a: any) => a.DESCR === 'InProgress').length,
            arrived: apps.filter((a: any) => a.DESCR === 'Arrived').length,
            completed: apps.filter((a: any) => a.DESCR === 'Completed').length,
        };
    });

    isSameDay(d1: Date | string, d2: Date): boolean {
        if (!d1) return false;
        const date1 = typeof d1 === 'string' ? new Date(d1) : d1;
        return date1.getFullYear() === d2.getFullYear() &&
               date1.getMonth() === d2.getMonth() &&
               date1.getDate() === d2.getDate();
    }

    getEventsForDay(day: Date): any[] {
        return this.filteredAppointments().filter((app: any) => this.isSameDay(app.AppointmentDate, day));
    }

    getEventPosition(appointmentDateStr: string) {
        if (!appointmentDateStr) return { top: '0px', height: '40px' };
        const date = new Date(appointmentDateStr);
        const hours = date.getHours();
        const minutes = date.getMinutes();
        const startMinute = hours * 60 + minutes;
        
        // Assume 1 hour default duration for appointments
        const duration = 60; 
        
        // Grid height is 960px (24 hours * 40px/hour)
        const top = (startMinute / 1440) * 960;
        const height = (duration / 1440) * 960;
        
        return {
            top: `${top}px`,
            height: `${height}px`
        };
    }

    getHourLayout(hour: number) {
        const viewDays = this.getDaysForView();
        const weekKey = viewDays.map(d => d.toDateString()).join(',');
        const appointments = this.filteredAppointments();
        
        // Simple hash key representing relevant changes
        const hash = `${appointments.length}-${appointments.map((a: any) => `${a.Appointmentid || a.AppointmentID}-${a.AppointmentDate}`).join(',')}`;
        
        if (this.lastWeekKey === weekKey && this.lastAppointmentsHash === hash && this.hourLayoutCache[hour]) {
            return this.hourLayoutCache[hour];
        }
        
        // Compute heights for each of the 24 hour slots
        const heights = Array(24).fill(40);
        for (let h = 0; h < 24; h++) {
            let maxCount = 0;
            for (const day of viewDays) {
                const dayEvents = this.getEventsForDay(day);
                const count = dayEvents.filter(app => {
                    if (!app.AppointmentDate) return false;
                    return new Date(app.AppointmentDate).getHours() === h;
                }).length;
                if (count > maxCount) {
                    maxCount = count;
                }
            }
            // Height is at least 40px, or matches the height required by stacked appointments (each taking 22px)
            heights[h] = Math.max(40, maxCount * 22);
        }
        
        // Compute cumulative top position for each hour slot
        const tops = Array(24).fill(0);
        let currentTop = 0;
        for (let h = 0; h < 24; h++) {
            tops[h] = currentTop;
            currentTop += heights[h];
        }
        
        // Store computed values in cache
        this.hourLayoutCache = {};
        for (let h = 0; h < 24; h++) {
            this.hourLayoutCache[h] = {
                top: tops[h],
                height: heights[h]
            };
        }
        
        this.lastWeekKey = weekKey;
        this.lastAppointmentsHash = hash;
        
        return this.hourLayoutCache[hour] || { top: hour * 40, height: 40 };
    }

    getEventStyle(ticket: any, dayEvents: any[]) {
        if (!ticket.AppointmentDate) return { top: '0px', left: '2px', width: 'calc(100% - 4px)' };
        
        const date = new Date(ticket.AppointmentDate);
        const hour = date.getHours();
        
        const layout = this.getHourLayout(hour);
        const baseTop = layout.top;
        
        // Find all events on the same day scheduled in the same hour
        const hourEvents = dayEvents.filter(app => {
            if (!app.AppointmentDate) return false;
            return new Date(app.AppointmentDate).getHours() === hour;
        });
        
        // Sort consistently
        hourEvents.sort((a, b) => {
            const timeA = new Date(a.AppointmentDate).getTime();
            const timeB = new Date(b.AppointmentDate).getTime();
            if (timeA !== timeB) return timeA - timeB;
            const idA = a.Appointmentid || a.AppointmentID || 0;
            const idB = b.Appointmentid || b.AppointmentID || 0;
            return idA.toString().localeCompare(idB.toString());
        });
        
        const ticketId = ticket.Appointmentid || ticket.AppointmentID;
        const index = hourEvents.findIndex(app => (app.Appointmentid || app.AppointmentID) === ticketId);
        
        // Stack vertically inside the hour slot: each card has 22px vertical space
        const topOffset = index !== -1 ? index * 22 : 0;
        const finalTop = baseTop + 2 + topOffset;
        
        return {
            top: `${finalTop}px`,
            left: '2px',
            width: 'calc(100% - 4px)'
        };
    }

    getWeekGridHeight(): string {
        const lastHourLayout = this.getHourLayout(23);
        const totalHeight = lastHourLayout.top + lastHourLayout.height;
        return `${totalHeight}px`;
    }

    formatHour(h: number): string {
        return `${h.toString().padStart(2, '0')}:00`;
    }

    getCurrentTimeLinePosition(): string {
        const now = this.currentTime();
        const hour = now.getHours();
        const minutes = now.getMinutes();
        
        const layout = this.getHourLayout(hour);
        const baseTop = layout.top;
        const height = layout.height;
        
        const top = baseTop + (minutes / 60) * height;
        return `${top}px`;
    }

    isTodayInCurrentView(): boolean {
        const days = this.getDaysForView();
        const today = new Date();
        return days.some(day => this.isSameDay(day, today));
    }

    getCurrentTimeLabel(): string {
        const now = this.currentTime();
        return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    }

    onSearch(event: Event) {
        const value = (event.target as HTMLInputElement).value || '';
        this.SearchValue = value;
        this.fetchAppointmentsForCurrentView();
    }

    onMenuClick(e: any) {
        // Kept for backward compatibility
        if (e === 'All') {
            this.selectedStatuses.set(this.statuses().map(x => x.Description));
        } else {
            this.selectedStatuses.set([e]);
        }
    }

    canReschedule(ticket: any): boolean {
        if (!ticket) return false;
        return ticket.DESCR === 'Scheduled' || ticket.DESCR === 'Rescheduled';
    }

    isTicketDragging(ticket: any): boolean {
        const current = this.draggedTicket();
        if (!current || !ticket) return false;
        const currentId = current.Appointmentid || current.AppointmentID;
        const ticketId = ticket.Appointmentid || ticket.AppointmentID;
        return currentId === ticketId;
    }

    onDragStart(event: DragEvent, ticket: any) {
        if (!this.canReschedule(ticket)) {
            event.preventDefault();
            return;
        }
        this.draggedTicket.set(ticket);
        this.isDragging.set(true);
        if (event.dataTransfer) {
            event.dataTransfer.setData('text/plain', (ticket.Appointmentid || ticket.AppointmentID).toString());
            event.dataTransfer.effectAllowed = 'move';
        }
    }

    onDragEnd() {
        this.isDragging.set(false);
        this.draggedTicket.set(null);
        this.activeDropHour.set(null);
        this.activeDropMonthDay.set(null);
        this.activeDropMiniDay.set(null);
        this.justFinishedDrag = true;
        setTimeout(() => {
            this.justFinishedDrag = false;
        }, 300);
    }

    onHourDragOver(event: DragEvent, day: Date, hour: number) {
        event.preventDefault();
        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = 'move';
        }
        const dayStr = this.formatDateToYYYYMMDD(day);
        const currentActive = this.activeDropHour();
        if (!currentActive || currentActive.dayStr !== dayStr || currentActive.hour !== hour) {
            this.activeDropHour.set({ dayStr, hour });
        }
    }

    onHourDrop(event: DragEvent, day: Date, hour: number) {
        event.preventDefault();
        const ticket = this.draggedTicket();
        this.onDragEnd();
        if (!ticket) return;
        this.initiateReschedule(ticket, day, hour, 0);
    }

    isHourDropActive(day: Date, hour: number): boolean {
        const active = this.activeDropHour();
        if (!active) return false;
        return active.dayStr === this.formatDateToYYYYMMDD(day) && active.hour === hour;
    }

    onMonthDayDragOver(event: DragEvent, day: Date) {
        event.preventDefault();
        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = 'move';
        }
        const dayStr = this.formatDateToYYYYMMDD(day);
        if (this.activeDropMonthDay() !== dayStr) {
            this.activeDropMonthDay.set(dayStr);
        }
    }

    onMonthDayDrop(event: DragEvent, day: Date) {
        event.preventDefault();
        const ticket = this.draggedTicket();
        this.onDragEnd();
        if (!ticket) return;

        let hour = 9;
        let minute = 0;
        if (ticket.AppointmentDate) {
            const d = typeof ticket.AppointmentDate === 'string' ? new Date(ticket.AppointmentDate) : ticket.AppointmentDate;
            if (!isNaN(d.getTime())) {
                hour = d.getHours();
                minute = d.getMinutes();
            }
        }
        this.initiateReschedule(ticket, day, hour, minute);
    }

    isMonthDropActive(day: Date): boolean {
        const active = this.activeDropMonthDay();
        if (!active) return false;
        return active === this.formatDateToYYYYMMDD(day);
    }

    onMiniDayDragOver(event: DragEvent, day: Date) {
        event.preventDefault();
        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = 'move';
        }
        const dayStr = this.formatDateToYYYYMMDD(day);
        if (this.activeDropMiniDay() !== dayStr) {
            this.activeDropMiniDay.set(dayStr);
        }
    }

    onMiniDayDrop(event: DragEvent, day: Date) {
        event.preventDefault();
        const ticket = this.draggedTicket();
        this.onDragEnd();
        if (!ticket) return;

        let hour = 9;
        let minute = 0;
        if (ticket.AppointmentDate) {
            const d = typeof ticket.AppointmentDate === 'string' ? new Date(ticket.AppointmentDate) : ticket.AppointmentDate;
            if (!isNaN(d.getTime())) {
                hour = d.getHours();
                minute = d.getMinutes();
            }
        }
        this.initiateReschedule(ticket, day, hour, minute);
    }

    isMiniDropActive(day: Date): boolean {
        const active = this.activeDropMiniDay();
        if (!active) return false;
        return active === this.formatDateToYYYYMMDD(day);
    }

    initiateReschedule(ticket: any, targetDay: Date, targetHour = 9, targetMinute = 0) {
        if (!this.canReschedule(ticket)) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Cannot Reschedule',
                detail: `Only Scheduled and Rescheduled appointments can be moved. (Current status: ${ticket.DESCR})`,
            });
            return;
        }

        const now = new Date();
        const targetDateTime = new Date(targetDay);
        targetDateTime.setHours(targetHour, targetMinute, 0, 0);

        if (targetDateTime.getTime() < now.getTime()) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Cannot Reschedule to Past',
                detail: 'The selected date and time has already passed. Please choose a future date and time.',
            });
            return;
        }

        if (ticket.AppointmentDate) {
            const currentD = typeof ticket.AppointmentDate === 'string' ? new Date(ticket.AppointmentDate) : ticket.AppointmentDate;
            if (this.isSameDay(currentD, targetDay) && currentD.getHours() === targetHour && currentD.getMinutes() === targetMinute) {
                this.messageService.add({
                    severity: 'info',
                    summary: 'No Change',
                    detail: 'Appointment is already scheduled for this date and time slot.',
                });
                return;
            }
        }

        const timeStr = `${targetHour.toString().padStart(2, '0')}:${targetMinute.toString().padStart(2, '0')}`;
        this.rescheduleTicket.set(ticket);
        this.rescheduleTargetDate.set(new Date(targetDay));
        this.rescheduleTargetTime.set(timeStr);
        this.showRescheduleDialog.set(true);
        this.rescheduleLoading.set(true);
        this.rescheduleAvailableSlots.set([]);
        this.rescheduleAvailableDocks.set([]);
        this.rescheduleSelectedSlotId.set(null);
        this.rescheduleSelectedDock.set(null);

        const dateStr = this.formatDateToYYYYMMDD(targetDay);
        const sub = this.AppointmentService.getAvailableSlot(dateStr).subscribe({
            next: (data: any) => {
                const slots = (data || []) as any[];
                this.rescheduleAvailableSlots.set(slots);

                if (slots.length === 0) {
                    this.rescheduleLoading.set(false);
                    return;
                }

                // Match slot by hour
                let matchedSlot = slots.find((s: any) => {
                    const [sH] = s.Slot.split(':').map(Number);
                    return sH === targetHour;
                });
                if (!matchedSlot) {
                    matchedSlot = slots[0];
                }

                this.rescheduleSelectedSlotId.set(matchedSlot.SlotId);
                this.rescheduleTargetTime.set(matchedSlot.Slot);
                this.loadDocksForSlot(dateStr, matchedSlot.Slot, matchedSlot.SlotId, ticket.Door);
            },
            error: (err: any) => {
                this.rescheduleLoading.set(false);
                this.messageService.add({
                    severity: 'error',
                    summary: 'Failed to load slots',
                    detail: err?.error?.Message || 'Could not fetch available slots for the selected date.',
                });
            }
        });
        this.destroyRef.onDestroy(() => sub.unsubscribe());
    }

    loadDocksForSlot(dateStr: string, slotTime: string, slotId: number, preferredDock?: string) {
        const formattedDateTime = `${dateStr}T${slotTime}${slotTime.split(':').length === 2 ? ':00' : ''}`;
        const sub = this.AppointmentService.getAvailableDock(formattedDateTime, slotId).subscribe({
            next: (dockData: any) => {
                const docks = (dockData || []) as any[];
                this.rescheduleAvailableDocks.set(docks);
                if (preferredDock && docks.some((d: any) => d.Dock === preferredDock)) {
                    this.rescheduleSelectedDock.set(preferredDock);
                } else if (docks.length > 0) {
                    this.rescheduleSelectedDock.set(docks[0].Dock);
                } else {
                    this.rescheduleSelectedDock.set(preferredDock || null);
                }
                this.rescheduleLoading.set(false);
            },
            error: () => {
                this.rescheduleLoading.set(false);
            }
        });
        this.destroyRef.onDestroy(() => sub.unsubscribe());
    }

    onRescheduleSlotChange(slotId: number) {
        const slot = this.rescheduleAvailableSlots().find((s: any) => s.SlotId === slotId);
        if (!slot) return;
        this.rescheduleSelectedSlotId.set(slot.SlotId);
        this.rescheduleTargetTime.set(slot.Slot);
        this.rescheduleLoading.set(true);
        const dateStr = this.formatDateToYYYYMMDD(this.rescheduleTargetDate());
        this.loadDocksForSlot(dateStr, slot.Slot, slot.SlotId, this.rescheduleSelectedDock() || this.rescheduleTicket()?.Door);
    }

    confirmDragReschedule() {
        const ticket = this.rescheduleTicket();
        const slotId = this.rescheduleSelectedSlotId();
        const dock = this.rescheduleSelectedDock();
        const time = this.rescheduleTargetTime();
        const date = this.rescheduleTargetDate();

        if (!ticket || !slotId || !dock || !time || !date) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Missing Information',
                detail: 'Please select an available time slot and dock door to confirm rescheduling.',
            });
            return;
        }

        const dateStr = this.formatDateToYYYYMMDD(date);
        const formattedDateTime = `${dateStr}T${time}${time.split(':').length === 2 ? ':00' : ''}`;
        const payload = {
            AppointmentId: ticket.Appointmentid || ticket.AppointmentID,
            NewSlotId: slotId,
            ToSlotDate: formattedDateTime,
            RequestedDock: dock,
        };

        this.rescheduleSaving.set(true);
        const sub = this.AppointmentService.rescheduleAppointment(payload)
            .pipe(finalize(() => {
                this.rescheduleSaving.set(false);
            }))
            .subscribe({
                next: (res: any) => {
                    this.showRescheduleDialog.set(false);
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Rescheduled Successfully',
                        detail: res?.Message || 'Appointment has been rescheduled successfully.',
                    });
                    this.fetchAppointmentsForCurrentView();
                },
                error: (error: any) => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Reschedule Failed',
                        detail: error?.error?.Message || error?.error?.message || 'Error occurred while rescheduling appointment.',
                    });
                }
            });
        this.destroyRef.onDestroy(() => sub.unsubscribe());
    }

    cancelDragReschedule() {
        this.showRescheduleDialog.set(false);
        this.rescheduleTicket.set(null);
    }

    OpenviewDetailsCard(card: any) {
        if (this.justFinishedDrag) {
            return;
        }
        this.ref = this.dialogService.open(DetailsCardComponent, {
            header: 'Driver Details',
            inputValues: {
                type: this.apiType,
            },
            data: {
                selectedCard: card,
            },
            closable: true,
            modal: true,
            draggable: true,
            width: '70rem',
            style: { height: '42rem' },
        });
        this.ref.onClose.subscribe(() => {
            this.GetAppointmentOrder();
        });
    }
    openBookingPopups() {
        this.ref = this.dialogService.open(AppointmentSlotComponent, {
            inputValues: {
                type: this.apiType,
            },
            showHeader: false,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: true,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',
            styleClass: 'right-slide-panel',
            style: {
                width: '75rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },
            contentStyle: {
                overflow: 'auto',
                height: '100%',
                padding: '0',
            },
            breakpoints: {
                '960px': '100vw',
            },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                this.AppointmentService.createAppointment(data)
                    .pipe(finalize(() => this.GetAppointmentOrder()))
                    .subscribe({
                        next: (response: any) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'New Appointment creation',
                                detail:
                                    response?.Message ||
                                    'Appointment created successfully.' +
                                        response,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'New Appointment creation',
                                    detail:
                                        (error.error.message as string) ||
                                        (error.error.Message as string) ||
                                        'Error occurred while creating Appointment.',
                                });
                            }
                        },
                    });
            }
        });
    }
}
