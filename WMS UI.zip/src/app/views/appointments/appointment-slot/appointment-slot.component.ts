import {
    Component,
    computed,
    DestroyRef,
    ElementRef,
    inject,
    input,
    signal,
    ViewChild,
} from '@angular/core';
import { DividerModule } from 'primeng/divider';
import { CommonModule } from '@angular/common';
import {
    FormControl,
    FormGroup,
    FormsModule,
    ReactiveFormsModule,
} from '@angular/forms';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { AppointmentOrderService } from '../appointment-order.service';
import {
    InputTextComponent,
    InputSelectComponent,
    LoadingComponent,
} from '../../../common/components';
import { OptionsService } from '../../../common/services';
import { AppointmentColumns } from '../appointment.columns';

@Component({
    selector: 'app-appointment-slot',
    imports: [
        DividerModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        InputTextComponent,
        InputSelectComponent,
        ButtonModule,
        LoadingComponent,
    ],
    templateUrl: './appointment-slot.component.html',
    styleUrl: './appointment-slot.component.scss',
})
export class AppointmentSlotComponent {
    type = input.required();
    @ViewChild('scrollContainer') scrollContainer!: ElementRef;
    private AppointmentService = inject(AppointmentOrderService);
    private destroyRef = inject(DestroyRef);
    private messageService = inject(MessageService);
    private OptionService = inject(OptionsService);
    ConfirmationRef: DynamicDialogRef | undefined;
    dates: Date[] = [];
    currentDate: Date | null = null;
    selectedTime: string | undefined;
    selectedDock: string | null = null;
    driverName: string = '';
    dockId = signal<any>(null);
    driverNumber: string = '';
    selectedCarrier: string | null = null;
    docks = signal<any>([]);
    private ref = inject(DynamicDialogRef);
    timeSlots = signal<any>([]);
    availableSlotsCount = computed(() =>
        this.timeSlots().filter((time: any) => !this.isSlotPast(time.Slot)).length
    );
    formControlsArray = signal(
        Object.values(AppointmentColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    loading = signal(true);
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    form = new FormGroup(this.formControls());
    carrierOptions = signal<any>([]);
    ngOnInit() {
        this.getCarrierOption();
        this.generateDateRange();
        this.currentDate = new Date();
        this.getAvailabeSlot(this.currentDate.toISOString().split('T')[0]);
    }
    closePanel() {
        this.ref.close();
    }
    getCarrierOption() {
        const subscription = this.OptionService.getCarrierOptions()
            .pipe()
            .subscribe({
                next: (res: any) => {
                    this.loading.set(false);
                    this.carrierOptions.set(res);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    onSubmit() {
        const date = this.currentDate?.toISOString().split('T')[0];
        const time = this.selectedTime;
        const formattedDateTime = time ? `${date}T${time}${time.split(':').length === 2 ? ':00' : ''}` : '';
        this.form.patchValue({
            AppointmentDate: formattedDateTime,
            ArrivalDate: formattedDateTime,
            Type: this.type(),
            slotid: this.dockId(),
        });
        if (this.form.valid) {
            this.ref.close(this.form.getRawValue());
            this.form.reset();
        } else {
            this.messageService.add({
                severity: 'warn',
                summary: 'Please select Mandatory fields',
                detail: 'Ensure you have selected available date , time and dock.',
            });
        }
    }

    today() {
        this.currentDate = new Date();
        this.getAvailabeSlot(this.currentDate.toISOString().split('T')[0]);
        this.scrollContainer.nativeElement.scrollTo({ left: 0 });
    }
    scrollToNextDay() {
        this.scrollContainer.nativeElement.scrollBy({
            left: 100,
            behavior: 'smooth',
        });
    }
    scrollToPreviousDay() {
        this.scrollContainer.nativeElement.scrollBy({
            left: -100,
            behavior: 'smooth',
        });
    }
    goToNextDate() {
        if (this.currentDate) {
            const today = new Date();
            const maxDate = new Date(today);
            maxDate.setDate(today.getDate() + 183);
            const newDate = new Date(this.currentDate);
            newDate.setDate(this.currentDate.getDate() + 1);
            if (newDate > maxDate) {
                return;
            }
            this.selectedTime = '';
            const formattedDate = newDate.toISOString().split('T')[0];
            this.getAvailabeSlot(formattedDate);
            this.currentDate = newDate;
            this.scrollContainer.nativeElement.scrollBy({
                left: 70,
                behavior: 'smooth',
            });
        }
    }
    goToPreviousDate() {
        if (this.currentDate) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const newDate = new Date(this.currentDate);
            newDate.setDate(this.currentDate.getDate() - 1);
            if (newDate < today) {
                return;
            }
            this.selectedTime = '';
            const formattedDate = newDate.toISOString().split('T')[0];
            this.getAvailabeSlot(formattedDate);
            this.currentDate = newDate;
            this.scrollContainer.nativeElement.scrollBy({
                left: -70,
                behavior: 'smooth',
            });
        }
    }
    getFormattedDate(): string {
        return this.currentDate?.toDateString() || '';
    }
    generateDateRange() {
        const today = new Date();
        for (let i = 0; i <= 183; i++) {
            const date = new Date(today);
            date.setDate(today.getDate() + i);
            this.dates.push(date);
        }
        this.loading.set(false);
    }
    highlightDate(date: Date, index: number) {
        this.selectedTime = '';
        const formattedDate = date.toISOString().split('T')[0];
        this.getAvailabeSlot(formattedDate);
        this.currentDate = date;
    }
    isSelected(date: Date): boolean {
        return this.currentDate?.toDateString() === date.toDateString();
    }
    isSlotPast(slotTime: string): boolean {
        if (!this.currentDate) return false;

        const today = new Date();
        const isToday = this.currentDate.toDateString() === today.toDateString();

        if (!isToday) {
            const selectedZero = new Date(this.currentDate);
            selectedZero.setHours(0, 0, 0, 0);
            const todayZero = new Date(today);
            todayZero.setHours(0, 0, 0, 0);
            return selectedZero < todayZero;
        }

        const [slotHour, slotMinute] = slotTime.split(':').map(Number);
        const currentHour = today.getHours();
        const currentMinute = today.getMinutes();

        if (slotHour < currentHour) {
            return true;
        } else if (slotHour === currentHour) {
            return slotMinute <= currentMinute;
        }
        return false;
    }
    selectTime(time: string, id: any) {
        if (this.isSlotPast(time)) {
            return;
        }
        this.selectedTime = time;
        this.dockId.set(id);
        const date = this.currentDate?.toISOString().split('T')[0];
        const formattedDateTime = `${date}T${time}${time.split(':').length === 2 ? ':00' : ''}`;
        this.getAvailabeDock(formattedDateTime, id);
    }
    formatTime(time: string): string {
        const [hour, minute] = time.split(':').map(Number);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const hour12 = hour % 12 || 12;
        return `${hour12}:${minute.toString().padStart(2, '0')} ${ampm}`;
    }
    getAvailabeSlot(date: any) {
        const subscription = this.AppointmentService.getAvailableSlot(date)
            .pipe()
            .subscribe({
                next: (data) => {
                    if (data) {
                        this.loading.set(false);
                        this.timeSlots.set(
                            (data as any[]).map((x: any, idx: number) => ({
                                ...x,
                                rowId: idx + 1,
                            })),
                        );
                    }
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getAvailabeDock(date: any, id: any) {
        const subscription = this.AppointmentService.getAvailableDock(date, id)
            .pipe()
            .subscribe({
                next: (data) => {
                    if (data) {
                        this.docks.set(data);
                    }
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
}
