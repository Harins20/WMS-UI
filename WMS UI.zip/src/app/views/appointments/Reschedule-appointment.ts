import {
    Component,
    DestroyRef,
    ElementRef,
    inject,
    signal,
    ViewChild,
} from '@angular/core';
import { AppointmentOrderService } from './appointment-order.service';
import { SelectModule } from 'primeng/select';
import { DividerModule } from 'primeng/divider';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'reschedule-appointment',
    imports: [
        SelectModule,
        DividerModule,
        CommonModule,
        FormsModule,
        ButtonModule,
    ],
    styleUrl: './appointment.component.scss',
    template: `
        <div class="flex justify-between items-center">
            <h2 class="text-xl font-semibold text-gray-800 dark:text-gray-100">
                Reschedule Appointment
            </h2>
            <div class="flex items-center gap-3">
                <span
                    class="px-3 py-1 rounded-full text-white text-sm bg-teal-500"
                    >Today</span
                >
                <span class="text-sm text-gray-700 dark:text-gray-300 font-medium">{{
                    getFormattedDate()
                }}</span>
                <button class="text-lg px-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white" (click)="goToPreviousDate()">
                    &#x276E;
                </button>
                <button class="text-lg px-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white" (click)="goToNextDate()">
                    &#x276F;
                </button>
            </div>
        </div>
        <p-divider styleClass="dark:border-gray-700" />
        <div class="mt-4 flex items-center gap-2">
            <button class="text-xl px-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white" (click)="scrollToPreviousDay()">
                &#x276E;
            </button>
            <div
                #scrollContainer
                class="flex overflow-x-auto scrollbar-hide gap-3 py-2"
            >
                <div
                    *ngFor="let date of dates(); let i = index"
                    class="min-w-[60px] rounded-lg text-center px-2 py-2 cursor-pointer border transition"
                    [ngClass]="isSelected(date) 
                        ? 'bg-teal-500 text-white border-teal-500 font-semibold shadow-xs' 
                        : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-800 hover:border-teal-500'"
                    (click)="highlightDate(date, i)"
                >
                    <div class="text-sm font-medium">
                        {{ date | date: 'EEE' }}
                    </div>
                    <div class="text-lg font-semibold">
                        {{ date | date: 'd' }}
                    </div>
                </div>
            </div>
            <button class="text-xl px-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white" (click)="scrollToNextDay()">
                &#x276F;
            </button>
        </div>

        <div class="mt-6">
            <div class="flex flex-wrap gap-3 py-2">
                @for (time of timeSlots(); track time.rowId) {
                    <div
                        class="px-4 py-2 text-sm text-center rounded-full border transition-all"
                        [ngClass]="{
                            'bg-teal-500 text-white !border-teal-500 cursor-pointer': selectedTime === time.Slot && !isSlotPast(time.Slot),
                            'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-200 cursor-pointer': selectedTime !== time.Slot && !isSlotPast(time.Slot),
                            'bg-gray-100 dark:bg-gray-800/50 text-gray-400 dark:text-gray-500 border-gray-200 dark:border-gray-700 cursor-not-allowed': isSlotPast(time.Slot)
                        }"
                        (click)="selectTime(time.Slot, time.SlotId)"
                    >
                        {{ time.Slot }}
                    </div>
                }
            </div>
        </div>
        @if (currentDate() && selectedTime) {
            <div
                class="mt-6 flex justify-between items-center px-6 py-3 rounded-full gap-4 bg-[#ecfdfa] dark:bg-teal-950/40 border border-teal-100 dark:border-teal-800/50"
            >
                <div class="text-sm text-gray-700 dark:text-gray-200 font-medium">
                    {{ currentDate() | date: 'dd MMM, yyyy' }}
                    |
                    {{ selectedTime }}
                </div>
                <div class="flex items-center gap-4">
                    <select
                        class="px-3 py-2 rounded-full border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-sm text-gray-700 dark:text-gray-200 focus:outline-none"
                        [(ngModel)]="selectedDock"
                        name="dock.Dock"
                    >
                        <option [ngValue]="null" disabled selected>
                            Select Dock
                        </option>
                        @for (dock of docks(); track dock.id) {
                            <option [value]="dock.Dock">
                                {{ dock.Dock }}
                            </option>
                        }
                    </select>
                </div>
            </div>
        }

        <div class="flex justify-end gap-3 mt-6">
            <button
                (click)="onSubmit()"
                class="bg-[#14B8A6] text-white text-sm px-4 py-2 rounded shadow-sm hover:bg-teal-600 transition"
            >
                Confirm
            </button>
            <button
                (click)="onClose()"
                class="bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 text-sm px-4 py-2 rounded transition"
            >
                Cancel
            </button>
        </div>
    `,
})
export class RescheduleAppointment {
    dates = signal<Date[]>([]);
    dockId = signal<number>(0);
    currentDate = signal<Date>(new Date());
    selectedTime: string | null = null;
    selectedDock: string | null = null;
    selectedDate: Date = new Date();
    timeSlots = signal<any>([]);
    docks = signal<any>([]);
    private AppointmentService = inject(AppointmentOrderService);
    private destroyRef = inject(DestroyRef);
    private ref = inject(DynamicDialogRef);
    private messageService = inject(MessageService);
    @ViewChild('scrollContainer', { static: false })
    scrollContainer!: ElementRef;
    ngOnInit() {
        this.generateDates();
        this.getAvailabeSlot(this.currentDate().toISOString().split('T')[0]);
    }
    generateDates() {
        const today = new Date();
        for (let i = 0; i <= 183; i++) {
            const date = new Date(today);
            date.setDate(today.getDate() + i);
            this.dates.update((current) => [...current, date]);
        }
    }
    onClose() {
        this.ref.close();
    }
    onSubmit() {
        if (this.currentDate && this.selectedTime && this.selectedDock) {
            const date = this.currentDate().toISOString().split('T')[0];
            const formattedDateTime = `${date}T${this.selectedTime}${this.selectedTime.split(':').length === 2 ? ':00' : ''}`;
            const data = {
                ToSlotDate: formattedDateTime,
                NewSlotId: this.dockId(),
                RequestedDock: this.selectedDock,
            };
            this.ref.close(data);
        } else {
            this.messageService.add({
                severity: 'warn',
                summary: 'Reschedule Appointment',
                detail: 'Please select every field to continue',
            });
        }
    }
    getAvailabeSlot(date: any) {
        const subscription = this.AppointmentService.getAvailableSlot(date)
            .pipe()
            .subscribe({
                next: (data) => {
                    if (data) {
                        this.timeSlots.set(
                            (data as any[]).map((x: any, idx: number) => ({
                                ...x,
                                rowId: idx + 1,
                            })),
                        );
                    }
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getAvailabeDock(date: any, id: any) {
        const subscription = this.AppointmentService.getAvailableDock(date, id)
            .pipe()
            .subscribe({
                next: (data) => {
                    if (data) {
                        this.docks.set(data);
                    }
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getFormattedDate() {
        return this.currentDate().toDateString();
    }
    isSelected(date: Date): boolean {
        return date.toDateString() === this.currentDate().toDateString();
    }
    highlightDate(date: Date, index: number) {
        this.selectedTime = '';
        const formattedDate = date.toISOString().split('T')[0];
        this.getAvailabeSlot(formattedDate);
        this.currentDate.set(date);
    }
    goToPreviousDate() {
        if (this.currentDate) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const newDate = new Date(this.currentDate());
            newDate.setDate(this.currentDate().getDate() - 1);
            if (newDate < today) {
                return;
            }
            this.selectedTime = '';
            const formattedDate = newDate.toISOString().split('T')[0];
            this.getAvailabeSlot(formattedDate);
            this.currentDate.set(newDate);
            this.scrollContainer.nativeElement.scrollBy({
                left: -70,
                behavior: 'smooth',
            });
        }
    }

    goToNextDate() {
        if (this.currentDate) {
            const today = new Date();
            const maxDate = new Date(today);
            maxDate.setDate(today.getDate() + 183);
            const newDate = new Date(this.currentDate());
            newDate.setDate(this.currentDate().getDate() + 1);
            if (newDate > maxDate) {
                return;
            }
            this.selectedTime = '';
            const formattedDate = newDate.toISOString().split('T')[0];
            this.getAvailabeSlot(formattedDate);
            this.currentDate.set(newDate);
            this.scrollContainer.nativeElement.scrollBy({
                left: 70,
                behavior: 'smooth',
            });
        }
    }
    scrollToPreviousDay() {
        this.scrollContainer.nativeElement.scrollLeft -= 100;
    }

    scrollToNextDay() {
        this.scrollContainer.nativeElement.scrollLeft += 100;
    }
    isSlotPast(slotTime: string): boolean {
        const currentDateVal = this.currentDate();
        if (!currentDateVal) return false;

        const today = new Date();
        const isToday = currentDateVal.toDateString() === today.toDateString();

        if (!isToday) {
            const selectedZero = new Date(currentDateVal);
            selectedZero.setHours(0, 0, 0, 0);
            const todayZero = new Date(today);
            todayZero.setHours(0, 0, 0, 0);
            return selectedZero < todayZero;
        }

        const [slotHour, slotMinute] = slotTime.split(':').map(Number);
        const currentHour = today.getHours();
        const currentMinute = today.getMinutes();

        if (slotHour < currentHour) {
            return true;
        } else if (slotHour === currentHour) {
            return slotMinute <= currentMinute;
        }
        return false;
    }
    selectTime(time: string, id: any) {
        if (this.isSlotPast(time)) {
            return;
        }
        this.selectedTime = time;
        this.dockId.set(id);
        const date = this.currentDate()?.toISOString().split('T')[0];
        const formattedDateTime = `${date}T${time}${time.split(':').length === 2 ? ':00' : ''}`;
        this.getAvailabeDock(
            formattedDateTime,
            id,
        );
    }
}
