import { OutboundPickupsComponent } from './appointment.component';

export default [
    {
        data: { name: 'Inbound Delivers' },
        path: 'inbounddelivers',
        component: OutboundPickupsComponent,
    },
    {
        data: { name: 'Outbound Pickups' },
        path: 'outboundpickups',
        component: OutboundPickupsComponent,
    },
];
