import { HttpClient } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { AppConfigService } from '../../../app.config.service';
import { ResponseDto } from '../../common/models';
import { AuthService } from '../../common/services';
import { map } from 'rxjs';
import { stringToDate } from '../../common/functions';
import { AppointmentColumns } from './appointment.columns';

@Injectable({
    providedIn: 'root',
})
export class AppointmentOrderService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getAppointment() {
        return this.httpClient.get(
            this.config.appConfig()?.AppointmentUrl + 'appointment',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getAppointmentPage(data: any, type: any) {
        return this.httpClient
            .post<any>(
                this.config.appConfig()?.AppointmentUrl +
                    `appointmentPaged?Type=${type}`,
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response) => {
                    response.Appointments.forEach((x: any) => {
                        Object.keys(x).forEach((key) => {
                            if (AppointmentColumns[key]?.type === 'date') {
                                x[key] = stringToDate(x[key]);
                            }
                        });
                    });
                    return response;
                }),
            );
    }
    getAppointmentDetail(id: any) {
        return this.httpClient.get<ResponseDto<[]>>(
            this.config.appConfig()?.AppointmentUrl +
                `appointment?AppointmentId=${id}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getAppointmentLines(id: any) {
        return this.httpClient.get(
            this.config.appConfig()?.AppointmentUrl +
                `appointment/lines?AppointmentId=${id}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    updateKey(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.AppointmentUrl + 'appointment/lines',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getAvailableOrderKeys() {
        return this.httpClient.get<ResponseDto<[]>>(
            this.config.appConfig()?.AppointmentUrl + 'appointment/orders',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    createAppointment(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.AppointmentUrl + 'appointment',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    scheduleAppointment(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.AppointmentUrl +
                'appointment/schedule-slot',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getAvailableSlot(date: any) {
        return this.httpClient.get(
            this.config.appConfig()?.AppointmentUrl +
                `appointment/slots/available?Date=${date}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getAvailableDock(date: any, id: any) {
        return this.httpClient.get(
            this.config.appConfig()?.AppointmentUrl +
                `appointment/docks?Date=${date}&slotid=${id}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getAvailableASN() {
        return this.httpClient.get(
            this.config.appConfig()?.AppointmentUrl + 'appointment/asn',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    rescheduleAppointment(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.AppointmentUrl + 'appointment/reschedule',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    cancelAppointment(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.AppointmentUrl + 'appointment/cancel',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getStatus() {
        return this.httpClient.get(
            this.config.appConfig()?.AppointmentUrl + 'appointment/status',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    updateStatus(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.AppointmentUrl + 'appointment/status',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
