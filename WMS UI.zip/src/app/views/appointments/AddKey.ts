import { Component, DestroyRef, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { ListboxModule } from 'primeng/listbox';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { AppointmentOrderService } from './appointment-order.service';

@Component({
    standalone: true,
    imports: [ListboxModule, FormsModule, ButtonModule, InputTextModule],
    selector: 'asn-add',
    template: `<div class="w-full">
        <input
            pInputText
            type="text"
            [(ngModel)]="Search"
            [placeholder]="'Search' + key() + '...'"
            class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 rounded-full px-3 py-2 text-sm mb-3"
        />

        <div
            class="flex flex-col max-h-60 overflow-y-auto border dark:border-gray-700 rounded-xl p-2 space-y-2 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200"
        >
            @for (Key of filteredAsns; track Key) {
                <label class="inline-flex items-center text-sm gap-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50 p-1 rounded-md transition">
                    <input
                        type="checkbox"
                        [value]="Key"
                        (change)="toggleAsnSelection(Key, $event)"
                        [checked]="selectedKey().includes(key)"
                        class="rounded border-gray-300 dark:border-gray-600 text-primary focus:ring-primary dark:bg-gray-700"
                    />
                    {{ Key }}
                </label>
            }
        </div>

        <div class="flex justify-end gap-3 mt-4">
            <button pButton (click)="onSubmit()">Confirm</button>
            <button pButton (click)="onClose()" severity="secondary">
                Cancel
            </button>
        </div>
    </div>`,
})
export class AddKey {
    Search: string = '';
    private ref = inject(DynamicDialogRef);
    list = signal<any>([]);
    selectedKey = signal<any>([]);
    private AppointmentService = inject(AppointmentOrderService);
    private destroyRef = inject(DestroyRef);
    key = signal<string>('');
    type = input.required();
    ngOnInit() {
        if (this.type() === 'Inbound') {
            this.key.set('ASN');
            this.getASN();
        } else {
            this.key.set('Order');
            this.getOrder();
        }
    }
    getOrder() {
        const subscription = this.AppointmentService.getAvailableOrderKeys()
            .pipe()
            .subscribe({
                next: (data: any) => {
                    this.list.set(data.Data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getASN() {
        const subscription = this.AppointmentService.getAvailableASN()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.list.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    onSubmit() {
        this.ref.close(this.selectedKey());
    }
    onClose() {
        this.ref.close();
    }
    toggleAsnSelection(asn: string, event: Event) {
        const checked = (event.target as HTMLInputElement).checked;
        if (checked) {
            const currentKey = this.selectedKey();
            currentKey.push(asn);
            this.selectedKey.set([...currentKey]);
        } else {
            this.selectedKey().filter((item: string) => item !== asn);
        }
    }
    get filteredAsns(): string[] {
        const temp = this.list().filter((asn: string) =>
            asn.toLowerCase().includes(this.Search.toLowerCase()),
        );
        return temp;
    }
}
