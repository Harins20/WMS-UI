import { Validators } from '@angular/forms';
import { Columns } from '../../common/models/Columns';

export const AppointmentColumns: Columns = {
    AppointmentID: {
        label: 'Appointment ID',
        field: 'AppointmentID',
        tableAlias: 'vw.',
    },
    AppointmentDate: {
        label: 'Appointment Date',
        field: 'AppointmentDate',
        tableAlias: 'vw.',
    },
    ArrivalDate: {
        label: 'Arrival Date',
        field: 'ArrivalDate',
        tableAlias: 'vw.',
    },
    DESCR: {
        label: 'DESCR',
        field: 'DESCR',
        tableAlias: 'vw.',
    },
    Door: {
        label: 'Door',
        field: 'Door',
        validators: [Validators.required],
        tableAlias: 'vw.',
    },
    CarrierName: {
        label: 'Carrier Name',
        field: 'CarrierName',
        validators: [Validators.required],
        tableAlias: 'vw.',
    },
    VehicleNumber: {
        label: 'Vehicle Number',
        field: 'VehicleNumber',
        validators: [Validators.required],
        tableAlias: 'vw.',
    },
    DriverName: {
        label: 'DriverName',
        field: 'DriverName',
        validators: [Validators.required],
        tableAlias: 'vw.',
    },
    DriverContactNumber: {
        label: 'DriverContactNumber',
        field: 'DriverContactNumber',
        validators: [Validators.required, Validators.maxLength(18)],
        tableAlias: 'vw.',
    },
    Type: {
        label: 'Type',
        field: 'Type',
        tableAlias: 'vw.',
    },
    slotid: {
        label: 'Slot ID',
        field: 'slotid',
        validators: [Validators.required],
        tableAlias: 'vw.',
        tableHidden: true,
    },
};
