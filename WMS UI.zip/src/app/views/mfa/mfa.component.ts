import { Component, DestroyRef, inject, input, signal } from '@angular/core';
import {
    FormControl,
    FormGroup,
    FormsModule,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../common/services';
import { InputOtp } from 'primeng/inputotp';
import { QRCodeComponent } from 'angularx-qrcode';
import { ButtonModule } from 'primeng/button';
import { MessageService } from 'primeng/api';
import { finalize } from 'rxjs';

@Component({
    selector: 'app-mfa',
    imports: [ReactiveFormsModule, QRCodeComponent, ButtonModule, InputOtp],
    templateUrl: './mfa.component.html',
    styleUrl: './mfa.component.scss',
})
export class MfaComponent {
    setupMfa = signal<boolean>(false);
    public authService = inject(AuthService);
    private destoryRef = inject(DestroyRef);
    private messageService = inject(MessageService);
    loading = signal(false);

    public router = inject(Router);
    qrCodeUrl = signal<string>('');
    mfaForm = new FormGroup({
        OTP: new FormControl<string | undefined>(undefined, [
            Validators.required,
            Validators.minLength(6),
            Validators.maxLength(6),
        ]),
    });
    constructor() {
        if (this.authService.isAuthenticated()) {
            this.router.navigate(['']);
        }
    }
    ngOnInit() {
        const setupMfa = this.authService.isMfaSetup();

        this.setupMfa.set(setupMfa);
        if (setupMfa) {
            this.getQrCode();
        }
    }
    getQrCode() {
        const subscription = this.authService
            .getQrCode()
            .pipe()
            .subscribe({
                next: (data: any) => {
                    this.qrCodeUrl.set(data);
                },
                error(err) {},
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    onSubmit() {
        if (this.mfaForm.valid) {
            this.loading.set(true);
            const otp = this.mfaForm.value.OTP!.toString();
            const subscription = this.authService
                .validateMfa(otp)
                .pipe(finalize(() => this.loading.set(false)))
                .subscribe({
                    next: (data: any) => {
                        // sessionStorage.clear();
                        sessionStorage.setItem(
                            'Token',
                            JSON.stringify(data.Token),
                        );
                        this.router.navigate(['']);
                    },
                    error: (err) => {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Authentication failed',
                            detail: 'Invalid Mfa',
                        });
                    },
                });
            this.destoryRef.onDestroy(() => subscription.unsubscribe());
        } else {
        }
    }
}
