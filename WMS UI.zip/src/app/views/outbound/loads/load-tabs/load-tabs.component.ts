import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { Component, input } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TabsModule } from 'primeng/tabs';
import { CalendarModule } from 'primeng/calendar';
import { LoadLineComponent } from '../load-lines/load-lines.component';
import { LoadOrdersComponent } from '../load-order-details/load-order-details.component';
import { LoadViewFormComponent } from '../load-view-form/load-view-form.component';
import { AccordionModule } from 'primeng/accordion';

@Component({
    selector: 'load-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        TabsModule,
        CalendarModule,
        LoadLineComponent,
        LoadOrdersComponent,
        LoadViewFormComponent,
        AccordionModule,
        AppTranslatePipe,
    ],
    templateUrl: './load-tabs.component.html',
})
export class LoadDetailsTabComponent {
    LoadID = input<any>();
}
