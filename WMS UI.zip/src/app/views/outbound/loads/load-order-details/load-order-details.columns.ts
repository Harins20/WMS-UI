import { Validators } from '@angular/forms';
import { Columns } from '../../../../common/models';

export const LoadOrdersColumns: Columns = {
    SerialKey: {
        label: 'SerialKey',
        field: 'SERIALKEY',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(32)],
        restrictEdit: true,
        restrictInsert: true,
        tableHidden: true,
    },
    OrderKey: {
        label: 'OrderKey',
        field: 'ORDERKEY',
        type: 'text',
        validators: [Validators.maxLength(32)],
        restrictEdit: true,
        restrictInsert: true,
    },
    Owner: {
        label: 'Owner',
        field: 'TRADERKEY',
        type: 'text',
        validators: [Validators.maxLength(32)],
        restrictEdit: true,
        restrictInsert: true,
    },

    StatusDesc: {
        label: 'Status',
        field: 'STATUSDESC',
        type: 'text',
        validators: [Validators.maxLength(200)],
        restrictInsert: true,
        restrictEdit: true,
    },
    Status: {
        label: 'Status',
        field: 'STATUS',
        type: 'text',
        validators: [Validators.maxLength(60)],
        restrictInsert: true,
        restrictEdit: true,
        tableHidden: true,
    },
    AddDate: {
        label: 'Add Date',
        field: 'ADDDATE',
        type: 'date',
        restrictEdit: true,
    },

    AddWho: {
        label: 'Add Who',
        field: 'ADDWHO',
        validators: [Validators.maxLength(50)],
        restrictEdit: true,
    },
};
