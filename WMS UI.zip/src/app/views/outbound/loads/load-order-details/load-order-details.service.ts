import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AuthService } from '../../../../common/services';
import { AppConfigService } from '../../../../../app.config.service';
import { map } from 'rxjs';
import {
    lowerCaseArray,
    lowerCaseObject,
    upperCaseArray,
    upperCaseObject,
} from '../../../../shared/utils/case-conversion.util';

@Injectable({
    providedIn: 'root',
})
export class LoadOrderService {
    createLoadDetailsLines(data: any) {
        throw new Error('Method not implemented.');
    }
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getLoadDetails(LoadID: string) {
        return this.httpClient
            .get(
                this.config.appConfig()?.OutUrl + `loads?LoadID=${LoadID}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res: any) => ({
                    ...res,
                    Response: upperCaseObject(res?.Response),
                })),
            );
    }
    getLoadOrders(LoadID: string) {
        return this.httpClient
            .get(
                this.config.appConfig()?.OutUrl + `loads/lines?LoadID=${LoadID}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res: any) => ({
                    ...res,
                    Response: {
                        ...res?.Response,
                        LoadOrders: upperCaseArray(res?.Response?.LoadOrders || []),
                    },
                })),
            );
    }

    createLoadOrders(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'Loads/Lines/Orders',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    loadOrders(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Loads/LoadOrders',
            lowerCaseObject(data),
            { headers: this.authService.getAuthHeaders() },
        );
    }
    DeleteLoadsOrder(data: any) {
        return this.httpClient.delete(
            this.config.appConfig()?.OutUrl + 'Loads/Orders',
            {
                headers: this.authService.getAuthHeaders(),
                body: lowerCaseObject(data),
            },
        );
    }

    unloadOrders(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Loads/UnLoadOrders',
            lowerCaseObject(data),
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
