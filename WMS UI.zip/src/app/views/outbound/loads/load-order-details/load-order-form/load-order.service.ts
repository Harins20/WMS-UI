import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../../../../../../app.config.service';
import { ResponseDto } from '../../../../../common/models';
import { AuthService } from '../../../../../common/services';
import { map } from 'rxjs';
import {
    lowerCaseObject,
    upperCaseArray,
} from '../../../../../shared/utils/case-conversion.util';

@Injectable({
    providedIn: 'root',
})
export class LoadOrdersCreationService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getLoadOrders(loadId: any) {
        return this.httpClient
            .get(
                this.config.appConfig()?.OutUrl + `loads/Orders?loadId=${loadId}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res: any) => ({
                    ...res,
                    Response: upperCaseArray(res?.Response || []),
                })),
            );
    }
    addLoad(orderKey: string, loadOrders: any) {
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + `loads/add?orderKey=${orderKey}`,
            lowerCaseObject(loadOrders),
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
