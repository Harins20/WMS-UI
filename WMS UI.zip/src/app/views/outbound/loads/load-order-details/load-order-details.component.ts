import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { LoadOrderService } from './load-order-details.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    LoadingComponent,
    CustomTableComponent,
} from '../../../../common/components';
import { Router } from '@angular/router';
import { LoadOrdersColumns } from './load-order-details.columns';
import { LoadOrderFormComponent } from './load-order-form/load-order-form.component';
import { Menu } from 'primeng/menu';
import { tableOptions } from '../../../../common/constants';
import { TooltipModule } from 'primeng/tooltip';
import { TagModule } from 'primeng/tag';
import { ConfirmationDialogComponent } from '../../../../common/components';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';
import { ExcelDownloadService } from '../../../../common/services/excel-download.service';

@Component({
    selector: 'app-load-details',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        Menu,
        TooltipModule,
        TagModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTableComponent,
    ],
    templateUrl: './load-order-details.component.html',
    styleUrl: './load-order-details.component.scss',
    providers: [DialogService],
})
export class LoadOrdersComponent {
    private translate = inject(TranslateService);
    LoadID = input.required<string>();
    loadOrders = signal<any[]>([]);
    loadDetails = signal<any>({});
    selectedOrderLines = signal<any[]>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    exportFileName = 'Load Orders Lines';
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    columns = signal(
        Object.values(LoadOrdersColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    ConfirmationRef: DynamicDialogRef | undefined;
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    LoadOrdersFormRef: DynamicDialogRef | undefined;
    private router = inject(Router);
    private messageService = inject(MessageService);
    private LoadOrderService = inject(LoadOrderService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    // mainLoading = signal(false);
    constructor() {}
    ngOnInit() {
        this.getLoadOrders();
        this.getLoadDetails();
    }
    ngAfterViewInit() {
        this.columns.update((columns) =>
            columns.map((column: any) => {
                if (column.field === 'STATUSDESC' || column.field === 'StatusDesc') {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }
                return column;
            }),
        );
    }
    getLoadDetails() {
        this.loading.set(true);
        this.loadDetails.set({});
        const subscription = this.LoadOrderService.getLoadDetails(
            this.LoadID(),
        ).subscribe({
            next: (res: any) => {
                this.loadDetails.set(res.Response);
                this.loading.set(false);
            },
            error: (error: HttpErrorResponse) => {
                if (error.status === 0)
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Load Details list',
                        detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                    });
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    getLoadOrders() {
        this.loading.set(true);
        this.loadOrders.set([]);
        const subscription = this.LoadOrderService.getLoadOrders(this.LoadID())
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res: any) => {
                    const rawOrders = res?.Response?.LoadOrders || res?.Response || [];
                    this.loadOrders.set(
                        rawOrders.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'LoadDetails list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getLoadOrders();
    }
    exportCSV() {
        downloadCSVFile(this.loadOrders(), this.exportFileName);
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.loadOrders(),
        );
    }
    // deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.loadOrders().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedOrderLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedOrderLines().length > 0 ? true : false,
    );
    isDisabled = computed(() => {
        const status = this.loadOrders().some((x) => x.STATUS === '0' || x.Status === '0');
        return status;
    });
    isDisabledUnload = computed(() => {
        const status = this.loadOrders().some((x) => x.STATUS === '2' || x.Status === '2');
        return status;
    });
    isDisabledCreate = computed(() => {
        const status = this.loadOrders().some((x) => x.STATUS === '9' || x.Status === '9');
        return status;
    });
    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    OpenCreateLoadOrdersForm() {
        const headertext = this.translate.instant('Create Order');
        this.LoadOrdersFormRef = this.dialogService.open(
            LoadOrderFormComponent,
            {
                inputValues: {
                    LoadId: this.LoadID(),
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                // duplicate: true,
                width: '65rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.LoadOrdersFormRef.onClose.subscribe((data) => {
            if (data) {
                const headertext = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('LoadOrderCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: headertext,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        const FilterData = data.map((x: any) => {
                            return { orderkey: x.ORDERKEY || x.orderkey, STORER: x.TRADERKEY || x.traderkey };
                        });
                        const CreateData = {
                            LoadOrderBody: FilterData,
                            EXTERNALORDERID: this.loadDetails()?.EXTERNALID,
                        };
                        this.LoadOrderService.createLoadOrders(CreateData)
                            .pipe(
                                finalize(() => {
                                    this.getLoadOrders();
                                    this.loading.set(false);
                                }),
                            )
                            .subscribe({
                                next: (response: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Order creation',
                                        detail: response.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Order creation',
                                            detail: error as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    loadOrdersAction() {
        if (this.selectedOrderLines().length > 0) {
            this.loading.set(true);
            const Rdata = this.selectedOrderLines().map((x: any) => x.ORDERKEY);
            const requestBody = {
                LoadID: this.LoadID(),
                OrderKeys: Rdata,
            };

            const subscription = this.LoadOrderService.loadOrders(requestBody)
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.selectedOrderLines.set([]);
                        this.getLoadDetails();
                        this.getLoadOrders();
                    }),
                )
                .subscribe({
                    next: (response) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Load',
                            detail: 'Loaded successfully.',
                        });
                        this.getLoadDetails();
                    },
                    error: (error) => {
                        if (
                            error.error.Message ===
                                'One or more errors occurred!' ||
                            error.error.message ===
                                'One or more errors occurred!'
                        ) {
                            this.ConfirmationRef = this.dialogService.open(
                                CommonErrorboxComponent,
                                {
                                    inputValues: {
                                        error: error,
                                    },
                                    header: 'Multiple Error',
                                    closable: true,
                                    modal: true,
                                    draggable: true,
                                    keepInViewport: true,
                                    width: '39rem',
                                    style: { maxHeight: '40rem' },
                                },
                            );
                        } else {
                            const errorMessage =
                                error?.error?.message || 'Failed to Load';
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Load',
                                detail: errorMessage,
                            });
                        }
                    },
                });

            this.destroyRef.onDestroy(() => subscription.unsubscribe());
        } else {
            this.messageService.add({
                severity: 'error',
                summary: 'Load',
                detail: 'Please select at least one record to Load.',
            });
        }
    }

    unloadOrdersAction() {
        if (this.selectedOrderLines().length > 0) {
            this.loading.set(true);
            const Rdata = this.selectedOrderLines().map((x: any) => x.ORDERKEY);
            const requestBody = {
                LoadID: this.LoadID(),
                OrderKeys: Rdata,
            };

            const subscription = this.LoadOrderService.unloadOrders(requestBody)
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.selectedOrderLines.set([]);
                        this.getLoadDetails();
                        this.getLoadOrders();
                    }),
                )
                .subscribe({
                    next: (response) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'UnLoaded',
                            detail: 'UnLoaded successfully.',
                        });
                        this.getLoadDetails();
                    },
                    error: (error) => {
                        if (
                            error.error.Message ===
                                'One or more errors occurred!' ||
                            error.error.message ===
                                'One or more errors occurred!'
                        ) {
                            this.ConfirmationRef = this.dialogService.open(
                                CommonErrorboxComponent,
                                {
                                    inputValues: {
                                        error: error,
                                    },
                                    header: 'Multiple Error',
                                    closable: true,
                                    modal: true,
                                    draggable: true,
                                    keepInViewport: true,
                                    width: '39rem',
                                    style: { maxHeight: '40rem' },
                                },
                            );
                        } else {
                            const errorMessage =
                                error?.error?.message || 'Failed to UnLoad';
                            this.messageService.add({
                                severity: 'error',
                                summary: 'UnLoaded',
                                detail: errorMessage,
                            });
                        }
                    },
                });

            this.destroyRef.onDestroy(() => subscription.unsubscribe());
        } else {
            this.messageService.add({
                severity: 'error',
                summary: 'UnLoaded',
                detail: 'Please select at least one record to UnLoad.',
            });
        }
    }
    DeleteLoadOrders() {
        if (this.selectedOrderLines().length === 0) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Delete Load Orders',
                detail: 'No orders selected for deletion.',
            });
            return;
        }

        const headertext = this.translate.instant('Confirm Deletion');
        const count = this.selectedOrderLines().length;
        const name =
            count > 1
                ? this.translate.instant('Load Orders')
                : this.translate.instant('Load Order');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });

        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((confirmed: boolean) => {
                if (confirmed) {
                    const orderKeys = this.selectedOrderLines().map(
                        (x: any) => x.ORDERKEY,
                    );
                    this.loading.set(true);
                    const requestBody = {
                        LOADID: this.LoadID(),
                        ORDERKEYS: orderKeys,
                    };

                    const subscription = this.LoadOrderService.DeleteLoadsOrder(
                        requestBody,
                    )
                        .pipe(
                            finalize(() => {
                                this.loading.set(false);
                                this.selectedOrderLines.set([]);
                                this.getLoadDetails();
                                this.getLoadOrders();
                            }),
                        )
                        .subscribe({
                            next: (response) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Delete Load',
                                    detail: 'Load deleted successfully.',
                                });
                                this.loadOrders.update((orders) => {
                                    return orders.filter(
                                        (order: any) =>
                                            !orderKeys.includes(order.ORDERKEY),
                                    );
                                });
                            },
                            error: (error) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef =
                                        this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                } else {
                                    const errorMessage =
                                        error?.error?.message ||
                                        'An unexpected error occurred while deleting the load orders. Please try again later.';
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Delete Load',
                                        detail: errorMessage,
                                    });
                                }
                            },
                        });

                    this.destroyRef.onDestroy(() => subscription.unsubscribe());
                }
            });
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
