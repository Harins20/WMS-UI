import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Load } from './load.model';
import { AuthService } from '../../../common/services';
import { ResponseDto } from '../../../common/models';
import { AppConfigService } from '../../../../app.config.service';
import { LoadColumns } from './load.columns';
import { map } from 'rxjs';
import { stringToDate } from '../../../common/functions';
import {
    lowerCaseArray,
    lowerCaseObject,
    upperCaseArray,
    upperCaseObject,
} from '../../../shared/utils/case-conversion.util';

interface LoadPage {
    Orders: Load[];
    totalRecords: number;
}

@Injectable({
    providedIn: 'root',
})
export class LoadService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getLoads() {
        return this.httpClient
            .get<ResponseDto<Load[]>>(
                this.config.appConfig()?.OutUrl + 'loads',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res: any) => ({
                    ...res,
                    Response: upperCaseArray(res?.Response),
                })),
            );
    }
    getLoad(data: any) {
        return this.httpClient
            .get<ResponseDto<Load>>(
                this.config.appConfig()?.OutUrl + 'loads?LOADID=' + data,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res: any) => ({
                    ...res,
                    Response: upperCaseObject(res?.Response),
                })),
            );
    }
    getLoadPage(data: any) {
        return this.httpClient
            .post<LoadPage>(
                this.config.appConfig()?.OutUrl + 'LoadsPaged',
                lowerCaseObject(data),
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response: any) => {
                    const rawItems =
                        response?.Response?.LoadHeaders ||
                        response?.Response?.Loads ||
                        response?.Orders ||
                        response?.Loads ||
                        [];
                    const items = upperCaseArray(rawItems);
                    if (response?.Response?.LoadHeaders) {
                        response.Response.LoadHeaders = items;
                    } else if (response?.Response?.Loads) {
                        response.Response.Loads = items;
                    } else if (response?.Orders) {
                        response.Orders = items;
                    } else if (response?.Loads) {
                        response.Loads = items;
                    }
                    if (Array.isArray(items)) {
                        items.forEach((Loads: any) => {
                            Object.keys(Loads).forEach((key) => {
                                if (LoadColumns[key]?.type === 'date') {
                                    Loads[key] = stringToDate(Loads[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    createLoad(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'loads',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    updateLoad(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'loads',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    deleteLoad(data: any) {
        return this.httpClient.delete(
            this.config.appConfig()?.OutUrl + 'loads/loads',
            {
                headers: this.authService.getAuthHeaders(),
                body: Array.isArray(data) ? data : lowerCaseObject(data),
            },
        );
    }

    shipLoad(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Loads/Ship/loads',
            lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
