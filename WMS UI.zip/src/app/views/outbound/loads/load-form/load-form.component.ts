import {
    Component,
    DestroyRef,
    computed,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import { selectOption } from '../../../../common/models';
import { AuthService, OptionsService } from '../../../../common/services';
import { TabsModule } from 'primeng/tabs';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import {
    InputDatepickerComponent,
    InputNumberComponent,
    InputSelectComponent,
    InputTextComponent,
} from '../../../../common/components';
import { LoadColumns } from '../load.columns';
import { DatePickerModule } from 'primeng/datepicker';
import { MessageService } from 'primeng/api';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { CommonModule } from '@angular/common';
import { LayoutService } from '../../../../layout/service/layout.service';
import {
    upperCaseArray,
    upperCaseObject,
} from '../../../../shared/utils/case-conversion.util';
@Component({
    selector: 'load-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        Select,
        ButtonModule,
        DatePickerModule,
        TabsModule,
        InputDatepickerComponent,
        InputNumberComponent,
        InputTextComponent,
        InputSelectComponent,
        AppTranslatePipe,
        CommonModule,
    ],
    templateUrl: './load-form.component.html',
    styleUrl: './load-form.component.scss',
})
export class LoadFormComponent {
    OrderData = input<any>();
    private destoryRef = inject(DestroyRef);
    private authservice = inject(AuthService);
    private optionService = inject(OptionsService);
    private router = inject(Router);
    private ref = inject(DynamicDialogRef);
    private messageService = inject(MessageService);
    loading = signal(false);
    // ✅ Single signal for tab validation warning
    setViewTAb = signal<boolean>(true);
    // ✅ Single signal for active tab
    activeTab = signal<number>(0);
    loadColumns: any[] = [];
    formControlsArray = signal(
        Object.values(LoadColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    form = new FormGroup(this.formControls());
    ownerOptions = signal<selectOption[]>([]);
    typeOptions = signal<selectOption[]>([]);
    carrierOptions = signal<selectOption[]>([]);
    doorOptions = signal<selectOption[]>([]);
    LayoutService = inject(LayoutService);
    isDarkTheme = computed(() => this.LayoutService.layoutConfig().darkTheme);
    // ✅ Navigate to tab
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    closePanel() {
        this.ref.close();
    }
    ngOnInit() {
        this.GetOwnerOptions();
        this.GetTypeOptions();
        this.GetCarrierOptions();
        this.handleCarrierSelection();
        this.GetDoorOptions();
        this.getColumns();

        if (this.OrderData()) {
            const rawData = upperCaseObject(this.OrderData());
            Object.values(LoadColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.form.controls[column.field]?.disable();
            });
            this.form.patchValue({
                ...rawData,
                ORDERDATE: rawData?.ORDERDATE ? new Date(rawData.ORDERDATE) : null,
                EXT_UDF_DATE1: rawData?.EXT_UDF_DATE1
                    ? new Date(rawData.EXT_UDF_DATE1)
                    : null,
                EXT_UDF_DATE2: rawData?.EXT_UDF_DATE2
                    ? new Date(rawData.EXT_UDF_DATE2)
                    : null,
                EXT_UDF_DATE3: rawData?.EXT_UDF_DATE3
                    ? new Date(rawData.EXT_UDF_DATE3)
                    : null,
                EXT_UDF_DATE4: rawData?.EXT_UDF_DATE4
                    ? new Date(rawData.EXT_UDF_DATE4)
                    : null,
                EXT_UDF_DATE5: rawData?.EXT_UDF_DATE5
                    ? new Date(rawData.EXT_UDF_DATE5)
                    : null,
                LOADDATE: rawData?.LOADDATE
                    ? new Date(rawData.LOADDATE)
                    : rawData?.LoadDate
                      ? new Date(rawData.LoadDate)
                      : null,
            });
        } else {
            Object.values(LoadColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.form.controls[column.field]?.disable();
                this.form.patchValue({
                    Type: this.OrderData(),
                });
            });
        }
    }
    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    handleCarrierSelection() {
        this.form
            .get('CARRIERID')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedTrader: any = this.carrierOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (selectedTrader) {
                    this.form.patchValue({
                        CARRIERNAME: selectedTrader.COMPANY || selectedTrader.Company || '',
                    });
                }
            });
    }
    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    GetDoorOptions() {
        const subscription = this.optionService
            .getLocation()
            .pipe()
            .subscribe({
                next: (data) => {
                    const doorLocations = data.filter(
                        (item: any) => item.LocationTypeDesc === 'Door',
                    );
                    this.doorOptions.set(
                        doorLocations.map((x: any) => ({
                            ...x,
                            label: x.Loc,
                            value: x.Loc,
                        })),
                    );
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    GetTypeOptions() {
        const subscription = this.optionService
            .getReceiptTypeOptions()
            .subscribe({
                next: (data) => {
                    this.typeOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    GetCarrierOptions() {
        const subscription = this.optionService.getCarrierOptions().subscribe({
            next: (data) => {
                this.carrierOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    onCancel() {
        this.ref.close();
    }
    onSubmit() {
        if (this.form.valid) {
            this.setViewTAb.set(true);
            this.ref.close(this.form.getRawValue());
            this.form.reset();
        } else {
            this.setViewTAb.set(false);
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
    getColumns() {
        this.optionService.getColumns(LoadColumns, 'LOAD').subscribe({
            next: (data) => {
                this.loadColumns = data.map((x: any) => {
                    if (x.field === 'EXT_UDF_DATETIME1') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE1',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME2') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE2',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME3') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE3',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME4') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE4',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME5') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE5',
                        };
                    } else {
                        return x;
                    }
                });
            },
        });
    }
}
