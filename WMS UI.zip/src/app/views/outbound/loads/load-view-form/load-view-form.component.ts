import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { Select } from 'primeng/select';
import {
    InputDatepickerComponent,
    InputNumberComponent,
    InputSelectComponent,
    InputTextComponent,
} from '../../../../common/components';
import { InputTextModule } from 'primeng/inputtext';
import { TabsModule } from 'primeng/tabs';
import { DatePickerModule } from 'primeng/datepicker';
import { LoadService } from '../load.service';
import { HttpErrorResponse } from '@angular/common/http';
import { MessageService } from 'primeng/api';
import { finalize } from 'rxjs';
import { Load } from '../load.model';
import { LoadColumns } from '../load.columns';
import { AccordionModule } from 'primeng/accordion';
import { OptionsService } from '../../../../common/services';
import { selectOption } from '../../../../common/models';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { upperCaseObject } from '../../../../shared/utils/case-conversion.util';

@Component({
    selector: 'app-load-view-form',
    imports: [
        Select,
        ButtonModule,
        ReactiveFormsModule,
        InputTextComponent,
        InputTextModule,
        InputDatepickerComponent,
        InputSelectComponent,
        InputNumberComponent,
        TabsModule,
        DatePickerModule,
        AppTranslatePipe, ],
    templateUrl: './load-view-form.component.html',
    styleUrl: './load-view-form.component.scss',
})
export class LoadViewFormComponent {
    private loadService = inject(LoadService);
    private messageService = inject(MessageService);
    private destroyRef = inject(DestroyRef);
    LoadId = input.required<any>();
    doorOptions = signal<selectOption[]>([]);
    carrierOptions = signal<selectOption[]>([]);
    private optionService = inject(OptionsService);
    loadDetail = signal<any>([]);
    formControlsArray = signal(
        Object.values(LoadColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    form = new FormGroup(this.formControls());

    ngOnInit() {
        this.GetCarrierOptions();
        this.GetDoorOptions();
        Object.values(LoadColumns).forEach((column) => {
            if (column) this.form.controls[column.field].disable();
        });
        if (this.LoadId()) {
            this.getLoaddetails(this.LoadId());
        }

        setTimeout(() => {}, 3000);
    }
    getLoaddetails(data: any) {
        const subscription = this.loadService
            .getLoad(data)
            .pipe()
            .subscribe({
                next: (res) => {
                    const rawDetail = upperCaseObject(res.Response);
                    this.loadDetail.set(rawDetail);
                    this.form.patchValue({
                        ...rawDetail,
                        EXT_UDF_DATE1: rawDetail?.EXT_UDF_DATE1
                            ? new Date(rawDetail.EXT_UDF_DATE1)
                            : null,
                        EXT_UDF_DATE2: rawDetail?.EXT_UDF_DATE2
                            ? new Date(rawDetail.EXT_UDF_DATE2)
                            : null,
                        EXT_UDF_DATE3: rawDetail?.EXT_UDF_DATE3
                            ? new Date(rawDetail.EXT_UDF_DATE3)
                            : null,
                        EXT_UDF_DATE4: rawDetail?.EXT_UDF_DATE4
                            ? new Date(rawDetail.EXT_UDF_DATE4)
                            : null,
                        LOADDATE: rawDetail?.LOADDATE
                            ? new Date(rawDetail.LOADDATE)
                            : rawDetail?.LoadDate
                              ? new Date(rawDetail.LoadDate)
                              : null,
                    });
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Load list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetCarrierOptions() {
        const subscription = this.optionService.getCarrierOptions().subscribe({
            next: (data) => {
                this.carrierOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetDoorOptions() {
        const subscription = this.optionService
            .getLocation()
            .pipe()
            .subscribe({
                next: (data) => {
                    const doorLocations = data.filter(
                        (item: any) => item.LocationTypeDesc === 'Door',
                    );
                    this.doorOptions.set(
                        doorLocations.map((x: any) => ({
                            ...x,
                            label: x.Loc,
                            value: x.Loc,
                        })),
                    );
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
}
