import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { LoadLines } from './load-lines.model';
import { AppConfigService } from '../../../../../app.config.service';
import { AuthService } from '../../../../common/services';
import { ResponseDto } from '../../../../common/models';
import { map } from 'rxjs';
import {
    lowerCaseArray,
    lowerCaseObject,
    upperCaseArray,
    upperCaseObject,
} from '../../../../shared/utils/case-conversion.util';

@Injectable({
    providedIn: 'root',
})
export class LoadLineService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getLoadDetails(LoadID: string) {
        return this.httpClient
            .get(
                this.config.appConfig()?.OutUrl + `loads?LoadID=${LoadID}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res: any) => ({
                    ...res,
                    Response: upperCaseObject(res?.Response),
                })),
            );
    }
    getLoadLines(LoadID: string) {
        return this.httpClient
            .get<ResponseDto<LoadLines[]>>(
                this.config.appConfig()?.OutUrl + `loads/lines?LoadID=${LoadID}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res: any) => ({
                    ...res,
                    Response: {
                        ...res?.Response,
                        LoadLines: upperCaseArray(res?.Response?.LoadLines || []),
                    },
                })),
            );
    }
    createLoadLines(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'Loads/Lines',
            Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data),
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    loadSingle(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Loads/Load',
            lowerCaseObject(data),
            { headers: this.authService.getAuthHeaders() },
        );
    }

    loadAll(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Loads/LoadLines',
            lowerCaseObject(data),
            { headers: this.authService.getAuthHeaders() },
        );
    }

    unloadbyId(data: { LoadLines: { load: string; loadId: string }[] }) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Loads/UnLoad',
            lowerCaseObject(data),
            { headers: this.authService.getAuthHeaders() },
        );
    }

    UnloadAll(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Loads/UnLoadLines',
            lowerCaseObject(data),
            { headers: this.authService.getAuthHeaders() },
        );
    }

    DeleteLoadsLines(data: any) {
        return this.httpClient.delete(
            this.config.appConfig()?.OutUrl + 'Loads/Lines',
            {
                headers: this.authService.getAuthHeaders(),
                body: Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data),
            },
        );
    }
}
