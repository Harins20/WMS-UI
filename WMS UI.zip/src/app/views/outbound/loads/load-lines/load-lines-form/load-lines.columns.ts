import { Validators } from '@angular/forms';
import { Columns } from '../../../../../common/models';

export const LoadlinesColumns: Columns = {
    ORDERLINENUMBER: {
        label: 'Line No',
        field: 'ORDERLINENUMBER',
        type: 'text',
        restrictInsert: true,
        restrictEdit: true,
    },
    SERIALKEY: {
        label: 'SERIALKEY',
        field: 'SERIALKEY',
        type: 'text',
        restrictEdit: true,
        tableHidden: true,
    },
    SKU: {
        label: 'Sku',
        field: 'SKU',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(50)],
        restrictEdit: true,
    },
    traderkey: {
        label: 'traderkey',
        field: 'TRADERKEY',
        type: 'text',
        restrictInsert: true,
        restrictEdit: true,
    },
    StdDesc: {
        label: 'Status',
        field: 'STDDESC',
        type: 'text',
        restrictInsert: true,
        restrictEdit: true,
    },
    PICKDETAILKEY: {
        label: 'PickDetailKey',
        field: 'PICKDETAILKEY',
        type: 'text',
        restrictInsert: true,
        restrictEdit: true,
    },
    LOT: {
        label: 'LOT',
        field: 'LOT',
        type: 'text',
        restrictInsert: true,
        restrictEdit: true,
    },

    LOC: {
        label: 'Location',
        field: 'LOC',
        type: 'select',
        defaultValue: 'New',
        restrictInsert: true,
        restrictEdit: true,
    },
    EDITWHO: {
        label: 'Edit Who',
        field: 'EDITWHO',
        type: 'select',
        defaultValue: 'New',
        restrictInsert: true,
        restrictEdit: true,
    },
    EDITDATE: {
        label: 'Edit Date',
        field: 'EDITDATE',
        type: 'date',
    },
    ADDWHO: {
        label: 'Add Who',
        field: 'ADDWHO',
        validators: [Validators.maxLength(50)],
        defaultValue: '0',
    },
    AddDate: {
        label: 'Add Date',
        field: 'ADDDATE',
        type: 'date',
    },
};
