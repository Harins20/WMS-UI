import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { PrimeNG } from 'primeng/config';
import { TooltipModule } from 'primeng/tooltip';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { MenuItem, MessageService } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { Table, TableModule } from 'primeng/table';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    LoadingComponent,
    CustomTableComponent,
} from '../../../../../common/components';

import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { ToolbarModule } from 'primeng/toolbar';

import { LoadlinesColumns } from './load-lines.columns';
import { LoadLineCreationService } from './load-lines.service';
import { TagModule } from 'primeng/tag';

@Component({
    selector: 'load-lines-form',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        TagModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTableComponent,
    ],
    templateUrl: './load-lines-form.component.html',
    styleUrl: './load-lines-form.component.scss',
})
export class LoadLinesFormComponent {
    private translate = inject(TranslateService);
    LoadPallets = signal([]);
    LoadId = input<any>();
    selectedLoadPallets = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    columns = signal(
        Object.values(LoadlinesColumns).filter((column) => !column.tableHidden),
    );
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    ngAfterViewInit() {
        this.columns.update((columns) =>
            columns.map((column: any) => {
                if (column.field === 'STDDESC' || column.field === 'StdDesc') {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }

                return column;
            }),
        );
    }
    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    private messageService = inject(MessageService);
    private LoadLineCreationService = inject(LoadLineCreationService);
    private destoryRef = inject(DestroyRef);
    private LoadLineFormRef = inject(DynamicDialogRef);

    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    constructor() {}
    ngOnInit() {
        this.getLoadPallets(this.LoadId());
        this.columns.update((columns) =>
            columns.map((column: any) => {
                console.log(columns);
                if (column.field === 'STDDESC' || column.field === 'StdDesc') {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }

                return column;
            }),
        );
    }

    getLoadPallets(loadId: any) {
        this.loading.set(true);
        this.LoadPallets.set([]);
        const subscription = this.LoadLineCreationService.getLoadPallets(loadId)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res: any) => {
                    this.LoadPallets.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            SERIALKEY: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Load Pallets List',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table, loadId: any) {
        table.clear();
        this.searchInput.set(undefined);
        this.getLoadPallets(loadId);
    }
    exportCSV() {
        this.dt().exportCSV();
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.LoadPallets().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedLoadPallets().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedLoadPallets().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }
    OnCreatePallets() {
        console.log(this.selectedLoadPallets());
        this.LoadLineFormRef.close(this.selectedLoadPallets());
    }
}
