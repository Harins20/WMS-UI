import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../../../../../../app.config.service';
import { ResponseDto } from '../../../../../common/models';
import { AuthService } from '../../../../../common/services';
import { map } from 'rxjs';
import {
    lowerCaseObject,
    upperCaseArray,
} from '../../../../../shared/utils/case-conversion.util';

@Injectable({
    providedIn: 'root',
})
export class LoadLineCreationService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getLoadPallets(loadId: any) {
        return this.httpClient
            .get(
                this.config.appConfig()?.OutUrl + `loads/pallets?loadId=${loadId}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res: any) => ({
                    ...res,
                    Response: upperCaseArray(res?.Response || []),
                })),
            );
    }
    addLoadPallet(loadPallet: any) {
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'loads/pallets',
            lowerCaseObject(loadPallet),
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
