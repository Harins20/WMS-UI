import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    LoadingComponent,
    CustomTableComponent,
} from '../../../../common/components';
import { tableOptions } from '../../../../common/constants';
import { ExcelDownloadService } from '../../../../common/services/excel-download.service';
import { LoadLinesFormComponent } from './load-lines-form/load-lines-form.component';
import { LoadLinesColumns } from './load-lines.columns';
import { LoadLines } from './load-lines.model';
import { LoadLineService } from './load-lines.service';
import { TooltipModule } from 'primeng/tooltip';
import { TagModule } from 'primeng/tag';
import { ConfirmationDialogComponent } from '../../../../common/components';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-loadlines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        TagModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTableComponent,
    ],
    templateUrl: './load-lines.component.html',
    styleUrl: './load-lines.component.scss',
    providers: [DialogService],
})
export class LoadLineComponent {
    private translate = inject(TranslateService);
    LoadID = input.required<string>();
    loadlines = signal<LoadLines[]>([]);
    searchInput = signal<string | undefined>(undefined);
    loadDetails = signal<{
        StatusDesc: string;
        LOADID?: string;
        EXTERNALID?: string;
        SERIALKEY?: string;
    }>({
        StatusDesc: '',
    });
    selectedLoadLines = signal<any>([]);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    tableEmptyMessage = signal('No data to display.');
    ConfirmationRef: DynamicDialogRef | undefined;
    tableOptions = signal(tableOptions);
    exportFileName = 'LoadLines-List';
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    columns = signal(
        Object.values(LoadLinesColumns).filter((column) => !column.tableHidden),
    );
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    ngAfterViewInit() {
        this.columns.update((columns) =>
            columns.map((column: any) => {
                if (
                    column.field === 'STATUSDESC' ||
                    column.field === 'StatusDesc'
                ) {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }

                return column;
            }),
        );
    }
    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    LoadLineFormRef: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private loadlinesService = inject(LoadLineService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    // mainLoading = signal(false);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    headerButtons: MenuItem[] = [
        {
            label: this.translate.instant('Load'),
            icon: 'pi pi-upload',
            command: () => this.loadAction(),
        },
    ];
    constructor() {}
    ngOnInit() {
        this.getLoadLines();
        this.getLoadDetails();
        this.headerButtons = [
            ...this.headerButtons,
            // ...existing buttons...
        ];

        this.columns.update((columns) =>
            columns.map((column: any) => {
                if (
                    column.field === 'STATUSDESC' ||
                    column.field === 'StatusDesc'
                ) {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }

                return column;
            }),
        );
    }
    getLoadDetails() {
        this.loadDetails.set({ StatusDesc: '' });
        this.loading.set(true);
        const subscription = this.loadlinesService
            .getLoadDetails(this.LoadID())
            .subscribe({
                next: (res: any) => {
                    this.loadDetails.set(res.Response);
                    this.loading.set(false);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Load Details list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getLoadLines() {
        this.loading.set(true);
        this.loadlines.set([]);
        const subscription = this.loadlinesService
            .getLoadLines(this.LoadID())
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res: any) => {
                    const rawLines =
                        res?.Response?.LoadLines || res?.Response || [];
                    this.loadlines.set(
                        rawLines.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Load Lines list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getLoadLines();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.loadlines(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.loadlines(), this.exportFileName);
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.loadlines().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedLoadLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedLoadLines().length > 0 ? true : false,
    );
    isDisabled = computed(() => {
        const status = this.loadlines().some((x) => x.STATUS === '0');
        return status;
    });
    isDisabledUnload = computed(() => {
        const status = this.loadlines().some((x) => x.STATUS === '2');
        return status;
    });
    isDisabledCreate = computed(() => {
        const status = this.loadlines().some((x) => x.STATUS === '9');
        return status;
    });
    nothing = computed(() => (this.loadlines().length != 0 ? true : false));
    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }
    OpenCreateLoadlineForm() {
        const headertext = this.translate.instant('Create Pallet');
        this.LoadLineFormRef = this.dialogService.open(LoadLinesFormComponent, {
            inputValues: {
                LoadId: this.LoadID(),
            },
            header: headertext,
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '55rem',
            style: { maxHeight: '45rem' },
        });
        this.LoadLineFormRef.onClose.subscribe((data: any) => {
            if (data) {
                const headertext = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('LoadLineCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: headertext,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        const FilterData = data.map((x: any) => {
                            return {
                                STORERKEY: x.TRADERKEY || x.traderkey,
                                LOADID: this.loadDetails()?.LOADID,
                                EXTERNALID: this.loadDetails()?.EXTERNALID,
                                STATUS: '0',
                                LOADUNITDETAILID: this.loadDetails()?.SERIALKEY,
                                ORDERKEY: x.ORDERKEY || x.orderkey,
                                ORDERLINENUMBER: x.ORDERLINENUMBER || x.orderlinenumber,
                                PICKDETAILKEY: x.PICKDETAILKEY || x.pickdetailkey,
                                SKU: x.SKU || x.sku,
                                LOT: x.LOT || x.lot,
                                LOC: x.LOC || x.loc,
                                ID: x.ID || x.id,
                            };
                        });

                        this.loadlinesService
                            .createLoadLines(FilterData)
                            .pipe(
                                finalize(() => {
                                    this.getLoadLines();
                                    this.loading.set(false);
                                }),
                            )
                            .subscribe({
                                next: (response: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Order creation',
                                        detail: response.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef = this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New Order creation',
                                            detail: error as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    onEditAction(loadlines: LoadLines) {}

    loadAction() {
        if (this.selectedLoadLines().length > 0) {
            const Rdata = this.selectedLoadLines().map((x: any) =>
                String(x.SERIALKEY),
            );
            this.loading.set(true);
            const requestBody = {
                LOADID: this.LoadID(),
                SerialKeys: Rdata,
            };

            const subscription = this.loadlinesService
                .loadAll(requestBody)
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.selectedLoadLines.set([]);
                        this.getLoadDetails();
                        this.getLoadLines();
                    }),
                )
                .subscribe({
                    next: (response) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Load',
                            detail: 'Loaded successfully.',
                        });
                        this.getLoadDetails();
                    },
                    error: (error) => {
                        if (
                            error.error.Message ===
                                'One or more errors occurred!' ||
                            error.error.message ===
                                'One or more errors occurred!'
                        ) {
                            this.ConfirmationRef = this.dialogService.open(
                                CommonErrorboxComponent,
                                {
                                    inputValues: {
                                        error: error,
                                    },
                                    header: 'Multiple Error',
                                    closable: true,
                                    modal: true,
                                    draggable: true,
                                    keepInViewport: true,
                                    width: '39rem',
                                    style: { maxHeight: '40rem' },
                                },
                            );
                        } else {
                            const errorMessage =
                                error?.error?.message || 'Failed to Load';
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Load',
                                detail: errorMessage,
                            });
                        }
                    },
                });

            this.destroyRef.onDestroy(() => subscription.unsubscribe());
        } else {
            this.messageService.add({
                severity: 'error',
                summary: 'Load',
                detail: 'Please select at least one record to Load.',
            });
        }
    }

    unloadAction() {
        if (this.selectedLoadLines().length > 0) {
            const Rdata = this.selectedLoadLines().map((x: any) =>
                String(x.SERIALKEY),
            );

            const requestBody = {
                LOADID: this.LoadID(),
                SerialKeys: Rdata,
            };
            this.loading.set(true);
            const subscription = this.loadlinesService
                .UnloadAll(requestBody)
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.selectedLoadLines.set([]);
                        this.getLoadDetails();
                        this.getLoadLines();
                    }),
                )
                .subscribe({
                    next: (response) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'UnLoaded',
                            detail: 'UnLoaded successfully.',
                        });
                        this.getLoadDetails();
                    },
                    error: (error) => {
                        if (
                            error.error.Message ===
                                'One or more errors occurred!' ||
                            error.error.message ===
                                'One or more errors occurred!'
                        ) {
                            this.ConfirmationRef = this.dialogService.open(
                                CommonErrorboxComponent,
                                {
                                    inputValues: {
                                        error: error,
                                    },
                                    header: 'Multiple Error',
                                    closable: true,
                                    modal: true,
                                    draggable: true,
                                    keepInViewport: true,
                                    width: '39rem',
                                    style: { maxHeight: '40rem' },
                                },
                            );
                        } else {
                            const errorMessage =
                                error?.error?.message || 'Failed to UnLoad';
                            this.messageService.add({
                                severity: 'error',
                                summary: 'UnLoaded',
                                detail: errorMessage,
                            });
                        }
                    },
                });

            this.destroyRef.onDestroy(() => subscription.unsubscribe());
        } else {
            this.messageService.add({
                severity: 'error',
                summary: 'UnLoaded',
                detail: 'Please select at least one record to UnLoad.',
            });
        }
    }
    DeleteLoadsLines() {
        const headertext = this.translate.instant('Confirm Deletion');
        const count = this.selectedLoadLines().length;
        const name =
            count > 1
                ? this.translate.instant('Load Lines')
                : this.translate.instant('Load Line');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                // duplicate: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const Rdata = this.selectedLoadLines().map((x: any) =>
                    String(x.SERIALKEY),
                );
                this.loading.set(true);
                const requestBody = {
                    LOADID: this.LoadID(),
                    SerialKeys: Rdata,
                };

                const subscription = this.loadlinesService
                    .DeleteLoadsLines(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedLoadLines.set([]);
                            this.getLoadDetails();
                            this.getLoadLines();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Deleted',
                                detail: 'Deleted successfully.',
                            });
                            this.getLoadDetails();
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    'An unexpected error occurred while deleting the load lines. Please try again later.';
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Deleted',
                                    detail: errorMessage,
                                });
                            }
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
