export interface LoadLines {
    ADDDATE: Date;
    ADDWHO: string;
    CARRIERCODE?: string;
    CARRIERNAME?: string;
    DOOR?: string;
    DRIVERNAME?: string;
    EDITDATE?: Date;
    EDITWHO?: string;
    EXTERNALID: string;
    LOADDATE?: Date;
    LOADID: string;
    PRONUMBER?: string;
    SERIALKEY: number;
    STATUS: string;
    STATUSDESC?: string;
    STDDESC?: string;
    StatusDesc?: string;
    TRAILERNUMBER?: string;
    UDF1?: string;
    UDF2?: string;
    UDF3?: string;
    UDF4?: string;
    UDF5?: string;
}
