import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule, FormGroup, FormControl } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { filterQuery } from '../../../common/functions';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { LoadColumns } from './load.columns';
import { Load } from './load.model';
import { LoadService } from './load.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../common/components';
import { Route, Router } from '@angular/router';
import { LoadFormComponent } from './load-form/load-form.component';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { TabService } from '../../../tabs/tab.service';
import outboundRoutes from '../outbound.routes';
import { tableOptions } from '../../../common/constants';
import { TagModule } from 'primeng/tag';
import { TreeModule } from 'primeng/tree';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';

import { OptionsService } from '../../../common/services';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
@Component({
    selector: 'app-loads',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TagModule,
        TooltipModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './loads.component.html',
    styleUrl: './loads.component.scss',
    providers: [DialogService],
})
export class LoadsComponent {
    private translate = inject(TranslateService);
    loads = signal<Load[]>([]);
    loadsExcel = signal<Load[]>([]);
    loadlineType = signal('Order');
    selectedLoad = signal<any>([]);
    loading = signal(true);
    searchInput = signal<string | undefined>(undefined);
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(20);
    // mainLoading = signal(false);
    ConfirmationRef: DynamicDialogRef | undefined;
    dt = viewChild.required<Table>('dt');
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    exportFileName = 'Loads-List';
    columns = signal<any>([]);
    OriginalColumns = signal<any>(LoadColumns);
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    globalFilterColumns = computed(() =>
        this.columns().map((x: any) => x.field),
    );

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    userFormRef: DynamicDialogRef | undefined;
    private router = inject(Router);
    private messageService = inject(MessageService);
    private loadService = inject(LoadService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    private tabService = inject(TabService);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    form: FormGroup;
    private optionService = inject(OptionsService);

    constructor() {
        this.form = new FormGroup({});
    }

    ngOnInit() {
        // this.getLoadPage();
        this.getColumns();

        if (this.selectedLoad()) {
            Object.values(LoadColumns).forEach((column) => {
                if (column.restrictEdit && this.form.controls[column.field]) {
                    this.form.controls[column.field].disable();
                }
            });
            this.form.patchValue({
                ...this.selectedLoad(),
                ORDERDATE: new Date(this.selectedLoad().ORDERDATE),
            });
        } else {
            Object.values(LoadColumns).forEach((column) => {
                if (column.restrictInsert && this.form.controls[column.field]) {
                    this.form.controls[column.field].disable();
                }
                this.form.patchValue({
                    Type: this.loadlineType(),
                });
            });
        }
    }
    getColumns() {
        this.optionService.getColumns(LoadColumns, 'LOAD').subscribe({
            next: (data) => {
                const FilterField = data.map((x: any) => x.field);
                FilterField.push('EXT_UDF_DATE1');
                FilterField.push('EXT_UDF_DATE2');
                FilterField.push('EXT_UDF_DATE3');
                FilterField.push('EXT_UDF_DATE4');
                FilterField.push('EXT_UDF_DATE5');

                const GetFilterFields = Object.values(LoadColumns).filter(
                    (x: any) => {
                        return !FilterField.includes(x.field);
                    },
                );

                const filter = data.map((x: any) => {
                    if (x.field === 'EXT_UDF_DATETIME1') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE1',
                            dateFormate: 'short',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME2') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE2',
                            dateFormate: 'short',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME3') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE3',
                            dateFormate: 'short',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME4') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE4',
                            dateFormate: 'short',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME5') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE5',
                            dateFormate: 'short',
                        };
                    } else {
                        return x;
                    }
                });
                const columns = [...GetFilterFields, ...filter];
                let updatedColumns = columns;
                updatedColumns = updatedColumns.map((column: any) => {
                    if (
                        column.field === 'EXT_UDF_DATE1' ||
                        column.field === 'EXT_UDF_DATE2' ||
                        column.field === 'EXT_UDF_DATE3' ||
                        column.field === 'EXT_UDF_DATE4' ||
                        column.field === 'EXT_UDF_DATE5'
                    ) {
                        return {
                            ...column,
                            type: 'date',
                        };
                    }

                    if (
                        column.field === 'STATUSDESC' ||
                        column.field === 'StatusDesc'
                    ) {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                });
                this.columns.set(
                    updatedColumns.filter((column: any) => !column.tableHidden),
                );
            },
        });
    }

    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         LoadColumns,
    //         'vw.',
    //     );
    //     this.getLoadPage({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getLoadPage(event);
    }
    getLoads() {
        this.getLoadPage();
    }

    getLoadPage(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.selectedLoad.set([]);
        this.loads.set([]);
        const subscription = this.loadService
            .getLoadPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    const loadList =
                        res?.Response?.LoadHeaders ||
                        res?.Response?.Loads ||
                        res?.Orders ||
                        res?.Loads ||
                        [];
                    const total =
                        res?.Response?.totalCount ??
                        res?.Response?.TotalCount ??
                        res?.totalRecords ??
                        res?.totalCount ??
                        0;

                    const first = data?.first ?? 0;
                    this.loads.set(
                        loadList.map((x: any, idx: number) => ({
                            ...x,
                            rowId: first + idx + 1,
                        })),
                    );
                    this.totalRecords.set(total);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Load list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getLoadPage();
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getLoadPage();
    }

    getLoadsForExcel(
        data: any = { Page: 1, PageSize: this.totalRecords() },
        type: string,
    ) {
        this.loadsExcel.set([]);
        const subscription = this.loadService
            .getLoadPage(data)
            .pipe()
            .subscribe({
                next: (res: any) => {
                    const loadList =
                        res?.Response?.LoadHeaders ||
                        res?.Response?.Loads ||
                        res?.Orders ||
                        res?.Loads ||
                        [];
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }

                    this.loadsExcel.set(loadList);
                    if (loadList && loadList.length > 0 && type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            loadList,
                        );
                    } else {
                        downloadCSVFile(loadList, this.exportFileName);
                    }
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Loads list for excel',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    export(type: string) {
        const event = this.loadEvent();
        const PageSize = this.totalRecords();
        const Page = (event.first || 0) / PageSize + 1;
        const { filter, orderBy } = filterQuery(
            event,
            this.globalFilterColumns(),
            LoadColumns,
            'vw.',
        );

        this.getLoadsForExcel(
            {
                Page,
                PageSize,
                Condition: filter,
                OrderBy: orderBy,
            },
            type,
        );
    }

    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(this.loads().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedLoad().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedLoad().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    onEditAction(load: Load) {}
    OnDelete() {
        const headertext = this.translate.instant('Confirm Deletion');
        const count = this.selectedLoad().length;
        const name =
            count > 1
                ? this.translate.instant('Loads')
                : this.translate.instant('Load');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const loadIds = this.selectedLoad().map((x: any) => x.LOADID);
                this.loading.set(true);

                const subscription = this.loadService
                    .deleteLoad(loadIds)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedLoad.set([]);
                            this.getLoads();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Delete Loads',
                                detail: 'Loads deleted successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    'An unexpected error occurred while deleting the loads. Please try again later.';
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Delete Loads',
                                    detail: errorMessage,
                                });
                            }
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    OpenCreateLoadForm() {
        const headertext = this.translate.instant('Create Load');
        this.userFormRef = this.dialogService.open(LoadFormComponent, {
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('LoadCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.loadService
                            .createLoad(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getLoads();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Load creation',
                                        detail: data.Response.message as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New Load creation',
                                            detail: error.error
                                                .message as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateOrderForm(data: any) {
        const headertext = this.translate.instant('Update Load');
        const selectedLoad: Load = Array.isArray(data) ? data[0] : data;
        this.userFormRef = this.dialogService.open(LoadFormComponent, {
            inputValues: {
                OrderData: data,
                LoadID: selectedLoad.LOADID,
                EXTERNALID: selectedLoad.EXTERNALID,
            },
            // header: 'Update Receipt - ' + selectedAsn.RECEIPTKEY,
            // closable: true,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },
            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },
            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('LoadUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        const updatedData: Load = {
                            ...data,
                            LoadID: selectedLoad.LOADID,
                            EXTERNALID: selectedLoad.EXTERNALID,
                        };
                        this.loadService
                            .updateLoad(updatedData)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedLoad.set([]);
                                    this.getLoads();
                                }),
                            )
                            .subscribe({
                                next: (response: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Update Load',
                                        detail: response.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Update Load',
                                            detail: error.error
                                                .Message as string,
                                        });
                                    }
                                },
                            });
                    }
                });
            }
        });
    }

    onClickLoadID(row: Load): void {
        const route = outboundRoutes.find(
            (route) => route.data?.name === 'loadline',
        ) as Route;
        var params = [{ name: 'LoadID', value: row.LOADID }];
        this.tabService.addTabWithParams(
            route,
            '',
            'Loadlines - ' + row.LOADID,
            params,
        );
    }

    shipLoad() {
        if (this.selectedLoad().length > 0) {
            const validLines = this.selectedLoad().filter(
                (x: any) =>
                    x.STATUSDESC === 'Loaded' || x.StatusDesc === 'Loaded',
            );
            this.loading.set(true);
            const FilterData = validLines.map((x: any) => {
                return x.LOADID;
            });
            const CreateData = {
                LOADID: FilterData, // Ensure LOADID is included correctly
            };
            if (validLines.length > 0) {
                const subscription = this.loadService
                    .shipLoad(CreateData)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedLoad.set([]);
                            this.getLoads();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Ship Load',
                                detail: 'Load shipped successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    'An error occurred while shipping the load.';
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Ship Load',
                                    detail: errorMessage,
                                });
                            }
                            this.loading.set(false);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            } else {
                this.messageService.add({
                    severity: 'error',
                    summary: 'Load',
                    detail: 'Only Loaded lines can be shipped.',
                });
                this.loading.set(false);
            }
        } else {
            this.messageService.add({
                severity: 'error',
                summary: 'Load',
                detail: 'Please select at least one line to ship.',
            });
        }
    }

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
