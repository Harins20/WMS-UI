import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { ReturnOrders } from './returns.model';
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';
import { map } from 'rxjs';
import { ReturnColumns } from './return.columns';
import { stringToDate } from '../../../common/functions';
import {
    upperCaseArray,
    upperCaseObject,
    lowerCaseObject,
    lowerCaseArray,
} from '../../../shared/utils/case-conversion.util';

interface ReturnPage {
    Returns: ReturnOrders[];
    totalRecords: number;
}

@Injectable({
    providedIn: 'root',
})
export class ReturnsOrderService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getReturn() {
        return this.httpClient
            .get<ResponseDto<ReturnOrders[]>>(
                this.config.appConfig()?.OutUrl + 'returns',
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res) => {
                    if (res?.Response && Array.isArray(res.Response)) {
                        return {
                            ...res,
                            Response: upperCaseArray(res.Response),
                        };
                    }
                    return res;
                }),
            );
    }
    getReturnPage(data: any) {
        return this.httpClient
            .post<ReturnPage>(
                this.config.appConfig()?.OutUrl + 'ReturnsPaged',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response: any) => {
                    const items =
                        response?.Response?.Returns ||
                        response?.Response?.ReturnHeaders ||
                        response?.Response?.Returns ||
                        response?.Orders ||
                        response?.Loads ||
                        response?.Returns ||
                        [];
                    if (Array.isArray(items)) {
                        const uppercasedItems = upperCaseArray(items);
                        uppercasedItems.forEach((Returns: any) => {
                            Object.keys(Returns).forEach((key) => {
                                if (ReturnColumns[key]?.type === 'date') {
                                    Returns[key] = stringToDate(Returns[key]);
                                }
                            });
                        });
                        if (response?.Response?.Returns) {
                            response.Response.Returns = uppercasedItems;
                        } else if (response?.Response?.ReturnHeaders) {
                            response.Response.ReturnHeaders = uppercasedItems;
                        } else if (response?.Returns) {
                            response.Returns = uppercasedItems;
                        } else if (response?.Orders) {
                            response.Orders = uppercasedItems;
                        } else if (response?.Loads) {
                            response.Loads = uppercasedItems;
                        } else if (response?.Response) {
                            response.Response = uppercasedItems;
                        }
                    }
                    return response;
                }),
            );
    }
    getReturnVerify(key: any, value: any) {
        return this.httpClient
            .get<ResponseDto<ReturnOrders[]>>(
                this.config.appConfig()?.OutUrl +
                    `Returns/verify?Key=${key}&Value=${value}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res) => {
                    if (res?.Response) {
                        if (Array.isArray(res.Response)) {
                            return {
                                ...res,
                                Response: upperCaseArray(res.Response),
                            };
                        } else if (typeof res.Response === 'object') {
                            return {
                                ...res,
                                Response: upperCaseObject(res.Response),
                            };
                        }
                    }
                    return res;
                }),
            );
    }
    createReturns(data: any) {
        const payload = Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data);
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'returns',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    updateReturns(data: any) {
        const payload = Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data);
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'returns',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
