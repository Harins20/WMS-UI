import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { CreateReturnLines } from './return-line-creation.model';
import { AuthService } from '../../../../../common/services';
import { ResponseDto } from '../../../../../common/models';
import { AppConfigService } from '../../../../../../app.config.service';
import { map, tap } from 'rxjs';
import {
    upperCaseArray,
    upperCaseObject,
    lowerCaseArray,
    lowerCaseObject,
} from '../../../../../shared/utils/case-conversion.util';

@Injectable({
    providedIn: 'root',
})
export class CreateReturnLineService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getCreateReturnLines(OrderKey: string, Sku: string) {
        return this.httpClient
            .get<ResponseDto<CreateReturnLines[]>>(
                this.config.appConfig()?.OutUrl +
                    `Returns/Lines/PickDetails?ORDERKEY=${OrderKey}&SKU=${Sku}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res) => {
                    if (res?.Response && Array.isArray(res.Response)) {
                        return {
                            ...res,
                            Response: upperCaseArray(res.Response),
                        };
                    }
                    return res;
                }),
            );
    }
    CreateReturnLines(data: any) {
        const payload = Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data);
        return this.httpClient.post<ResponseDto<CreateReturnLines[]>>(
            this.config.appConfig()?.OutUrl + `Returns/Lines`,
            payload,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
