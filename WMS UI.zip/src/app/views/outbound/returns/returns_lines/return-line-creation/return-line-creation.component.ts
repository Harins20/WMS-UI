import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { tableOptions } from '../../../../../common/constants';
import { finalize } from 'rxjs';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { CreateReturnLineService } from './return-line-creation.service';
import { CreateReturnlineColumns } from './return-line-creation.columns';
import { CreateReturnLines } from './return-line-creation.model';
import {
    ColumnPicklistComponent,
    CustomTableComponent,
} from '../../../../../common/components';
import { OptionsService } from '../../../../../common/services';
import { selectOption } from '../../../../../common/models';
import { Select } from 'primeng/select';
import { TabService } from '../../../../../tabs/tab.service';
import { TagModule } from 'primeng/tag';
import { CommonErrorboxComponent } from '../../../../../common/components/common-errorbox/common-errorbox.component';
import { ExcelDownloadService } from '../../../../../common/services/excel-download.service';
import { downloadCSVFile } from '../../../../../common/functions/downloadCSVFile';

import { TooltipModule } from 'primeng/tooltip';
import { ReturnLinesComponent } from '../return-lines.component';

@Component({
    selector: 'app-create-return-lines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        Select,
        TagModule,
        AppTranslatePipe,
        TooltipModule,
        CustomTableComponent,
    ],
    templateUrl: './return-line-creation.component.html',
    styleUrl: './return-line-creation.component.scss',
    providers: [DialogService, ReturnLinesComponent],
})
export class CreateReturnLinesComponent {
    private translate = inject(TranslateService);
    createreturnlines = input.required<string>();
    ReturnID = input.required<string>();
    ReturnIDLine = input.required<string>();
    OrderKey = input.required<string>();
    Sku = input.required<string>();
    id = input.required<number>();
    createreturnLines = signal<CreateReturnLines[]>([]);
    selectedCreateReturnLines = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);

    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');

    toLocTemplate = viewChild.required<TemplateRef<any>>('toLocTemplate');
    toLocOutputTemplate = viewChild.required<TemplateRef<any>>(
        'toLocOutputTemplate',
    );

    rtnQtyTemplate = viewChild.required<TemplateRef<any>>('rtnQtyTemplate');
    rtnQtyOutputTemplate = viewChild.required<TemplateRef<any>>(
        'rtnQtyOutputTemplate',
    );

    columns = computed(() => {
        const toLocTpl = this.toLocTemplate();
        const toLocOutTpl = this.toLocOutputTemplate();

        const rtnQtyTpl = this.rtnQtyTemplate();
        const rtnQtyOutTpl = this.rtnQtyOutputTemplate();

        const statusTpl = this.customStatusCellTemplate();

        return Object.values(CreateReturnlineColumns)
            .filter((column) => !column.tableHidden)
            .map((col) => {
                if (col.field === 'TOLOC') {
                    return {
                        ...col,
                        editable: true,
                        customCellTemplate: toLocTpl,
                        customOutputTemplate: toLocOutTpl,
                    };
                }

                if (col.field === 'RTNQTY') {
                    return {
                        ...col,
                        editable: true,
                        customCellTemplate: rtnQtyTpl,
                        customOutputTemplate: rtnQtyOutTpl,
                    };
                }

                if (col.field === 'STDDESC' || col.field === 'STATUS_DESC') {
                    return {
                        ...col,
                        editable: false,
                        customCellTemplate: statusTpl,
                    };
                }

                return col;
            });
    });
    ConfirmationRef: DynamicDialogRef | undefined;

    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    userFormRef: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private tabService = inject(TabService);
    private createreturnlineService = inject(CreateReturnLineService);
    private destroyRef = inject(DestroyRef);
    private optionService = inject(OptionsService);
    private excelDownloadService = inject(ExcelDownloadService);
    locationOptions = signal<selectOption[]>([]);
    private linecomponent = inject(ReturnLinesComponent);

    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    constructor() {}
    ngOnInit() {
        this.GetLocationOptions();
        if (this.OrderKey() && this.Sku()) {
            this.getCreateReturnLines(this.OrderKey(), this.Sku());
        } else {
            console.error('Missing OrderKey or Sku');
        }
    }

    getCreateReturnLines(OrderKey: string, Sku: string) {
        this.loading.set(true);
        this.createreturnLines.set([]);

        const subscription = this.createreturnlineService
            .getCreateReturnLines(OrderKey, Sku)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res) => {
                    this.createreturnLines.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                            RTNQTY: (x.QTY ?? 0) - (x.QTYRETURNED ?? 0),
                        })),
                    );
                    if (
                        Array.isArray(res.Response) &&
                        res.Response.length === 0
                    ) {
                        setTimeout(() => {
                            this.linecomponent.refresh();
                            this.tabService.removeTab(this.id());
                        }, 5000);
                    }
                },
                error: (error: HttpErrorResponse) => {
                    if (!error.error?.success) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Return Lines list',
                            detail: 'Network error occurred. Please check your internet connection and contact the administrator if required.',
                        });
                        setTimeout(() => {
                            this.linecomponent.refresh();
                            this.tabService.removeTab(this.id());
                        }, 5000);
                    }
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table, OrderKey: string, Sku: string) {
        table.clear();
        this.searchInput.set(undefined);
        this.getCreateReturnLines(OrderKey, Sku);
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            'Create Return Lines-list',
            [],
            this.createreturnLines(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.createreturnLines(), 'Create Return Lines-list');
    }

    options(field: string) {
        const uniqueValues = new Set(
            this.createreturnLines().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedCreateReturnLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedCreateReturnLines().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }
    OnClickAddtoReturns() {
        if (this.selectedCreateReturnLines().length === 0) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Add Returns',
                detail: 'Please select at least one return line to add.',
            });
            this.loading.set(true);
            return;
        }
        if (
            this.selectedCreateReturnLines().every(
                (x: any) => x.RTNQTY <= (x.REMAININGQTY ?? x.QTY),
            )
        ) {
            this.loading.set(true);
            const requestBody = this.selectedCreateReturnLines().map(
                (x: any) => ({
                    TRADERKEY: x.TRADERKEY || x.STORERKEY,
                    RETURNID: this.ReturnID(),
                    ORDERKEY: this.OrderKey(),
                    ORDERLINENUMBER: x.ORDERLINENUMBER,
                    PICKDETAILKEY: x.PICKDETAILKEY,
                    SKU: x.SKU,
                    LOT: x.LOT,
                    LOC: x.LOC,
                    TOLOC: x.TOLOC || x.LOC,
                    ID: x.ID,
                    RTNQTY: x.RTNQTY,
                    STATUS: x.STATUS,
                    ACTUALSHIPDATE: new Date().toISOString(),
                    SHIPQTY: x.QTY,
                }),
            );

            const subscription = this.createreturnlineService
                .CreateReturnLines(requestBody)
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.getCreateReturnLines(this.OrderKey(), this.Sku());
                        this.selectedCreateReturnLines.set([]);
                    }),
                )
                .subscribe({
                    next: (response) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Add Returns',
                            detail: 'Return lines added successfully.',
                        });
                    },
                    error: (error: HttpErrorResponse) => {
                        if (
                            error.error.Message ===
                                'One or more errors occurred!' ||
                            error.error.message ===
                                'One or more errors occurred!'
                        ) {
                            this.ConfirmationRef = this.dialogService.open(
                                CommonErrorboxComponent,
                                {
                                    inputValues: {
                                        error: error,
                                    },
                                    header: 'Multiple Error',
                                    closable: true,
                                    modal: true,
                                    draggable: true,
                                    keepInViewport: true,
                                    width: '39rem',
                                    style: { maxHeight: '40rem' },
                                },
                            );
                        } else {
                            const errorMessage =
                                error.status === 0
                                    ? 'Network error occurred. Please check your internet connection.'
                                    : error.error?.Message ||
                                      'Failed to add return lines.';
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Add Returns',
                                detail: errorMessage,
                            });
                        }
                        this.loading.set(false);
                    },
                });

            this.destroyRef.onDestroy(() => subscription.unsubscribe());
        } else {
            this.messageService.add({
                severity: 'warn',
                summary: 'Add Returns',
                detail: 'Return quantity cannot be greater than quantity.',
            });
        }
    }

    GetLocationOptions() {
        const subscription = this.optionService.getLocationOptions().subscribe({
            next: (data) => {
                this.locationOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching Location dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    onEditAction(createreturnlines: CreateReturnLines) {}
}
