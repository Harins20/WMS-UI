import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    Injectable,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { ReturnlineColumns } from './return-lines.columns';
import { ReturnLines } from './return-lines.models';
import { ReturnLineService } from './return-lines.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
    CustomTableComponent,
} from '../../../../common/components';
import { TagModule } from 'primeng/tag';
import { ReturnLineFormComponent } from './return-lines-form/return-lines-form.component';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';
import { ExcelDownloadService } from '../../../../common/services/excel-download.service';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';

@Injectable({
    providedIn: 'root',
})
@Component({
    selector: 'app-returnlines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        TagModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTableComponent,
    ],
    templateUrl: './return-lines.component.html',
    styleUrl: './return-lines.component.scss',
    providers: [DialogService],
})
export class ReturnLinesComponent {
    private translate = inject(TranslateService);
    actions: MenuItem[] = [
        {
            label: this.translate.instant('Accept'),
            command: () => this.acceptReturn(),
        },
        {
            label: this.translate.instant('Reject'),
            command: () => this.rejectReturn(),
        },
    ];
    returnorders = input.required<string>();
    returnlines = input.required<string>();
    ReturnID = input.required<string>();
    OrderKey = input.required<string>();
    returnLines = signal<ReturnLines[]>([]);
    selectedReturnLines = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    exportFileName = 'Return Lines';
    // mainLoading = signal(false);
    dt = viewChild.required<Table>('dt');
    columns = signal(
        Object.values(ReturnlineColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    userFormRef: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private returnlineService = inject(ReturnLineService);
    private destroyRef = inject(DestroyRef);
    ConfirmationRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private excelDownloadService = inject(ExcelDownloadService);
    constructor() {}
    ngOnInit() {
        this.getReturnLines();
    }
    ngAfterViewInit() {
        this.columns.update((columns) =>
            columns.map((column: any) => {
                if (column.field === 'STATUSDESC') {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }

                return column;
            }),
        );
    }
    getReturnLines() {
        this.loading.set(true);
        this.returnLines.set([]);
        const subscription = this.returnlineService
            .getReturnLines(this.ReturnID())
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res) => {
                    this.returnLines.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        })),
                    );
                },
                error: (error: HttpErrorResponse) => {
                    const errorMessage =
                        error.status === 0
                            ? 'Network error occurred. Please check your internet connection.'
                            : error.error?.Message ||
                              'Failed to fetch return lines.';
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Return Lines',
                        detail: errorMessage,
                    });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    hasAcceptedReturnLines = computed(() => {
        const lines = this.returnLines();
        if (!lines || lines.length === 0) return false;
        return lines.some(
            (line) =>
                line.STATUS_DESC === 'Accepted' ||
                line.STATUS_DESC === 'Rejected',
        );
    });

    acceptReturn() {
        const headertext = this.translate.instant('Accept Return');
        const value = this.translate.instant('ReturnAccept');
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                if (this.selectedReturnLines().length > 0) {
                    this.loading.set(true);
                    const Rdata = this.selectedReturnLines().map(
                        (x: any) => x.SERIALKEY,
                    );
                    const requestBody = {
                        ReturnId: this.ReturnID(),
                        SerialKeys: Rdata,
                    };
                    const subscription = this.returnlineService
                        .acceptReturnsLines(requestBody)
                        .pipe(
                            finalize(() => {
                                this.loading.set(false);
                                this.selectedReturnLines.set([]);
                                this.getReturnLines();
                            }),
                        )
                        .subscribe({
                            next: () => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Return Accept',
                                    detail: 'Return order accepted successfully.',
                                });
                            },
                            error: (error) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef = this.dialogService.open(
                                        CommonErrorboxComponent,
                                        {
                                            inputValues: {
                                                error: error,
                                            },
                                            header: 'Multiple Error',
                                            closable: true,
                                            modal: true,
                                            draggable: true,
                                            keepInViewport: true,
                                            width: '39rem',
                                            style: { maxHeight: '40rem' },
                                        },
                                    );
                                } else {
                                    const errorMessage =
                                        error?.error?.message ||
                                        'Failed to accept return order.';
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Return Accept',
                                        detail: errorMessage,
                                    });
                                }
                            },
                        });

                    this.destroyRef.onDestroy(() => subscription.unsubscribe());
                } else {
                    const subscription = this.returnlineService
                        .acceptReturn(this.ReturnID())
                        .subscribe({
                            next: () => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Return Accept',
                                    detail: 'Return order accepted successfully.',
                                });
                                this.getReturnLines();
                            },
                            error: (error) => {
                                const errorMessage =
                                    error?.error?.message ||
                                    'Failed to accept return order.';
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Return Accept',
                                    detail: errorMessage,
                                });
                            },
                        });
                }
            }
        });
    }

    rejectReturn() {
        const headertext = this.translate.instant('Reject Return');
        const value = this.translate.instant('ReturnReject');
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                if (this.selectedReturnLines().length > 0) {
                    this.loading.set(true);
                    const Rdata = this.selectedReturnLines().map(
                        (x: any) => x.SERIALKEY,
                    );
                    const requestBody = {
                        ReturnId: this.ReturnID(),
                        SerialKeys: Rdata,
                    };

                    const subscription = this.returnlineService
                        .rejectReturnsLines(requestBody)
                        .pipe(
                            finalize(() => {
                                this.loading.set(false);
                                this.selectedReturnLines.set([]);
                                this.getReturnLines();
                            }),
                        )
                        .subscribe({
                            next: (response) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: ' Return Order',
                                    detail: ' Return Order Reject successfully.',
                                });
                            },
                            error: (error) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef = this.dialogService.open(
                                        CommonErrorboxComponent,
                                        {
                                            inputValues: {
                                                error: error,
                                            },
                                            header: 'Multiple Error',
                                            closable: true,
                                            modal: true,
                                            draggable: true,
                                            keepInViewport: true,
                                            width: '39rem',
                                            style: { maxHeight: '40rem' },
                                        },
                                    );
                                } else {
                                    const errorMessage =
                                        error?.error?.message ||
                                        'Failed to reject return order.';
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Return Order',
                                        detail: errorMessage,
                                    });
                                }
                                this.loading.set(false);
                            },
                        });

                    this.destroyRef.onDestroy(() => subscription.unsubscribe());
                } else {
                    const subscription = this.returnlineService
                        .rejectReturn(this.ReturnID())
                        .subscribe({
                            next: () => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Return rejected',
                                    detail: 'Return order rejected successfully.',
                                });
                                this.getReturnLines();
                            },
                            error: (error) => {
                                const errorMessage =
                                    error?.error?.message ||
                                    'Failed to accept return order.';
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Return Accept',
                                    detail: errorMessage,
                                });
                            },
                        });
                }
            }
        });
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table?: Table) {
        table?.clear();
        this.searchInput.set(undefined);
        this.getReturnLines();
    }
    // exportCSV() {
    //     this.dt().exportCSV();
    // }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.returnLines(),
        );
    }
    exportCSV() {
        downloadCSVFile(this.returnLines(), this.exportFileName);
    }
    // deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.returnLines().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedReturnLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedReturnLines().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }
    OpenCreateReturnslineForm() {
        try {
            this.userFormRef = this.dialogService.open(
                ReturnLineFormComponent,
                {
                    inputValues: {
                        ReturnID: this.ReturnID(),
                        ReturnIDLine: this.ReturnID(),
                        OrderKey: this.OrderKey(),
                    },
                    header: 'Create Return Line',
                    closable: true,
                    modal: true,
                    draggable: true,
                    keepInViewport: true,
                    width: '65rem',
                    style: { maxHeight: '40rem' },
                },
            );

            this.userFormRef.onClose.subscribe((data) => {
                if (data) {
                    // this.messageService.add({
                    //     severity: 'success',
                    //     summary: 'Return Line',
                    //     detail: 'Return line created successfully.',
                    // });
                    this.getReturnLines(); // Refresh the return lines list
                }
            });
        } catch (error) {
            console.error('Error opening Create Return Line form:', error);
            this.messageService.add({
                severity: 'error',
                summary: 'Return Line',
                detail: 'Failed to open the Create Return Line form. Please try again.',
            });
        }
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
