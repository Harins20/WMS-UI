import { Subscription } from 'rxjs';
import { Component, DestroyRef, inject, input, signal } from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { Route } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import { selectOption } from '../../../../../common/models';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../../common/functions';
import { TabService } from '../../../../../tabs';
import outboundRoutes from '../../../outbound.routes';
import { ReturnLineService } from '../return-lines.service';
import { TooltipModule } from 'primeng/tooltip';
import { CreateReturnLineService } from '../return-line-creation/return-line-creation.service';
import { MessageService } from 'primeng/api';
import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { upperCaseObject } from '../../../../../shared/utils/case-conversion.util';

@Component({
    selector: 'order-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        Select,
        ButtonModule,
        TooltipModule,
        AppTranslatePipe,
    ],
    templateUrl: './return-lines-form.component.html',
})
export class ReturnLineFormComponent {
    OrderData = input<any>();
    ReturnID = input<any>();
    ReturnIDLine = input<any>();
    OrderKey = input<any>();
    private destoryRef = inject(DestroyRef);
    private ref = inject(DynamicDialogRef);
    private returnlineService = inject(ReturnLineService);
    private messageService = inject(MessageService);
    private tabService = inject(TabService);
    private createreturnlineService = inject(CreateReturnLineService);

    loading = signal(false);

    form = new FormGroup({
        SKU: new FormControl<string>('', [Validators.required]),
    });
    SkuOptions = signal<selectOption[]>([]);

    ngOnInit() {
        if (this.OrderData()) {
            const data = upperCaseObject(this.OrderData());
            this.form.patchValue({
                SKU: data.SKU,
            });
        }
        this.getReturnSkuOptions();
    }

    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }

    getReturnSkuOptions() {
        this.loading.set(true);
        this.SkuOptions.set([]);
        const subscription = this.returnlineService
            .getReturnSkuOptions(this.OrderKey())
            .pipe()
            .subscribe({
                next: (res: any) => {
                    this.SkuOptions.set(res);
                },
            });
        this.loading.set(false);
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    onClickSave() {
        if (this.form.valid) {
            let sku1: any = this.form.get('SKU')?.value;
            const Subscription = this.createreturnlineService
                .getCreateReturnLines(this.OrderKey(), sku1)
                .subscribe({
                    next: (res) => {
                        if (res.Response.length >= 1) {
                            const route = outboundRoutes.find(
                                (route) =>
                                    route.data?.name === 'createreturnline',
                            ) as Route | undefined;

                            if (!route) {
                                return;
                            }

                            const returnID = this.ReturnID();
                            const returnIDLine = this.ReturnIDLine();
                            const orderKey = this.OrderKey();
                            const sku = this.form.get('SKU')?.value;

                            if (!returnID || !orderKey) {
                                return;
                            }

                            if (!sku) {
                                return;
                            }

                            const params = [
                                { name: 'ReturnID', value: returnID },
                                { name: 'OrderKey', value: orderKey },
                                { name: 'Sku', value: sku },
                                { name: 'ReturnIDLine', value: returnIDLine },
                            ];

                            this.tabService.addTabWithParams(
                                route,
                                '',
                                `Return Line - ${returnID} - ${sku}`,
                                params,
                            );

                            this.ref.close(this.form.value);
                            this.form.reset();
                        }
                    },
                    error: (error) => {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Pick Order Lines',
                            detail: error?.error?.message || 'Error occurred',
                        });
                        this.ref.close(this.form.value);
                    },
                });
        } else {
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
}
