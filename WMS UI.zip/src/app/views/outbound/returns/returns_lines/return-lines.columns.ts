import { Validators } from '@angular/forms';
import { Columns } from '../../../../common/models';

export const ReturnlineColumns: Columns = {
    ROWID: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
    },
    RETURNLINENUMBER: {
        label: 'Line No',
        field: 'RETURNLINENUMBER',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(20)],
        restrictEdit: true,
        restrictInsert: true,
    },
    RETURNID: {
        label: 'Return ID',
        field: 'RETURNID',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(20)],
        restrictEdit: true,
        restrictInsert: true,
    },
    ORDERKEY: {
        label: 'OrderKey',
        field: 'ORDERKEY',
        restrictInsert: true,
        restrictEdit: true,
    },
    SKU: {
        label: 'Sku',
        field: 'SKU',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(50)],
        restrictEdit: true,
    },
    LOT: {
        label: 'LOT',
        field: 'LOT',
        type: 'select',
        validators: [Validators.maxLength(60)],
        restrictEdit: true,
    },
    LOC: {
        label: 'Location',
        field: 'LOC',
        type: 'text',
        validators: [Validators.maxLength(20)],
        restrictEdit: true,
    },
    ID: {
        label: 'ID',
        field: 'ID',
        type: 'text',
        validators: [Validators.maxLength(50)],
    },
    STATUS: {
        label: 'Status',
        field: 'STATUS',
        validators: [Validators.maxLength(10)],
        defaultValue: '0',
        tableHidden: true,
    },
    STATUSDESC: {
        label: 'Status',
        field: 'STATUSDESC',
        validators: [Validators.maxLength(10)],
        defaultValue: '0',
    },
    RTNQTY: {
        label: 'Quantity',
        field: 'RTNQTY',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(50)],
        restrictEdit: true,
    },
    PICKDETAILKEY: {
        label: 'Pick Detail Key',
        field: 'PICKDETAILKEY',
        type: 'select',
        validators: [Validators.required, Validators.maxLength(20)],
        restrictEdit: true,
    },
    REASON: {
        label: 'Reason',
        field: 'REASON',
        type: 'select',
        validators: [Validators.required, Validators.maxLength(20)],
        restrictEdit: true,
    },
};
