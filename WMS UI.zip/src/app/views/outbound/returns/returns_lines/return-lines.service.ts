import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { ReturnLines } from './return-lines.models';
import { AuthService } from '../../../../common/services';
import { ResponseDto } from '../../../../common/models';
import { AppConfigService } from '../../../../../app.config.service';
import { map, tap } from 'rxjs';
import {
    upperCaseArray,
    upperCaseObject,
    lowerCaseObject,
    lowerCaseArray,
} from '../../../../shared/utils/case-conversion.util';

@Injectable({
    providedIn: 'root',
})
export class ReturnLineService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getReturnLines(ReturnID: string) {
        return this.httpClient
            .get<ResponseDto<ReturnLines[]>>(
                this.config.appConfig()?.OutUrl +
                    `returns/lines?ReturnID=${ReturnID}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((res) => {
                    if (res?.Response && Array.isArray(res.Response)) {
                        return {
                            ...res,
                            Response: upperCaseArray(res.Response),
                        };
                    }
                    return res;
                }),
            );
    }
    getReturnSkuOptions(OrderKey: string) {
        return this.httpClient
            .get(
                this.config.appConfig()?.OutUrl +
                    `Returns/Lines/skus?ORDERKEY=${OrderKey}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) => {
                    const items = Array.isArray(value?.Response)
                        ? upperCaseArray(value.Response)
                        : [];
                    return items.map((x: any) => ({
                        label: x.SKU,
                        value: x.SKU,
                    }));
                }),
            );
    }

    createReturnLines(data: any) {
        const payload = Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data);
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'returns/lines',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    acceptReturn(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'returns/Accept',
            {
                returnid: data,
            },
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    acceptReturnsLines(data: any) {
        const payload = Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data);
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'returns/lines/accept',
            payload,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    rejectReturn(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'returns/Reject',
            {
                returnid: data,
            },
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    rejectReturnsLines(data: any) {
        const payload = Array.isArray(data) ? lowerCaseArray(data) : lowerCaseObject(data);
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'returns/lines/reject',
            payload,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
