export interface ReturnLines {
    SERIALKEY: number;
    STORERKEY: string;
    RETURNID: string;
    EXTERNALORDERKEY: string;
    ORDERKEY: string;
    STATUS: string;
    STATUS_DESC: string;
    RETURNDATE: Date;
    REASON: string;
    ACCEPTEDDATE: Date;
    ACTUALSHIPDATE: Date;
    UDF1: string;
    UDF2: string;
    UDF3: string;
    UDF4: string;
    UDF5: string;
    ADDWHO: string;
    ADDDATE: Date;
    EDITWHO: string;
    EDITDATE: Date;
}