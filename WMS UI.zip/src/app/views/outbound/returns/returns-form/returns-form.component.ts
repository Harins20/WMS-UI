import { Component, computed, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { ReturnColumns } from '../return.columns';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';

@Component({
    selector: 'returns-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        Select,
        ButtonModule,
        AppTranslatePipe,
    ],
    templateUrl: './returns-form.component.html',
})
export class ReturnsFormComponent {
    private ref = inject(DynamicDialogRef);

    loading = signal(false);
    formControlsArray = signal(
        Object.values(ReturnColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue || '', {
                validators: column.validators,
            }),
        ]),
    );
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    form = new FormGroup(this.formControls());
    ngOnInit() {
        // this.GetShipTo();
    }
    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }

    onSubmit() {
        if (this.form.valid) {
            console.log(this.form.value);
            this.ref.close(this.form.value);
            this.form.reset();
        } else {
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
}
