import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { filterQuery } from '../../../common/functions';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { ReturnColumns } from './return.columns';
import { ReturnOrders } from './returns.model';
import { ReturnsOrderService } from './returns.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../common/components';
import { Route, Router } from '@angular/router';
import { ReturnsFormComponent } from '../returns/returns-form/returns-form.component';
import outboundRoutes from '../outbound.routes';
import { TabService } from '../../../tabs/tab.service';
import { tableOptions } from '../../../common/constants';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import { TagModule } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';
import { OptionsService } from '../../../common/services/options.service';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import { AsnColumns } from '../../inbound';

@Component({
    selector: 'app-returns',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        // FileUpload,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TagModule,
        TooltipModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './returns.component.html',
    styleUrl: './returns.component.scss',
    providers: [DialogService],
})
export class ReturnsComponent {
    private optionService = inject(OptionsService);
    private translate = inject(TranslateService);
    returnorders = signal<ReturnOrders[]>([]);
    returnordersExcel = signal<ReturnOrders[]>([]);
    selectedReturns = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(15);
    dt = viewChild.required<Table>('dt');
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    exportFileName = 'Return Orders-List';
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    columns = signal<any>(
        Object.values(ReturnColumns).filter(
            (column: any) => !column.tableHidden,
        ),
    );
    OrginalColumns = signal<any>(ReturnColumns);

    selectedColumns = linkedSignal(() => this.columns());

    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x: any) => x.tableAlias && !x.tableHidden)
            .map((x: any) => x.field),
    );

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    userFormRef: DynamicDialogRef | undefined;
    private router = inject(Router);
    private messageService = inject(MessageService);
    private returnorderService = inject(ReturnsOrderService);
    private destoryRef = inject(DestroyRef);
    private tabService = inject(TabService);
    ConfirmationRef: DynamicDialogRef | undefined;
    private excelDownloadService = inject(ExcelDownloadService);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    constructor() {}

    ngOnInit() {
        // this.getReturnPage();
        this.getColumns();
    }
    ngAfterViewInit(): void {
        //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
        //Add 'implements AfterViewInit' to the class.

        const c = this.columns().map((column: any) => {
            if (column.field === 'STATUSDESC') {
                return {
                    ...column,
                    customCellTemplate: this.customStatusCellTemplate(),
                };
            }

            return column;
        });
        this.columns.set(c);
    }
    getColumns() {
        this.optionService.getColumns(ReturnColumns, 'RETURNS').subscribe({
            next: (data) => {
                const FilterField = data.map((x: any) => x.field);
                const GetFilterFields = Object.values(ReturnColumns).filter(
                    (x: any) => !FilterField.includes(x.field),
                );

                const columns = [...GetFilterFields, ...data];

                let updatedColumns = columns.map((column: any) => {
                    if (column.field === 'STATUSDESC') {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                });

                this.columns.set(
                    updatedColumns.filter((column: any) => !column.tableHidden),
                );
            },
        });
    }

    // getColumns() {
    //     this.optionService.getColumns(ReturnColumns, 'RETURNS').subscribe({
    //         next: (data) => {
    //             if (data && data.length > 0) {
    //                 const FilterField = data.map((x: any) => x.field);
    //                 const GetFilterFields = Object.values(ReturnColumns).filter(
    //                     (x: any) => {
    //                         return !FilterField.includes(x.field);
    //                     },
    //                 );
    //                 const columns = [...GetFilterFields, ...data];
    //                 this.columns.set(
    //                     columns.filter((column: any) => !column.tableHidden),
    //                 );
    //             }
    //         },
    //     });
    // }

    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         ReturnColumns,
    //         'vw.',
    //     );
    //     this.getReturnPage({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getReturnPage(event);
    }
    getReturnOrders() {
        this.getReturnPage();
    }

    getReturnPage(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.selectedReturns.set([]);
        this.returnorders.set([]);
        const subscription = this.returnorderService
            .getReturnPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    const returnList =
                        res?.Response?.Returns ||
                        res?.Response?.ReturnHeaders ||
                        res?.Response?.Loads ||
                        res?.Returns ||
                        res?.Orders ||
                        res?.Loads ||
                        res?.Response ||
                        [];
                    const total =
                        res?.Response?.totalCount ??
                        res?.Response?.TotalCount ??
                        res?.totalRecords ??
                        res?.totalCount ??
                        0;

                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }

                    const items = Array.isArray(returnList) ? returnList : [];
                    const first = data?.first ?? 0;
                    this.returnorders.set(
                        items.map((x: any, idx: number) => ({
                            ...x,
                            rowId: first + idx + 1,
                        })),
                    );
                    this.totalRecords.set(total);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'ReturnOrders list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    this.loading.set(false);
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getReturnPage();
    }

    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getReturnPage();
    }

    getReturnsForExcel(
        data: any = { Page: 1, PageSize: this.totalRecords() },
        type: string,
    ) {
        this.returnordersExcel.set([]);
        const subscription = this.returnorderService
            .getReturnPage(data)
            .pipe()
            .subscribe({
                next: (res: any) => {
                    const returnList =
                        res?.Response?.Returns ||
                        res?.Response?.ReturnHeaders ||
                        res?.Response?.Returns ||
                        res?.Returns ||
                        res?.Orders ||
                        res?.Loads ||
                        res?.Response ||
                        [];
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }

                    const items = Array.isArray(returnList) ? returnList : [];
                    this.returnordersExcel.set(items);
                    if (items && items.length > 0 && type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            items,
                        );
                    } else {
                        downloadCSVFile(items, this.exportFileName);
                    }
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Returns list for excel',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    export(type: string) {
        const event = this.loadEvent();
        const PageSize = this.totalRecords();
        const Page = (event.first || 0) / PageSize + 1;
        const { filter, orderBy } = filterQuery(
            event,
            this.globalFilterColumns(),
            ReturnColumns,
            'vw.',
        );

        this.getReturnsForExcel(
            {
                Page,
                PageSize,
                Condition: filter,
                OrderBy: orderBy,
            },
            type,
        );
    }

    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }

    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.returnorders().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedReturns().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedReturns().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    onEditAction(returnorders: ReturnOrders) {}
    // onClickReturnID(event: any, row: ReturnOrders): void {
    //     event.preventDefault();
    //     const route = outboundRoutes.find(
    //         (route) => route.data?.name === 'returnline',
    //     ) as Route;
    //     var params = [
    //         { name: 'ReturnID', value: row.RETURNID },
    //         { name: 'OrderKey', value: row.ORDERKEY },
    //     ];
    //     this.tabService.addTabWithParams(
    //         route,
    //         '',
    //         'Return Line -' + row.RETURNID,

    //         params,
    //     );
    // }
    onClickReturnID(row: ReturnOrders): void {
        const route = outboundRoutes.find(
            (route) => route.data?.name === 'returnline',
        ) as Route;

        const params = [
            { name: 'ReturnID', value: row.RETURNID },
            { name: 'OrderKey', value: row.ORDERKEY },
        ];

        this.tabService.addTabWithParams(
            route,
            '',
            'Return Line -' + row.RETURNID,
            params,
        );
    }
    OpenCreateReturnsForm() {
        this.userFormRef = this.dialogService.open(ReturnsFormComponent, {
            header: 'Create Return Order',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '55rem',
            style: { maxHeight: '40rem' },
        });

        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                this.returnorderService
                    .getReturnVerify(data.SELECTPARAMS, data.VALUE)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                        }),
                    )
                    .subscribe({
                        next: (response: any) => {
                            const ValidData = [response.Response].map((x) => ({
                                ORDERKEY: x.ORDERKEY,
                                REASON: data?.REASON || '',
                                UDF1: x.SUSR1,
                                UDF2: x.SUSR2,
                                UDF3: x.SUSR3,
                                UDF4: x.SUSR4,
                                UDF5: x.SUSR5,
                            }));
                            const FinalData = ValidData.find((x) => x);
                            this.onCreation(FinalData);
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Return Verify',
                                detail: 'Return verified successfully.',
                            });
                        },
                        error: (error: HttpErrorResponse) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error.status === 0
                                        ? 'Network error occurred. Please check your internet connection.'
                                        : error.error?.Message ||
                                          `Orderkey doesn't have any shipped lines.`;
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Return Verify',
                                    detail: errorMessage,
                                });
                            }
                        },
                    });
            }
        });
    }

    onCreation(FinalData: any) {
        const headertext = this.translate.instant('Confirm Creation');
        const value = this.translate.instant('ReturnCreation');
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                this.loading.set(true);
                this.returnorderService
                    .createReturns(FinalData)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.getReturnPage();
                        }),
                    )
                    .subscribe({
                        next: (data: any) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Returns creation',
                                detail: data.Response.message as string,
                            });
                            this.getReturnPage();
                        },
                        error: (error: any) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message === 'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Returns creation',
                                    detail: error.Response as string,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            }
        });
    }

    OpenUpdateReturnsForm() {
        this.userFormRef = this.dialogService.open(ReturnsFormComponent, {
            header: 'Update',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            width: '55rem',
            style: { maxHeight: '40rem' },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const headertext = this.translate.instant('Confirm Update');
                const value = this.translate.instant('ReturnUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: headertext,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.returnorderService
                            .updateReturns(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedReturns.set([]);
                                    this.getReturnPage();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Returns Updation',
                                        detail: data.Response as string,
                                    });
                                    this.getReturnPage();
                                },
                                error: (error: any) => {
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Returns Updation',
                                        detail: error.Rersponse as string,
                                    });
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
