import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { OrderLine } from './order-lines/order-line.models';
import { AuthService } from '../../../../common/services';
import { ResponseDto } from '../../../../common/models';
import { AppConfigService } from '../../../../../app.config.service';
import { finalize, map, Subject, Subscription } from 'rxjs';
import { PickDetails } from './pick-details/pick-details-model';
import { Order } from '../order.model';
import { OrderColumns } from '../order.columns';
import { stringToDate } from '../../../../common/functions';
import {
    upperCaseArray,
    upperCaseObject,
    lowerCaseArray,
    lowerCaseObject,
} from '../../../../shared/utils/case-conversion.util';

interface OrderDetailPage {
    OrderLinePage: OrderLine[];
    totalRecords: number;
}

@Injectable({
    providedIn: 'root',
})
export class OrderLineService {
    orderKey = signal<string>('');
    orderHeader = signal<any>({});
    orderLines = signal<OrderLine[]>([]);
    PickDetails = signal<PickDetails[]>([]);
    orderLineLoading = signal<boolean>(false);
    PickDetailsLoading = signal<boolean>(false);
    coolerTimer = signal<number>(0);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);
    init(orderKey: string) {
        this.orderKey.set(orderKey);
        this.getOrderLines();
        this.getPickDetails();
        this.getOrderHeader();
        this.getCoolerTime();
    }
    reload() {
        this.getOrderLines();
        this.getPickDetails();
        this.getCoolerTime();
        this.getOrderHeader();
    }

    getOrderHeader() {
        this.orderLineLoading.set(true);
        const subscription = this.httpClient
            .get<ResponseDto<OrderLine[]>>(
                this.config.appConfig()?.OutUrl +
                    `orders?OrderKey=${this.orderKey()}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(finalize(() => this.orderLineLoading.set(false)))
            .subscribe({
                next: (response: any) => {
                    const header = response?.Response ? upperCaseObject(response.Response) : {};
                    this.orderHeader.set(header);
                },
            });
    }

    getCoolerTime() {
        const subscription = this.httpClient
            .get(
                this.config.appConfig()?.OutUrl +
                    `Orders/cooldowntimer?ORDERKEY=${this.orderKey()}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(finalize(() => this.orderLineLoading.set(false)))
            .subscribe({
                next: (response: any) => {
                    if (response) {
                        this.coolerTimer.set(response);
                    }
                },
                error: (error) => {
                    console.error('Error fetching order lines:', error);
                },
            });
    }

    getOrderLines() {
        this.orderLineLoading.set(true);
        const subscription = this.httpClient
            .get<ResponseDto<OrderLine[]>>(
                this.config.appConfig()?.OutUrl +
                    `orders/lines?OrderKey=${this.orderKey()}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(finalize(() => this.orderLineLoading.set(false)))
            .subscribe({
                next: (response) => {
                    const rawList = response?.Response && Array.isArray(response.Response) ? upperCaseArray(response.Response) : [];
                    const orderLines = rawList.map(
                        (x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        }),
                    );
                    this.orderLines.set(orderLines);
                },
                error: (error) => {
                    console.error('Error fetching order lines:', error);
                },
            });
    }

    getOrderDetailsPage(data: any) {
        return this.httpClient
            .post<OrderDetailPage>(
                this.config.appConfig()?.OutUrl + 'Orderdetails/page',
                data,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((response: any) => {
                    if (response?.OrderLinePage && Array.isArray(response.OrderLinePage)) {
                        response.OrderLinePage = upperCaseArray(response.OrderLinePage);
                    }
                    return response;
                }),
            );
    }

    createOrderLines(data: any) {
        const payload = Array.isArray(data) ? lowerCaseArray(data) : typeof data === 'object' && data !== null ? lowerCaseObject(data) : data;
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'Orders/Lines',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    updateOrderLine(data: any) {
        const payload = typeof data === 'object' && data !== null ? lowerCaseObject(data) : data;
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/Lines',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    DeleteOrderLines(OrderLines: any) {
        const payload = typeof OrderLines === 'object' && OrderLines !== null ? lowerCaseObject(OrderLines) : OrderLines;
        return this.httpClient.request(
            'delete',
            this.config.appConfig()?.OutUrl + 'Orders/Lines',
            {
                headers: this.authService.getAuthHeaders(),
                body: payload,
            },
        );
    }

    allocateLines(ORDERKEY: string) {
        const payload = lowerCaseObject({ ORDERKEY: ORDERKEY });
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/Allocate',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    unallocateLines(ORDERKEY: string) {
        const payload = lowerCaseObject({ ORDERKEY: ORDERKEY });
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/UnAllocate',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    createBackOrders(orderData: any) {
        const payload = typeof orderData === 'object' && orderData !== null ? lowerCaseObject(orderData) : orderData;
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/Close',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    getPickDetails() {
        this.PickDetailsLoading.set(true);
        const subscription = this.httpClient
            .get<ResponseDto<PickDetails[]>>(
                this.config.appConfig()?.OutUrl +
                    `Orders/PickDetail?OrderKey=${this.orderKey()}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(finalize(() => this.PickDetailsLoading.set(false)))
            .subscribe({
                next: (response) => {
                    const rawList = response?.Response && Array.isArray(response.Response) ? upperCaseArray(response.Response) : [];
                    const pickLines = rawList.map(
                        (x: any, idx: number) => ({
                            ...x,
                            rowId: idx + 1,
                        }),
                    );
                    this.PickDetails.set(pickLines);
                },
                error: (error) => {
                    console.error('Error fetching order lines:', error);
                },
            });
    }

    pickbyOrderkey(validLines: any) {
        const payload = typeof validLines === 'object' && validLines !== null ? lowerCaseObject(validLines) : validLines;
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/Pick',
            payload,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    pickbyOrderLines(validLines: any[]) {
        const payload = Array.isArray(validLines) ? lowerCaseArray(validLines) : validLines;
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/Pick/Lines',
            payload,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    unpickOrderKey(orderKey: string) {
        const payload = lowerCaseObject({ OrderKey: orderKey });
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/UnPick',
            payload,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    unpickOrderLines(validLines: any[]) {
        const payload = Array.isArray(validLines) ? lowerCaseArray(validLines) : validLines;
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/UnPick/Lines',
            payload,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    shipOrderLines(data: any) {
        const payload = lowerCaseObject({ OrderKey: data });
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/Ship',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    unshipOrderLines(data: any, notes: any) {
        const payload = lowerCaseObject({ OrderKey: data, Notes: notes });
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/UnShip',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
