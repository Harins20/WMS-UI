import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    Input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
    CustomTableComponent,
} from '../../../../../common/components';
import { tableOptions } from '../../../../../common/constants';
import {
    ExcelDownloadService,
    OptionsService,
} from '../../../../../common/services';
import { OrderLineService } from '../order-line.service';
import { OrderlineColumns } from './order-line.column';
import { OrderLine } from './order-line.models';
import { OrderLineFormComponent } from './order-lines-form/order-lines-form.component';
import { CommonErrorboxComponent } from '../../../../../common/components/common-errorbox/common-errorbox.component';
import { downloadCSVFile } from '../../../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-order-lines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TagModule,
        TooltipModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTableComponent,
    ],
    templateUrl: './order-lines.component.html',
    styleUrl: './order-lines.component.scss',
    providers: [DialogService, ConfirmationService],
})
export class OrderLinesComponent {
    private translate = inject(TranslateService);
    ref: DynamicDialogRef | undefined;
    orderDetailExcel = signal<OrderLine[]>([]);
    searchInput = signal<string | undefined>(undefined);
    OrderKey = input.required<string>();
    StorerKey = input.required<string>();
    ExternOrderKey = input.required<string>();
    @Input() orderlineService!: OrderLineService;
    ConfirmationRef: DynamicDialogRef | undefined;
    selectedOrderLines = signal<any>([]);
    loading = signal(false);
    // mainLoading = signal(false);
    dt = viewChild.required<Table>('dt');
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    columns = signal<any>([]);
    excelData: any = [];
    exportFileName = 'Orders Line List';
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    // exportTypes: MenuItem[] = [
    //     {
    //         label: this.translate.instant('Excel'),
    //         command: () => this.exportExcel(),
    //     },
    //     {
    //         label: this.translate.instant('CSV'),
    //         command: () => this.exportCSV(),
    //     },
    // ];

    userFormRef: DynamicDialogRef | undefined;

    private messageService = inject(MessageService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);

    columnPicklistRef: DynamicDialogRef | undefined;
    conformationRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private optionService = inject(OptionsService);

    confirmDialogService: any;
    orderActionsService: any;
    orderClosed = signal(false); // Add a flag to track if the order is closed

    globalFilterColumns = computed(() =>
        this.columns().map((x: any) => x.field),
    );
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');

    isOrderClosed = computed(() =>
        ['97'].includes(this.orderlineService.orderHeader().STATUS),
    );

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }
    ngOnInit() {
        this.getColumns();
    }

    getColumns() {
        this.optionService
            .getColumns(OrderlineColumns, 'ORDERLINES')
            .subscribe({
                next: (data) => {
                    const FilterField = data.map((x: any) => x.field);

                    const GetFilterFields = Object.values(
                        OrderlineColumns,
                    ).filter((x: any) => {
                        return !FilterField.includes(x.field);
                    });

                    const allowedFields = [
                        'UDFSTR1',
                        'UDFSTR2',
                        'UDFSTR3',
                        'UDFSTR4',
                        'UDFSTR5',
                    ];

                    const limitedColumns = data.filter(
                        (x: any) =>
                            !x.field?.startsWith('UDF') ||
                            allowedFields.includes(x.field),
                    );

                    const columns = [...GetFilterFields, ...limitedColumns];

                    let updatedColumns = columns;
                    updatedColumns = updatedColumns.map((column: any) => {
                        if (column.field === 'STATUS_DESC') {
                            return {
                                ...column,
                                customCellTemplate:
                                    this.customStatusCellTemplate(),
                            };
                        }

                        return column;
                    });
                    this.columns.set(
                        updatedColumns.filter(
                            (column: any) => !column.tableHidden,
                        ),
                    );
                },
            });
    }
    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.orderlineService.getOrderLines();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.orderlineService.orderLines(),
        );
    }
    exportCSV() {
        downloadCSVFile(
            this.orderlineService.orderLines(),
            this.exportFileName,
        );
    }
    // exportCSV() {
    //     this.dt().exportCSV();
    // }
    // deleteSelectedProducts() {}

    exportExcelTemplate() {
        const Column = [
            'Owner',
            'ExternOrderKey',
            'OrderDate',
            'ExpectedDeliveryDate',
            'ShipTo',
            'CarrierCode',
            'Sku',
            'AltSku',
            'TotalQty',
            'Lottable01',
            'Lottable02',
            'Lottable03',
            'ManufactureDate',
            'ExpirationDate',
            'Lottable06',
            'Lottable07',
            'Lottable08',
            'Lottable09',
            'Lottable10',
            'AllocationStrategy',
        ];
        this.excelDownloadService.downloadExcelFile(
            'Order-Detail-Template',
            Column,
            null,
        );
    }
    options(field: string) {
        const uniqueValues = new Set(
            this.orderlineService.orderLines().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedOrderLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedOrderLines().length > 0 ? true : false,
    );

    IsAllocated = computed(() =>
        this.orderlineService
            .orderLines()
            .reduce((sum, item) => sum + item.ORIGINALQTY, 0) -
            (this.orderlineService
                .orderLines()
                .reduce((sum, item) => sum + item.QTYALLOCATED, 0) +
                this.orderlineService
                    .orderLines()
                    .reduce((sum, item) => sum + item.QTYPICKED, 0) +
                this.orderlineService
                    .orderLines()
                    .reduce((sum, item) => sum + item.SHIPPEDQTY, 0)) >
        0
            ? true
            : false,
    );

    IsUnallocated = computed(() =>
        this.orderlineService
            .orderLines()
            .reduce((sum, item) => sum + item.QTYALLOCATED, 0) > 0
            ? true
            : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    OpenCreateOrderlineForm() {
        const headertext = this.translate.instant('Create OrderLine');
        this.userFormRef = this.dialogService.open(OrderLineFormComponent, {
            inputValues: {
                orderlineCreateData: {
                    ORDERKEY: this.OrderKey(),
                    TRADERKEY: this.StorerKey(),
                    EXTERNORDERKEY: this.ExternOrderKey(),
                },
            },
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('OrderLineCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.orderlineService
                            .createOrderLines(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.orderlineService.reload();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Order creation',
                                        detail: data.Response as string,
                                    });
                                },
                                error: (err) => {
                                    console.error('Error Order creation', err);
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'New Order creation',
                                        detail: 'Failed to Create Order Lines.',
                                    });
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }
    OpenUpdateOrderLinesForm(data: any) {
        const headertext = this.translate.instant('Update OrderLine');
        const selectedOrderLine: OrderLine = Array.isArray(data)
            ? data[0]
            : data;
        this.userFormRef = this.dialogService.open(OrderLineFormComponent, {
            inputValues: {
                orderlinesData: {
                    ...data,
                    TRADERKEY: selectedOrderLine.TRADERKEY,
                    ORDERKEY: selectedOrderLine.ORDERKEY,
                    EXTERNORDERKEY: selectedOrderLine.EXTERNORDERKEY,
                    ORDERLINENUMBER: selectedOrderLine.ORDERLINENUMBER,
                },
            },
            // header: headertext,
            // closable: true,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('OrderLineUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        const updatedData: OrderLine = {
                            ...data,
                            StorerKey: selectedOrderLine.TRADERKEY,
                            OrderKey: selectedOrderLine.ORDERKEY,
                            ExternOrderKey: selectedOrderLine.EXTERNORDERKEY,
                            OrderLineNumber: selectedOrderLine.ORDERLINENUMBER,
                        };
                        this.orderlineService
                            .updateOrderLine(updatedData)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedOrderLines.set([]);
                                    this.orderlineService.reload();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Order Lines Updated',
                                        detail: data.Response as string,
                                    });
                                },
                                error: (err) => {
                                    console.error('Error Update Order', err);
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Order Lines Updated',
                                        detail: 'Failed to Update Order Lines.',
                                    });
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    DeleteOrderLines() {
        const headertext = this.translate.instant('Confirm Deletion');
        const count = this.selectedOrderLines().length;
        const name =
            count > 1
                ? this.translate.instant('Order Lines')
                : this.translate.instant('Order Line');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const SerialKeys = this.selectedOrderLines().map((x: any) =>
                    x.SERIALKEY.toString(),
                );
                this.loading.set(true);
                let orderData = {
                    ORDERKEY: this.OrderKey(),
                    SERIALKEY: SerialKeys,
                };
                const subscription = this.orderlineService
                    .DeleteOrderLines(orderData)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedOrderLines.set([]);
                            this.orderlineService.reload();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Deleted Order Lines',
                                detail: 'Order Lines deleted successfully.',
                            });
                        },
                        error: (err) => {
                            console.error('Error deleting Order Lines:', err);
                            const errorMessage =
                                err?.error?.FieldErrors?.map(
                                    (fieldError: any) =>
                                        `${fieldError.Field}: ${fieldError.Message}`,
                                ).join(', ') ||
                                err?.error?.Message ||
                                'An unexpected error occurred while deleting the order lines. Please try again later.';
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Deleted Order Lines',
                                detail: errorMessage,
                            });
                            this.loading.set(false);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }
    allocate() {
        if (this.orderlineService.orderLines().length > 0) {
            this.loading.set(true);
            const subscription = this.orderlineService
                .allocateLines(this.OrderKey())
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.selectedOrderLines.set([]);
                        this.orderlineService.reload();
                    }),
                )
                .subscribe({
                    next: (response) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Allocate Order Lines',
                            detail: 'Order Lines allocated successfully.',
                        });
                    },
                    error: (error) => {
                        if (
                            error.error.Message ===
                                'One or more errors occurred!' ||
                            error.error.message ===
                                'One or more errors occurred!'
                        ) {
                            this.ConfirmationRef = this.dialogService.open(
                                CommonErrorboxComponent,
                                {
                                    inputValues: {
                                        error: error,
                                    },
                                    header: 'Multiple Error',
                                    closable: true,
                                    modal: true,
                                    draggable: true,
                                    keepInViewport: true,
                                    width: '39rem',
                                    style: { maxHeight: '40rem' },
                                },
                            );
                        } else {
                            const errorMessage =
                                error?.error?.message ||
                                'An unexpected error occurred while allocating Order Lines. Please try again later.';
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Allocate Order Lines',
                                detail: errorMessage,
                            });
                        }
                        this.loading.set(false);
                    },
                });

            this.destroyRef.onDestroy(() => subscription.unsubscribe());
        } else {
            this.messageService.add({
                severity: 'error',
                summary: 'Allocate Order Lines',
                detail: "Order doesn't have any lines to be allocated.",
            });
        }
    }

    unallocate() {
        if (this.orderlineService.orderLines().length > 0) {
            this.loading.set(true);
            const subscription = this.orderlineService
                .unallocateLines(this.OrderKey())
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.selectedOrderLines.set([]);
                        this.orderlineService.reload();
                    }),
                )
                .subscribe({
                    next: (response) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Unallocate Order',
                            detail: 'Order Unallocated successfully.',
                        });
                    },
                    error: (err) => {
                        console.error('Error unallocating Order', err);
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Un-Allocate',
                            detail: 'Failed to unallocate Order.',
                        });
                        this.loading.set(false);
                    },
                });

            this.destroyRef.onDestroy(() => subscription.unsubscribe());
        } else {
            this.messageService.add({
                severity: 'error',
                summary: 'Un-Allocate',
                detail: "Order doesn't have any lines that can be un-allocated.",
            });
        }
    }

    OnClickCreateBackOrder() {
        if (this.orderClosed()) {
            this.messageService.add({
                severity: 'error',
                summary: 'Back Order',
                detail: 'This order has already been closed.',
            });
            return;
        }

        let shippedQty = 0;
        let originalQty = 0;

        this.orderlineService.orderLines().forEach((x: any) => {
            shippedQty += (x.SHIPPEDQTY ?? 0);
            originalQty += (x.ORIGINALQTY ?? 0);
        });

        if (originalQty > shippedQty) {
            this.ref = this.dialogService.open(ConfirmationDialogComponent, {
                inputValues: {
                    message:
                        'The selected order will be Back ordered. Do you wish to continue?',
                },
                header: 'Back Order Confirmation',
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '35rem',
                style: { maxHeight: '40rem' },
            });

            this.ref.onClose.subscribe(async (data) => {
                if (data) {
                    this.loading.set(true);
                    const BackOrderTrueData = {
                        ORDERKEY: this.OrderKey(),
                        CREATEBACKORDER: true,
                    };

                    this.loading.set(true);

                    this.orderlineService
                        .createBackOrders(BackOrderTrueData)
                        .pipe(
                            finalize(() => {
                                this.loading.set(false);
                                this.selectedOrderLines.set([]);
                                this.orderClosed.set(true); // Set the flag to true after closing the order
                            }),
                        )
                        .subscribe({
                            next: (res: any) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Back Order',
                                    detail: res.Response as string,
                                });
                            },
                            error: (error: any) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef =
                                        this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                } else {
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Back Order',
                                        detail: error.error.message as string,
                                    });
                                }
                                this.loading.set(false);
                            },
                        });
                } else {
                    const BackOrderFalseData = {
                        ORDERKEY: this.OrderKey(),
                        CREATEBACKORDER: false,
                    };

                    this.loading.set(true);

                    this.orderlineService
                        .createBackOrders(BackOrderFalseData)
                        .pipe(
                            finalize(() => {
                                this.loading.set(false);
                                this.selectedOrderLines.set([]);
                                this.orderlineService.reload();
                                this.orderClosed.set(true); // Set the flag to true after closing the order
                            }),
                        )
                        .subscribe({
                            next: (res: any) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Back Order',
                                    detail: res.Response as string,
                                });
                            },
                            error: (error: any) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef =
                                        this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                } else {
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Back Order',
                                        detail: error.error.message as string,
                                    });
                                }
                                this.loading.set(false);
                            },
                        });
                }
            });
        } else {
            const requestData = {
                ORDERKEY: this.OrderKey(),
                CREATEBACKORDER: false,
            };

            this.loading.set(true);

            this.orderlineService
                .createBackOrders(requestData)
                .pipe(
                    finalize(() => {
                        this.loading.set(false);
                        this.selectedOrderLines.set([]);
                        this.orderlineService.reload();
                        this.orderClosed.set(true); // Set the flag to true after closing the order
                    }),
                )
                .subscribe({
                    next: (res: any) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Back Order',
                            detail: res.Response as string,
                        });
                    },
                    error: (error: any) => {
                        if (
                            error.error.Message ===
                                'One or more errors occurred!' ||
                            error.error.message ===
                                'One or more errors occurred!'
                        ) {
                            this.ConfirmationRef = this.dialogService.open(
                                CommonErrorboxComponent,
                                {
                                    inputValues: {
                                        error: error,
                                    },
                                    header: 'Multiple Error',
                                    closable: true,
                                    modal: true,
                                    draggable: true,
                                    keepInViewport: true,
                                    width: '39rem',
                                    style: { maxHeight: '40rem' },
                                },
                            );
                        } else {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Back Order',
                                detail: error.error as string,
                            });
                        }
                        this.loading.set(false);
                    },
                });
        }
    }

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
