import { CommonModule } from '@angular/common';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { IftaLabelModule } from 'primeng/iftalabel';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { DatePicker } from 'primeng/datepicker';
import { Select } from 'primeng/select';
import { TabsModule } from 'primeng/tabs';

import { OrderlineColumns } from '../order-line.column';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../../../common/functions';
import { selectOption } from '../../../../../../common/models';
import { AuthService, OptionsService } from '../../../../../../common/services';
import { MessageService } from 'primeng/api';
import { InputTextComponent } from '../../../../../../common/components/input-text/input-text.component';
import { AppTranslatePipe } from '../../../../../../common/pipes/translate.pipe';
import { LayoutService } from '../../../../../../layout/service/layout.service';
import { upperCaseObject } from '../../../../../../shared/utils/case-conversion.util';

@Component({
    selector: 'orderlines-form',
    imports: [
        ReactiveFormsModule,
        CommonModule,
        IftaLabelModule,
        InputTextModule,
        PasswordModule,
        ButtonModule,
        TabsModule,
        Select,
        DatePicker,
        InputTextComponent,
        AppTranslatePipe,
    ],
    templateUrl: './order-lines-form.component.html',
    styleUrl: './order-lines-form.component.scss',
})
export class OrderLineFormComponent {
    orderlinesData = input<any>();
    orderlineCreateData = input<any>();
    private destroyRef = inject(DestroyRef);
    private ref = inject(DynamicDialogRef);
    private authservice = inject(AuthService);
    private router = inject(Router);
    private optionService = inject(OptionsService);
    private messageService = inject(MessageService);
    loading = signal(false);
    orderlineColumns: any[] = [];
    formControlsArray = signal(
        Object.values(OrderlineColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );

    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    form = new FormGroup(this.formControls());
    itemOptions = signal<selectOption[]>([]);
    packOptions = signal<selectOption[]>([]);
    uomOptions = signal<selectOption[]>([]);
    typeOptions = signal<selectOption[]>([]);
    ownerOptions = signal<selectOption[]>([]);
    LayoutService = inject(LayoutService);
    isDarkTheme = computed(() => this.LayoutService.layoutConfig().darkTheme);
    // ✅ Single signal for tab validation warning
    setViewTAb = signal<boolean>(true);
    // ✅ Single signal for active tab
    activeTab = signal<number>(0);
    closePanel() {
        this.ref.close();
    } // ✅ Navigate to tab
    goToTab(index: number): void {
        this.activeTab.set(index);
    }

    ngOnInit() {
        this.getColumns();
        const incomingData = this.orderlinesData() ? upperCaseObject(this.orderlinesData()) : null;
        const incomingCreateData = this.orderlineCreateData() ? upperCaseObject(this.orderlineCreateData()) : null;

        if (incomingData) {
            Object.values(OrderlineColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.form.controls[column.field].disable();
            });
            this.form.patchValue({
                ...incomingData,
                ORDERDATE: incomingData.ORDERDATE ? new Date(incomingData.ORDERDATE) : null,
                LOTTABLE04: incomingData.LOTTABLE04
                    ? new Date(incomingData.LOTTABLE04)
                    : null,
                LOTTABLE05: incomingData.LOTTABLE05
                    ? new Date(incomingData.LOTTABLE05)
                    : null,
            });
            const selectedPack = incomingData.PACKKEY;
            if (selectedPack) {
                this.GetUOMOptions(selectedPack);
            }

            const selectedStorerKey = incomingData.TRADERKEY;
            if (selectedStorerKey) {
                this.GetItemOptions(selectedStorerKey);
            }
        } else {
            Object.values(OrderlineColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.form.controls[column.field].disable();
                if (incomingCreateData) {
                    this.form.patchValue({
                        ...incomingCreateData,
                    });
                }
            });

            const selectedStorerKey = incomingCreateData?.TRADERKEY;
            if (selectedStorerKey) {
                this.GetItemOptions(selectedStorerKey);
            }
        }

        this.GetPackOptions();

        this.form
            .get('PACKKEY')
            ?.valueChanges.pipe()
            .subscribe((selectedPack) => {
                if (selectedPack) {
                    this.GetUOMOptions(selectedPack);
                }
            });

        this.typeOptions.set([
            { label: 'FIFO', value: 'FIFO' },
            // { label: 'FEFO', value: 'FEFO' },
            // { label: 'LIFO', value: 'LIFO' },
        ]);
    }

    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }

    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetItemOptions(StorerKey: string) {
        const subscription = this.optionService
            .getItemOptions(StorerKey)
            .subscribe({
                next: (data) => {
                    this.itemOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPackOptions() {
        const subscription = this.optionService.getPackOptions().subscribe({
            next: (data) => {
                this.packOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching pack dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetUOMOptions(Packkey: string) {
        const subscription = this.optionService
            .getUomOptions(Packkey)
            .subscribe({
                next: (data) => {
                    this.uomOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching UOM dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    onSubmit() {
        if (this.form.valid) {
            this.setViewTAb.set(true);
            this.ref.close(this.form.getRawValue());
            this.form.reset();
        } else {
            this.setViewTAb.set(false);
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
    getColumns() {
        this.optionService
            .getColumns(OrderlineColumns, 'ORDERLINES')
            .subscribe({
                next: (data) => {
                    this.orderlineColumns = data;
                },
            });
    }
}
