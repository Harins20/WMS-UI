import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { Component, Input, inject } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TabsModule } from 'primeng/tabs';
import { CalendarModule } from 'primeng/calendar';
import { OrderLinesComponent, OrderLineService } from './order-lines';
import { PickDetailsComponent } from './pick-details/pick-details.component';
import { AccordionModule } from 'primeng/accordion';
import { OrdersViewFormComponent } from '../order-view-form/orders-view-form.component';

@Component({
    selector: 'order-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        TabsModule,
        CalendarModule,
        OrderLinesComponent,
        PickDetailsComponent,
        AccordionModule,
        OrdersViewFormComponent,
        AppTranslatePipe,
    ],
    templateUrl: './order-tabs.component.html',
    providers: [OrderLineService],
})
export class OrderTabComponent {
    @Input() OrderKey!: string;
    @Input() StorerKey!: string;
    @Input() ExternOrderKey!: string;

    orderLineService = inject(OrderLineService);

    ngOnInit() {
        this.orderLineService.init(this.OrderKey);
    }
}
