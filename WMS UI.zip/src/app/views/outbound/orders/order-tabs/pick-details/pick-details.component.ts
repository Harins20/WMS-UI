import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { AppReminingTime } from './../../../../../common/functions/reminingTime';
import { CommonModule, DatePipe } from '@angular/common';
import {
    Component,
    input,
    signal,
    viewChild,
    linkedSignal,
    computed,
    inject,
    DestroyRef,
    Input,
    effect,
    contentChild,
    TemplateRef,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
    CustomTableComponent,
} from '../../../../../common/components';
import { tableOptions } from '../../../../../common/constants';
import { ExcelDownloadService } from '../../../../../common/services';
import { PickDetailsColumns } from './pick-details.columns';
import { OrderLineService } from '../order-line.service';
import { PickDetails } from './pick-details-model';
import { CommonErrorboxComponent } from '../../../../../common/components/common-errorbox/common-errorbox.component';

import { UnshipConfrimationComponent } from './unship-confrimation/unship-confrimation.component';
import { OrderTimerComponent } from '../../order-timer/order-timer.component';
import { downloadCSVFile } from '../../../../../common/functions/downloadCSVFile';
@Component({
    selector: 'app-pick-details',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        MenuModule,
        TooltipModule,
        ProgressSpinner,
        TagModule,
        AppTranslatePipe,
        OrderTimerComponent,
        LoadingComponent,
        CustomTableComponent,
    ],
    templateUrl: './pick-details.component.html',
    styleUrl: './pick-details.component.scss',
    providers: [DialogService],
})
export class PickDetailsComponent {
    private translate = inject(TranslateService);
    actions: MenuItem[] = [
        {
            label: this.translate.instant('Pick'),
            command: () => this.Pick(),
        },
        {
            label: this.translate.instant('UnPick'),
            command: () => this.UnPick(),
        },
        {
            label: this.translate.instant('Ship'),
            command: () => this.Ship(),
        },
    ];
    enableUnship = signal(false);
    timer = viewChild<OrderTimerComponent>('timer');
    log = effect(() => {
        // console.log(this.pickDetailsService?.orderHeader().STATUS);

        if (this.timer() || (this.timer()?.remaining() ?? 0) > 0) {
            this.enableUnship.set(
                (this.timer()!.remaining() < 0 &&
                    this.pickDetailsService.orderHeader().STATUS_DESC !==
                        'Unshipped') ||
                    this.pickDetailsService.orderHeader().STATUS !== '95',
            );
        }
    });
    OrderKey = input.required<string>();
    orderLines = signal<PickDetails[]>([]);
    ACTUALSHIPDATE = signal<Date | null>(null);
    exportFileName = 'Pick-List';
    selectedOrderLines = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    @Input() pickDetailsService!: OrderLineService;
    AppReminingTime = inject(AppReminingTime);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    columns = signal(
        Object.values(PickDetailsColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    canUnship = computed(() => {
        if (!this.AppReminingTime.coolingPeriodActive()) return false;
        const now = new Date();
        const endTime = this.AppReminingTime.coolingPeriodEndTime();
        if (!endTime) return false;
        const isWithinCoolingPeriod = now.getTime() <= endTime.getTime();
        const allShipped = this.pickDetailsService
            .PickDetails()
            .every((line) => line.STATUS === '9');

        return isWithinCoolingPeriod && allShipped;
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    userFormRef: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    ConfirmationRef: DynamicDialogRef | undefined;
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    NotesRef: DynamicDialogRef | undefined;

    ngOnInit() {
        this.pickDetailsService.orderHeader();
        this.pickDetailsService.getCoolerTime();
    }
    ngAfterViewInit() {
        this.columns.update((columns) =>
            columns.map((column: any) => {
                if (column.field === 'STDDESC') {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }

                return column;
            }),
        );
    }
    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.pickDetailsService.getPickDetails();
    }
    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.exportFileName,
            [],
            this.pickDetailsService.PickDetails(),
        );
    }
    exportCSV() {
        downloadCSVFile(
            this.pickDetailsService.PickDetails(),
            this.exportFileName,
        );
    }

    options(field: string) {
        const uniqueValues = new Set(
            this.orderLines().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }
    IsPicked = computed(() =>
        this.pickDetailsService
            .PickDetails()
            .every((item) => item.STATUS === '5' || item.STATUS === '9')
            ? true
            : false,
    );
    IsShiped = computed(() =>
        this.pickDetailsService
            .PickDetails()
            .every((item) => item.STATUS === '9' || item.STATUS === '0')
            ? true
            : false,
    );

    enableButtonOnSingleSelection = computed(() =>
        this.selectedOrderLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedOrderLines().length > 0 ? true : false,
    );
    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    Pick() {
        if (this.selectedOrderLines().length === 0) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Pick Order Lines',
                detail: 'Please select at least one order line before picking.',
            });
            return;
        }
        const picklines = this.pickDetailsService
            .PickDetails()
            .filter((x) => x.STATUS === '0');
        const headertext = this.translate.instant('Pick Order Lines');
        const value = this.translate.instant('Picklines', {
            no:
                this.selectedOrderLines().length === 0
                    ? picklines.length
                    : this.selectedOrderLines().length,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                if (this.selectedOrderLines().length > 0) {
                    this.loading.set(true);
                    const subscription = this.pickDetailsService
                        .pickbyOrderLines(this.selectedOrderLines())
                        .subscribe({
                            next: (response) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Pick Order Lines',
                                    detail: 'Order Lines picked successfully.',
                                });
                                this.pickDetailsService.reload();
                                this.loading.set(false);
                                this.selectedOrderLines.set([]);
                            },
                            error: (error) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef =
                                        this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                } else {
                                    const errorMessage =
                                        error?.error?.message ||
                                        'An unexpected error occurred while picking Order Lines. Please try again later.';
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Pick Order Lines',
                                        detail: errorMessage,
                                    });
                                }
                                this.loading.set(false);
                            },
                        });

                    this.destroyRef.onDestroy(() => subscription.unsubscribe());
                } else if (this.pickDetailsService.PickDetails().length > 0) {
                    this.loading.set(true);
                    const subscription = this.pickDetailsService
                        .pickbyOrderkey(this.OrderKey())
                        .subscribe({
                            next: (response) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Pick Order Lines',
                                    detail: 'Order Lines picked successfully.',
                                });
                                this.pickDetailsService.reload();
                                this.loading.set(false);
                                this.selectedOrderLines.set([]);
                            },
                            error: (error) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef =
                                        this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                } else {
                                    const errorMessage =
                                        error?.error?.message ||
                                        'An unexpected error occurred while picking Order Lines. Please try again later.';
                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Pick Order Lines',
                                        detail: errorMessage,
                                    });
                                }
                                this.loading.set(false);
                            },
                        });

                    this.destroyRef.onDestroy(() => subscription.unsubscribe());
                } else {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Pick Order Lines',
                        detail: 'No Order Lines available to pick.',
                    });
                    this.loading.set(false);
                }
            }
        });
    }
    UnPick() {
        if (this.selectedOrderLines().length === 0) {
            this.messageService.add({
                severity: 'warn',
                summary: 'UnPick Order Lines',
                detail: 'Please select at least one order line before unpicking.',
            });
            return;
        }
        if (this.selectedOrderLines().length > 0) {
            this.loading.set(true);
            const subscription = this.pickDetailsService
                .unpickOrderLines(this.selectedOrderLines())
                .subscribe({
                    next: (response) => {
                        this.messageService.add({
                            severity: 'success',
                            summary: 'UnPick Order Lines',
                            detail: 'Order Lines Unpicked successfully.',
                        });
                        this.pickDetailsService.reload();
                        this.loading.set(false);
                        this.selectedOrderLines.set([]);
                    },
                    error: (error) => {
                        if (
                            error.error.Message ===
                                'One or more errors occurred!' ||
                            error.error.message ===
                                'One or more errors occurred!'
                        ) {
                            this.ConfirmationRef = this.dialogService.open(
                                CommonErrorboxComponent,
                                {
                                    inputValues: {
                                        error: error,
                                    },
                                    header: 'Multiple Error',
                                    closable: true,
                                    modal: true,
                                    draggable: true,
                                    keepInViewport: true,
                                    width: '39rem',
                                    style: { maxHeight: '40rem' },
                                },
                            );
                        } else {
                            const errorMessage =
                                error?.error?.message ||
                                'Failed to Unpick Order Lines.';
                            this.messageService.add({
                                severity: 'error',
                                summary: 'UnPick Order Lines',
                                detail: errorMessage,
                            });
                        }
                        this.loading.set(false);
                    },
                });

            this.destroyRef.onDestroy(() => subscription.unsubscribe());
        } else {
            if (this.pickDetailsService.PickDetails().length > 0) {
                this.loading.set(true);
                const subscription = this.pickDetailsService
                    .unpickOrderKey(this.OrderKey())
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'UnPick Order Lines',
                                detail: 'Order Lines Unpicked successfully.',
                            });
                            this.pickDetailsService.reload();
                            this.loading.set(false);
                            this.selectedOrderLines.set([]);
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    'Failed to Unpick Order Lines.';
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'UnPick Order Lines',
                                    detail: errorMessage,
                                });
                            }
                            this.loading.set(false);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            } else {
                this.messageService.add({
                    severity: 'error',
                    summary: 'UnPick Order Lines',
                    detail: 'No Order Lines to Unpick.',
                });
            }
        }
    }

    Ship() {
        if (this.selectedOrderLines().length === 0) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Ship Order Lines',
                detail: 'Please select at least one order line before shipping.',
            });
            return;
        }
        let shiplines = this.pickDetailsService
            .PickDetails()
            .filter((x) => x.STATUS === '5');
        const headertext = this.translate.instant('Ship Order Lines');
        const value = this.translate.instant('Shiplines', {
            no:
                this.selectedOrderLines().length === 0
                    ? shiplines.length
                    : this.selectedOrderLines().length,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                if (this.pickDetailsService.PickDetails().length > 0) {
                    this.loading.set(true);
                    const subscription = this.pickDetailsService
                        .shipOrderLines(this.OrderKey())
                        .subscribe({
                            next: (response) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'Ship Order Lines',
                                    detail: 'Order lines shipped successfully.',
                                });
                                this.pickDetailsService.reload();
                                this.loading.set(false);
                                this.selectedOrderLines.set([]);
                            },
                            error: (error) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef =
                                        this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                } else {
                                    const errorMessage =
                                        error?.error?.message ||
                                        'An error occurred while shipping the order lines. Please try again.';

                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Ship Order Lines',
                                        detail: errorMessage,
                                    });
                                }
                                this.loading.set(false);
                            },
                        });

                    this.destroyRef.onDestroy(() => subscription.unsubscribe());
                } else {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Ship Order Lines',
                        detail: 'There are no order lines available for shipping.',
                    });
                    this.loading.set(false);
                }
            }
        });
    }
    UnShip() {
        if (this.selectedOrderLines().length === 0) {
            this.messageService.add({
                severity: 'warn',
                summary: 'UnShip Order Lines',
                detail: 'Please select at least one order line before unshipping.',
            });
            return;
        }
        let shiplines = this.pickDetailsService
            .PickDetails()
            .filter((x) => x.STATUS === '9');
        const headertext = this.translate.instant('UnShip Order Lines');
        const value = this.translate.instant('Are you sure UnShip the Order?', {
            no:
                this.selectedOrderLines().length === 0
                    ? shiplines.length
                    : this.selectedOrderLines().length,
        });
        this.ConfirmationRef = this.dialogService.open(
            UnshipConfrimationComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '39rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                console.log(confirmed);
                if (this.pickDetailsService.PickDetails().length > 0) {
                    this.loading.set(true);
                    const subscription = this.pickDetailsService
                        .unshipOrderLines(this.OrderKey(), confirmed)
                        .subscribe({
                            next: (response) => {
                                this.messageService.add({
                                    severity: 'success',
                                    summary: 'UnShip Order Lines',
                                    detail: 'Order lines UnShip successfully.',
                                });
                                this.pickDetailsService.reload();
                                this.loading.set(false);
                                this.selectedOrderLines.set([]);
                            },
                            error: (error) => {
                                if (
                                    error.error.Message ===
                                        'One or more errors occurred!' ||
                                    error.error.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef =
                                        this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Error',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                } else {
                                    const errorMessage =
                                        error?.error?.message ||
                                        'An error occurred while shipping the order lines. Please try again.';

                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'UnShip Order Lines',
                                        detail: errorMessage,
                                    });
                                }
                                this.loading.set(false);
                            },
                        });

                    this.destroyRef.onDestroy(() => subscription.unsubscribe());
                } else {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'UnShip Order Lines',
                        detail: 'There are no order lines available for UnShiped.',
                    });
                    this.loading.set(false);
                }
            }
        });
    }

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
