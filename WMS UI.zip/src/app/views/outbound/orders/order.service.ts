import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { Order } from './order.model';
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';
import { map, finalize } from 'rxjs';
import { stringToDate } from '../../../common/functions';
import { OrderColumns } from './order.columns';
import { Trader } from '../../masters';
import {
    upperCaseArray,
    upperCaseObject,
    lowerCaseArray,
    lowerCaseObject,
} from '../../../shared/utils/case-conversion.util';

interface OrderPage {
    Orders: Order[];
    totalRecords: number;
}
@Injectable({
    providedIn: 'root',
})
export class OrderService {
    ACTUALSHIPDATE: any;
    Order() {
        throw new Error('Method not implemented.');
    }
    loading = signal<boolean>(false);
    SetActive = signal(false);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getOrder(params: { OrderKey: string }) {
        return this.httpClient
            .get<
                ResponseDto<Order[]>
            >(this.config.appConfig()?.OutUrl + 'orders', { headers: this.authService.getAuthHeaders(), params })
            .pipe(
                map((response) => {
                    if (
                        response?.Response &&
                        Array.isArray(response.Response)
                    ) {
                        response.Response = upperCaseArray(response.Response);
                        response.Response.forEach((order: any) => {
                            Object.keys(order).forEach((key) => {
                                if (OrderColumns[key]?.type === 'date') {
                                    order[key] = stringToDate(order[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    getOrderPage(data: any) {
        return this.httpClient
            .post<OrderPage>(
                this.config.appConfig()?.OutUrl + 'orders/page',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response: any) => {
                    if (
                        response?.Response &&
                        Array.isArray(response.Response)
                    ) {
                        response.Response = upperCaseArray(response.Response);
                        response.Response.forEach((order: any) => {
                            Object.keys(order).forEach((key) => {
                                if (OrderColumns[key]?.type === 'date') {
                                    order[key] = stringToDate(order[key]);
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }

    GetOrderAttachment(Id: any) {
        return this.httpClient.get(
            this.config.appConfig()?.OutUrl +
                `orders/attachment?Facility=DEV&Id=${Id}`,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    createOrder(data: any) {
        const payload =
            typeof data === 'object' && data !== null
                ? lowerCaseObject(data)
                : data;
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'orders',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    updateOrder(data: any) {
        const payload =
            typeof data === 'object' && data !== null
                ? lowerCaseObject(data)
                : data;
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    deleteOrder(data: any) {
        const payload = Array.isArray(data)
            ? data
            : typeof data === 'object' && data !== null
              ? lowerCaseObject(data)
              : data;
        return this.httpClient.delete<ResponseDto<{ deletedOrderKey: string }>>(
            this.config.appConfig()?.OutUrl + 'orders',
            {
                headers: this.authService.getAuthHeaders(),
                body: payload,
            },
        );
    }
    createOrderTemplate(data: any) {
        this.SetActive.set(true);
        const payload = Array.isArray(data)
            ? lowerCaseArray(data)
            : typeof data === 'object' && data !== null
              ? lowerCaseObject(data)
              : data;
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'Orders/edi',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    CreateBackOrders(orderData: any) {
        const payload =
            typeof orderData === 'object' && orderData !== null
                ? lowerCaseObject(orderData)
                : orderData;
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Orders/Close',
            payload,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
