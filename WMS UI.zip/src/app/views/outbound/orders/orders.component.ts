import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
    input,
    effect,
    TemplateRef,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize, lastValueFrom, take } from 'rxjs';
import { OrderColumns } from './order.columns';
import { Order } from './order.model';
import { OrderService } from './order.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    LoadingComponent,
    ConfirmationDialogComponent,
    ViewImageDialogComponent,
} from '../../../common/components';
import { Route, Router } from '@angular/router';
import { OrderFormComponent } from './order-form/orders.form.component';
import outboundRoutes from '../outbound.routes';
import { TabService } from '../../../tabs/tab.service';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import * as XLSX from 'xlsx';
import { acceptedImageTypes, tableOptions } from '../../../common/constants';
import { TagModule } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';
import { convertExcelDate } from '../../../common/functions/numberToDate';

import { OrderTimerComponent } from './order-timer/order-timer.component';
import { filterQuery } from '../../../common/functions';
import { OptionsService } from '../../../common/services/options.service';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';

interface UploadEvent {
    originalEvent: Event;
    files: File[];
}
@Component({
    selector: 'app-orders',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        FileUpload,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TagModule,
        TooltipModule,
        AppTranslatePipe,
        OrderTimerComponent,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './orders.component.html',
    styleUrl: './orders.component.scss',
    providers: [DialogService],
})
export class OrdersComponent {
    private optionService = inject(OptionsService);
    private translate = inject(TranslateService);
    order = signal<Order[]>([]);
    orderExcel = signal<Order[]>([]);
    selectedOrder = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    OrderKey = input.required<string>();
    dt = viewChild<Table>('dt');
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(15);
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    ConfirmationRef: DynamicDialogRef | undefined;
    excelData: any = [];
    exportFileName = 'Order-list';
    columns = signal<any>([]);
    OrginalColumns = signal<any>(OrderColumns);

    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');

    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x: any) => x.tableAlias && !x.tableHidden)
            .map((x: any) => x.field),
    );

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    typeRestricted(params: string) {
        return acceptedImageTypes.includes(params);
    }
    userFormRef: DynamicDialogRef | undefined;
    private router = inject(Router);
    private ref!: DynamicDialogRef;
    private messageService = inject(MessageService);
    private orderService = inject(OrderService);
    private destroyRef = inject(DestroyRef);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private tabService = inject(TabService);
    private excelDownloadService = inject(ExcelDownloadService);

    ngOnInit() {
        // this.getOrderPage();
        this.getColumns();
    }
    // getColumns() {
    //     this.optionService.getColumns(OrderColumns, 'VY_STO').subscribe({
    //         next: (data) => {
    //             const FilterField = data.map((x: any) => x.field);
    //             const GetFilterFields = Object.values(OrderColumns).filter(
    //                 (x: any) => {
    //                     return !FilterField.includes(x.field);
    //                 },
    //             );
    //             const columns = [...GetFilterFields, ...data];
    //             this.columns.set(
    //                 columns.filter((column: any) => !column.tableHidden),
    //             );

    //
    //         },
    //     });
    // }
    getColumns() {
        this.optionService.getColumns(OrderColumns, 'ORDERS').subscribe({
            next: (data) => {
                const FilterField = data.map((x: any) => x.field);

                const GetFilterFields = Object.values(OrderColumns).filter(
                    (x: any) => {
                        return !FilterField.includes(x.field);
                    },
                );

                const allowedFields = [
                    'UDFSTR1',
                    'UDFSTR2',
                    'UDFSTR3',
                    'UDFSTR4',
                    'UDFSTR5',
                ];

                const limitedColumns = data.filter(
                    (x: any) =>
                        !x.field?.startsWith('UDF') ||
                        allowedFields.includes(x.field),
                );

                const columns = [...GetFilterFields, ...limitedColumns];

                let updatedColumns = columns;

                updatedColumns = updatedColumns.map((column: any) => {
                    if (column.field === 'STATUS_DESC') {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                });
                this.columns.set(
                    updatedColumns.filter((column: any) => !column.tableHidden),
                );
            },
        });
    }
    statusSeverity: Record<
        string,
        'success' | 'info' | 'warn' | 'danger' | undefined
    > = {
        'Created Internally': 'info',
        'Created Externally': 'info',
        Allocated: 'success',
        'Picked Complete': 'warn',
        Loaded: 'danger',
        'Order Closed': 'danger',
    };
    statusStyles: Record<
        string,
        {
            badge: string;
            dot: string;
        }
    > = {
        info: {
            badge: 'bg-blue-50 text-blue-600',
            dot: 'bg-blue-500',
        },
        success: {
            badge: 'bg-green-50 text-green-600',
            dot: 'bg-green-500',
        },
        warn: {
            badge: 'bg-yellow-50 text-yellow-600',
            dot: 'bg-yellow-500',
        },
        danger: {
            badge: 'bg-red-50 text-red-600',
            dot: 'bg-red-500',
        },
    };
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getOrderPage(event);
    }

    getImageDatax = effect(() => {
        this.order()?.forEach((x: any) => {
            if (x.ATTACHMENTID) {
                this.orderService
                    .GetOrderAttachment(x.ATTACHMENTID)
                    .pipe((imageData) => (x.FILEDATA = imageData));
            }
        });
    });
    getOrderPage(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.selectedOrder.set([]);
        // this.order.set([]);
        const subscription = this.orderService
            .getOrderPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    const first = data?.first ?? 0;
                    this.order.set(
                        res.Response.map((x: any, idx: number) => ({
                            ...x,
                            rowId: first + idx + 1,
                        })),
                    );
                    this.totalRecords.set(res.TotalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'OrderDetails list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetOrderAttachment(Id: any) {
        return this.orderService.GetOrderAttachment(Id);
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getOrderPage();
    }

    getOrdersForExcel(data: any, type: string) {
        this.loading.set(true);

        const subscription = this.orderService
            .getOrderPage(data)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res: any) => {
                    const orders = res?.Response ?? [];

                    if (!Array.isArray(orders) || orders.length === 0) {
                        this.messageService.add({
                            severity: 'warn',
                            summary: 'Export Orders',
                            detail: 'No order records were returned for export.',
                        });
                        return;
                    }

                    if (type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            orders,
                        );
                    } else {
                        downloadCSVFile(orders, this.exportFileName);
                    }
                },
                error: (error: HttpErrorResponse) => {
                    console.error('Order export failed:', error);
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Export Orders',
                        detail: 'Failed to retrieve orders for export.',
                    });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    export(type: string) {
        const event = this.loadEvent();
        this.getOrdersForExcel(
            {
                ...event,
                first: 0,
                rows: this.totalRecords(),
            },
            type,
        );
    }
    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }
    exportExcelTemplate() {
        const Column = [
            'Owner',
            'ExternOrderKey',
            'OrderDate',
            'ExpectedDeliveryDate',
            'ShipTo',
            'CarrierCode',
            'Sku',
            'AltSku',
            'TotalQty',
            'Lottable01',
            'Lottable02',
            'Lottable03',
            'ManufactureDate',
            'ExpirationDate',
            'Lottable06',
            'Lottable07',
            'Lottable08',
            'Lottable09',
            'Lottable10',
            'AllocationStrategy',
        ];
        this.excelDownloadService.downloadExcelFile(
            'Order-Template',
            Column,
            null,
        );
    }

    options(field: string) {
        const uniqueValues = new Set(this.order().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedOrder().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedOrder().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }
    async OpenImage(order: any) {
        const image = await lastValueFrom(order.FILEDATA.pipe(take(1)));
        this.userFormRef = this.dialogService.open(ViewImageDialogComponent, {
            inputValues: {
                image: image,
                fileName: order?.ATTACHMENTFILENAME,
            },
            header: 'Image',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            width: '55rem',
            style: { height: '45rem' },
        });
        this.userFormRef.onClose.subscribe((data) => {});
    }
    OpenCreateOrderForm() {
        const headertext = this.translate.instant('Create Order');
        this.userFormRef = this.dialogService.open(OrderFormComponent, {
            // header: headertext,
            // closable: true,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },
            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },
            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('OrderCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.orderService
                            .createOrder(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getOrderPage();
                                }),
                            )
                            .subscribe({
                                next: (outData: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Order Creation',
                                        detail: outData.Response.message as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'New Order Creation',
                                            detail: error?.error
                                                ?.message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateOrderForm(orderdata: any) {
        const headertext = this.translate.instant('Update Order');
        const selectedOrder: Order = Array.isArray(orderdata)
            ? orderdata[0]
            : orderdata;
        this.userFormRef = this.dialogService.open(OrderFormComponent, {
            inputValues: {
                OrderData: selectedOrder,
            },
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.userFormRef.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('OrderUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        const updatedData: Order = {
                            ...selectedOrder,
                            ...data,
                        };
                        this.orderService
                            .updateOrder(updatedData)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.selectedOrder.set([]);
                                    this.getOrderPage();
                                }),
                            )
                            .subscribe({
                                next: (response: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Order Updated',
                                        detail: response.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Order Update Failed',
                                            detail: error.error
                                                .message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }
    DeleteOrder() {
        const validOrders = this.selectedOrder().filter(
            (order: any) =>
                order.STATUS_DESC === 'Created Internally' ||
                order.STATUS_DESC === 'Created Externally',
        );

        if (validOrders.length === 0) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Delete Order',
                detail: 'No deletable orders selected. Only orders with status "Created Internally" or "Created Externally" can be deleted.',
            });
            return;
        }
        const headertext = this.translate.instant('Confirm Deletion');
        const count = validOrders.length;
        const name =
            count > 1
                ? this.translate.instant('Orders')
                : this.translate.instant('Order');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const validOrderKeys = validOrders.map((x: any) => x.ORDERKEY);

                const subscription = this.orderService
                    .deleteOrder(validOrderKeys)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedOrder.set([]);
                            this.getOrderPage();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Delete Order',
                                detail: 'Order(s) deleted successfully.',
                            });

                            // Update UI by removing deleted orders
                            this.order.set(
                                this.order().filter(
                                    (order) =>
                                        !validOrderKeys.includes(
                                            order.ORDERKEY,
                                        ),
                                ),
                            );
                        },
                        error: (err) => {
                            console.error('Error deleting Order:', err);

                            const fieldErrors = err?.error?.FieldErrors?.map(
                                (fieldError: any) =>
                                    `${fieldError.Field}: ${fieldError.Message}`,
                            ).join(', ');

                            const apiMessage =
                                err?.error?.message || err?.error?.Message;

                            const errorMessage =
                                fieldErrors ||
                                apiMessage ||
                                'An unexpected error occurred while deleting the order. Please try again later.';

                            this.messageService.add({
                                severity: 'error',
                                summary: 'Delete Order',
                                detail: errorMessage,
                            });
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    onEditAction(order: Order) {}

    onClickOrderKey(row: Order): void {
        // event.preventDefault();
        const route = outboundRoutes.find(
            (route) => route.data?.name === 'orderline',
        ) as Route;
        var params = [
            { name: 'OrderKey', value: row.ORDERKEY },
            { name: 'StorerKey', value: row.TRADERKEY },
            { name: 'ExternOrderKey', value: row.EXTERNORDERKEY },
        ];
        this.tabService.addTabWithParams(
            route,
            '',
            'Order Details - ' + row.ORDERKEY,
            params,
        );
    }

    onFileSelect(event: any) {
        const file = event.files[0];
        const reader = new FileReader();
        reader.onload = async (e: any) => {
            const workbook = XLSX.read(e.target.result, { type: 'binary' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            this.excelData = XLSX.utils.sheet_to_json(worksheet, { raw: true });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const sheetData: any[][] = XLSX.utils.sheet_to_json(sheet, {
                header: 1,
            });
            if (this.excelData.length > 0) {
                this.loading.set(true);
                const dataRows = sheetData.slice(1);

                const FinalData = dataRows.map(
                    (row: any[], rowIndex: number) => {
                        return {
                            StoreCode: row[0] ? row[0].toString() : null,
                            ExternalOrderKey: row[1] ? row[1].toString() : null,
                            ORDERDATE: row[2]
                                ? convertExcelDate(row[2])
                                : new Date(),
                            ExpectedDeliveryDate: row[3]
                                ? convertExcelDate(row[3])
                                : null,
                            CustomerId: row[4] ? row[4].toString() : null,
                            CarrierId: row[5] ? row[5].toString() : null,
                            Sku: row[6] ? row[6].toString() : null,
                            AltSku: row[7] ? row[7].toString() : null,
                            Quantity: row[8],
                            Lottable01: row[9],
                            Lottable02: row[10],
                            Lottable03: row[11],
                            Lottable04: row[12]
                                ? convertExcelDate(row[12])
                                : null,
                            Lottable05: row[13]
                                ? convertExcelDate(row[13])
                                : null,
                            Lottable06: row[14],
                            Lottable07: row[15],
                            Lottable08: row[16],
                            Lottable09: row[17],
                            Lottable10: row[18],
                            AllocationStrategy: row[19],
                            Status: 0,
                        };
                    },
                );
                this.orderService
                    .createOrderTemplate(FinalData)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.getOrderPage();
                        }),
                    )
                    .subscribe({
                        next: (data: any) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Order Upload',
                                detail: data.Response,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Order Upload',
                                    detail: error?.error?.Message as string,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            } else {
                this.loading.set(false);
                this.messageService.add({
                    severity: 'warn',
                    summary: 'Order Upload',
                    detail: 'The file contains no data rows. Please add data below the header row and try again.',
                });
            }
        };
        reader.readAsArrayBuffer(file);
    }

    OnClickCreateBackOrders() {
        const validOrders = this.selectedOrder().filter(
            (x: any) => x.STATUS === '04',
        );

        if (validOrders.length === 0) {
            this.messageService.add({
                severity: 'error',
                summary: 'Close order',
                detail: 'No valid orders to close.',
            });
            return;
        }

        const header = this.translate.instant('Close Order');
        const value = this.translate.instant('OrderClose');
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: header,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                this.loading.set(true);
                const requestBody = {
                    ORDERKEY: validOrders.map((x: any) => x.ORDERKEY).join(','), // Convert array to comma-separated string
                };

                const subscription = this.orderService
                    .CreateBackOrders(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedOrder.set([]);
                            this.getOrderPage();
                        }),
                    )
                    .subscribe({
                        next: (response) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Close order',
                                detail: 'Order closed successfully.',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message === 'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message || 'Failed to close Order.';

                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Close Order',
                                    detail: errorMessage,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getOrderPage();
    }
    getColumnWidthNormal(column: any) {
        if (column.field === 'STATUS_DESC' || column.field === 'STATUS') {
            return { width: '16.5rem', 'min-width': '16.5rem' };
        } else if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
