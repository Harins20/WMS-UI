import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { AppConfigService } from '../../../../../app.config.service';
import { ResponseDto } from '../../../../common/models';
import { AuthService } from '../../../../common/services';
import { Order } from '../order.model';
import { CrossDocksColumns } from './cross-dock.columns';
import { stringToDate } from '../../../../common/functions';
import { map } from 'rxjs';

interface CrossDockPage {
    CrossDocks: Order[];
    totalRecords: number;
}

@Injectable({
    providedIn: 'root',
})
export class CrossDockService {
    SetActive = signal(false);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getCrossDockList() {
        return this.httpClient.get<ResponseDto<Order[]>>(
            this.config.appConfig()?.OutUrl + 'orders/cross-dock',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getCrossDockPaged(data: any) {
        return this.httpClient
            .post<CrossDockPage>(
                this.config.appConfig()?.OutUrl + 'Orders/cross-dock',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response: any) => {
                    const items =
                        response?.Response?.CrossDocks ||
                        response?.CrossDocks ||
                        [];
                    if (Array.isArray(items)) {
                        items.forEach((CrossDocks: any) => {
                            Object.keys(CrossDocks).forEach((key) => {
                                if (CrossDocksColumns[key]?.type === 'date') {
                                    CrossDocks[key] = stringToDate(
                                        CrossDocks[key],
                                    );
                                }
                            });
                        });
                    }
                    return response;
                }),
            );
    }
    createCrossDock(data: any) {
        this.SetActive.set(true);
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'orders/cd/edi',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
