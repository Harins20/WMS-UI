import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload, FileUploadEvent } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { Route, Router } from '@angular/router';
import {
    ColumnPicklistComponent,
    LoadingComponent,
} from '../../../../common/components';
import { CrossDocksColumns } from '../cross-dock/cross-dock.columns';
import { Order } from '../order.model';
import { CrossDockService } from './cross-dock.service';
import { ExcelDownloadService } from '../../../../common/services/excel-download.service';
import * as XLSX from 'xlsx';
import outboundRoutes from '../../outbound.routes';
import { TabService } from '../../../../tabs/tab.service';
import { tableOptions } from '../../../../common/constants';
import { TooltipModule } from 'primeng/tooltip';
import { TagModule } from 'primeng/tag';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';

import { convertExcelDate } from '../../../../common/functions/numberToDate';
import { filterQuery } from '../../../../common/functions';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';
import { CustomTablePaginationComponent } from '../../../../common/components/custom-table-pagination/custom-table-pagination.component';

interface UploadEvent {
    originalEvent: Event;
    files: File[];
}

@Component({
    selector: 'app-orders',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        FileUpload,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TagModule,
        TooltipModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './cross-dock.component.html',
    styleUrl: './cross-dock.component.scss',
    providers: [DialogService],
})
export class CrossDockComponent {
    private translate = inject(TranslateService);
    crossDockList = signal<Order[]>([]);
    crossDockExcel = signal<Order[]>([]);
    selectedCrossDock = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    // mainLoading = signal(false);
    ConfirmationRef: DynamicDialogRef | undefined;
    dt = viewChild.required<Table>('dt');
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(10);
    exportFileName = 'Cross-Dock-List';
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    OrginalColumns = signal<any>(CrossDocksColumns);
    columns = signal(
        Object.values(CrossDocksColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    excelData: any = [];
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    userFormRef: DynamicDialogRef | undefined;
    private router = inject(Router);
    private messageService = inject(MessageService);
    private crossDockService = inject(CrossDockService);
    private excelDownloadService = inject(ExcelDownloadService);
    private destoryRef = inject(DestroyRef);
    private tabService = inject(TabService);

    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    constructor() {}
    ngOnInit() {
        this.getCrossDockPaged();
    }

    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         CrossDocksColumns,
    //         'vw.',
    //     );
    //     this.getCrossDockPaged({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getCrossDockPaged(event);
    }
    getCrossDockPaged(data: any = this.loadEvent()) {
        this.loading.set(true);
        this.selectedCrossDock.set([]);
        this.crossDockList.set([]);
        const subscription = this.crossDockService
            .getCrossDockPaged(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    const items =
                        res?.Response?.CrossDocks ||
                        res?.CrossDocks ||
                        res?.Response?.Orders ||
                        res?.Orders ||
                        res?.Response ||
                        [];
                    const total =
                        res?.Response?.totalRecords ??
                        res?.Response?.TotalRecords ??
                        res?.totalRecords ??
                        res?.TotalRecords ??
                        res?.Response?.totalCount ??
                        res?.Response?.TotalCount ??
                        res?.totalCount ??
                        0;

                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }

                    const list = Array.isArray(items) ? items : [];

                    this.crossDockList.set(
                        list.map((x: any, idx: number) => ({
                            ...x,
                            rowId: desc ? idBase - idx : idBase + idx + 1,
                        })),
                    );
                    this.totalRecords.set(total);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Cross Dock list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                    this.loading.set(false);
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getCrossDockPaged();
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getCrossDockPaged();
    }

    getCrossDockForExcel(
        data: any = { Page: 1, PageSize: this.totalRecords() },
        type: string,
    ) {
        this.crossDockExcel.set([]);
        const subscription = this.crossDockService
            .getCrossDockPaged(data)
            .pipe()
            .subscribe({
                next: (res: any) => {
                    const items =
                        res?.Response?.CrossDocks ||
                        res?.CrossDocks ||
                        res?.Response?.Orders ||
                        res?.Orders ||
                        res?.Response ||
                        [];
                    const list = Array.isArray(items) ? items : [];
                    this.crossDockExcel.set(list);
                    if (list && type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            list,
                        );
                    } else {
                        downloadCSVFile(list, this.exportFileName);
                    }
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Cross Dock list for excel',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    export(type: string) {
        const event = this.loadEvent();
        const PageSize = this.totalRecords();
        const Page = (event.first || 0) / PageSize + 1;
        const { filter, orderBy } = filterQuery(
            event,
            this.globalFilterColumns(),
            CrossDocksColumns,
            'vw.',
        );

        this.getCrossDockForExcel(
            {
                Page,
                PageSize,
                Condition: filter,
                OrderBy: orderBy,
            },
            type,
        );
    }

    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }
    exportExcelTemplate() {
        const Column = [
            'Owner',
            'ExternOrderKey',
            'OrderDate',
            'ExpectedDeliveryDate',
            'ShipTo',
            'CarrierCode',
            'Sku',
            'AltSku',
            'TotalQty',
            'Lottable01',
            'Lottable02',
            'Lottable03',
            'ManufactureDate',
            'ExpirationDate',
            'Lottable06',
            'Lottable07',
            'Lottable08',
            'Lottable09',
            'Lottable10',
            'AllocationStrategy',
        ];
        this.excelDownloadService.downloadExcelFile(
            'Cross-Dock-Template',
            Column,
            null,
        );
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.crossDockList().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedCrossDock().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedCrossDock().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }

    onEditAction(order: Order) {}

    onClickOrderKey(row: Order): void {
        // event.preventDefault();

        if (!row.ORDERKEY || !row.TRADERKEY || !row.EXTERNORDERKEY) {
            this.messageService.add({
                severity: 'error',
                summary: 'Navigation Error',
                detail: 'Missing required data: ORDERKEY, TRADERKEY, or EXTERNORDERKEY.',
            });
            return;
        }

        const route = outboundRoutes.find(
            (route) => route.data?.name === 'orderline',
        ) as Route;

        const params = [
            { name: 'OrderKey', value: row.ORDERKEY },
            { name: 'StorerKey', value: row.TRADERKEY },
            { name: 'ExternOrderKey', value: row.EXTERNORDERKEY },
        ];

        this.tabService.addTabWithParams(
            route,
            '',
            'Order Details - ' + row.ORDERKEY,
            params,
        );
    }

    onFileSelect(event: any) {
        const file = event.files[0];
        this.loading.set(true);
        const reader = new FileReader();
        reader.onload = async (e: any) => {
            const workbook = XLSX.read(e.target.result, { type: 'binary' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            this.excelData = XLSX.utils.sheet_to_json(worksheet, { raw: true });
            if (this.excelData.length > 0) {
                const FinalData = this.excelData.map((x: any) => {
                    return {
                        TRADERKEY: x.Owner ? x.Owner.toString() : null,
                        EXTERNALORDERKEY: x.ExternOrderKey
                            ? x.ExternOrderKey.toString()
                            : null,
                        ORDERDATE: x.OrderDate
                            ? convertExcelDate(x.OrderDate)
                            : new Date(),
                        EXPECTEDDELIVERYDATE: x.ExpectedDeliveryDate
                            ? convertExcelDate(x.ExpectedDeliveryDate)
                            : null,
                        CUSTOMERID: x.ShipTo ? x.ShipTo.toString() : null,
                        CARRIERID: x.CarrierCode
                            ? x.CarrierCode.toString()
                            : null,
                        SKU: x.Sku ? x.Sku.toString() : null,
                        ALTSKU: x.AltSku,
                        QUANTITY: x.TotalQty,
                        LOTTABLE01: x.Lottable01,
                        LOTTABLE02: x.Lottable02,
                        LOTTABLE03: x.Lottable03,
                        LOTTABLE04: x.ManufactureDate,
                        LOTTABLE05: x.ExpirationDate,
                        LOTTABLE06: x.Lottable06,
                        LOTTABLE07: x.Lottable07,
                        LOTTABLE08: x.Lottable08,
                        LOTTABLE09: x.Lottable09,
                        LOTTABLE10: x.Lottable10,
                        ALLOCATIONSTRATEGY: x.AllocationStrategy,
                        STATUS: 0,
                    };
                });
                this.crossDockService
                    .createCrossDock(FinalData)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.getCrossDockPaged();
                        }),
                    )
                    .subscribe({
                        next: (data) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Cross Dock',
                                detail: 'Cross Dock Successful',
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Cross Dock',
                                    detail: error?.error?.Message as string,
                                });
                            }
                            this.loading.set(false);
                        },
                    });
            } else {
                this.loading.set(false);
                this.messageService.add({
                    severity: 'warn',
                    summary: 'Cross Dock Upload',
                    detail: 'The file contains no data rows. Please add data below the header row and try again.',
                });
            }
        };
        reader.readAsArrayBuffer(file);
    }
}
