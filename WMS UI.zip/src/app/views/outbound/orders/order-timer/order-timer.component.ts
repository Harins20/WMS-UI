import {
    Component,
    Input,
    OnDestroy,
    OnInit,
    effect,
    input,
    signal,
} from '@angular/core';
import { TagModule } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';

import { interval, Subscription } from 'rxjs';

@Component({
    selector: 'app-order-timer',
    imports: [TagModule, TooltipModule],
    templateUrl: 'order-timer.component.html',
})
export class OrderTimerComponent implements OnInit, OnDestroy {
    actualShipDate = input.required<string>();

    coolDownTimer = input.required<number>(); // in minutes

    status = input.required<string>();

    remainingTime = signal<string>('');
    remaining = signal<number>(0);

    showTimer = signal(false);

    private subscription!: Subscription;

    log = effect(() => {
        if (
            this.status() !== '95' ||
            !this.actualShipDate() ||
            !this.coolDownTimer()
        ) {
            this.subscription?.unsubscribe();
            this.showTimer.set(false);
            this.remaining.set(0);

            return;
        } else {
            const shipTimeUTC = new Date(this.actualShipDate() + 'Z'); // still in UTC

            const endTime =
                shipTimeUTC.getTime() + this.coolDownTimer() * 60_000;

            this.subscription = interval(1000).subscribe(() => {
                const now = Date.now();
                const remainingMs = endTime - now;

                if (remainingMs > 0) {
                    this.showTimer.set(true);
                    this.remainingTime.set(this.formatTime(remainingMs));
                } else {
                    this.showTimer.set(false);
                    this.remaining.set(remainingMs);

                    this.subscription.unsubscribe();
                }
            });
        }
    });

    ngOnInit(): void {}

    formatTime(ms: number): string {
        const totalSeconds = Math.floor(ms / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;

        return `${this.pad(hours)}:${this.pad(minutes)}:${this.pad(seconds)}`;
    }

    pad(value: number): string {
        return value < 10 ? '0' + value : value.toString();
    }

    ngOnDestroy(): void {
        this.subscription?.unsubscribe();
    }
}
