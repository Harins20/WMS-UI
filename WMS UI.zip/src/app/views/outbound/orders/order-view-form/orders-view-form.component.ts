import {
    Component,
    computed,
    DestroyRef,
    effect,
    inject,
    Input,
    input,
    linkedSignal,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePicker } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import { TabsModule } from 'primeng/tabs';
import { selectOption } from '../../../../common/models';
import { OptionsService } from '../../../../common/services';
import { getErrorMessages } from '../../../../common/functions';
import { OrderColumns } from '../order.columns';
import { acceptedImageTypes } from '../../../../common/constants';
import { OrderLineService } from '../order-tabs/order-line.service';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';

@Component({
    selector: 'order-view-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        Select,
        ButtonModule,
        TabsModule,
        DatePicker,
        AppTranslatePipe, ],
    templateUrl: './order-view-form.component.html',
})
export class OrdersViewFormComponent {
    OrderKey = input.required<any>();
    OrderData = input<any>();
    attachmentData = signal<string | null>(null);
    typeRestricted(params: string) {
        return acceptedImageTypes.includes(params);
    }
    private destroyRef = inject(DestroyRef);
    private optionService = inject(OptionsService);

    orderlineService = input.required<OrderLineService>();

    loading = signal(false);
    formControlsArray = signal(
        Object.values(OrderColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue),
        ]),
    );
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    form = new FormGroup(this.formControls());
    ownerOptions = signal<selectOption[]>([]);
    typeOptions = signal<selectOption[]>([]);
    transformationfromOptions = signal<selectOption[]>([]);
    priorityOptions = signal<selectOption[]>([]);

    orderHeader = computed(() => {
        if (this.orderlineService()) {
            return this.orderlineService().orderHeader();
        }
        return undefined;
    });

    log = effect(() => {
        if (this.orderHeader()) {
            this.form.patchValue({
                ...this.orderHeader(),
                ORDERDATE: this.orderHeader().ORDERDATE
                    ? new Date(this.orderHeader().ORDERDATE)
                    : null,
                REQUESTEDSHIPDATE: this.orderHeader().REQUESTEDSHIPDATE
                    ? new Date(this.orderHeader().REQUESTEDSHIPDATE)
                    : null,
                TRANSPORTATIONMODE: this.orderHeader().TRANSPORTATIONMODE,
            });
        }
    });

    ngOnInit() {
        Object.values(OrderColumns).forEach((column) => {
            if (column) {
                this.form.controls[column.field].disable();
            }
        });
        // this.form.patchValue({
        //     ...this.orderHeaderService?.orderHeader(),
        // });
        this.GetOwnerOptions();
        this.GetTypeOptions();
        this.GetTransformationMode();
        this.GetPriorityOptions();
    }

    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetTypeOptions() {
        const subscription = this.optionService
            .getOrderTypeOptions()
            .subscribe({
                next: (data) => {
                    this.typeOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetTransformationMode() {
        const subscription = this.optionService
            .getTransportationModeOptions()
            .subscribe({
                next: (data) => {
                    this.transformationfromOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPriorityOptions() {
        const subscription = this.optionService.getPriorityOptions().subscribe({
            next: (data) => {
                this.priorityOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
}
