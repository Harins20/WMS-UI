import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePicker } from 'primeng/datepicker';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import { TabsModule } from 'primeng/tabs';
import { selectOption } from '../../../../common/models';
import {
    AuthService,
    Base64ConvertService,
    OptionsService,
    safeAtob,
} from '../../../../common/services';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { OrderColumns } from '../order.columns';
import { FileUpload } from 'primeng/fileupload';
import { acceptedImageTypes } from '../../../../common/constants';
import { TextareaModule } from 'primeng/textarea';
import { Checkbox } from 'primeng/checkbox';
import { ToggleButton } from 'primeng/togglebutton';
import { MessageService } from 'primeng/api';
import { InputTextComponent } from '../../../../common/components/input-text/input-text.component';
import { InputDatepickerComponent } from '../../../../common/components';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { CommonModule } from '@angular/common';
import { LayoutService } from '../../../../layout/service/layout.service';
import {
    upperCaseObject,
    lowerCaseObject,
} from '../../../../shared/utils/case-conversion.util';

@Component({
    selector: 'order-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        Select,
        ButtonModule,
        TabsModule,
        FileUpload,
        Checkbox,
        ToggleButton,
        InputTextComponent,
        InputDatepickerComponent,
        AppTranslatePipe,
        CommonModule,
    ],
    styleUrls: ['./order-form.component.scss'],
    templateUrl: './order-form.component.html',
})
export class OrderFormComponent {
    orderType = input<any>();
    OrderData = input<any>();
    activeTab = signal<number>(0);
    LayoutService = inject(LayoutService);
    isDarkTheme = computed(() => this.LayoutService.layoutConfig().darkTheme);
    attachmentData = signal<string | null>(null);
    typeRestricted(params: string) {
        return acceptedImageTypes.includes(params);
    }
    private destroyRef = inject(DestroyRef);
    private authservice = inject(AuthService);
    private optionService = inject(OptionsService);
    private router = inject(Router);
    private ref = inject(DynamicDialogRef);
    private base64convert = inject(Base64ConvertService);
    setViewTAb = signal(true);
    private messageService = inject(MessageService);
    loading = signal(false);
    formControlsArray = signal(
        Object.values(OrderColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    form = new FormGroup(this.formControls());
    ownerOptions = signal<selectOption[]>([]);
    typeOptions = signal<selectOption[]>([]);
    orderColumns: any[] = [];
    transformationfromOptions = signal<selectOption[]>([]);
    priorityOptions = signal<selectOption[]>([]);
    carrierOptions = signal<selectOption[]>([]);
    shiptoOptions = signal<selectOption[]>([]);
    private authService = inject(AuthService);
    minOrderDate = computed(() => {
        const orderDate = this.form.get('ORDERDATE')?.value as Date | null;

        const RShipDate = this.form.get('REQUESTEDSHIPDATE')
            ?.value as Date | null;

        if (RShipDate) {
            const minDate = new Date(RShipDate);
            minDate.setDate(minDate.getDate() + 1);
            return minDate;
        }

        return orderDate ?? new Date();
    });

    ngOnInit() {
        if (this.OrderData()) {
            const data = upperCaseObject(this.OrderData());
            Object.values(OrderColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.form.controls[column.field].disable();
            });
            this.form.patchValue({
                ...data,
                FILENAME: data?.ATTACHMENTFILENAME || data?.FILENAME,
                TRANSPORTATIONMODE: data?.TRANSPORTATIONMODE,
            });
        } else {
            Object.values(OrderColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.form.controls[column.field].disable();
            });
            this.form.patchValue({
                TRADERKEY: safeAtob(sessionStorage.getItem('TraderKey')),
            });
        }
        this.GetOwnerOptions();
        this.GetTypeOptions();
        this.GetTransformationMode();
        this.GetPriorityOptions();
        this.GetCarrierOptions();
        this.GetShipToOptions();
        this.handleShipToSelection();
        this.handleCarrierSelection();
        this.getColumns();

        if (this.form.get('INSURED')?.value === false) {
            this.form.get('INSURANCENO')?.disable();
        }
    }
    closePanel() {
        this.ref.close();
    }
    traderType(): any {
        throw new Error('Method not implemented.');
    }
    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }
    goToTab(index: number): void {
        this.activeTab.set(index);
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }
    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetTypeOptions() {
        const subscription = this.optionService
            .getOrderTypeOptions()
            .subscribe({
                next: (data) => {
                    this.typeOptions.set(data.filter((x) => x.value !== '18'));
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetTransformationMode() {
        const subscription = this.optionService
            .getTransportationModeOptions()
            .subscribe({
                next: (data) => {
                    this.transformationfromOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPriorityOptions() {
        const subscription = this.optionService.getPriorityOptions().subscribe({
            next: (data) => {
                this.priorityOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetShipToOptions() {
        const subscription = this.optionService.getShipToOptions().subscribe({
            next: (data) => {
                this.shiptoOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    handleShipToSelection() {
        this.form
            .get('CONSIGNEEKEY')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedTrader: any = this.shiptoOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (selectedTrader) {
                    this.form.patchValue({
                        C_COMPANY:
                            selectedTrader.Company ||
                            selectedTrader.COMPANY ||
                            '',
                        C_ADDRESS1:
                            selectedTrader.Address1 ||
                            selectedTrader.ADDRESS1 ||
                            '',
                        C_ADDRESS2:
                            selectedTrader.Address2 ||
                            selectedTrader.ADDRESS2 ||
                            '',
                        C_ADDRESS3:
                            selectedTrader.Address3 ||
                            selectedTrader.ADDRESS3 ||
                            '',
                        C_ADDRESS4:
                            selectedTrader.Address4 ||
                            selectedTrader.ADDRESS4 ||
                            '',
                        C_CITY:
                            selectedTrader.City || selectedTrader.CITY || '',
                        C_STATE:
                            selectedTrader.State || selectedTrader.STATE || '',
                        C_ZIP: selectedTrader.Zip || selectedTrader.ZIP || '',
                        C_COUNTRY:
                            selectedTrader.Country ||
                            selectedTrader.COUNTRY ||
                            '',
                        C_EMAIL1:
                            selectedTrader.Email1 ||
                            selectedTrader.EMAIL1 ||
                            '',
                        C_CONTACT1:
                            selectedTrader.Contact1 ||
                            selectedTrader.CONTACT1 ||
                            '',
                        C_PHONE1:
                            selectedTrader.Phone1 ||
                            selectedTrader.PHONE1 ||
                            '',
                    });
                }
            });
    }

    GetCarrierOptions() {
        const subscription = this.optionService.getCarrierOptions().subscribe({
            next: (data) => {
                this.carrierOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    handleCarrierSelection() {
        this.form
            .get('CARRIERCODE')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedShipTo: any = this.carrierOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (selectedShipTo) {
                    this.form.patchValue({
                        CARRIERNAME:
                            selectedShipTo.Company ||
                            selectedShipTo.COMPANY ||
                            '',
                        CARRIERADDRESS1:
                            selectedShipTo.Address1 ||
                            selectedShipTo.ADDRESS1 ||
                            '',
                        CARRIERADDRESS2:
                            selectedShipTo.Address2 ||
                            selectedShipTo.ADDRESS2 ||
                            '',
                        CARRIERCITY:
                            selectedShipTo.City || selectedShipTo.CITY || '',
                        CARRIERSTATE:
                            selectedShipTo.State || selectedShipTo.STATE || '',
                        CARRIERCOUNTRY:
                            selectedShipTo.Country ||
                            selectedShipTo.COUNTRY ||
                            '',
                        CARRIERZIP:
                            selectedShipTo.Zip || selectedShipTo.ZIP || '',
                        CARRIERPHONE:
                            selectedShipTo.Phone1 ||
                            selectedShipTo.PHONE1 ||
                            '',
                    });
                }
            });
    }

    onCheckboxChange(event: any): void {
        if (event.checked) {
            this.form.get('INSURANCENO')?.enable();
        } else {
            this.form.get('INSURANCENO')?.disable();
        }
    }
    onSubmit() {
        if (this.form.valid) {
            this.setViewTAb.set(true);
            this.ref.close(lowerCaseObject(this.form.getRawValue()));
            this.form.reset();
        } else {
            this.setViewTAb.set(false);
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }

    async onFileSelect(event: any) {
        const file = event.files[0];
        const fileName = file.name;

        const base64: string = (await this.base64convert.baseConverFile(
            file,
        )) as string;
        this.form.get('FILENAME')?.setValue(fileName);
        if (base64) {
            this.form.get('FILEDATA')?.setValue(base64);
            this.attachmentData.set(base64);
        }
    }
    getColumns() {
        this.optionService.getColumns(OrderColumns, 'ORDERS').subscribe({
            next: (data) => {
                this.orderColumns = data;
            },
        });
    }
}
