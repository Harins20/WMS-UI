import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { ChipModule } from 'primeng/chip';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    LoadingComponent,
    ConfirmationDialogComponent,
} from '../../../common/components';
import { Route, Router } from '@angular/router';
import outboundRoutes from '../outbound.routes';
import { TabService } from '../../../tabs/tab.service';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';
import * as XLSX from 'xlsx';
import { acceptedImageTypes, tableOptions } from '../../../common/constants';
import { TagModule } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';
import { parseDateToISO } from '../../../common/functions/numberToDate';

import { OptionsService } from '../../../common/services/options.service';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';
import { PackingSlipService } from './packing-slip.service';
import { PackingSlip, PackingSlipColumns } from './packing-slip.columns';
import { Column, Columns } from '../../../common/models';
import { filterQuery } from '../../../common/functions';

@Component({
    selector: 'app-packing-slip',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        FileUpload,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TagModule,
        TooltipModule,
        ChipModule,
        AppTranslatePipe,
        LoadingComponent,
    ],
    templateUrl: './packing-slip.component.html',
    styleUrl: './packing-slip.component.scss',
    providers: [DialogService],
})
export class PackingSlipComponent {
    private optionService = inject(OptionsService);
    private translate = inject(TranslateService);
    packingSlips = signal<PackingSlip[]>([]);
    selectedPackingSlips = signal<PackingSlip[]>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(20);
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    ConfirmationRef: DynamicDialogRef | undefined;
    excelData: any = [];
    exportFileName = 'Packing-Slip-List';
    columns = signal<any>([]);
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    private isProcessingCardClick = false;
    private currentSubscription: any = null;

    // Statistics
    statistics = signal({
        total: 0,
        loaded: 0,
        unloaded: 0,
        todaysLR: 0,
        partiallyLoaded: 0,
    });

    globalFilterColumns = computed(() =>
        this.columns()
            // .filter((x: any) => !x.tableHidden)
            .filter((x: any) => !x.tableHidden && x.field !== 'rowId')
            .map((x: any) => x.field),
    );
    // globalFilterColumns = computed(() =>
    //   this.columns()
    //     .filter((x: any) => x.tableAlias && !x.tableHidden)
    //     .map((x: any) => x.field),
    // );

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    typeRestricted(params: string) {
        return acceptedImageTypes.includes(params);
    }

    userFormRef: DynamicDialogRef | undefined;
    private router = inject(Router);
    private ref!: DynamicDialogRef;
    private messageService = inject(MessageService);
    private packingSlipService = inject(PackingSlipService);
    private destroyRef = inject(DestroyRef);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private tabService = inject(TabService);
    private excelDownloadService = inject(ExcelDownloadService);

    activeStatFilter = signal<string | null>(null);

    ngOnInit() {
        this.getPackingSlipList();
        this.getColumns();
    }

    getColumns() {
        this.optionService.getColumns(PackingSlipColumns, 'VY_STO').subscribe({
            next: (data) => {
                const FilterField = data.map((x: any) => x.field);

                const GetFilterFields = Object.values(
                    PackingSlipColumns,
                ).filter((x: any) => {
                    return !FilterField.includes(x.field);
                });

                const columns = [...GetFilterFields, ...data];

                this.columns.set(
                    columns.filter((column: any) => !column.tableHidden),
                );
            },
        });
    }

    loadData(event: TableLazyLoadEvent) {
        this.loadEvent.set(event);
        const PageSize = event.rows || this.rows();
        const Page = (event.first || 0) / PageSize + 1;

        let orderBy: string | null = null;
        let filter: string | null = null;

        // If stat filter is active, ignore sort and only apply search
        if (this.activeStatFilter()) {
            // Only handle global search if stat filter is active
            if (event.globalFilter) {
                const searchValue = event.globalFilter.toString();
                const searchConditions: string[] = [];
                Object.values(PackingSlipColumns).forEach((column: Column) => {
                    if (column?.dbField && !column?.tableHidden) {
                        searchConditions.push(
                            `${column.dbField} like '%${searchValue}%'`,
                        );
                    }
                });
                if (searchConditions.length > 0) {
                    filter = `(${searchConditions.join(' or ')})`;
                }
            }
            // Don't apply sorting when stat filter is active
            orderBy = null;
        } else {
            // Apply both filter and sort when no stat filter is active
            const result = filterQuery(
                event,
                this.globalFilterColumns(),
                PackingSlipColumns,
                '',
            );
            filter = result.filter;
            orderBy = result.orderBy;
        }

        const requestData: any = {
            Page,
            PageSize,
        };

        if (filter) {
            requestData.Condition = filter;
        }

        if (orderBy) {
            requestData.OrderBy = orderBy;
        }

        this.getPackingSlipList(requestData);
    }

    onStatCardClick(cardType: string) {
        // Prevent multiple clicks while processing
        if (this.isProcessingCardClick) {
            return;
        }

        this.isProcessingCardClick = true;

        try {
            // Clear the search input first
            this.searchInput.set(undefined);

            // Get the table instance
            const table = this.dt();

            // Clear all table filters and sorting
            table?.clear();

            // Reset the loadEvent to clear any stored filters
            this.loadEvent.set({});

            // CRITICAL: Reset totalRecords to 0 BEFORE making API call
            this.totalRecords.set(0);

            // Clear selected items
            this.selectedPackingSlips.set([]);

            // CRITICAL: Reset packingSlips to empty array
            this.packingSlips.set([]);

            // CRITICAL: Reset the table's pagination to first page
            if (table) {
                table.reset();
                (table as any).first = 0; // Reset to first page
            }

            if (cardType === 'total') {
                // Clear active filter
                this.activeStatFilter.set(null);
                // Reset to first page with default rows
                this.getPackingSlipList({ Page: 1, PageSize: this.rows() });
                return;
            }

            // Set the active filter
            this.activeStatFilter.set(cardType);

            let filterCondition: string | null = null;

            switch (cardType) {
                case 'loaded':
                    filterCondition = 'IsLoaded = 1';
                    break;
                case 'unloaded':
                    filterCondition = 'IsLoaded = 0';
                    break;
                case 'todaysLR':
                    const today = new Date();
                    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
                    filterCondition = `CONVERT(date, LR_Date) = '${todayStr}'`;
                    break;
                case 'partiallyLoaded':
                    filterCondition = 'PARTIALLY_LOADED';
                    // filterCondition = "StandardCases > 0 AND PackingCases > 0";
                    break;
            }

            const requestData: any = {
                Page: 1,
                PageSize: this.rows(),
            };

            if (filterCondition) {
                requestData.Condition = filterCondition;
            }

            // Clear any existing OrderBy when applying stat filter
            delete requestData.OrderBy;

            // Call getPackingSlipList directly
            this.getPackingSlipList(requestData);
        } finally {
            // Reset the flag after a short delay
            setTimeout(() => {
                this.isProcessingCardClick = false;
            }, 500);
        }
    }
    getPackingSlipList(data: any = { Page: 1, PageSize: 15 }) {
        // Cancel any ongoing request
        if (this.currentSubscription) {
            this.currentSubscription.unsubscribe();
        }

        // Reset loading state
        this.loading.set(true);

        // Clear existing data immediately
        this.selectedPackingSlips.set([]);
        this.packingSlips.set([]);

        // Clean up data - remove empty strings and undefined values
        const cleanedData: any = {
            Page: data.Page || 1,
            PageSize: data.PageSize || 15,
        };

        // IMPORTANT: For stat filters, always use the condition from activeStatFilter
        // Don't use data.Condition when stat filter is active
        if (this.activeStatFilter()) {
            let filterCondition: string | null = null;
            switch (this.activeStatFilter()) {
                case 'loaded':
                    filterCondition = 'IsLoaded = 1';
                    break;
                case 'unloaded':
                    filterCondition = 'IsLoaded = 0';
                    break;
                case 'todaysLR':
                    const today = new Date();
                    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
                    filterCondition = `CONVERT(date, LR_Date) = '${todayStr}'`;
                    break;
                case 'partiallyLoaded':
                    filterCondition = 'PARTIALLY_LOADED';
                    // filterCondition = "StandardCases > 0 AND PackingCases > 0";
                    break;
            }
            if (filterCondition) {
                cleanedData.Condition = filterCondition;
            }
        } else {
            // Only use data.Condition when no stat filter is active
            if (data.Condition && data.Condition.trim() !== '') {
                cleanedData.Condition = data.Condition;
            }
        }

        // Only add OrderBy if it has value AND no active stat filter
        if (
            data.OrderBy &&
            data.OrderBy.trim() !== '' &&
            !this.activeStatFilter()
        ) {
            cleanedData.OrderBy = data.OrderBy;
        }

        // Remove parentheses from Condition if they exist
        if (cleanedData.Condition) {
            cleanedData.Condition = cleanedData.Condition.replace(
                /^\(|\)$/g,
                '',
            );
        }

        this.currentSubscription = this.packingSlipService
            .getPackingSlipList(cleanedData)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    // Calculate row IDs
                    let idBase =
                        cleanedData.Page * cleanedData.PageSize -
                        cleanedData.PageSize;
                    let desc = false;
                    if (cleanedData.OrderBy?.includes('PackingSlipNo desc')) {
                        idBase =
                            (res.totalRecords || 0) -
                            (cleanedData.Page - 1) * cleanedData.PageSize;
                        desc = true;
                    }

                    const packingSlipsWithRowId = (res.packingSlips || []).map(
                        (x: any, idx: number) => ({
                            rowId: desc ? idBase - idx : idBase + idx + 1,
                            packingSlipNo: x.PackingSlipNo,
                            packingSlipLabel: x.PackingSlipLabel,
                            packingSlipDate: x.PackingSlipDate,
                            customerCode: x.CustomerCode,
                            // customerCode: parseInt(x.CustomerCode),
                            customerName: x.CustomerName,
                            place: x.Place,
                            LR_Number: x.LR_Number,
                            LR_Date: x.LR_Date,
                            transporter: x.Transporter,
                            standardCases: x.StandardCases,
                            packingCases: x.PackingCases,
                            totalCases: x.TotalCases,
                            isLoaded: x.IsLoaded,
                            loadedDate: x.LoadedDate,
                            invoiceNumbers: x.InvoiceNumbers,
                            uploadBatchId: x.UploadBatchId,
                        }),
                    );

                    this.packingSlips.set(packingSlipsWithRowId);

                    // CRITICAL: Use res.totalRecords only
                    const newTotalRecords = res.totalRecords || 0;
                    this.totalRecords.set(newTotalRecords);

                    // Use statistics directly from API response
                    this.statistics.set({
                        total: res.OverallCount || 0,
                        loaded: res.LoadedCount || 0,
                        unloaded: res.UnloadedCount || 0,
                        todaysLR: res.TodaysLRCount || 0,
                        partiallyLoaded: res.PartiallyLoadedCount || 0,
                    });
                },
                error: (error: HttpErrorResponse) => {
                    console.error(error);
                    if (error.status === 0) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Packing Slip List',
                            detail: 'Network error occurred. Please check your internet connection.',
                        });
                    } else {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Packing Slip List',
                            detail:
                                error.error?.Message ||
                                'Failed to load packing slips.',
                        });
                    }
                    // Reset totalRecords on error
                    this.totalRecords.set(0);
                },
            });

        this.destroyRef.onDestroy(() => {
            if (this.currentSubscription) {
                this.currentSubscription.unsubscribe();
            }
        });
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        // Trim leading and trailing whitespace
        const trimmedValue = eventValue?.trim() || '';
        this.searchInput.set(trimmedValue);

        // This will trigger a new lazy load with the filter
        dt.filterGlobal(trimmedValue, 'contains');
    }
    // globalFilter(dt: Table, event: Event) {
    //   const eventValue = (event.target as HTMLInputElement).value;
    //   this.searchInput.set(eventValue);
    //   // This will trigger a new lazy load with the filter
    //   dt.filterGlobal(eventValue, 'contains');
    // }

    clear(table: Table) {
        // Cancel any ongoing request
        if (this.currentSubscription) {
            this.currentSubscription.unsubscribe();
            this.currentSubscription = null;
        }

        table?.clear();
        this.searchInput.set(undefined);
        this.activeStatFilter.set(null);
        this.loadEvent.set({});
        this.totalRecords.set(0);
        this.selectedPackingSlips.set([]);
        this.packingSlips.set([]);
        // Reset to first page
        this.getPackingSlipList({ Page: 1, PageSize: this.rows() });
    }

    refresh(table: Table) {
        // Cancel any ongoing request
        if (this.currentSubscription) {
            this.currentSubscription.unsubscribe();
            this.currentSubscription = null;
        }

        table?.clear();
        this.searchInput.set(undefined);
        this.activeStatFilter.set(null);
        this.loadEvent.set({});
        this.totalRecords.set(0);
        this.selectedPackingSlips.set([]);
        this.packingSlips.set([]);
        // Reset to first page
        this.getPackingSlipList({ Page: 1, PageSize: this.rows() });
    }

    getPackingSlipsForExcel(
        data: any = { Page: 1, PageSize: this.totalRecords() },
        type: string,
    ) {
        const subscription = this.packingSlipService
            .getPackingSlipList(data)
            .subscribe({
                next: (res: any) => {
                    if (res?.packingSlips && type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            res.packingSlips,
                        );
                    } else if (res?.packingSlips && type === 'CSV') {
                        downloadCSVFile(res.packingSlips, this.exportFileName);
                    }
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Export Failed',
                            detail: 'Network error occurred.',
                        });
                    }
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    export(type: string) {
        const event = this.loadEvent();
        const PageSize = this.totalRecords();
        const Page = 1;

        // USE THE SAME filterQuery FUNCTION
        const { filter, orderBy } = filterQuery(
            event,
            this.globalFilterColumns(),
            PackingSlipColumns,
            '',
            // 'vw.'
        );

        const requestData: any = {
            Page: Page,
            PageSize: PageSize > 0 ? PageSize : this.totalRecords(),
        };

        if (filter) {
            requestData.Condition = filter;
        }

        if (orderBy) {
            requestData.OrderBy = orderBy;
        }

        this.getPackingSlipsForExcel(requestData, type);
    }
    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }

    options(field: string) {
        const uniqueValues = new Set(
            this.packingSlips().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(
        () => this.selectedPackingSlips().length === 1,
    );

    enableButtonOnOneOrMoreSelection = computed(
        () => this.selectedPackingSlips().length > 0,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe(() => {});
    }

    onClickPrintLabel(): void {
        const selectedSlips = this.selectedPackingSlips();
        if (selectedSlips.length === 0) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Print Label',
                detail: 'Please select at least one packing slip to print.',
            });
            return;
        }

        // Group by PackingSlipNo to avoid duplicates
        const uniqueSlips = new Map<string, PackingSlip>();
        selectedSlips.forEach((slip) => {
            if (!uniqueSlips.has(slip.packingSlipNo)) {
                uniqueSlips.set(slip.packingSlipNo, slip);
            }
        });

        // Map to the format expected by MultiLabelViewerComponent (PascalCase)
        const data = {
            packingSlips: Array.from(uniqueSlips.values()).map((slip) => ({
                PackingSlipNo: slip.packingSlipNo, // Note: Capital P
                PackingSlipLabel: slip.packingSlipLabel, // Note: Capital P
                totalCases: slip.totalCases, // Note: Capital P
            })),
        };

        const route = outboundRoutes.find(
            (route) => route.data?.name === 'Multi Label Viewer',
        ) as Route;

        const params = [{ name: 'packingSlips', value: data.packingSlips }];

        this.tabService.addTabWithParams(
            route,
            '',
            `Packing Labels (${data.packingSlips.length})`,
            params,
        );
    }

    DeletePackingSlip() {
        const selectedSlips = this.selectedPackingSlips();

        if (selectedSlips.length === 0) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Delete Packing Slip',
                detail: 'No packing slips selected for deletion.',
            });
            return;
        }

        const headertext = this.translate.instant('Confirm Deletion');
        const count = selectedSlips.length;
        const name =
            count > 1
                ? this.translate.instant('Packing Slips')
                : this.translate.instant('Packing Slip');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });

        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );

        this.ConfirmationRef.onClose.subscribe((confirmed) => {
            if (confirmed) {
                this.loading.set(true);
                // const packingSlipNos = selectedSlips.map(x => x.packingSlipNo);
                // Delete logic here when API is ready
                this.loading.set(false);
                this.getPackingSlipList();
            }
        });
    }

    getColumnWidthNormal(column: any): { [key: string]: string } {
        if (column.width) {
            return { width: column.width };
        }

        switch (column.type) {
            case 'date':
                return { width: '130px' };
            case 'number':
                return { width: '110px' };
            case 'select':
                return { width: '180px' };
            default:
                return { width: '150px' };
        }
    }

    onFileSelect(event: any) {
        const file = event.files[0];
        const reader = new FileReader();
        reader.onload = async (e: any) => {
            try {
                const workbook = XLSX.read(e.target.result, { type: 'binary' });
                const firstSheetName = workbook.SheetNames[0];
                const sheet = workbook.Sheets[firstSheetName];
                const sheetData: any[][] = XLSX.utils.sheet_to_json(sheet, {
                    header: 1,
                    defval: '', // Set default value for empty cells
                });
                const rowIndex = 1; // Row 1
                const firstRowValues: any[] = [];
                for (let col = 1; col; col++) {
                    const cellRef = XLSX.utils.encode_cell({
                        r: rowIndex - 1,
                        c: col - 1,
                    });
                    const cell = sheet[cellRef];

                    if (!cell) {
                        break; // stop when no cell exists
                    }
                    firstRowValues.push(cell ? String(cell.v).trim() : null);
                }

                const excelHeaders: string[] = [
                    'Packing Slip No:',
                    'Packing Slip date',
                    'Customer Code',
                    'Customer Name',
                    'Place',
                    'Lr_Number',
                    'Lr Date',
                    'Transporter',
                    'Standard Cases',
                    'Packing Cases',
                    'Total Cases',
                    'Document No.',
                    'Date',
                    'Value',
                ];
                const requiredHeaders = excelHeaders.slice(0, -1);

                const mandatoryMatch = requiredHeaders.every(
                    (val, idx) => val === firstRowValues[idx],
                );

                const lastCell = firstRowValues[requiredHeaders.length];

                const headersMatch = mandatoryMatch;

                if (!headersMatch) {
                    const msg =
                        'Excel headers do not match the expected format.';

                    this.ConfirmationRef = this.dialogService.open(
                        CommonErrorboxComponent,
                        {
                            inputValues: {
                                error: {
                                    error: {
                                        Message: 'Excel Validation Errors',
                                        Errors: {
                                            Excel: [msg],
                                        },
                                    },
                                },
                            },
                            header: 'Excel Validation Errors',
                            closable: true,
                            modal: true,
                            draggable: true,
                            keepInViewport: true,
                            width: '50rem',
                            style: { maxHeight: '40rem' },
                        },
                    );

                    return;
                }

                if (sheetData.length > 1) {
                    this.loading.set(true);
                    // Skip header row and filter out empty rows
                    const dataRows = sheetData.slice(1).filter((row) => {
                        // Check if row has any data (not all empty)
                        return row.some(
                            (cell) =>
                                cell !== undefined &&
                                cell !== null &&
                                cell !== '',
                        );
                    });

                    const validationErrors: any[] = [];
                    const packingSlips: any[] = [];

                    for (
                        let rowIndex = 0;
                        rowIndex < dataRows.length;
                        rowIndex++
                    ) {
                        const row = dataRows[rowIndex];
                        const rowNumber = rowIndex + 2; // +2 because header is row 1 and array is 0-based

                        const parseDate = (
                            dateValue: any,
                            fieldName: string,
                            rowNum: number,
                        ): string | null => {
                            if (!dateValue || dateValue === '') {
                                validationErrors.push({
                                    row: rowNum,
                                    field: fieldName,
                                    error: `${fieldName} is missing or empty`,
                                });
                                return null;
                            }

                            const isoDate = parseDateToISO(dateValue);
                            if (!isoDate) {
                                validationErrors.push({
                                    row: rowNum,
                                    field: fieldName,
                                    error: `${fieldName} has invalid date format: "${dateValue}". Expected format: DD.MM.YYYY`,
                                });
                                return null;
                            }

                            const datePart = isoDate.split('T')[0];
                            return `${datePart}T00:00:00`;
                        };

                        // Column mapping based on your Excel structure:
                        // Col 0: Packing Slip No
                        // Col 1: Packing Slip date
                        // Col 2: Customer Code
                        // Col 3: Customer Name
                        // Col 4: Place
                        // Col 5: Lr_Number
                        // Col 6: Lr Date
                        // Col 7: Transporter
                        // Col 8: Standard Cases
                        // Col 9: Packing Cases
                        // Col 10: Total Cases
                        // Col 11: Document No. (optional)

                        const packingSlipNo = row[0]
                            ? row[0].toString().trim()
                            : null;
                        if (!packingSlipNo) {
                            validationErrors.push({
                                row: rowNumber,
                                field: 'Packing Slip No',
                                error: 'Packing Slip No is required',
                            });
                        }

                        const packingSlipDate = parseDate(
                            row[1],
                            'Packing Slip Date',
                            rowNumber,
                        );

                        const customerCode = row[2]
                            ? row[2].toString().trim()
                            : null;
                        if (!customerCode) {
                            validationErrors.push({
                                row: rowNumber,
                                field: 'Customer Code',
                                error: 'Customer Code is required',
                            });
                        }

                        const customerName = row[3]
                            ? row[3].toString().trim()
                            : null;
                        if (!customerName) {
                            validationErrors.push({
                                row: rowNumber,
                                field: 'Customer Name',
                                error: 'Customer Name is required',
                            });
                        }

                        const place = row[4] ? row[4].toString().trim() : null;

                        const lrNumber = row[5]
                            ? row[5].toString().trim()
                            : null;
                        if (!lrNumber) {
                            validationErrors.push({
                                row: rowNumber,
                                field: 'LR Number',
                                error: 'LR Number is required',
                            });
                        }

                        const lrDate = parseDate(row[6], 'LR Date', rowNumber);

                        const transporter = row[7]
                            ? row[7].toString().trim()
                            : null;
                        if (!transporter) {
                            validationErrors.push({
                                row: rowNumber,
                                field: 'Transporter',
                                error: 'Transporter is required',
                            });
                        }

                        // Parse numeric fields
                        let standardCases = 0;
                        let packingCases = 0;
                        let totalCases = 0;

                        if (
                            row[8] !== undefined &&
                            row[8] !== null &&
                            row[8] !== ''
                        ) {
                            const parsed = Number(row[8]);
                            if (isNaN(parsed)) {
                                validationErrors.push({
                                    row: rowNumber,
                                    field: 'Standard Cases',
                                    error: `Standard Cases must be a valid number. Got: ${row[8]}`,
                                });
                            } else {
                                standardCases = parsed;
                            }
                        }

                        if (
                            row[9] !== undefined &&
                            row[9] !== null &&
                            row[9] !== ''
                        ) {
                            const parsed = Number(row[9]);
                            if (isNaN(parsed)) {
                                validationErrors.push({
                                    row: rowNumber,
                                    field: 'Packing Cases',
                                    error: `Packing Cases must be a valid number. Got: ${row[9]}`,
                                });
                            } else {
                                packingCases = parsed;
                            }
                        }

                        if (
                            row[10] !== undefined &&
                            row[10] !== null &&
                            row[10] !== ''
                        ) {
                            const parsed = Number(row[10]);
                            if (isNaN(parsed)) {
                                validationErrors.push({
                                    row: rowNumber,
                                    field: 'Total Cases',
                                    error: `Total Cases must be a valid number. Got: ${row[10]}`,
                                });
                            } else {
                                totalCases = parsed;
                            }
                        }

                        // Only add to packingSlips if packingSlipNo exists
                        if (packingSlipNo) {
                            packingSlips.push({
                                packingSlipNo: packingSlipNo,
                                packingSlipDate: packingSlipDate,
                                customerCode: customerCode,
                                customerName: customerName,
                                place: place,
                                lrNumber: lrNumber,
                                lrDate: lrDate,
                                transporter: transporter,
                                standardCases: standardCases,
                                packingCases: packingCases,
                                totalCases: totalCases,
                                DocumentNo: row[11]
                                    ? row[11].toString().trim()
                                    : null,
                            });
                        }
                    }

                    if (validationErrors.length > 0) {
                        this.loading.set(false);

                        // Show first few errors in toast
                        const errorSummary = validationErrors
                            .slice(0, 3)
                            .map(
                                (err) =>
                                    `Row ${err.row}: ${err.field} - ${err.error}`,
                            )
                            .join('\n');

                        this.messageService.add({
                            severity: 'error',
                            summary: 'Validation Failed',
                            detail: `${validationErrors.length} error(s) found.\n${errorSummary}${validationErrors.length > 3 ? `\n... and ${validationErrors.length - 3} more` : ''}`,
                            life: 8000,
                        });

                        // Also open dialog with all errors
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: {
                                        error: {
                                            Message: 'Excel Validation Errors',
                                            Errors: {
                                                Excel: validationErrors.map(
                                                    (err) =>
                                                        `Row ${err.row}: ${err.field} - ${err.error}`,
                                                ),
                                            },
                                        },
                                    },
                                },
                                header: 'Excel Validation Errors',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '50rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                        return;
                    }

                    if (packingSlips.length === 0) {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Upload Failed',
                            detail: 'No valid data found in the Excel file.',
                        });
                        this.loading.set(false);
                        return;
                    }

                    const payload = {
                        PackingSlips: packingSlips,
                        fileName: file.name,
                    };

                    this.packingSlipService
                        .createPackingSlipTemplate(payload)
                        .pipe(
                            finalize(() => {
                                this.loading.set(false);
                                this.getPackingSlipList();
                            }),
                        )
                        .subscribe({
                            next: (response: any) => {
                                if (response?.Success == 0) {
                                    const failureMessage =
                                        response?.FailureReason ||
                                        `${packingSlips.length} packing slip(s) uploaded successfully.`;

                                    this.messageService.add({
                                        severity: 'success',
                                        summary: response?.Message || 'Failed',
                                        detail: failureMessage,
                                    });
                                } else {
                                    const successMessage =
                                        response?.Response ||
                                        response?.response?.message ||
                                        `${packingSlips.length} packing slip(s) uploaded successfully.`;

                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Upload Successful',
                                        detail: successMessage,
                                    });
                                }
                                event.options?.clear?.();
                            },
                            error: (error) => {
                                console.error('Upload error:', error);

                                if (
                                    error.error?.Message ===
                                        'One or more errors occurred!' ||
                                    error.error?.message ===
                                        'One or more errors occurred!'
                                ) {
                                    this.ConfirmationRef =
                                        this.dialogService.open(
                                            CommonErrorboxComponent,
                                            {
                                                inputValues: {
                                                    error: error,
                                                },
                                                header: 'Multiple Errors',
                                                closable: true,
                                                modal: true,
                                                draggable: true,
                                                keepInViewport: true,
                                                width: '39rem',
                                                style: { maxHeight: '40rem' },
                                            },
                                        );
                                } else {
                                    const errorMessage =
                                        error?.error?.Message ||
                                        error?.error?.message ||
                                        error?.message ||
                                        'Failed to upload packing slips.';

                                    this.messageService.add({
                                        severity: 'error',
                                        summary: 'Upload Failed',
                                        detail: errorMessage,
                                    });
                                }
                                this.loading.set(false);
                            },
                        });
                } else {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Upload Failed',
                        detail: 'No data available in the Excel file.',
                    });
                }
            } catch (error) {
                console.error('File reading error:', error);
                this.messageService.add({
                    severity: 'error',
                    summary: 'Upload Failed',
                    detail: 'Failed to process the Excel file. Please check the file format.',
                });
                this.loading.set(false);
            }
        };

        reader.onerror = () => {
            this.messageService.add({
                severity: 'error',
                summary: 'Upload Failed',
                detail: 'Failed to read the file. Please try again.',
            });
            this.loading.set(false);
        };

        reader.readAsArrayBuffer(file);
    }
    onSingleSelect(packingSlip: PackingSlip, event: any) {
        const isChecked = event.target.checked;

        if (isChecked) {
            // Select only this one
            this.selectedPackingSlips.set([packingSlip]);
        } else {
            // Deselect
            this.selectedPackingSlips.set([]);
        }
    }
}
