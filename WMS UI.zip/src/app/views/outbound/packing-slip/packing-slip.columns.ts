import { Validators } from '@angular/forms';
import { Columns } from '../../../common/models';

export const PackingSlipColumns: Columns = {
    rowId: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
        validators: [Validators.maxLength(200)],
        width: '60px',
    },
    packingSlipNo: {
        // label: 'Pkg Slip No',
        label: 'Packing Slip No',
        field: 'packingSlipNo',
        dbField: 'PackingSlipNo', // Database column name
        type: 'text',
        validators: [Validators.required, Validators.maxLength(50)],
        tableAlias: '',
        width: '150px',
    },
    packingSlipLabel: {
        // label: 'Pkg Slip Label',
        label: 'Packing Slip Label',
        field: 'packingSlipLabel',
        dbField: 'PackingSlipLabel',
        type: 'text',
        validators: [Validators.maxLength(100)],
        tableAlias: '',
    },
    packingSlipDate: {
        // label: 'Pkg Slip Date',
        label: 'Packing Slip Date',
        field: 'packingSlipDate',
        dbField: 'PackingSlipDate',
        type: 'date',
        defaultValue: null,
        tableAlias: '',
    },
    customerCode: {
        label: 'Customer Code',
        field: 'customerCode',
        dbField: 'CustomerCode',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(50)],
        tableAlias: '',
    },
    customerName: {
        label: 'Customer Name',
        field: 'customerName',
        dbField: 'CustomerName',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(200)],
        tableAlias: '',
    },
    place: {
        label: 'Place',
        field: 'place',
        dbField: 'Place',
        type: 'text',
        validators: [Validators.maxLength(100)],
        tableAlias: '',
    },
    lrNumber: {
        label: 'LR Number',
        field: 'LR_Number',
        // field: 'lrNumber',
        dbField: 'LR_Number',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(50)],
        tableAlias: '',
        width: '120px',
    },
    lrDate: {
        label: 'LR Date',
        field: 'LR_Date',
        // field: 'lrDate',
        dbField: 'LR_Date',
        type: 'date',
        defaultValue: null,
        tableAlias: '',
    },
    isLoaded: {
        label: 'Status',
        field: 'isLoaded',
        dbField: 'IsLoaded',
        type: 'text',
        defaultValue: 'Not Loaded',
        tableAlias: '',
        width: '120px',
    },
    transporter: {
        label: 'Transporter',
        field: 'transporter',
        dbField: 'Transporter',
        type: 'text',
        validators: [Validators.required, Validators.maxLength(200)],
        tableAlias: '',
    },
    standardCases: {
        label: 'Standard Cases',
        field: 'standardCases',
        dbField: 'StandardCases',
        type: 'number',
        validators: [Validators.maxLength(22.5)],
        defaultValue: 0,
        tableAlias: '',
        width: '110px',
    },
    packingCases: {
        label: 'Packing Cases',
        field: 'packingCases',
        dbField: 'PackingCases',
        type: 'number',
        validators: [Validators.maxLength(22.5)],
        defaultValue: 0,
        tableAlias: '',
    },
    totalCases: {
        label: 'Total Cases',
        field: 'totalCases',
        dbField: 'TotalCases',
        type: 'number',
        validators: [Validators.maxLength(22.5)],
        defaultValue: 0,
        tableAlias: '',
    },

    loadedDate: {
        label: 'Loaded Date',
        field: 'loadedDate',
        dbField: 'LoadedDate',
        type: 'date',
        defaultValue: null,
        tableAlias: '',
    },
    uploadBatchId: {
        label: 'Upload Batch ID',
        field: 'uploadBatchId',
        dbField: 'UploadBatchId',
        type: 'text',
        validators: [Validators.maxLength(100)],
        tableHidden: true,
        tableAlias: '',
    },
    invoiceNumbers: {
        label: 'Invoice Number',
        field: 'invoiceNumbers',
        dbField: 'InvoiceNumbers',
        type: 'text',
        validators: [Validators.maxLength(100)],
        tableAlias: '',
        width: '200px',
    },
};

export interface PackingSlip {
    rowId?: number;
    packingSlipNo: string;
    packingSlipLabel: string;
    packingSlipDate: string | null;
    customerCode: string;
    customerName: string;
    place: string | null;
    lrNumber: string;
    lrDate: string | null;
    transporter: string;
    standardCases: number;
    packingCases: number;
    totalCases: number;
    isLoaded: boolean;
    loadedDate: string | null;
    uploadBatchId: string;
    invoiceNumbers: string | null;
}
