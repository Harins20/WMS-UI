export interface PackingSlipItem {
    PackingSlipNo: string;
    PackingSlipLabel: string;
    PackingSlipDate: string;
    CustomerCode: string;
    CustomerName: string;
    Place: string;
    LR_Number: string;
    LR_Date: string;
    Transporter: string;
    StandardCases: number;
    PackingCases: number;
    TotalCases: number;
    IsLoaded: boolean;
    LoadedDate: string | null;
    UploadBatchId: string;
}

export interface PackingSlipResponse {
    PackingSlips: PackingSlipItem[];
    TotalCount: number;
    OverallCount: number;
    PartiallyLoadedCount: number;
    TodaysLRCount:number;
    UnloadedCount:number
    LoadedCount:number

}

export interface PackingSlipPage {
    Response: PackingSlipResponse;
    Message: string;
    Success: boolean;
}