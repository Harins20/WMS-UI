import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { Order } from '../orders/order.model'; //TODO
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';
import { map, finalize } from 'rxjs';
import { stringToDate } from '../../../common/functions';
import { OrderColumns } from '../orders/order.columns'; //TODO
import { Trader } from '../../masters';
import { PackingSlipPage } from './packing-slip.model';

interface OrderPage {
    Orders: Order[];
    totalRecords: number;
}
@Injectable({
    providedIn: 'root',
})
export class PackingSlipService {
    ACTUALSHIPDATE: any;
    Order() {
        throw new Error('Method not implemented.');
    }
    loading = signal<boolean>(false);
    SetActive = signal(false);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getOrder(params: { OrderKey: string }) {
        return this.httpClient
            .get<
                ResponseDto<Order[]>
            >(this.config.appConfig()?.OutUrl + 'orders', { headers: this.authService.getAuthHeaders(), params })
            .pipe(
                map((response) => {
                    response.Response.forEach((order: any) => {
                        Object.keys(order).forEach((key) => {
                            if (OrderColumns[key]?.type === 'date') {
                                order[key] = stringToDate(order[key]);
                            }
                        });
                    });
                    return response;
                }),
            );
    }
    getPackingSlipList(data: any) {
        return this.httpClient
            .post<PackingSlipPage>(
                this.config.appConfig()?.OutUrl +
                    'packingslip/PackingSlipsPaged',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response: PackingSlipPage) => {
                    return {
                        packingSlips: response.Response?.PackingSlips || [],
                        totalRecords: response.Response?.TotalCount || 0,
                        OverallCount: response.Response?.OverallCount || 0,
                        LoadedCount: response.Response?.LoadedCount || 0,
                        TodaysLRCount: response.Response?.TodaysLRCount || 0,
                        UnloadedCount: response.Response?.UnloadedCount || 0,
                        PartiallyLoadedCount:
                            response.Response?.PartiallyLoadedCount || 0,
                    };
                }),
            );
    }

    createPackingSlipTemplate(data: any) {
        this.SetActive.set(true);
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'packingslip/import',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    deleteOrder(data: any) {
        return this.httpClient.delete<ResponseDto<{ deletedOrderKey: string }>>(
            this.config.appConfig()?.OutUrl + 'orders',
            {
                headers: this.authService.getAuthHeaders(),
                body: data,
            },
        );
    }
}
