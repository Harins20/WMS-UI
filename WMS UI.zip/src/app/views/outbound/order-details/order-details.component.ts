import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { finalize } from 'rxjs';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    ColumnPicklistComponent,
    LoadingComponent,
} from '../../../common/components';
import { ExcelDownloadService } from '../../../common/services/excel-download.service';

import { tableOptions } from '../../../common/constants';
import { filterQuery } from '../../../common/functions';
import { OrderDetailsColumns } from './order-details.column';
import { OptionsService } from '../../../common/services';
import { TooltipModule } from 'primeng/tooltip';
import { TagModule } from 'primeng/tag';
import { OrderLineService } from '../orders/order-tabs/order-line.service';
import { OrderLine } from '../orders/order-tabs/order-lines';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';

@Component({
    selector: 'app-orderdetails',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        TooltipModule,
        TagModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './order-details.component.html',
    styleUrl: './order-details.component.scss',
    providers: [DialogService],
})
export class OrderDetailsComponent {
    private translate = inject(TranslateService);
    orderDetails = signal<OrderLine[]>([]);
    orderDetailsForExcel = signal<OrderLine[]>([]);
    loadEvent = signal<any>({});
    selectedOrder = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    optionsData = signal<{ [key: string]: any[] }>({
        TRADERKEY: [],
        SKU: [],
        PACKKEY: [],
        STATUS_DESC: [
            { label: 'Created Externally', value: 'Created Externally' },
            { label: 'Created Internally', value: 'Created Internally' },
            { label: 'Open', value: 'Open' },
            { label: 'Allocated', value: 'Allocated' },
            { label: 'Picked Complete', value: 'Picked Complete' },
            { label: 'Shipped Complete', value: 'Shipped Complete' },
        ],
        NEWALLOCATIONSTRATEGY: [],
    });
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    rows = signal(15);
    totalRecords = signal(0);
    gs = signal<string | undefined>(undefined);

    columns = signal(
        Object.values(OrderDetailsColumns).filter(
            (column) => !column.tableHidden,
        ),
    );
    ngAfterViewInit() {
        this.columns.set(
            Object.values(OrderDetailsColumns)
                .filter((column) => !column.tableHidden)
                .map((column: any) => {
                    if (column.field === 'STATUS_DESC') {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                }),
        );
    }
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    globalFilterColumns = computed(() =>
        this.columns()
            .filter((x) => x.tableAlias && !x.tableHidden)
            .map((x) => x.field),
    );
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    OriginalColumns = signal<any>(OrderDetailsColumns);
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    private messageService = inject(MessageService);
    private orderdetailsService = inject(OrderLineService);
    private destroyRef = inject(DestroyRef);
    private optionService = inject(OptionsService);
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    // mainLoading = signal(false);
    private excelDownloadService = inject(ExcelDownloadService);
    constructor() {}
    ngOnInit() {
        // this.getOrderdetails();
        // this.loadOptions();
    }

    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         OrderDetailsColumns,
    //         'vw.',
    //     );
    //     this.getOrderdetails({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getOrderdetails(event);
    }
    // loadOptions() {
    //     this.GetItemOptions();
    //     this.GetPackkeyOptions();
    //     this.GetOwnerOption();
    //     this.GetStatusOptions();
    //     this.GetAllocationOption();
    // }

    GetItemOptions() {
        const subscription = this.optionService.getItems().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, SKU: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPackkeyOptions() {
        const subscription = this.optionService.getPackkey().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, PACKKEY: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetOwnerOption() {
        const subscription = this.optionService.getOwner().subscribe({
            next: (data) => {
                this.optionsData.update((old) => ({ ...old, TRADERKEY: data }));
            },
            error: (err) => {
                console.error('Error fetching item dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetStatusOptions() {
        const subscription = this.optionService
            .getOrderStatusOptions()
            .subscribe({
                next: (data) => {
                    const remap = data.map((x) => ({ ...x, value: x.Label }));
                    this.optionsData.update((old) => ({
                        ...old,
                        STATUS_DESC: remap,
                    }));
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetAllocationOption() {
        const additionalOptionsAllocation = [
            { label: 'FIFO', value: 'FIFO' },
            // { label: 'FEFO', value: 'FEFO' },
            // { label: 'LIFO', value: 'LIFO' },
        ];

        this.optionsData.update((old) => ({
            ...old,
            NEWALLOCATIONSTRATEGY: additionalOptionsAllocation,
        }));
    }
    getOrderdetails(
        data: any = {
            Page: this.loadEvent()?.Page || 1,
            PageSize: this.loadEvent()?.PageSize || this.rows(),
        },
    ) {
        this.loading.set(true);
        this.selectedOrder.set([]);
        this.orderDetails.set([]);
        const subscription = this.orderdetailsService
            .getOrderDetailsPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }
                    const first = data?.first ?? 0;
                    this.orderDetails.set(
                        res.Orders.map((x: any, idx: number) => ({
                            ...x,
                            rowId: first + idx + 1,
                        })),
                    );
                    this.totalRecords.set(res.totalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'OrderDetails list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }
    export(type: string) {
        const event = this.loadEvent();
        const PageSize = this.totalRecords();
        const Page = (event.first || 0) / PageSize + 1;
        const { filter, orderBy } = filterQuery(
            event,
            this.globalFilterColumns(),
            OrderDetailsColumns,
            'vw.',
        );
        this.getOrderdetailsForExcel(
            {
                Page,
                PageSize,
                Condition: filter,
                OrderBy: orderBy,
            },
            type,
        );
    }
    getOrderdetailsForExcel(
        data: any = { Page: 1, PageSize: this.totalRecords },
        type: string,
    ) {
        this.loading.set(true);
        this.orderDetailsForExcel.set([]);
        const subscription = this.orderdetailsService
            .getOrderDetailsPage(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }

                    this.orderDetailsForExcel.set(res.Orders);
                    if (res?.Orders && type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            'OrdersDetails-List',
                            [],
                            res.Orders,
                        );
                    } else {
                        this.downloadCSVFile(res.Orders, 'OrdersDetails-List');
                    }
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'OrderDetails list for excel',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    downloadCSVFile(data: any[], filename: string) {
        if (!data.length) return;
        const headers = Object.keys(data[0]);
        const csvRows = data.map((row) =>
            headers
                .map((field) =>
                    JSON.stringify(row[field], (_, val) => val ?? ''),
                )
                .join(','),
        );
        const csvContent = [headers.join(','), ...csvRows].join('\r\n');
        const blob = new Blob([csvContent], {
            type: 'text/csv;charset=utf-8;',
        });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `${filename}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    // deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.orderDetails().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedOrder().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedOrder().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }
}
