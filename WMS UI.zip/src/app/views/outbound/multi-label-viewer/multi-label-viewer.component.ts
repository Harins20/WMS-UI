import {
    Component,
    effect,
    ElementRef,
    inject,
    input,
    linkedSignal,
    signal,
    viewChild,
} from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { AppConfigService } from '../../../../app.config.service';
import { CommonModule } from '@angular/common';

declare var Stimulsoft: any;

interface PackingSlipData {
    PackingSlipNo: string;
    PackingSlipLabel: string;
    totalCases: number;
}

@Component({
    selector: 'app-multi-label-viewer',
    imports: [ButtonModule, CardModule, CommonModule],
    templateUrl: './multi-label-viewer.component.html',
    styleUrl: './multi-label-viewer.component.scss',
})
export class MultiLabelViewerComponent {
    // Input data from the packing slip component
    packingSlips = input<PackingSlipData[]>([]);

    // Current packing slip being viewed
    currentPackingSlip = linkedSignal<PackingSlipData>(
        () => this.packingSlips()[this.currentPage()],
    );

    currentPage = signal<number>(0);
    viewInitialized = signal<boolean>(false);
    private config = inject(AppConfigService);
    viewcontainer = viewChild<ElementRef>('customReportViewer');

    // Effect to load report when view container is ready
    log = effect(() => {
        if (
            this.viewcontainer() &&
            this.viewInitialized() &&
            this.currentPackingSlip()
        ) {
            const options = new Stimulsoft.Viewer.StiViewerOptions();
            options.appearance.fullScreenMode = false;
            options.toolbar.showPrintButton = true;
            options.toolbar.showSaveButton = true;

            const viewer = new Stimulsoft.Viewer.StiViewer(
                options,
                'StiViewer',
                false,
            );

            const report = new Stimulsoft.Report.StiReport();
            // Load the packing slip label report template
            // '/assets/reports/Order_Shipping_Label.mrt'
            report.loadFile('/assets/reports/PackingSlipLabel.mrt');

            // Get the JSON data source - make sure this matches your report
            const jsonDataSource =
                report.dictionary.databases.getByName('LabelData');

            // Build the API URL for fetching label data
            const apiUrl = this.config.appConfig()?.OutUrl;
            // const newUrl = `${apiUrl}PackingSlip/LabelData?Facility={FACILITY}&PackingSlipNo={PACKINGSLIPNO}&PackingSlipLabel={PACKINGSLIPLABEL}`;

            // if (jsonDataSource) {
            //     jsonDataSource.pathData = newUrl;
            // }

            // Set report variables
            const facilityVariable =
                report.dictionary.variables.getByName('FACILITY');
            let facility = atob(sessionStorage.getItem('Facility') ?? '');

            if (facilityVariable) {
                facilityVariable.value = facility;
                facilityVariable.requestFromUser = false;
            }
            const packingSlipNoVariable =
                report.dictionary.variables.getByName('PackingSlipNo');
            // const packingSlipNoVariable = report.dictionary.variables.getByName('PSNo');
            if (packingSlipNoVariable) {
                packingSlipNoVariable.value =
                    this.currentPackingSlip().PackingSlipNo;
                packingSlipNoVariable.requestFromUser = false;
            }
            const boxnoVariable =
                report.dictionary.variables.getByName('BoxQty');
            if (boxnoVariable) {
                boxnoVariable.value = this.currentPackingSlip().totalCases;
                boxnoVariable.requestFromUser = false;
            }

            // const packingSlipLabelVariable = report.dictionary.variables.getByName('PACKINGSLIPLABEL');
            // if (packingSlipLabelVariable) {
            //     packingSlipLabelVariable.value = this.currentPackingSlip().PackingSlipLabel;
            //     packingSlipLabelVariable.requestFromUser = false;
            // }

            viewer.report = report;
            viewer.renderHtml(this.viewcontainer()?.nativeElement);
        }
    });

    ngAfterViewInit(): void {
        Stimulsoft.Base.StiLicense.Key =
            '6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHnbeLC+bqPRqQ+5kkhFK29KQ+9iuHzyQojjOXTfUVm/KXZ4TwNf75psyetLPBiBfndUD7BZmK4zaHQAFah78X6NqhijqHmnqlANbaXbf6oqXdHOggFKuc56nN1QPq/iG8EpVmKzEekpF5ymIAqkEyEE7ooM88jNzMCQQ3iK8ffoV8C+BRYRNAKBVj1LouW3vCj5bTTtZhPzdtJXyAFS06G7dXNyRK2NaqYITw7HFMAB+tGvzFW7s6F0656aSVlMNSUj6Nsr3tzuFyDT/t72P8Ea4L0bXWshSRgM2kJKu1qmgE+mz4zQ4Yi7wdTI1jh3JVdEQuOeFT2yqY28VGSP7cdOcpWG+1Nv3/S+zZoRan4slHZma90QrLzIdZOOV1KS5Dt5ftiHCOC/5+ENThUiQBKg2u3wTnaWd06nqrXUY282ehdHQE/IdzxGw/NA3YVviwOWLJrzHsPifS2kvgLfZMaC65ErUTS1TcQH/WQ+PJmayG3y20+bZAe8Fx63nNwNHg0SHyQc8/uwNXjA1RxLOjOW';

        setTimeout(() => this.viewInitialized.set(true), 1);
    }

    nextPage(): void {
        if (this.currentPage() < this.packingSlips().length - 1) {
            this.currentPage.set(this.currentPage() + 1);
            // Stimulsoft will reload with new data via effect
        }
    }

    prevPage(): void {
        if (this.currentPage() > 0) {
            this.currentPage.set(this.currentPage() - 1);
            // Stimulsoft will reload with new data via effect
        }
    }
}

// import {
//     Component,
//     effect,
//     ElementRef,
//     inject,
//     input,
//     linkedSignal,
//     signal,
//     viewChild,
// } from '@angular/core';
// import { ButtonModule } from 'primeng/button';
// import { CardModule } from 'primeng/card';
// import { AppConfigService } from '../../../../app.config.service';

// declare var Stimulsoft: any;

// interface PackingSlipData {
//     PackingSlipNo: string;
//     PackingSlipLabel: string;
// }

// @Component({
//     selector: 'app-multi-label-viewer',
//     imports: [ButtonModule, CardModule],
//     templateUrl: './multi-label-viewer.component.html',
//     styleUrl: './multi-label-viewer.component.scss'
// })
// export class MultiLabelViewerComponent {
//     facility = signal<string | null>(sessionStorage.getItem('Facility'));

//     // Input data from the packing slip component
//     packingSlips = input<PackingSlipData[]>([]);

//     // Current packing slip being viewed
//     currentPackingSlip = linkedSignal<PackingSlipData>(
//         () => this.packingSlips()[this.currentPage()]
//     );

//     currentPage = signal<number>(0);
//     viewInitialized = signal<boolean>(false);
//     private config = inject(AppConfigService);
//     viewcontainer = viewChild<ElementRef>('customReportViewer');

//     // Effect to load report when view container is ready
//     log = effect(() => {
//         ,
//             this.viewcontainer()?.nativeElement,
//         );

//         if (
//             this.viewcontainer() &&
//             this.viewInitialized() &&
//             this.currentPackingSlip()
//         ) {
//             this.loadReport();
//         }
//     });

//     ngAfterViewInit(): void {
//         Stimulsoft.Base.StiLicense.Key =
//             '6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHnbeLC+bqPRqQ+5kkhFK29KQ+9iuHzyQojjOXTfUVm/KXZ4TwNf75psyetLPBiBfndUD7BZmK4zaHQAFah78X6NqhijqHmnqlANbaXbf6oqXdHOggFKuc56nN1QPq/iG8EpVmKzEekpF5ymIAqkEyEE7ooM88jNzMCQQ3iK8ffoV8C+BRYRNAKBVj1LouW3vCj5bTTtZhPzdtJXyAFS06G7dXNyRK2NaqYITw7HFMAB+tGvzFW7s6F0656aSVlMNSUj6Nsr3tzuFyDT/t72P8Ea4L0bXWshSRgM2kJKu1qmgE+mz4zQ4Yi7wdTI1jh3JVdEQuOeFT2yqY28VGSP7cdOcpWG+1Nv3/S+zZoRan4slHZma90QrLzIdZOOV1KS5Dt5ftiHCOC/5+ENThUiQBKg2u3wTnaWd06nqrXUY282ehdHQE/IdzxGw/NA3YVviwOWLJrzHsPifS2kvgLfZMaC65ErUTS1TcQH/WQ+PJmayG3y20+bZAe8Fx63nNwNHg0SHyQc8/uwNXjA1RxLOjOW';

//         setTimeout(() => this.viewInitialized.set(true), 1);
//     }

//     loadReport(): void {
//         try {
//             const options = new Stimulsoft.Viewer.StiViewerOptions();
//             options.appearance.fullScreenMode = false;
//             options.toolbar.showPrintButton = true;
//             options.toolbar.showSaveButton = true;
//             // options.toolbar.viewMode = Stimulsoft.Viewer.StiViewMode.WholeReport;

//             const viewer = new Stimulsoft.Viewer.StiViewer(
//                 options,
//                 'StiViewer',
//                 false,
//             );

//             const report = new Stimulsoft.Report.StiReport();
//             // Load the packing slip label report template
//             report.loadFile('/assets/reports/PackingSlipLabel.mrt');

//             // Get the JSON data source
//             const jsonDataSource = report.dictionary.databases.getByName('LabelData');

//             // Build the API URL for fetching label data
//             const apiUrl = this.config.appConfig()?.OutUrl;
//             const newUrl = `${apiUrl}PackingSlip/LabelData?Facility={FACILITY}&PackingSlipNo={PACKINGSLIPNO}&PackingSlipLabel={PACKINGSLIPLABEL}`;

//             jsonDataSource.pathData = newUrl;

//             // Set report variables
//             const facilityVariable = report.dictionary.variables.getByName('FACILITY');
//             if (facilityVariable) {
//                 facilityVariable.value = this.facility() || '';
//                 facilityVariable.requestFromUser = false;
//             }

//             const packingSlipNoVariable = report.dictionary.variables.getByName('PACKINGSLIPNO');
//             if (packingSlipNoVariable) {
//                 packingSlipNoVariable.value = this.currentPackingSlip().PackingSlipNo;
//                 packingSlipNoVariable.requestFromUser = false;
//             }

//             const packingSlipLabelVariable = report.dictionary.variables.getByName('PACKINGSLIPLABEL');
//             if (packingSlipLabelVariable) {
//                 packingSlipLabelVariable.value = this.currentPackingSlip().PackingSlipLabel;
//                 packingSlipLabelVariable.requestFromUser = false;
//             }

//             viewer.report = report;
//             viewer.renderHtml(this.viewcontainer()?.nativeElement);
//         } catch (error) {
//             console.error('Error loading report:', error);
//         }
//     }

//     nextPage(): void {
//         if (this.currentPage() < this.packingSlips().length - 1) {
//             this.currentPage.set(this.currentPage() + 1);
//             // Stimulsoft will reload with new data
//         }
//     }

//     prevPage(): void {
//         if (this.currentPage() > 0) {
//             this.currentPage.set(this.currentPage() - 1);
//             // Stimulsoft will reload with new data
//         }
//     }
// }
