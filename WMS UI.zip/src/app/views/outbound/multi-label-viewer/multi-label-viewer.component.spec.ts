import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiLabelViewerComponent } from './multi-label-viewer.component';

describe('MultiLabelViewerComponent', () => {
  let component: MultiLabelViewerComponent;
  let fixture: ComponentFixture<MultiLabelViewerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MultiLabelViewerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MultiLabelViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
