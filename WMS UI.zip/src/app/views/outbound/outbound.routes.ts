import { LoadsComponent } from './loads';
import { OrdersComponent } from './orders';
import { OrderDetailsComponent } from './order-details';
import { ReturnLinesComponent, ReturnsComponent } from './returns';
import { OrderTabComponent } from './orders/order-tabs/order-tabs.component';
import { LoadDetailsTabComponent } from '../outbound/loads/load-tabs/load-tabs.component';
import { CrossDockComponent } from './orders/cross-dock/cross-dock.component';
import { CreateReturnLinesComponent } from './returns/returns_lines/return-line-creation/return-line-creation.component';
import { PackingSlipComponent } from './packing-slip/packing-slip.component';
import { MultiLabelViewerComponent } from './multi-label-viewer/multi-label-viewer.component';
import { SalesOrderComponent } from './sales-order/sales-order.component';
import { SoLinesComponent } from './sales-order/so-lines/so-lines.component';

export default [
    { data: { name: 'Orders' }, path: 'orders', component: OrdersComponent },

    {
        data: { name: 'orderline' },
        path: 'orders/tab/:OrderKey',
        component: OrderTabComponent,
    },
    { data: { name: 'Loads' }, path: 'load', component: LoadsComponent },

    {
        data: { name: 'loadline' },
        path: 'load/tab/:LoadID',
        component: LoadDetailsTabComponent,
    },
    {
        data: { name: 'Return Orders' },
        path: 'returns',
        component: ReturnsComponent,
    },
    {
        data: { name: 'returnline' },
        path: 'returns/lines/:ReturnID',
        component: ReturnLinesComponent,
    },
    {
        data: { name: 'createreturnline' },
        path: 'returns/lines/:ReturnID/:OrderKey/Sku',
        component: CreateReturnLinesComponent,
    },
    {
        data: { name: 'Order Detail' },
        path: 'orderdetails',
        component: OrderDetailsComponent,
    },
    {
        data: { name: 'Sales Order' },
        path: 'salesorder',
        component: SalesOrderComponent,
    },
    {
        data: { name: 'soline' },
        path: 'so-lines/:soKey/:storerKey',
        component: SoLinesComponent,
    },
    {
        data: { name: 'Cross Dock' },
        path: 'crossdock',
        component: CrossDockComponent,
    },
    {
        data: { name: 'Packing Slip' },
        path: 'packing-slip',
        component: PackingSlipComponent,
    },
    {
        data: { name: 'Multi Label Viewer' },
        path: 'label-viewer',
        component: MultiLabelViewerComponent,
    },
];
