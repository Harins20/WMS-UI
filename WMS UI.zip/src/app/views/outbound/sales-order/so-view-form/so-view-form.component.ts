import { CommonModule } from '@angular/common';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { TabsModule } from 'primeng/tabs';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { IftaLabelModule } from 'primeng/iftalabel';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import {
    InputSelectComponent,
    InputTextComponent,
    InputDatepickerComponent,
} from '../../../../common/components';
import { getErrorMessages } from '../../../../common/functions';
import { selectOption } from '../../../../common/models';
import { OptionsService } from '../../../../common/services';
import { Select } from 'primeng/select';
import { Checkbox } from 'primeng/checkbox';
import { SalesOrderColumns } from '../sales-order.column';

@Component({
    selector: 'app-so-view-form',
    imports: [
        ReactiveFormsModule,
        CommonModule,
        IftaLabelModule,
        InputTextModule,
        PasswordModule,
        ButtonModule,
        DatePickerModule,
        AppTranslatePipe, TabsModule,
        Select,
        Checkbox,
        InputSelectComponent,
        InputSelectComponent,
        InputTextComponent,
        InputDatepickerComponent,
    ],
    templateUrl: './so-view-form.component.html',
    styleUrl: './so-view-form.component.scss',
})
export class SoViewFormComponent {
    salesorderData = input<any>();
    private destroyRef = inject(DestroyRef);
    private optionService = inject(OptionsService);

    loading = signal(false);
    formControlsArray = signal(
        Object.values(SalesOrderColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue),
        ]),
    );
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    salesorderform = new FormGroup(this.formControls());
    ownerOptions = signal<selectOption[]>([]);
    carrierOptions = signal<selectOption[]>([]);
    shipfromOptions = signal<selectOption[]>([]);
    typeOptions = signal<selectOption[]>([]);
    transformationfromOptions = signal<selectOption[]>([]);
    priorityOptions = signal<selectOption[]>([]);
    shiptoOptions = signal<selectOption[]>([]);
    ngOnInit() {
        this.GetOwnerOptions();
        this.GetShipFromOptions();
        this.handleShipFromSelection();
        this.GetCarrierOptions();
        this.handleCarrierSelection();
        this.GetTypeOptions();
        this.GetShipToOptions();
        this.GetTransformationMode();
        this.GetPriorityOptions();
    }
    ngOnChanges() {
        Object.values(SalesOrderColumns).forEach((column) => {
            if (column) this.salesorderform.controls[column.field].disable();
        });
        if (this.salesorderData()) {
            const e = this.salesorderData();
            this.salesorderform.patchValue({
                ...this.salesorderData(),
                REQUESTEDSHIPDATE: this.salesorderData()?.REQUESTEDSHIPDATE
                    ? new Date(this.salesorderData().REQUESTEDSHIPDATE)
                    : null,
                EXPECTEDDELIVERYDATE: this.salesorderData()
                    ?.EXPECTEDDELIVERYDATE
                    ? new Date(this.salesorderData().EXPECTEDDELIVERYDATE)
                    : null,
                ORDERDATE: this.salesorderData()?.ORDERDATE
                    ? new Date(this.salesorderData().ORDERDATE)
                    : null,
                PODATE: this.salesorderData()?.PODATE
                    ? new Date(this.salesorderData().PODATE)
                    : null,
                LastGrnDate: this.salesorderData()?.LastGrnDate
                    ? new Date(this.salesorderData().LastGrnDate)
                    : null,
            });
        }
    }
    hasError(formControlName: string) {
        const formControl = this.salesorderform.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.salesorderform.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetShipToOptions() {
        const subscription = this.optionService.getShipToOptions().subscribe({
            next: (data) => {
                this.shiptoOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetShipFromOptions() {
        const subscription = this.optionService.getShipFromOptions().subscribe({
            next: (data) => {
                this.shipfromOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetCarrierOptions() {
        const subscription = this.optionService.getCarrierOptions().subscribe({
            next: (data) => {
                this.carrierOptions.set(data);
            },
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetTypeOptions() {
        const subscription = this.optionService
            .getOrderTypeOptions()
            .subscribe({
                next: (data) => {
                    this.typeOptions.set(data.filter((x) => x.value !== '18'));
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetTransformationMode() {
        const subscription = this.optionService
            .getTransportationModeOptions()
            .subscribe({
                next: (data) => {
                    this.transformationfromOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPriorityOptions() {
        const subscription = this.optionService.getPriorityOptions().subscribe({
            next: (data) => {
                this.priorityOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    handleCarrierSelection() {
        this.salesorderform
            .get('CARRIERKEY')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedCarrier: any = this.carrierOptions().find(
                    (carrier) => carrier.value === selectedValue,
                );

                if (selectedCarrier) {
                    this.salesorderform.patchValue({
                        CARRIERNAME: selectedCarrier.Company,
                    });
                }
            });
    }

    handleShipFromSelection() {
        this.salesorderform
            .get('SELLERCODE')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedTrader: any = this.shipfromOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (selectedTrader) {
                    this.salesorderform.patchValue({
                        SELLERNAME: selectedTrader.Company || '',
                    });
                }
            });
    }
}
