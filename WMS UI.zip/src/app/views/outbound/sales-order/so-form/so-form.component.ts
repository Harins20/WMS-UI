import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateModule } from '@ngx-translate/core';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { SalesOrderColumns } from '../sales-order.column';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../common/functions';
import { selectOption } from '../../../../common/models';
import {
    OptionsService,
    AuthService,
    Base64ConvertService,
    safeAtob,
} from '../../../../common/services';
import { CommonModule } from '@angular/common';

import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { IftaLabelModule } from 'primeng/iftalabel';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import {
    InputTextComponent,
    InputDatepickerComponent,
} from '../../../../common/components';
import { FileUploadModule } from 'primeng/fileupload';
import { Select } from 'primeng/select';
import { Checkbox } from 'primeng/checkbox';
import { acceptedImageTypes } from '../../../../common/constants/imageExtention';
import { LayoutService } from '../../../../layout/service/layout.service';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-so-form',
    imports: [
        ReactiveFormsModule,
        CommonModule,
        IftaLabelModule,
        InputTextModule,
        PasswordModule,
        ButtonModule,
        DatePickerModule,
        CommonModule,
        TranslateModule,
        InputTextComponent,
        InputDatepickerComponent,
        AppTranslatePipe,
        FileUploadModule,
        Select,
        Checkbox,
    ],
    templateUrl: './so-form.component.html',
    styleUrl: './so-form.component.scss',
})
export class SoFormComponent {
    SalesOrderData = input<any>();
    private destroyRef = inject(DestroyRef);
    private ref = inject(DynamicDialogRef);
    private optionService = inject(OptionsService);
    private authService = inject(AuthService);
    private messageService = inject(MessageService);

    SalesOrderColumns: any[] = [];
    loading = signal(false);
    formControlsArray = signal(
        Object.values(SalesOrderColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    LayoutService = inject(LayoutService);
    isDarkTheme = computed(() => this.LayoutService.layoutConfig().darkTheme);
    setViewTAb = signal<boolean>(true);
    activeTab = signal<number>(0);
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    SalesOrderform = new FormGroup(this.formControls());
    ownerOptions = signal<selectOption[]>([]);
    carrierOptions = signal<selectOption[]>([]);
    shipfromOptions = signal<selectOption[]>([]);
    priorityOptions = signal<selectOption[]>([]);
    transformationfromOptions = signal<selectOption[]>([]);
    typeOptions = signal<selectOption[]>([]);
    shiptoOptions = signal<selectOption[]>([]);
    orderColumns: any;
    attachmentData = signal<string | null>(null);
    private base64convert = inject(Base64ConvertService);
    typeRestricted(params: string) {
        return acceptedImageTypes.includes(params);
    }
    ngOnInit() {
        if (this.SalesOrderData()) {
            this.SalesOrderform.patchValue({
                ...this.SalesOrderData(),
                REQUESTEDSHIPDATE: this.SalesOrderData()?.REQUESTEDSHIPDATE
                    ? new Date(this.SalesOrderData().REQUESTEDSHIPDATE)
                    : null,
                EXPECTEDDELIVERYDATE: this.SalesOrderData()
                    ?.EXPECTEDDELIVERYDATE
                    ? new Date(this.SalesOrderData().EXPECTEDDELIVERYDATE)
                    : null,
                ORDERDATE: this.SalesOrderData()?.ORDERDATE
                    ? new Date(this.SalesOrderData().ORDERDATE)
                    : null,
                LastGrnDate: this.SalesOrderData()?.LastGrnDate
                    ? new Date(this.SalesOrderData().LastGrnDate)
                    : null,
            });
            Object.values(SalesOrderColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.SalesOrderform.controls[column.field].disable();
            });
        } else {
            Object.values(SalesOrderColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.SalesOrderform.controls[column.field].disable();
            });
            this.SalesOrderform.patchValue({
                TRADERKEY: safeAtob(sessionStorage.getItem('TraderKey')),
            });
        }
        this.GetTypeOptions();
        this.GetTransformationMode();
        this.GetPriorityOptions();
        this.GetShipToOptions();
        this.GetOwnerOptions();
        this.GetShipFromOptions();
        // this.handleShipFromSelection();
        this.handleShipToSelection();
        this.handleCarrierSelection();
        this.GetCarrierOptions();
        // this.handleCarrierSelcetion();
        this.getColumns();

        if (this.SalesOrderform.get('Insured')?.value === false) {
            this.SalesOrderform.get('INSURANCENO')?.disable();
        }
    }
    hasError(formControlName: string) {
        const formControl = this.SalesOrderform.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    // Navigate to tab
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    closePanel() {
        this.ref.close();
    }
    getErrors(formControlName: string, title?: string) {
        const formControl = this.SalesOrderform.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    onCancel() {
        this.ref.close();
    }

    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetTypeOptions() {
        const subscription = this.optionService
            .getOrderTypeOptions()
            .subscribe({
                next: (data) => {
                    this.typeOptions.set(data.filter((x) => x.value !== '18'));
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetTransformationMode() {
        const subscription = this.optionService
            .getTransportationModeOptions()
            .subscribe({
                next: (data) => {
                    this.transformationfromOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPriorityOptions() {
        const subscription = this.optionService.getPriorityOptions().subscribe({
            next: (data) => {
                this.priorityOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    GetShipToOptions() {
        const subscription = this.optionService.getShipToOptions().subscribe({
            next: (data) => {
                this.shiptoOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetCarrierOptions() {
        const subscription = this.optionService.getCarrierOptions().subscribe({
            next: (data) => {
                this.carrierOptions.set(data);
            },
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetShipFromOptions() {
        const subscription = this.optionService.getShipFromOptions().subscribe({
            next: (data) => {
                this.shipfromOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    onCheckboxChange(event: any): void {
        if (event.checked) {
            this.SalesOrderform.get('INSURANCENO')?.enable();
        } else {
            this.SalesOrderform.get('INSURANCENO')?.disable();
        }
    }
    handleShipToSelection() {
        this.SalesOrderform.get('CONSIGNEEKEY')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedTrader: any = this.shiptoOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (selectedTrader) {
                    this.SalesOrderform.patchValue({
                        C_COMPANY: selectedTrader.Company || '',
                        C_ADDRESS1: selectedTrader.Address1 || '',
                        C_ADDRESS2: selectedTrader.Address2 || '',
                        C_ADDRESS3: selectedTrader.Address3 || '',
                        C_ADDRESS4: selectedTrader.Address4 || '',
                        C_CITY: selectedTrader.City || '',
                        C_STATE: selectedTrader.State || '',
                        C_ZIP: selectedTrader.Zip || '',
                        C_COUNTRY: selectedTrader.Country || '',
                        C_EMAIL1: selectedTrader.Email1 || '',
                        C_CONTACT1: selectedTrader.Contact1 || '',
                        C_PHONE1: selectedTrader.Phone1 || '',
                    });
                }
            });
    }

    handleCarrierSelection() {
        this.SalesOrderform.get('CARRIERCODE')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedShipTo: any = this.carrierOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (selectedShipTo) {
                    this.SalesOrderform.patchValue({
                        CARRIERNAME: selectedShipTo.Company || '',
                        // CarrierReference: selectedShipTo.B_Address1 || '',
                        CARRIERADDRESS1: selectedShipTo.Address1 || '',
                        CARRIERADDRESS2: selectedShipTo.Address2 || '',
                        CARRIERCITY: selectedShipTo.City || '',
                        CARRIERSTATE: selectedShipTo.State || '',
                        CARRIERCOUNTRY: selectedShipTo.Country || '',
                        CARRIERZIP: selectedShipTo.Zip || '',
                        CARRIERPHONE: selectedShipTo.Phone1 || '',
                    });
                }
            });
    }

    handleShipFromSelection() {
        this.SalesOrderform.get('SELLERCODE')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedTrader: any = this.shipfromOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (selectedTrader) {
                    this.SalesOrderform.patchValue({
                        SELLERNAME: selectedTrader.Company || '',
                    });
                }
            });
    }
    handleCarrierSelcetion() {
        this.SalesOrderform.get('CARRIERKEY')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedCarrier: any = this.carrierOptions().find(
                    (carrier) => carrier.value === selectedValue,
                );

                if (selectedCarrier) {
                    this.SalesOrderform.patchValue({
                        CARRIERNAME: selectedCarrier.Company,
                    });
                }
            });
    }
    onSubmit() {
        // console.log('Form submitted:', this.SalesOrderform.getRawValue());
        // return;
        if (this.SalesOrderform.valid) {
            this.setViewTAb.set(true);

            this.ref.close(this.SalesOrderform.getRawValue());
            this.SalesOrderform.reset();
        } else {
            this.setViewTAb.set(false);

            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.SalesOrderform.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.SalesOrderform.controls));
        }
    }

    getColumns() {
        this.optionService.getColumns(SalesOrderColumns, 'PO').subscribe({
            next: (data) => {
                this.SalesOrderColumns = data;
            },
        });
    }

    async onFileSelect(event: any) {
        // console.log('File selected:', event.files[0]);
        const file = event.files[0];
        const fileName = file.name;

        const base64: string = (await this.base64convert.baseConverFile(
            file,
        )) as string;
        this.SalesOrderform.get('FileName')?.setValue(fileName);
        if (base64) {
            // console.log('Base64 string:', base64);
            this.SalesOrderform.get('FileData')?.setValue(base64);
            this.attachmentData.set(base64);
        }
    }
}
