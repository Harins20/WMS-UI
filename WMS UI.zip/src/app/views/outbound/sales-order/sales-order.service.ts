import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';
import { salesorder } from './sales-order.model';

@Injectable({
    providedIn: 'root',
})
export class SalesOrderService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getSO(data: any) {
        return this.httpClient.post<ResponseDto<any[]>>(
            this.config.appConfig()?.OutUrl + 'SalesOrder/header/Paged',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    createSO(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'salesorder/header/create',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    updateSO(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Po',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    deleteSO(data: any) {
        return this.httpClient.delete(
            this.config.appConfig()?.OutUrl + 'salesorder',
            {
                headers: this.authService.getAuthHeaders(),
                body: data,
            },
        );
    }

    getSoKeyDetail(poKey: any) {
        return this.httpClient.get<ResponseDto<salesorder[]>>(
            this.config.appConfig()?.OutUrl +
                `SalesOrder/header?SOKEY=${poKey}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
