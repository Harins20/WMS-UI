import { CommonModule } from '@angular/common';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { IftaLabelModule } from 'primeng/iftalabel';
import { InputTextModule } from 'primeng/inputtext';
import { KeyFilterModule } from 'primeng/keyfilter';
import { PasswordModule } from 'primeng/password';
import {
    InputNumberComponent,
    InputTextComponent,
    InputSelectComponent,
} from '../../../../../common/components';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../../../common/functions';
import { selectOption } from '../../../../../common/models';
import { OptionsService } from '../../../../../common/services';
import { POLineService } from '../../../../inbound';
import { SOLinesColumns } from '../so-lines.column';
import { Select } from 'primeng/select';
import { DatePicker } from 'primeng/datepicker';
import { LayoutService } from '../../../../../layout/service/layout.service';

@Component({
    selector: 'app-so-line-form',
    imports: [
        ReactiveFormsModule,
        CommonModule,
        IftaLabelModule,
        InputTextModule,
        PasswordModule,
        ButtonModule,
        CalendarModule,
        KeyFilterModule,
        InputNumberComponent,
        InputTextComponent,
        AppTranslatePipe,
        InputSelectComponent,
        InputNumberComponent,
        Select,
        DatePicker,
    ],
    templateUrl: './so-line-form.component.html',
    styleUrl: './so-line-form.component.scss',
})
export class SoLineFormComponent {
    solinesData = input<any>();
    solineCreateData = input<any>();
    private ref = inject(DynamicDialogRef);
    private destroyRef = inject(DestroyRef);
    private optionService = inject(OptionsService);
    private solineService = inject(POLineService);
    LayoutService = inject(LayoutService);
    isDarkTheme = computed(() => this.LayoutService.layoutConfig().darkTheme);
    loading = signal(false);
    formControlsArray = signal(
        Object.values(SOLinesColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    polineform = new FormGroup(this.formControls());
    itemOptions = signal<selectOption[]>([]);
    packOptions = signal<selectOption[]>([]);
    SOLinesColumns: any[] = [];
    // ✅ Single signal for tab validation warning
    setViewTAb = signal<boolean>(true);
    activeTab = signal<number>(0);
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    ngOnInit() {
        if (this.solinesData()) {
            Object.values(SOLinesColumns).forEach((column) => {
                if (column.restrictEdit)
                    this.polineform.controls[column.field].disable();
            });
            const selectedStorerKey = this.solinesData()?.TRADERKEY;
            console.log(selectedStorerKey);
            if (selectedStorerKey) {
                this.GetItemOptions(selectedStorerKey);
            }
            this.polineform.patchValue({
                ...this.solinesData(),
            });
        } else {
            Object.values(SOLinesColumns).forEach((column) => {
                if (column.restrictInsert)
                    this.polineform.controls[column.field].disable();
            });
            // console.log('this.solineCreateData()', this.solineCreateData());
            this.polineform.patchValue({
                ...this.solineCreateData(),
            });
            const selectedStorerKey = this.solineCreateData()?.TRADERKEY;
            if (selectedStorerKey) {
                this.GetItemOptions(selectedStorerKey);
            }
        }
        let tkey = atob(sessionStorage.getItem('TraderKey') ?? '');
        this.GetItemOptions(tkey);
        this.GetPackOptions();
    }

    hasError(formControlName: string) {
        const formControl = this.polineform.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.polineform.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }
    closePanel() {
        this.ref.close();
    }
    onCancel() {
        this.ref.close();
    }

    itemPrice$ = this.polineform.controls['SKU'].valueChanges.subscribe(
        (value) => {
            if (value) {
                this.itemOptions().forEach((item: any) => {
                    if (item.value === value) {
                        this.polineform.get('Price')?.setValue(item.Price);
                    }
                });
            }
        },
    );

    GetItemOptions(StorerKey: string) {
        const subscription = this.solineService
            .getItemDetailsOptions(StorerKey)
            .subscribe({
                next: (data) => {
                    this.itemOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetPackOptions() {
        const subscription = this.optionService.getPackOptions().subscribe({
            next: (data) => {
                this.packOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching pack dropdown data:', err);
            },
        });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    onSubmit() {
        if (this.polineform.valid) {
            this.ref.close(this.polineform.getRawValue());
            this.polineform.reset();
        } else {
            this.polineform.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.polineform.controls));
        }
    }
}
