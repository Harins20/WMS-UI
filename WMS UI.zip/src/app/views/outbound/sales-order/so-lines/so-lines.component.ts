import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { SoLineFormComponent } from './so-line-form/so-line-form.component';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';

import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { AccordionModule } from 'primeng/accordion';
import { MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Tag, TagModule } from 'primeng/tag';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { finalize, map } from 'rxjs';
import {
    LoadingComponent,
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    CustomTableComponent,
} from '../../../../common/components';
import { CommonErrorboxComponent } from '../../../../common/components/common-errorbox/common-errorbox.component';
import { tableOptions } from '../../../../common/constants';
import { ExcelDownloadService } from '../../../../common/services';
import { POLineService, POService } from '../../../inbound';
import { SoViewFormComponent } from '../so-view-form/so-view-form.component';
import { SalesOrderLines } from './so-lines.model';
import { SOLinesColumns } from './so-lines.column';
import { SalesOrderLineService } from './so-lines.service';
import { filterQuery } from '../../../../common/functions';
import { SalesOrderService } from '../sales-order.service';
import { downloadCSVFile } from '../../../../common/functions/downloadCSVFile';
import { CustomTablePaginationComponent } from '../../../../common/components/custom-table-pagination/custom-table-pagination.component';

@Component({
    selector: 'app-so-lines',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        DatePipe,
        MultiSelectModule,
        TooltipModule,
        AccordionModule,
        AppTranslatePipe,
        LoadingComponent,
        TagModule,
        SoViewFormComponent,
        CustomTableComponent,
        CustomTablePaginationComponent,
    ],
    templateUrl: './so-lines.component.html',
    styleUrl: './so-lines.component.scss',
    providers: [DialogService],
})
export class SoLinesComponent {
    ref: DynamicDialogRef | undefined;
    storerKey = input.required<string>();
    soKey = input.required<string>();
    SOHeader = signal<any>([]);
    externalPoKey = input.required<string>();
    solines = signal<SalesOrderLines[]>([]);
    selectedPOLines = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    private translate = inject(TranslateService);
    columns = signal(
        Object.values(SOLinesColumns).filter((column) => !column.tableHidden),
    );
    OrginalColumns = signal<any>(SOLinesColumns);
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    ConfirmationRef: DynamicDialogRef | undefined;
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    selectedColumns = linkedSignal(() => this.columns());
    exportFileName = 'Sales Order Lines List';
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportCSV(),
        },
    ];

    private messageService = inject(MessageService);
    private solinesService = inject(SalesOrderLineService);
    private destroyRef = inject(DestroyRef);
    private excelDownloadService = inject(ExcelDownloadService);
    private poService = inject(SalesOrderService);
    private dialogService = inject(DialogService);
    // constructor(private location: Location) {}
    loadEvent = signal<any>({});
    rows = signal(10);
    totalRecords = signal(0);

    ngOnInit() {
        this.getSOLines();
        if (this.soKey()) {
            this.getSOHeader();
        }
    }
    ngAfterViewInit() {
        this.columns.update((columns) =>
            columns.map((column: any) => {
                if (column.field === 'STATUS_DESC') {
                    return {
                        ...column,
                        customCellTemplate: this.customStatusCellTemplate(),
                    };
                }

                return column;
            }),
        );
    }
    getSOHeader() {
        const subscription = this.poService
            .getSoKeyDetail(this.soKey())
            .subscribe({
                next: (data: any) => {
                    this.SOHeader.set(data.Response);
                },
                error: (err) => {
                    console.error('Error fetching item dropdown data:', err);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    getSOLines(data: any = { Page: 1, PageSize: 15 }) {
        this.loading.set(true);
        this.solines.set([]);
        const subscription = this.solinesService
            .getSalesOrderLines(this.soKey(), data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }
                    this.solines.set(
                        res.Response.SalesOrderLines.map(
                            (x: any, idx: number) => ({
                                ...x,
                                rowId: desc ? idBase - idx : idBase + idx + 1,
                            }),
                        ),
                    );
                    this.totalRecords.set(res?.Response?.TotalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Sales Order Lines list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getSOLinesExcel(
        data: any = { Page: 1, PageSize: this.totalRecords },
        type: string,
    ) {
        this.loading.set(true);
        const subscription = this.solinesService
            .getSalesOrderLines(this.soKey(), data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let ExcelData = res?.Response?.SalesOrderLines;
                    if (ExcelData.length === 0) {
                        this.messageService.add({
                            severity: 'info',
                            summary: 'Sales Order Lines list',
                            detail: 'No data available to export.',
                        });
                        return;
                    }

                    if (ExcelData && type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            ExcelData,
                        );
                    } else {
                        downloadCSVFile(ExcelData, this.exportFileName);
                    }
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Sales Order Lines list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    loadData(event: TableLazyLoadEvent) {
        this.loadEvent.set(event);
        this.getSOLines(event);
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getSOLines();
    }
    exportExcel() {
        this.export('Excel');
    }
    exportCSV() {
        this.export('CSV');
    }

    export(type: string) {
        this.getSOLinesExcel(this.loadEvent(), type);
    }
    options(field: string) {
        const uniqueValues = new Set(this.solines().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedPOLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedPOLines().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.ref = this.dialogService.open(ColumnPicklistComponent, {
            inputValues: {
                selectedColumns: this.selectedColumns(),
                unSelectedColumns: this.unSelectedColumns(),
            },
            header: headertext,
            closable: true,
            modal: true,
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {});
    }

    OpenCreateSOLineForm() {
        const headertext = this.translate.instant('Create SO Line');

        this.ref = this.dialogService.open(SoLineFormComponent, {
            inputValues: {
                solineCreateData: this.SOHeader(),
            },
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('SalesOrderLineCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.solinesService
                            .createSOLine(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getSOLines();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary:
                                            'New Sales Order Line creation',
                                        detail: data.Message as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary:
                                                'New Sales Order Line creation',
                                            detail: error.error
                                                .message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateSOLineForm(polinesData: any) {
        const headertext = this.translate.instant('Update Sales Order Line');
        this.ref = this.dialogService.open(SoLineFormComponent, {
            inputValues: {
                solinesData: polinesData,
            },
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('SalesOrderLineUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.solinesService
                            .updateSOLine(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getSOLines();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Sales Order Line Update',
                                        detail: data.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Sales Order Line Update',
                                            detail: error.error
                                                .message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    DeleteSOLines() {
        const headertext = this.translate.instant('Confirm Deletion');
        const count = this.selectedPOLines().length;
        const name =
            count > 1
                ? this.translate.instant('Sales Order Lines')
                : this.translate.instant('Sales Order Line');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const Rdata = this.selectedPOLines().map((x: any) =>
                    String(x.ID),
                );
                this.loading.set(true);
                const requestBody = {
                    SoKey: this.soKey(),
                    Ids: Rdata,
                };
                // console.log(requestBody);
                const subscription = this.solinesService
                    .deleteSOLine(requestBody)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedPOLines.set([]);
                            this.getSOLines();
                        }),
                    )
                    .subscribe({
                        next: (res: any) => {
                            // console.log(res?.Response);
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Delete Sales Order Line',
                                detail: res.Response as string,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                const errorMessage =
                                    error?.error?.message ||
                                    'Failed to delete Sales Order Line.';

                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Delete Sales Order Line',
                                    detail: errorMessage,
                                });
                            }
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }

    OnClickCreateOrder() {
        const Rdata = this.selectedPOLines().map((x: any) => {
            return x.ID;
        });
        this.loading.set(true);
        const requestBody = {
            LineIds: typeof Rdata === 'number' ? [Rdata] : Rdata,
        };
        // console.log(requestBody, this.soKey());
        // let so = this.soKey().toString();
        // console.log(so, typeof so);
        const subscription = this.solinesService
            .createOrder(requestBody, this.soKey())
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                    this.selectedPOLines.set([]);
                    this.getSOLines();
                    this.getSOHeader();
                }),
            )
            .subscribe({
                next: (response) => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Create Order',
                        detail: 'Order created successfully.',
                    });
                },
                error: (error) => {
                    if (
                        error.error.Message ===
                            'One or more errors occurred!' ||
                        error.error.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: {
                                    error: error,
                                },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                    } else {
                        const errorMessage =
                            error?.error?.message || 'Failed to create Order';

                        this.messageService.add({
                            severity: 'error',
                            summary: 'Create Order',
                            detail: errorMessage,
                        });
                    }
                    this.loading.set(false);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
    isOrderOpen = computed(() => {
        return this.SOHeader()?.STATUS_DESC === 'Order Open';
    });
}
