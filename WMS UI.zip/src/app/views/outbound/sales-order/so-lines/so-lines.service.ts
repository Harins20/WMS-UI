import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../../../../../app.config.service';
import { AuthService } from '../../../../common/services';
import { ResponseDto } from '../../../../common/models';
import { map } from 'rxjs';
import { SalesOrderLines } from './so-lines.model';
@Injectable({
    providedIn: 'root',
})
export class SalesOrderLineService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getSalesOrderLines(salesorderKey: string, data: any) {
        return this.httpClient.post<ResponseDto<SalesOrderLines[]>>(
            this.config.appConfig()?.OutUrl +
                `SalesOrderLine/Paged?SOKEY=${salesorderKey}`,
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    createSOLine(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'SalesOrderLine/line/create',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    updateSOLine(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.InbUrl + 'Po/Lines',
            [data],
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    deleteSOLine(data: any) {
        return this.httpClient.delete(
            this.config.appConfig()?.OutUrl + 'SalesOrderLine',
            {
                headers: this.authService.getAuthHeaders(),
                body: data,
            },
        );
    }
    createOrder(data: any, SOKey: any) {
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl +
                'salesorder/submit?SOKEY=' +
                SOKey,
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    createOrderHeader(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.InbUrl + 'Po/Asnheader',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }

    getItemDetailsOptions(TraderKey: string) {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    `items?TraderKey=${TraderKey}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    value.map((x: any) => ({
                        ...x,
                        label: x.Sku,
                        value: x.Sku,
                    })),
                ),
            );
    }
}
