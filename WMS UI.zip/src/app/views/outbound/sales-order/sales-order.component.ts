import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { salesorder } from './sales-order.model';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, Route } from '@angular/router';

import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { MenuItem, MessageService } from 'primeng/api';
import { DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';
import { finalize } from 'rxjs';
import {
    ColumnPicklistComponent,
    ConfirmationDialogComponent,
    LoadingComponent,
} from '../../../common/components';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';
import { tableOptions } from '../../../common/constants';
import { copyToClipboardText } from '../../../common/functions/clickToCopy';
import { ExcelDownloadService, OptionsService } from '../../../common/services';
import { TabService } from '../../../tabs';
import { PO, POService, POLineService, POLines } from '../../inbound';
import inboundRoutes from '../../inbound/inbound.routes';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { TagModule } from 'primeng/tag';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { SalesOrderColumns } from './sales-order.column';
import { SoFormComponent } from './so-form/so-form.component';
import outboundRoutes from '../outbound.routes';
import { SalesOrderLineService } from './so-lines/so-lines.service';
import { SalesOrderService } from './sales-order.service';
import { filterQuery } from '../../../common/functions';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';

@Component({
    selector: 'app-sales-order',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        LoadingComponent,
        TagModule,
        TooltipModule,
        AppTranslatePipe,
        CustomTablePaginationComponent,
    ],
    templateUrl: './sales-order.component.html',
    styleUrl: './sales-order.component.scss',
    providers: [DialogService],
})
export class SalesOrderComponent {
    hoveredRow: string | null = null;
    SalesOrders = signal<salesorder[]>([]);
    selectedSalesOrders = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');
    private translate = inject(TranslateService);
    columns = signal<any>([]);
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(15);
    globalFilterColumns = computed(() =>
        this.columns().map((x: any) => x.field),
    );
    tableOptions = signal(tableOptions);
    OriginalColumns = signal<any>(SalesOrderColumns);
    selectedColumns = linkedSignal(() => this.columns());
    exportFileName = 'SalesOrders-list';
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];
    ref: DynamicDialogRef | undefined;
    private messageService = inject(MessageService);
    private SalesOrderService = inject(SalesOrderService);
    private destroyRef = inject(DestroyRef);
    private tabService = inject(TabService);
    private dialogService = inject(DialogService);
    private excelDownloadService = inject(ExcelDownloadService);
    private optionService = inject(OptionsService);
    ConfirmationRef: DynamicDialogRef | undefined;
    private router = inject(Router);
    selectedSalesOrderLines = signal<any>([]);
    private SalesOrderlinesService = inject(SalesOrderLineService);
    SalesOrderlines = signal<POLines[]>([]);
    SalesOrderKey = computed(() =>
        this.selectedSalesOrders().length > 0
            ? this.selectedSalesOrders()[0].SOKEY
            : '',
    );
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');

    constructor() {}
    ngOnInit() {
        this.getSalesOrders();
        this.getColumns();
    }

    getColumns() {
        this.optionService.getColumns(SalesOrderColumns, 'PO').subscribe({
            next: (data) => {
                const FilterField = data.map((x: any) => x.field);

                const GetFilterFields = Object.values(SalesOrderColumns).filter(
                    (x: any) => {
                        return !FilterField.includes(x.field);
                    },
                );

                const allowedFields = [
                    'UDFSTR1',
                    'UDFSTR2',
                    'UDFSTR3',
                    'UDFSTR4',
                    'UDFSTR5',
                ];

                const limitedColumns = data.filter(
                    (x: any) =>
                        !x.field?.startsWith('UDF') ||
                        allowedFields.includes(x.field),
                );

                const columns = [...GetFilterFields, ...limitedColumns];
                let updatedColumns = columns;

                updatedColumns = updatedColumns.map((column: any) => {
                    if (column.field === 'STATUS_DESC') {
                        return {
                            ...column,
                            customCellTemplate: this.customStatusCellTemplate(),
                        };
                    }

                    return column;
                });
                this.columns.set(
                    updatedColumns.filter((column: any) => !column.tableHidden),
                );
            },
        });
    }

    getSalesOrders(
        data: any = {
            Page: this.loadEvent()?.Page || 1,
            PageSize: this.loadEvent()?.PageSize || this.rows(),
        },
    ) {
        this.loading.set(true);
        this.SalesOrders.set([]);
        const subscription = this.SalesOrderService.getSO(data)
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (
                        data.OrderBy &&
                        data.OrderBy.includes('SerialKey desc')
                    ) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }
                    // console.log(
                    //     'idBase',
                    //     idBase,
                    //     'desc',
                    //     desc,
                    //     'totalRecords',
                    //     this.totalRecords(),
                    // );
                    // console.log('idBase', res.Response.SalesOrders);
                    const first = data?.first ?? 0;
                    this.SalesOrders.set(
                        res.Response.SalesOrders.map((x: any, idx: number) => ({
                            ...x,
                            rowId: first + idx + 1,
                            PODATE: x.PODATE ? new Date(x.PODATE) : null,
                        })),
                    );
                    this.totalRecords.set(res.Response.TotalRecords);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Sales Orders list',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.globalFilterColumns(),
    //         SalesOrderColumns,
    //         'vw.',
    //     );
    //     this.getSalesOrders({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getSalesOrders(event);
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getSalesOrders();
    }
    refresh(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
        this.getSalesOrders();
    }
    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }
    getSalesOrdersForExcel(
        data: any = {
            Page: 1,
            PageSize: this.totalRecords(),
        },
        type: string,
    ) {
        this.SalesOrderService.getSO(data).subscribe({
            next: (res: any) => {
                const salesOrders = res?.Response?.SalesOrders || [];

                if (type === 'Excel') {
                    this.excelDownloadService.downloadExcelFile(
                        this.exportFileName,
                        [],
                        salesOrders,
                    );
                } else {
                    downloadCSVFile(salesOrders, this.exportFileName);
                }
            },
        });
    }

    export(type: string) {
        const event = this.loadEvent();

        const Page = 1;
        const PageSize = this.totalRecords();

        const { filter, orderBy } = filterQuery(
            event,
            this.globalFilterColumns(),
            SalesOrderColumns,
            'vw.',
        );

        this.getSalesOrdersForExcel(
            {
                Page,
                PageSize,
                Condition: filter,
                OrderBy: orderBy,
            },
            type,
        );
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.SalesOrders().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedSalesOrders().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedSalesOrders().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.ref = this.dialogService.open(ColumnPicklistComponent, {
            inputValues: {
                selectedColumns: this.selectedColumns(),
                unSelectedColumns: this.unSelectedColumns(),
            },
            header: headertext,
            closable: true,
            modal: true,
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {});
    }

    copyToClipboard(text: string) {
        copyToClipboardText(text, this.messageService);
    }

    OpenCreateSalesOrderForm() {
        const headertext = this.translate.instant('Create Sales Order');
        this.ref = this.dialogService.open(SoFormComponent, {
            // header: headerText,
            closable: false,
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Creation');
                const value = this.translate.instant('SalesOrderCreation');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.SalesOrderService.createSO(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getSalesOrders();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'New Sales Order creation',
                                        detail: data.Message as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary:
                                                'New Sales Order creation',
                                            detail: error.error
                                                .message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    OpenUpdateSalesOrderForm(soData: any) {
        const headertext = this.translate.instant('Update Sales Order');

        this.ref = this.dialogService.open(SoFormComponent, {
            inputValues: {
                SalesOrderData: soData,
            },
            modal: true,
            position: 'right',
            draggable: false,
            dismissableMask: false,
            transitionOptions: '300ms cubic-bezier(0, 0, 0.2, 1)',

            styleClass: 'right-slide-panel',
            style: {
                width: '70rem',
                height: '100vh',
                maxHeight: '100vh',
                margin: '0',
                borderRadius: '0',
            },

            contentStyle: {
                overflow: 'auto',
                height: '100%',
            },

            breakpoints: {
                '960px': '100vw',
            },
        });

        this.ref.onClose.subscribe((data) => {
            if (data) {
                const header = this.translate.instant('Confirm Update');
                const value = this.translate.instant('SalesOrderUpdate');
                this.ConfirmationRef = this.dialogService.open(
                    ConfirmationDialogComponent,
                    {
                        inputValues: {
                            message: value,
                        },
                        header: header,
                        closable: true,
                        modal: true,
                        draggable: true,
                        keepInViewport: true,
                        width: '30rem',
                        style: { maxHeight: '40rem' },
                    },
                );
                this.ConfirmationRef.onClose.subscribe((confirmed) => {
                    if (confirmed) {
                        this.loading.set(true);
                        this.SalesOrderService.updateSO(data)
                            .pipe(
                                finalize(() => {
                                    this.loading.set(false);
                                    this.getSalesOrders();
                                }),
                            )
                            .subscribe({
                                next: (data: any) => {
                                    this.messageService.add({
                                        severity: 'success',
                                        summary: 'Sales Order Update',
                                        detail: data.Response as string,
                                    });
                                },
                                error: (error) => {
                                    if (
                                        error.error.Message ===
                                            'One or more errors occurred!' ||
                                        error.error.message ===
                                            'One or more errors occurred!'
                                    ) {
                                        this.ConfirmationRef =
                                            this.dialogService.open(
                                                CommonErrorboxComponent,
                                                {
                                                    inputValues: {
                                                        error: error,
                                                    },
                                                    header: 'Multiple Error',
                                                    closable: true,
                                                    modal: true,
                                                    draggable: true,
                                                    keepInViewport: true,
                                                    width: '39rem',
                                                    style: {
                                                        maxHeight: '40rem',
                                                    },
                                                },
                                            );
                                    } else {
                                        this.messageService.add({
                                            severity: 'error',
                                            summary: 'Sales Order Update',
                                            detail: error.error
                                                .message as string,
                                        });
                                    }
                                    this.loading.set(false);
                                },
                            });
                    }
                });
            }
        });
    }

    // getSalesOrderLines() {
    //     this.loading.set(true);
    //     this.SalesOrderlines.set([]);
    //     const subscription = this.SalesOrderlinesService.getSalesOrderLines(
    //         this.SalesOrderKey(),
    //     )
    //         .pipe(
    //             finalize(() => {
    //                 this.loading.set(false);
    //             }),
    //         )
    //         .subscribe({
    //             next: (res) => {
    //                 this.SalesOrderlines.set(
    //                     res.Response.map((x: any, idx: number) => ({
    //                         ...x,
    //                         rowId: idx + 1,
    //                     })),
    //                 );
    //             },
    //             error: (error: HttpErrorResponse) => {
    //                 if (error.status === 0)
    //                     this.messageService.add({
    //                         severity: 'error',
    //                         summary: 'Sales Order Lines list',
    //                         detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
    //                     });
    //             },
    //         });

    //     this.destroyRef.onDestroy(() => subscription.unsubscribe());
    // }

    OnClickCreateOrder() {
        const SalesOrderKey = this.SalesOrderKey();
        if (!SalesOrderKey) {
            this.messageService.add({
                severity: 'warn',
                summary: 'Create Order',
                detail: 'Please select at least one Sales Order.',
            });
            return;
        }

        const Rdata = this.selectedSalesOrders().map((x: any) => x.SERIALKEY);
        this.loading.set(true);

        const requestBody = {
            POKEY: SalesOrderKey,
            SERIALKEY: Rdata,
        };

        const subscription = this.SalesOrderlinesService.createOrderHeader(
            requestBody,
        )
            .pipe(
                finalize(() => {
                    this.loading.set(false);
                    this.selectedSalesOrders.set([]);
                    this.getSalesOrders();
                }),
            )
            .subscribe({
                next: () => {
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Create Order',
                        detail: 'Order created successfully.',
                    });
                },
                error: (error) => {
                    if (
                        error.error.Message ===
                            'One or more errors occurred!' ||
                        error.error.message === 'One or more errors occurred!'
                    ) {
                        this.ConfirmationRef = this.dialogService.open(
                            CommonErrorboxComponent,
                            {
                                inputValues: { error },
                                header: 'Multiple Error',
                                closable: true,
                                modal: true,
                                draggable: true,
                                keepInViewport: true,
                                width: '39rem',
                                style: { maxHeight: '40rem' },
                            },
                        );
                    } else {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Create Order',
                            detail:
                                error?.error?.message ||
                                'Failed to create Order',
                        });
                    }
                    this.loading.set(false);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    DeleteSalesOrder() {
        const headertext = this.translate.instant('Confirm Deletion');
        const count = this.selectedSalesOrders().length;
        const name =
            count > 1
                ? this.translate.instant('Sales Orders')
                : this.translate.instant('Sales Order');
        const value = this.translate.instant('Delete', {
            no: count,
            name: name,
        });
        this.ConfirmationRef = this.dialogService.open(
            ConfirmationDialogComponent,
            {
                inputValues: {
                    message: value,
                },
                header: headertext,
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '30rem',
                style: { maxHeight: '40rem' },
            },
        );
        this.ConfirmationRef.onClose.subscribe((data) => {
            if (data) {
                this.loading.set(true);
                const Rdata = this.selectedSalesOrders().map((x: any) => {
                    return x.SOKEY;
                });
                // console.log(Rdata);
                const subscription = this.SalesOrderService.deleteSO(Rdata)
                    .pipe(
                        finalize(() => {
                            this.loading.set(false);
                            this.selectedSalesOrders.set([]);
                            this.getSalesOrders();
                        }),
                    )
                    .subscribe({
                        next: (res: any) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Delete Sales Order',
                                detail: res.Response as string,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Delete Sales Order',
                                    detail:
                                        error.error.message ||
                                        'Failed to delete Sales Order.',
                                });
                            }
                            this.loading.set(false);
                        },
                    });

                this.destroyRef.onDestroy(() => subscription.unsubscribe());
            }
        });
    }
    onClickSalesOrderKey(row: salesorder): void {
        const route = outboundRoutes.find(
            (route) => route.data?.name === 'soline',
        ) as Route;

        const params = [
            { name: 'soKey', value: row.SOKEY },
            { name: 'storerKey', value: row.TRADERKEY },
        ];

        this.tabService.addTabWithParams(
            route,
            '',
            'Sales Order Details - ' + row.SOKEY,
            params,
        );
    }

    onEditAction(SalesOrder: salesorder) {}

    getColumnWidthNormal(column: any) {
        if (column.label > 15) {
            return { width: '120px' };
        }
        return { width: '135px' };
    }
}
