import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';
import { Wave } from '../wave.model';
import { WaveFilterColumns } from './wave-filter.columns';
import { stringToDate } from '../../../common/functions';
import { map } from 'rxjs';

interface WaveFilterPage {
    WaveFilters: Wave[];
    totalRecords: number;
}

@Injectable({
    providedIn: 'root',
})
export class WaveFilterService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);

    getWavesFilters() {
        return this.httpClient.get<ResponseDto<Wave[]>>(
            this.config.appConfig()?.OutUrl + 'Wave/WaveFilter',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getWaveFilterPaged(data: any) {
        return this.httpClient
            .post<WaveFilterPage>(
                this.config.appConfig()?.OutUrl + 'WavesPaged',
                data,
                {
                    headers: this.authService.getAuthHeaders(),
                },
            )
            .pipe(
                map((response: any) => {
                    const items =
                        response?.Response?.WaveFilters ||
                        response?.WaveFilters ||
                        response?.Response?.CrossDocks ||
                        response?.CrossDocks ||
                        response?.Response ||
                        [];

                    if (Array.isArray(items)) {
                        items.forEach((WaveFilters: any) => {
                            Object.keys(WaveFilters).forEach((key) => {
                                const column = WaveFilterColumns.find(
                                    (column: any) => column.field === key,
                                );

                                if (column?.type === 'date') {
                                    WaveFilters[key] = stringToDate(
                                        WaveFilters[key],
                                    );
                                }
                            });
                        });
                    }

                    return response;
                }),
            );
    }
    CreateWaveFilter(data: any) {
        return this.httpClient.post(
            this.config.appConfig()?.OutUrl + 'Wave/WaveFilter',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
    UpdateWaveFilter(data: any) {
        return this.httpClient.put(
            this.config.appConfig()?.OutUrl + 'Wave/WaveFilter',
            data,
            {
                headers: this.authService.getAuthHeaders(),
            },
        );
    }
}
