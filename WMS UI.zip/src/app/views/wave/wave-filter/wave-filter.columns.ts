import { Validators } from '@angular/forms';
import { Column } from '../../../common/models';

export const WaveFilterColumns: Column[] = [
    {
        field: 'rowId',
        label: 'S/No',
        type: 'number',
    },
    {
        field: 'ID',
        label: 'ID',
        type: 'number',
        tableHidden: true,
        tableAlias: 'vw.',
    },
    {
        field: 'FILTERNAME',
        label: 'Filter Name',
        type: 'text',
        restrictEdit: true,
        validators: [Validators.required],
        tableAlias: 'vw.',
    },
    {
        field: 'FACILITY',
        label: 'Facility',
        type: 'text',
        tableHidden: true,
        restrictInsert: true,
        restrictEdit: true,
        tableAlias: 'vw.',
    },
    {
        field: 'TRADERKEY',
        label: 'Trader Key',
        type: 'text',
        tableHidden: true,
        restrictInsert: true,
        restrictEdit: true,
        tableAlias: 'vw.',
    },
    {
        field: 'ORDERS_MIN',
        label: 'Orders Min',
        type: 'number',
        validators: [Validators.min(1), Validators.max(99999)],
        tableAlias: 'vw.',
    },
    {
        field: 'ORDERS_MAX',
        label: 'Orders Max',
        type: 'number',
        validators: [Validators.min(1), Validators.max(99999)],
        tableAlias: 'vw.',
    },
    {
        field: 'ORDER_LINES_MIN',
        label: 'Order Lines Min',
        type: 'number',
        validators: [Validators.min(1), Validators.max(99999)],
        tableAlias: 'vw.',
    },
    {
        field: 'ORDER_LINES_MAX',
        label: 'Order Lines Max',
        type: 'number',
        validators: [Validators.min(1), Validators.max(99999)],
        tableAlias: 'vw.',
    },

    {
        field: 'ISACTIVE',
        label: 'Active',
        tableAlias: 'vw.',
    },
    {
        field: 'INCLUDE_EXISTING_WAVE_ORDERS',
        label: 'Include Orders From Existing Wave',
        tableAlias: 'vw.',
    },
    {
        field: 'ADDWHO',
        label: 'Added By',
        type: 'text',
        tableAlias: 'vw.',
    },
    {
        field: 'ADDDATE',
        label: 'Added Date',
        type: 'date',
        tableAlias: 'vw.',
    },
    {
        field: 'EDITWHO',
        label: 'Edited By',
        type: 'text',
        tableAlias: 'vw.',
    },
    {
        field: 'EDITDATE',
        label: 'Edited Date',
        type: 'date',
        tableAlias: 'vw.',
    },
    {
        field: 'ISACTIVE',
        label: 'Active',
        tableAlias: 'vw.',
    },
];
