import {
    Component,
    DestroyRef,
    inject,
    linkedSignal,
    signal,
} from '@angular/core';
import { CustomTablePaginationComponent } from '../../../common/components/custom-table-pagination/custom-table-pagination.component';
import { ExcelDownloadService } from '../../../common/services';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { WaveFilterColumns } from './wave-filter.columns';
import { ButtonModule } from 'primeng/button';
import { WaveFilterFormComponent } from './wave-filter-form/wave-filter-form.component';
import { finalize } from 'rxjs';
import { CommonErrorboxComponent } from '../../../common/components/common-errorbox/common-errorbox.component';
import { MessageService } from 'primeng/api';
import { CommonLoadingService } from '../../../common/services/common-loading.service';
import { WaveFilterService } from './wave-filter.service';
import { TableLazyLoadEvent } from 'primeng/table';
import { filterQuery } from '../../../common/functions';
import { downloadCSVFile } from '../../../common/functions/downloadCSVFile';

import { Columns } from '../../../common/models';

const waveFilterColumnsMap: Columns = WaveFilterColumns.reduce(
    (acc: Columns, col: any) => {
        if (col.field) {
            acc[col.field] = col;
        }
        return acc;
    },
    {} as Columns,
);

@Component({
    selector: 'app-wave-filter',
    imports: [CustomTablePaginationComponent, ButtonModule],
    templateUrl: './wave-filter.component.html',
    styleUrl: './wave-filter.component.scss',
})
export class WaveFilterComponent {
    listData = signal<any>([]);
    waveFilterExcel = signal<any[]>([]);
    ref: DynamicDialogRef | undefined;
    ConfirmationRef: DynamicDialogRef | undefined;
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    rows = signal(15);
    exportFileName = 'Wave-Filters';

    private commonLoadingService = inject(CommonLoadingService);
    private messageService = inject(MessageService);
    private dialogService = inject(DialogService);
    private waveFilterService = inject(WaveFilterService);
    private readonly excelDownloadService = inject(ExcelDownloadService);
    private destroyRef = inject(DestroyRef);

    columns = signal<any>(
        WaveFilterColumns.filter((column: any) => !column.tableHidden),
    );
    OrginalColumns = signal<any>(WaveFilterColumns);
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column: any) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        }

        return this.columns();
    });

    ngOnInit() {
        this.getWaveFilterPaged();
    }

    // loadData(event: TableLazyLoadEvent) {
    //     this.loadEvent.set(event);
    //     const PageSize = event.rows || this.rows();
    //     const Page = (event.first || 0) / PageSize + 1;
    //     const { filter, orderBy } = filterQuery(
    //         event,
    //         this.columns().map((x: any) => x.field),
    //         waveFilterColumnsMap,
    //         'vw.',
    //     );
    //     this.getWaveFilterPaged({
    //         Page,
    //         PageSize,
    //         Condition: filter,
    //         OrderBy: orderBy,
    //     });
    // }
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getWaveFilterPaged(event);
    }
    getWaveFilterPaged(data: any = this.loadEvent()) {
        this.commonLoadingService.loading.set(true);

        const subscription = this.waveFilterService
            .getWaveFilterPaged(data)
            .pipe(
                finalize(() => {
                    this.commonLoadingService.loading.set(false);
                }),
            )
            .subscribe({
                next: (res: any) => {
                    const first = data?.first ?? 0;
                    const items =
                        res?.Response?.WaveHeaders ||
                        res?.WaveFilters ||
                        res?.Response?.CrossDocks ||
                        res?.CrossDocks ||
                        res?.Response ||
                        [];
                    const total =
                        res?.Response?.totalRecords ??
                        res?.Response?.TotalRecords ??
                        res?.totalRecords ??
                        res?.TotalRecords ??
                        res?.Response?.totalCount ??
                        res?.Response?.TotalCount ??
                        res?.totalCount ??
                        0;

                    let idBase = data.Page * data.PageSize - data.PageSize;
                    let desc = false;
                    if (data.OrderBy && data.OrderBy.includes('ID desc')) {
                        idBase =
                            this.totalRecords() -
                            (data.Page - 1) * data.PageSize;
                        desc = true;
                    }

                    const list = Array.isArray(items) ? items : [];

                    this.listData.set(
                        list.map((x: any, idx: number) => ({
                            ...x,
                            rowId: first + idx + 1,
                            ISACTIVE:
                                x.ISACTIVE === true ? 'Active' : 'Inactive',
                        })),
                    );
                    this.totalRecords.set(total);
                },
                error: (err: any) => {
                    console.error('Error fetching wave filter data:', err);
                    this.commonLoadingService.loading.set(false);
                },
            });

        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    GetWaveFilters() {
        this.getWaveFilterPaged();
    }

    getWaveFilterForExcel(
        data: any = { Page: 1, PageSize: this.totalRecords() },
        type: string,
    ) {
        this.waveFilterExcel.set([]);
        const subscription = this.waveFilterService
            .getWaveFilterPaged(data)
            .pipe()
            .subscribe({
                next: (res: any) => {
                    const items =
                        res?.Response?.WaveFilters ||
                        res?.WaveFilters ||
                        res?.Response?.CrossDocks ||
                        res?.CrossDocks ||
                        res?.Response ||
                        [];
                    const list = Array.isArray(items) ? items : [];
                    this.waveFilterExcel.set(list);
                    if (list && type === 'Excel') {
                        this.excelDownloadService.downloadExcelFile(
                            this.exportFileName,
                            [],
                            list,
                        );
                    } else {
                        downloadCSVFile(list, this.exportFileName);
                    }
                },
                error: (error: any) => {
                    console.error('Error exporting wave filters:', error);
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    export(type: string) {
        const event = this.loadEvent();
        const PageSize = this.totalRecords();
        const Page = (event.first || 0) / PageSize + 1;
        const { filter, orderBy } = filterQuery(
            event,
            this.columns().map((x: any) => x.field),
            waveFilterColumnsMap,
            'vw.',
        );

        this.getWaveFilterForExcel(
            {
                Page,
                PageSize,
                Condition: filter,
                OrderBy: orderBy,
            },
            type,
        );
    }

    exportExcel() {
        this.export('Excel');
    }

    exportCSV() {
        this.export('CSV');
    }

    openNewForm() {
        this.ref = this.dialogService.open(WaveFilterFormComponent, {
            header: 'Wave Filter Form',
            closable: true,
            modal: true,
            draggable: false,
            dismissableMask: false,
            width: '50rem',
            style: { maxHeight: '50rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                this.waveFilterService
                    .CreateWaveFilter(data)
                    .pipe(
                        finalize(() => {
                            this.getWaveFilterPaged();
                        }),
                    )
                    .subscribe({
                        next: (outData: any) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'New Order Creation',
                                detail: outData.Message as string,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.Message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'New Order Creation',
                                    detail: error?.error?.message as string,
                                });
                            }
                        },
                    });
            }
        });
    }

    onEdit(row: any): void {
        this.ref = this.dialogService.open(WaveFilterFormComponent, {
            header: 'View Wave Filter',
            inputValues: {
                formData: row,
                type: 'Update',
            },
            closable: true,
            modal: true,
            draggable: false,
            dismissableMask: false,
            width: '50rem',
            style: { maxHeight: '50rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
                this.waveFilterService
                    .UpdateWaveFilter(data)
                    .pipe(
                        finalize(() => {
                            this.getWaveFilterPaged();
                        }),
                    )
                    .subscribe({
                        next: (outData: any) => {
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Update Wave Filter',
                                detail: outData.Message as string,
                            });
                        },
                        error: (error) => {
                            if (
                                error.error.Message ===
                                    'One or more errors occurred!' ||
                                error.error.Message ===
                                    'One or more errors occurred!'
                            ) {
                                this.ConfirmationRef = this.dialogService.open(
                                    CommonErrorboxComponent,
                                    {
                                        inputValues: {
                                            error: error,
                                        },
                                        header: 'Multiple Error',
                                        closable: true,
                                        modal: true,
                                        draggable: true,
                                        keepInViewport: true,
                                        width: '39rem',
                                        style: { maxHeight: '40rem' },
                                    },
                                );
                            } else {
                                this.messageService.add({
                                    severity: 'error',
                                    summary: 'Update Wave Filter',
                                    detail: error?.error?.message as string,
                                });
                            }
                        },
                    });
            }
        });
    }

    onClickDataKey(row: any): void {
        this.ref = this.dialogService.open(WaveFilterFormComponent, {
            header: 'View Wave Filter',
            inputValues: {
                formData: row,
            },
            closable: true,
            modal: true,
            draggable: false,
            dismissableMask: false,
            width: '50rem',
            style: { maxHeight: '50rem' },
        });
        this.ref.onClose.subscribe((data) => {
            if (data) {
            }
        });
    }
}
