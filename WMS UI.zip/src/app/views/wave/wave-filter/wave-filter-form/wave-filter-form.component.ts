import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    OnInit,
    signal,
} from '@angular/core';
import {
    FormArray,
    FormBuilder,
    FormControl,
    FormGroup,
    FormsModule,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { InputTextModule } from 'primeng/inputtext';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { DatePickerModule } from 'primeng/datepicker';
import { MessageService } from 'primeng/api';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { selectOption } from '../../../../common/models';
import { OptionsService } from '../../../../common/services';
import { WaveFilterColumns } from '../wave-filter.columns';
import { InputTextComponent } from '../../../../common/components';

export type ValueFieldType = 'text' | 'number' | 'date' | 'dropdown';

@Component({
    selector: 'app-wave-filter-form',
    imports: [
        ReactiveFormsModule,
        FormsModule,
        ButtonModule,
        InputTextModule,
        InputNumberModule,
        InputGroupModule,
        InputGroupAddonModule,
        DatePickerModule,
        SelectModule,
        InputTextComponent,
    ],
    templateUrl: './wave-filter-form.component.html',
    styleUrl: './wave-filter-form.component.scss',
})
export class WaveFilterFormComponent implements OnInit {
    formData = input<any>();
    type = input<any>();

    private messageService = inject(MessageService);
    private ref = inject(DynamicDialogRef);
    private optionService = inject(OptionsService);
    private destroyRef = inject(DestroyRef);

    // --- API-driven dropdown signals ---
    statusOptions = signal<selectOption[]>([]);
    priorityOptions = signal<selectOption[]>([]);
    shipToOptions = signal<selectOption[]>([]);
    transportModeOptions = signal<selectOption[]>([]);
    carrierOptions = signal<selectOption[]>([]);
    typeOptions = signal<selectOption[]>([]);

    fieldOptions = [
        { label: 'Status', value: 'STATUS_DESC' },
        { label: 'Order Date', value: 'ORDERDATE' },
        { label: 'Delivery Date', value: 'DELIVERYDATE' },
        { label: 'Priority', value: 'PRIORITY' },
        { label: 'Ship To', value: 'CONSIGNEEKEY' },
        { label: 'Transportation Mode', value: 'TRANSPORTATIONMODE' },
        { label: 'Requested Ship Date', value: 'REQUESTEDSHIPDATE' },
        { label: 'Carrier Code', value: 'CarrierCode' },
        { label: 'Trailer Number', value: 'TrailerNumber' },
        { label: 'Trailer Owner', value: 'TrailerOwner' },
        { label: 'Total Quantity', value: 'TOTALQTY' },
        { label: 'Trailer Key', value: 'TRAILERKEY' },
        { label: 'Type', value: 'TYPE' },
        { label: 'Priority', value: 'Priority_Desc' },
        { label: 'Insurance Number', value: 'InsuranceNo' },
        { label: 'BOE', value: 'BOE' },
        { label: 'User Defined Field 1', value: 'UDFSTR1' },
        { label: 'User Defined Field 2', value: 'UDFSTR2' },
        { label: 'User Defined Field 3', value: 'UDFSTR3' },
        { label: 'User Defined Field 4', value: 'UDFSTR4' },
        { label: 'User Defined Field 5', value: 'UDFSTR5' },
        { label: 'Expected Delivery Date', value: 'EXPECTEDDELIVERYDATE' },
    ];
    operatorOptions = [
        { label: 'Equals', value: '=' },
        { label: 'Not Equals', value: '!=' },
        { label: 'Contains', value: 'LIKE' },
        { label: 'Greater Than', value: '>' },
        { label: 'Less Than', value: '<' },
        { label: 'Greater Than or Equal', value: '>=' },
        { label: 'Less Than or Equal', value: '<=' },
    ];

    // --- Field type classification ---

    private readonly dateFields = new Set([
        'ORDERDATE',
        'DELIVERYDATE',
        'REQUESTEDSHIPDATE',
        'EXPECTEDDELIVERYDATE',
    ]);

    private readonly numberFields = new Set(['TOTALQTY', 'TRAILERKEY']);

    // All fields whose Value should render as a dropdown
    private readonly dropdownFields = new Set([
        'STATUS_DESC',
        'PRIORITY',
        'Priority_Desc',
        'CONSIGNEEKEY',
        'TRANSPORTATIONMODE',
        'CarrierCode',
        'TYPE',
    ]);

    formControlsArray = signal(
        Object.values(WaveFilterColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );

    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    filterForm = new FormGroup({
        ...this.formControls(),
        ConditionsList: new FormArray<FormGroup>([]),
    });

    get conditions(): FormArray {
        return this.filterForm.get('ConditionsList') as FormArray;
    }
    addCondition(): void {
        const condition = new FormGroup({
            FIELD: new FormControl('', Validators.required),

            OPERATOR: new FormControl('', Validators.required),

            VALUE: new FormControl('', Validators.required),
        });

        this.conditions.push(condition);
    }
    removeCondition(index: number): void {
        this.conditions.removeAt(index);

        // Keep one condition row
        if (this.conditions.length === 0) {
            this.addCondition();
        }
    }

    ngOnInit(): void {
        this.loadStatusOptions();
        this.loadPriorityOptions();
        this.loadShipToOptions();
        this.loadTransportModeOptions();
        this.loadCarrierCodeOptions();
        this.loadTypeOptions();
        const data = this.formData();
        let facility = atob(sessionStorage.getItem('Facility') ?? '');
        let TraderKey = atob(sessionStorage.getItem('TraderKey') ?? '');

        this.addCondition();

        if (data) {
            // Patch normal form fields
            this.filterForm.patchValue({
                ID: data.ID,
                FILTERNAME: data.FILTERNAME,
                FACILITY: data.FACILITY,
                TRADERKEY: data.TRADERKEY,
                ORDERS_MIN: data.ORDERS_MIN ?? null,
                ORDERS_MAX: data.ORDERS_MAX ?? null,
                ORDER_LINES_MIN: data.ORDER_LINES_MIN ?? null,
                ORDER_LINES_MAX: data.ORDER_LINES_MAX ?? null,
                ISACTIVE: data.ISACTIVE === 'Active' || data.ISACTIVE === true,
                INCLUDE_EXISTING_WAVE_ORDERS:
                    data.INCLUDE_EXISTING_WAVE_ORDERS === true ||
                    data.INCLUDE_EXISTING_WAVE_ORDERS === 'true',
                ADDDATE: data.ADDDATE ? new Date(data.ADDDATE) : null,
            });

            // Clear existing conditions
            this.conditions.clear();

            // Parse CONDITIONS string
            let conditionsList: any[] = [];

            try {
                if (data.CONDITIONS) {
                    conditionsList =
                        typeof data.CONDITIONS === 'string'
                            ? JSON.parse(data.CONDITIONS)
                            : data.CONDITIONS;
                }
            } catch (error) {
                console.error('Failed to parse CONDITIONS:', error);

                conditionsList = [];
            }
            conditionsList.forEach((condition: any) => {
                const conditionForm = new FormGroup({
                    FIELD: new FormControl(
                        condition.FIELD ?? '',
                        Validators.required,
                    ),

                    OPERATOR: new FormControl(
                        condition.OPERATOR ?? '',
                        Validators.required,
                    ),

                    VALUE: new FormControl(
                        condition.FIELD?.toUpperCase().includes('DATE') &&
                        condition.VALUE
                            ? new Date(condition.VALUE)
                            : (condition.VALUE ?? ''),
                        Validators.required,
                    ),
                });

                this.conditions.push(conditionForm);
            });

            // Add empty condition if no conditions exist
            if (this.conditions.length === 0) {
                this.addCondition();
            }
            Object.values(WaveFilterColumns).forEach((column) => {
                if (column.restrictEdit) {
                    this.filterForm.controls[column.field].disable();
                }
            });
        } else {
            Object.values(WaveFilterColumns).forEach((column) => {
                if (column.restrictInsert) {
                    this.filterForm.controls[column.field].disable();
                }
            });
            this.filterForm.patchValue({
                TRADERKEY: TraderKey,
                FACILITY: facility,
                ISACTIVE: true,
                INCLUDE_EXISTING_WAVE_ORDERS: false,
            });
        }

        // If no conditions, add one empty row
        if (this.conditions.length === 0) {
            this.addCondition();
        }

        console.log('Patched Form:', this.filterForm.getRawValue());
    }

    private loadStatusOptions(): void {
        const sub = this.optionService.getOrderStatusOptions().subscribe({
            next: (data) => this.statusOptions.set(data),
            error: (err) =>
                console.error('Error fetching status options:', err),
        });
        this.destroyRef.onDestroy(() => sub.unsubscribe());
    }

    private loadPriorityOptions(): void {
        const sub = this.optionService.getPriorityOptions().subscribe({
            next: (data) => this.priorityOptions.set(data),
            error: (err) =>
                console.error('Error fetching priority options:', err),
        });
        this.destroyRef.onDestroy(() => sub.unsubscribe());
    }

    private loadShipToOptions(): void {
        const sub = this.optionService.getShipToOptions().subscribe({
            next: (data) => this.shipToOptions.set(data),
            error: (err) =>
                console.error('Error fetching ship-to options:', err),
        });
        this.destroyRef.onDestroy(() => sub.unsubscribe());
    }

    private loadTransportModeOptions(): void {
        const sub = this.optionService
            .getTransportationModeOptions()
            .subscribe({
                next: (data) => this.transportModeOptions.set(data),
                error: (err) =>
                    console.error(
                        'Error fetching transport mode options:',
                        err,
                    ),
            });
        this.destroyRef.onDestroy(() => sub.unsubscribe());
    }

    private loadCarrierCodeOptions(): void {
        const sub = this.optionService.getCarrierOptions().subscribe({
            next: (data) => this.carrierOptions.set(data),
            error: (err) =>
                console.error('Error fetching carrier options:', err),
        });
        this.destroyRef.onDestroy(() => sub.unsubscribe());
    }

    private loadTypeOptions(): void {
        const sub = this.optionService.getReceiptTypeOptions().subscribe({
            next: (data) => this.typeOptions.set(data),
            error: (err) => console.error('Error fetching type options:', err),
        });
        this.destroyRef.onDestroy(() => sub.unsubscribe());
    }
    getOperatorOptions(fieldValue: string): { label: string; value: string }[] {
        const type = this.getValueFieldType(fieldValue);

        switch (type) {
            case 'date':
            case 'number':
                // All operators make sense for date and number
                return [
                    { label: 'Equals', value: '=' },
                    { label: 'Not Equals', value: '!=' },
                    { label: 'Greater Than', value: '>' },
                    { label: 'Less Than', value: '<' },
                    { label: 'Greater Than or Equal', value: '>=' },
                    { label: 'Less Than or Equal', value: '<=' },
                ];

            case 'text':
                // Free text gets Contains too
                return [
                    { label: 'Equals', value: '=' },
                    { label: 'Not Equals', value: '!=' },
                    { label: 'Contains', value: 'LIKE' },
                ];

            case 'dropdown':
                // Dropdowns only need Equals / Not Equals
                return [
                    { label: 'Equals', value: '=' },
                    { label: 'Not Equals', value: '!=' },
                ];

            default:
                return this.operatorOptions;
        }
    }
    onFieldChange(index: number): void {
        const conditionGroup = this.conditions.at(index) as FormGroup;
        conditionGroup.get('VALUE')?.reset('');
        conditionGroup.get('OPERATOR')?.reset(''); // ← add this
    }

    getValueFieldType(fieldValue: string): ValueFieldType {
        if (!fieldValue) return 'text';
        if (this.dateFields.has(fieldValue)) return 'date';
        if (this.numberFields.has(fieldValue)) return 'number';
        if (this.dropdownFields.has(fieldValue)) return 'dropdown';
        return 'text';
    }

    clearField(fieldName: string): void {
        this.filterForm.get(fieldName)?.reset(null);
    }
    getDropdownOptions(fieldValue: string): selectOption[] {
        const map: Record<string, selectOption[]> = {
            STATUS_DESC: this.statusOptions(),
            PRIORITY: this.priorityOptions(),
            Priority_Desc: this.priorityOptions(),
            CONSIGNEEKEY: this.shipToOptions(),
            TRANSPORTATIONMODE: this.transportModeOptions(),
            CarrierCode: this.carrierOptions(),
            TYPE: this.typeOptions(),
        };
        return map[fieldValue] ?? [];
    }

    // --- Save ---

    save(): void {
        if (this.filterForm.invalid) {
            this.filterForm.markAllAsTouched();
            return;
        }

        const formValue = this.filterForm.value;

        const conditionsText = formValue.ConditionsList.map(
            (condition: any) => {
                const val =
                    condition.VALUE instanceof Date
                        ? condition.VALUE.toISOString().split('T')[0]
                        : condition.VALUE;
                return `${condition.FIELD} ${condition.OPERATOR} '${val}'`;
            },
        ).join(' AND ');

        const payload: any = {
            ...(formValue.ID != null ? { ID: formValue.ID } : {}),
            FILTERNAME: this.filterForm.getRawValue()?.FILTERNAME,
            FACILITY: formValue.FACILITY,
            TRADERKEY: formValue.TRADERKEY,
            ORDERS_MIN: formValue.ORDERS_MIN,
            ORDERS_MAX: formValue.ORDERS_MAX,
            ORDER_LINES_MIN: formValue.ORDER_LINES_MIN,
            ORDER_LINES_MAX: formValue.ORDER_LINES_MAX,
            CONDITIONS: conditionsText,
            ConditionsList: formValue.ConditionsList,
            ISACTIVE: formValue.ISACTIVE ?? true,
            INCLUDE_EXISTING_WAVE_ORDERS:
                formValue.INCLUDE_EXISTING_WAVE_ORDERS ?? false,
            ...(formValue.ADDDATE != null
                ? { ADDDATE: formValue.ADDDATE }
                : {}),
        };

        console.log('Payload:', payload);
        this.ref.close(payload);
        this.filterForm.reset();
    }
}
