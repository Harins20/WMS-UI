import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { PrimeNG } from 'primeng/config';
import { TooltipModule } from 'primeng/tooltip';
import { HttpErrorResponse } from '@angular/common/http';
import {
    Component,
    computed,
    DestroyRef,
    inject,
    input,
    linkedSignal,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { MenuItem, MessageService } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { Table, TableModule } from 'primeng/table';
import { finalize } from 'rxjs';

import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { ToolbarModule } from 'primeng/toolbar';

import { WavelinesColumns } from './wave-lines.columns';
import { WaveLineCreationService } from './wave-lines.service';
import { TagModule } from 'primeng/tag';

import {
    ColumnPicklistComponent,
    CustomTableComponent,
    LoadingComponent,
} from '../../../../common/components';
import { CustomTablePaginationComponent } from '../../../../common/components/custom-table-pagination/custom-table-pagination.component';
@Component({
    selector: 'wave-lines-form',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        TooltipModule,
        TagModule,
        AppTranslatePipe,
        LoadingComponent,
        CustomTableComponent,
    ],
    templateUrl: './wave-lines-form.component.html',
    styleUrl: './wave-lines-form.component.scss',
})
export class WaveLinesFormComponent {
    private translate = inject(TranslateService);
    WavePallets = signal([]);
    WaveId = input<any>();
    FilterId = input<any>();
    selectedWaveLines = signal<any>([]);
    searchInput = signal<string | undefined>(undefined);
    loading = signal(false);
    dt = viewChild.required<Table>('dt');

    OrginalColumns = signal<any>(WavelinesColumns);
    selectedColumns = linkedSignal(() => this.columns());
    unSelectedColumns = linkedSignal(() => {
        if (this.selectedColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.selectedColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV(),
        },
    ];

    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    loadData(event: any) {
        this.loadEvent.set(event);
        this.getWavePallets(this.WaveId(), this.FilterId());
    }
    private messageService = inject(MessageService);
    private waveLineCreationService = inject(WaveLineCreationService);
    private destoryRef = inject(DestroyRef);
    private WaveLineFormRef = inject(DynamicDialogRef);
    customStatusCellTemplate =
        viewChild.required<TemplateRef<any>>('customStatusCell');
    columns = computed(() => {
        const template = this.customStatusCellTemplate();
        return Object.values(WavelinesColumns)
            .filter((column) => !column.tableHidden)
            .map((col) => {
                if (col.field === 'StatusDesc') {
                    return {
                        ...col,
                        customCellTemplate: template,
                    };
                }
                return col;
            });
    });
    columnPicklistRef: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    totalRecords = signal(0);
    loadEvent = signal<any>({});
    constructor() {}
    ngOnInit() {
        if (this.WaveId() && this.FilterId()) {
            this.getWavePallets(this.WaveId(), this.FilterId());
        }
    }

    getWavePallets(waveId: any, filterId: any) {
        this.loading.set(true);
        this.WavePallets.set([]);
        const subscription = this.waveLineCreationService
            .getWavePallets(waveId, filterId)
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: (res: any) => {
                    this.WavePallets.set(res.Response);
                },
                error: (error: HttpErrorResponse) => {
                    if (error.status === 0)
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Load Pallets List',
                            detail: 'Network error occured. Please check your internet connection and contact the administrator if required.',
                        });
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    globalFilter(dt: Table, event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        dt.filterGlobal(eventValue, 'contains');
    }

    clear(table: Table) {
        table.clear();
        this.searchInput.set(undefined);
    }
    refresh(table: Table, loadId: any, filterId: any) {
        table.clear();
        this.searchInput.set(undefined);
        this.getWavePallets(loadId, filterId);
    }
    exportCSV() {
        this.dt().exportCSV();
    }
    deleteSelectedProducts() {}

    options(field: string) {
        const uniqueValues = new Set(
            this.WavePallets().map((x: any) => x[field]),
        );
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedWaveLines().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedWaveLines().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: this.selectedColumns(),
                    unSelectedColumns: this.unSelectedColumns(),
                },
                header: headertext,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onClose.subscribe((data) => {});
    }
    OnCreateWaveLine() {
        this.WaveLineFormRef.close(this.selectedWaveLines());
    }
}
