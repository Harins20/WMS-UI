import {
    Component,
    DestroyRef,
    computed,
    inject,
    input,
    signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import { TabsModule } from 'primeng/tabs';

import { WaveColumns } from '../wave.columns';
import { DatePickerModule } from 'primeng/datepicker';
import { MessageService } from 'primeng/api';
import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { CommonModule } from '@angular/common';
import {
    InputDatepickerComponent,
    InputNumberComponent,
    InputTextComponent,
    InputSelectComponent,
} from '../../../common/components';
import {
    getErrorMessages,
    markAllControlsAsDirty,
} from '../../../common/functions';
import { selectOption } from '../../../common/models';
import { AuthService, OptionsService } from '../../../common/services';
import { WaveFilterService } from '../wave-filter/wave-filter.service';
import { WaveFilterViewComponent } from './wave-filter-view/wave-filter-view.component';
import { LayoutService } from '../../../layout/service/layout.service';
interface FilterOption extends selectOption {
    CONDITIONS: string;
    FILTERNAME: string;
    FACILITY: string;
    TRADERKEY: string;
    ISACTIVE: boolean;
}
@Component({
    selector: 'wave-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        Select,
        ButtonModule,
        DatePickerModule,
        TabsModule,
        InputDatepickerComponent,
        InputNumberComponent,
        InputTextComponent,
        InputSelectComponent,
        AppTranslatePipe,
        CommonModule,
        WaveFilterViewComponent,
    ],
    templateUrl: './wave-form.component.html',
    styleUrl: './wave-form.component.scss',
})
export class WaveFormComponent {
    OrderData = input<any>();
    private destoryRef = inject(DestroyRef);
    private authservice = inject(AuthService);
    private optionService = inject(OptionsService);
    private router = inject(Router);
    private ref = inject(DynamicDialogRef);
    private messageService = inject(MessageService);
    private waveFilterService = inject(WaveFilterService);

    loading = signal(false);
    // ✅ Single signal for tab validation warning
    setViewTab = signal<boolean>(true);
    // ✅ Single signal for active tab
    activeTab = signal<number>(0);
    loadColumns: any[] = [];
    formControlsArray = signal(
        Object.values(WaveColumns).map((column) => [
            column.field,
            new FormControl(column.defaultValue, {
                validators: column.validators,
            }),
        ]),
    );
    formControls = computed(() => Object.fromEntries(this.formControlsArray()));
    form = new FormGroup(this.formControls());
    ownerOptions = signal<selectOption[]>([]);
    typeOptions = signal<selectOption[]>([]);
    carrierOptions = signal<selectOption[]>([]);
    doorOptions = signal<selectOption[]>([]);
    FilterOptions = signal<selectOption[]>([]);
    // Add this signal near the other signals
    selectedFilterConditions = signal<string>('');
    LayoutService = inject(LayoutService);
    isDarkTheme = computed(() => this.LayoutService.layoutConfig().darkTheme);
    // ✅ Navigate to tab
    goToTab(index: number): void {
        this.activeTab.set(index);
    }
    closePanel() {
        this.ref.close();
    }

    ngOnInit() {
        this.GetOwnerOptions();
        this.GetTypeOptions();
        this.GetCarrierOptions();
        this.handleCarrierSelection();
        this.GetDoorOptions();
        this.GetFilterOptions();
        this.getColumns();

        // Watch Apply Filter value
        this.form.get('FILTERID')?.valueChanges.subscribe((filterId) => {
            console.log('FILTERID changed:', filterId);
            this.onFilterSelect(filterId);
        });

        if (this.OrderData()) {
            Object.values(WaveColumns).forEach((column) => {
                if (column.restrictEdit) {
                    this.form.controls[column.field].disable();
                }
            });

            this.form.patchValue({
                ...this.OrderData(),
                ORDERDATE: new Date(this.OrderData().ORDERDATE),
                EXT_UDF_DATE1: this.OrderData()?.EXT_UDF_DATE1
                    ? new Date(this.OrderData().EXT_UDF_DATE1)
                    : null,
                EXT_UDF_DATE2: this.OrderData()?.EXT_UDF_DATE2
                    ? new Date(this.OrderData().EXT_UDF_DATE2)
                    : null,
                EXT_UDF_DATE3: this.OrderData()?.EXT_UDF_DATE3
                    ? new Date(this.OrderData().EXT_UDF_DATE3)
                    : null,
                EXT_UDF_DATE4: this.OrderData()?.EXT_UDF_DATE4
                    ? new Date(this.OrderData().EXT_UDF_DATE4)
                    : null,
                WAVEDate: this.OrderData()?.WAVEDate
                    ? new Date(this.OrderData().WAVEDate)
                    : null,
            });
        } else {
            Object.values(WaveColumns).forEach((column) => {
                if (column.restrictInsert) {
                    this.form.controls[column.field].disable();
                }
            });

            this.form.patchValue({
                Type: this.OrderData(),
            });
        }
    }
    onFilterSelect(filterId: any): void {
        if (!filterId) {
            this.selectedFilterConditions.set('');
            return;
        }

        const selected: any = this.FilterOptions().find(
            (f: any) => String(f.value) === String(filterId),
        );

        if (!selected?.CONDITIONS) {
            this.selectedFilterConditions.set('');
            return;
        }

        this.selectedFilterConditions.set(selected);
    }
    hasError(formControlName: string) {
        const formControl = this.form.get(formControlName);
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    getErrors(formControlName: string, title?: string) {
        const formControl = this.form.get(formControlName);
        return formControl ? getErrorMessages(formControl.errors, title) : [];
    }

    handleCarrierSelection() {
        this.form
            .get('CarrierCode')
            ?.valueChanges.pipe()
            .subscribe((selectedValue) => {
                if (!selectedValue) return;

                const selectedTrader: any = this.carrierOptions().find(
                    (trader) => trader.value === selectedValue,
                );

                if (selectedTrader) {
                    this.form.patchValue({
                        CarrierName: selectedTrader.Company || '',
                    });
                }
            });
    }
    GetOwnerOptions() {
        const subscription = this.optionService
            .getOwnerOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.ownerOptions.set(data);
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    GetFilterOptions() {
        const subscription = this.waveFilterService
            .getWavesFilters()
            .pipe()
            .subscribe({
                next: (data) => {
                    this.FilterOptions.set(
                        data.Response.map((x: any) => ({
                            ...x,
                            label: x.FILTERNAME,
                            value: x.ID,
                        })),
                    );
                    // Re-apply filter selection after options load (fixes race condition in Update mode)
                    const currentFilterId = this.form.get('FILTERID')?.value;
                    if (currentFilterId) {
                        this.onFilterSelect(currentFilterId);
                    }
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    GetDoorOptions() {
        const subscription = this.optionService
            .getLocation()
            .pipe()
            .subscribe({
                next: (data) => {
                    const doorLocations = data.filter(
                        (item: any) => item.LocationTypeDesc === 'Door',
                    );
                    this.doorOptions.set(
                        doorLocations.map((x: any) => ({
                            ...x,
                            label: x.Loc,
                            value: x.Loc,
                        })),
                    );
                },
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    GetTypeOptions() {
        const subscription = this.optionService
            .getReceiptTypeOptions()
            .subscribe({
                next: (data) => {
                    this.typeOptions.set(data);
                },
                error: (err) => {
                    console.error('Error fetching dropdown data:', err);
                },
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    GetCarrierOptions() {
        const subscription = this.optionService.getCarrierOptions().subscribe({
            next: (data) => {
                this.carrierOptions.set(data);
            },
            error: (err) => {
                console.error('Error fetching dropdown data:', err);
            },
        });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    onCancel() {
        this.ref.close();
    }
    onSubmit() {
        if (this.form.valid) {
            this.setViewTab.set(true);
            this.ref.close(this.form.getRawValue());
            this.form.reset();
        } else {
            this.setViewTab.set(false);
            this.messageService.add({
                severity: 'warn',
                summary: 'Mandatory Field',
                detail: 'Please fill the mandatory field',
            });
            this.form.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.form.controls));
        }
    }
    getColumns() {
        this.optionService.getColumns(WaveColumns, 'WAVE').subscribe({
            next: (data) => {
                this.loadColumns = data.map((x: any) => {
                    if (x.field === 'EXT_UDF_DATETIME1') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE1',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME2') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE2',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME3') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE3',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME4') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE4',
                        };
                    } else if (x.field === 'EXT_UDF_DATETIME5') {
                        return {
                            ...x,
                            field: 'EXT_UDF_DATE5',
                        };
                    } else {
                        return x;
                    }
                });
            },
        });
    }
}
