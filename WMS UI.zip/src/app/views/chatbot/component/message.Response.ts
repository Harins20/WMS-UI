import { Component, inject, input, signal } from '@angular/core';
import { InputTextModule } from 'primeng/inputtext';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { AsnDetails } from '../chatbot.columns';
import { AvatarModule } from 'primeng/avatar';
import { ExcelDownloadService } from '../../../common/services';
import { ChatBotService } from '../chatbot.service';
import { ChatMenu } from './message.menu';

@Component({
    selector: 'app-message-response',
    standalone: true,
    imports: [
        InputTextModule,
        FormsModule,
        ReactiveFormsModule,
        ButtonModule,
        CardModule,
        AvatarModule,
    ],
    template: `
        @for (entry of ResData(); track entry) {
            <div class="grid grid-cols-1  m-2 pr-8 py-0">
                <p-avatar
                    label="V"
                    styleClass="mr-1"
                    size="normal"
                    shape="circle"
                />

                @if (entry.image) {
                    <div class="grid grid-cols-1  m-2 ml-7 pr-8 py-0">
                        <img
                            [src]="entry.image"
                            class="w-[200px] h-[200px] object-cover border-2 rounded-lg"
                        />
                    </div>
                }

                @for (Data0 of entry?.Response; track Data0) {
                    <div class="flex flex-col gap-2 ml-7">
                        <div
                            class="bg-slate-100 p-4 m-2 rounded-lg shadow w-full"
                        >
                            @for (key of Object.keys(Data0); track key) {
                                <div
                                    class="text-sm text-gray-800 grid mb-1 gap-2"
                                    style="grid-template-columns: 42% 2% 42%"
                                >
                                    <div class="font-semibold">
                                        {{
                                            userFields[key]
                                                ? userFields[key].label
                                                : key
                                        }}
                                    </div>
                                    <div>:</div>
                                    <div>{{ Data0[key] ?? '—' }}</div>
                                </div>
                            }
                        </div>
                    </div>
                }
            </div>
        }

        <div class="grid grid-cols m-2 pr-8 py-0">
            <div class="flex flex-col-2 gap-2 ml-9">
                @if (setActive()) {
                    <p-button
                        icon="fa-solid fa-bars"
                        (click)="addMenu()"
                        tooltipPosition="bottom"
                        label="Menu"
                    />
                }
                <p-button
                    icon="fa-solid fa-file-excel"
                    (click)="exportExcel()"
                    tooltipPosition="bottom"
                    [label]="getExportLabel()"
                />
            </div>
        </div>
    `,
})
export class MessageResponse {
    Response = input<any>();
    Content = input<any>();
    public userFields = AsnDetails;
    ResData = signal<any[]>([]);
    setActive = signal<boolean>(true);

    private excelDownloadService = inject(ExcelDownloadService);
    messageService = inject(ChatBotService);

    Object = Object;

    ngOnInit() {
        if (this.Response() && this.Content()) {
        }
    }

    ngOnChanges() {
        this.ResData.set([...this.ResData(), this.Content()]);
    }

    toEntries(obj: any): [string, any][] {
        return Object.entries(obj);
    }

    addMenu() {
        this.messageService.storelog({
            name: 'bot',
            Type: 'menu',
            Items: ChatMenu,
        });
        this.setActive.set(!this.setActive());
    }

    getExportLabel(): string {
        const title = this.Content()?.Title;
        const value = this.Content()?.value;

        const systemKeywords = [
            'InbStatusEnquiry',
            'LocStatusEnquiry',
            'InvStatusEnquiry',
            'OutStatusEnquiry',
        ];

        return systemKeywords.includes(value) ? title : `${title}_${value}`;
    }

    exportExcel() {
        this.excelDownloadService.downloadExcelFile(
            this.getExportLabel(),
            [],
            this.Response(),
        );
    }
}
