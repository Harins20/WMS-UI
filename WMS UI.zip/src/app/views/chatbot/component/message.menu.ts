import { MenuItem } from 'primeng/api';

export const ChatMenu: MenuItem = [
    {
        label: 'Inbound',
    },
    {
        label: 'Inventory',
    },
    {
        label: 'Outbound',
    },
    {
        label: 'Masters',
    },
];

export const InboundMenu: MenuItem = [
    {
        label: 'ASN Enquiry',
        title: 'ASNEnquiry',
    },
    {
        label: 'ASN Status Counts',
        title: 'InbStatusEnquiry',
    },
];
export const OutboundMenu: MenuItem = [
    {
        label: 'Order Enquiry',
        title: 'OrderEnquiry',
    },
    {
        label: 'Orders Status Counts',
        title: 'OutStatusEnquiry',
    },
];
export const InventoryMenu: MenuItem = [
    {
        label: 'Available Quantity',
        title: 'InventoryEnquiry',
    },
    {
        label: 'Pallet Enquiry',
        title: 'PalletEnquiry',
    },
    {
        label: 'Inventory Status Counts',
        title: 'InvStatusEnquiry',
    },
];
export const MastersMenu: MenuItem = [
    {
        label: 'Item Enquiry',
        title: 'ItemEnquiry',
    },
    {
        label: 'Location Enquiry',
        title: 'LocationEnquiry',
    },
    {
        label: 'Location Status Counts',
        title: 'LocStatusEnquiry',
    },
];
