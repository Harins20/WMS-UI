import { Component, effect, inject, input } from '@angular/core';
import { InputTextModule } from 'primeng/inputtext';
import {
    FormControl,
    FormGroup,
    FormsModule,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { ChatBotService } from '../chatbot.service';
import { message } from '../chatbot.model';
import { AvatarModule } from 'primeng/avatar';
import { VoiceRecognitionService } from '../../../common/functions/voice-recognition.service';

@Component({
    selector: 'app-message-input',
    standalone: true,
    imports: [
        InputTextModule,
        FormsModule,
        ReactiveFormsModule,
        ButtonModule,
        AvatarModule,
    ],
    template: ` <div class="p-4">
        <form
            [formGroup]="form"
            (ngSubmit)="submit()"
            class="flex flex-row gap-2 items-center"
        >
            <div class="w-9/12">
                <input
                    pInputText
                    id="name"
                    formControlName="name"
                    autocomplete="off"
                    [placeholder]="placeholderText"
                    class="w-full"
                />
            </div>
            <div class="w-3/12">
                <p-button type="submit" label="Submit" class="w-full" />
            </div>
        </form>

        <!-- <div>
            <p-button (click)="startVoiceInput()">Start Voice Input</p-button>
            <p-button (click)="stopVoiceInput()">Stop Voice Input</p-button>
            <p>Transcript: {{ this.voiceService.transcript() }}</p>
        </div> -->
    </div>`,
})
export class MessageInput {
    currentTranscript: string = '';

    Item = input<any | undefined>();
    private messageService = inject(ChatBotService);
    public voiceService = inject(VoiceRecognitionService);
    form!: FormGroup;

    ngOnInit(): void {
        this.form = new FormGroup(this.formControls());
    }
    test = effect(() => {
        const transcript = this.voiceService.transcript(); // <-- use () to access signal
        if (transcript) {
            this.form.patchValue({ name: transcript });
        }
        if (this.form.value.name && this.form.value.name.trim() !== '') {
            this.submit();
            this.messageService.SetOption.set(false);
        }
    });

    formControls() {
        return {
            name: new FormControl('', Validators.required),
        };
    }
    startVoiceInput(): void {
        this.voiceService.startListening();
    }

    stopVoiceInput(): void {
        this.voiceService.stopListening();
    }

    ngOnDestroy(): void {
        this.voiceService.stopListening(); // Stop listening when component is destroyed
    }

    get placeholderText(): string | undefined {
        const title = this.Item()?.title;
        const label = this.Item()?.label;

        switch (title) {
            case 'ASNEnquiry':
                return 'Please enter the ASN Number';

            case 'InventoryEnquiry':
                if (label === 'Available Quantity') {
                    return 'Please enter the Item Code for Available Quantity';
                }
                return 'Please enter the Inventory Number';

            case 'PalletEnquiry':
                return 'Please enter the Pallet Number';

            case 'ItemEnquiry':
                return 'Please enter the Item Code';

            case 'OrderEnquiry':
                return 'Please enter the Order Number';

            case 'LocationEnquiry':
                if (label === 'Item Quantity') {
                    return 'Please enter the Item Quantity';
                }
                return 'Please enter the Location';

            case 'InbStatusEnquiry':
            case 'OutStatusEnquiry':
            case 'InvStatusEnquiry':
            case 'LocStatusEnquiry':
                return `Please enter the ${label}`;

            default:
                return undefined;
        }
    }

    submit() {
        this.messageService.SetOption.set(false);

        const logEntry: message = {
            name: 'user',
            Type: 'Request',
            value: this.form.value.name,
        };
        this.messageService.storelog(logEntry);
        if (this.Item().title == 'InbStatusEnquiry') {
            const subscription = this.messageService.getInbAnalyticsEnquiry(
                '',
                this.form.value.name,
                this.Item().label,
            );
        } else if (this.Item().title == 'OutStatusEnquiry') {
            const subscription = this.messageService.getOutAnalyticsEnquiry(
                '',
                this.form.value.name,
                this.Item().label,
            );
        } else if (this.Item().title == 'InvStatusEnquiry') {
            const subscription = this.messageService.getInvAnalyticsEnquiry(
                '',
                this.form.value.name,
                this.Item().label,
            );
        } else if (this.Item().title == 'LocStatusEnquiry') {
            const subscription = this.messageService.getLocAnalyticsEnquiry(
                '',
                this.form.value.name,
                this.Item().label,
            );
        } else if (this.Item().title == 'ASNEnquiry') {
            const subscription = this.messageService.getAsnEnquiry(
                this.form.value.name,
                this.Item().label,
            );
        } else if (this.Item().title == 'InventoryEnquiry') {
            const subscription = this.messageService.getInventoryEnquiry(
                this.form.value.name,
                this.Item().label,
            );
        } else if (this.Item().title == 'ItemEnquiry') {
            const subscription = this.messageService.getItemEnquiry(
                this.form.value.name,
                this.Item().label,
            );
        } else if (this.Item().title == 'LocationEnquiry') {
            const subscription = this.messageService.getLocationHeaderEnquiry(
                this.form.value.name,
                this.Item().label,
            );
        } else if (this.Item().title == 'OrderEnquiry') {
            const subscription = this.messageService.getOrderEnquiry(
                this.form.value.name,
                this.Item().label,
            );
        } else if (this.Item().title == 'PalletEnquiry') {
            const subscription = this.messageService.getPalletHeaderEnquiry(
                this.form.value.name,
                this.Item().label,
            );
        }

        this.form.reset();
        this.voiceService.transcript.set('');
    }
}
