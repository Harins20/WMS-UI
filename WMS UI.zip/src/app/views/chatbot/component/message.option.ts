import { Component, inject, input, Input } from '@angular/core';
import { InputTextModule } from 'primeng/inputtext';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { message } from '../chatbot.model';
import { ChatBotService } from '../chatbot.service';
import { AvatarModule } from 'primeng/avatar';
import {
    InboundMenu,
    InventoryMenu,
    MastersMenu,
    OutboundMenu,
} from './message.menu';

@Component({
    selector: 'app-message-option',
    standalone: true,
    imports: [
        InputTextModule,
        FormsModule,
        ReactiveFormsModule,
        ButtonModule,
        AvatarModule,
    ],
    template: `
        <div class="flex items-end ml-2 p-1 pb-5">
            <p-avatar
                label="V"
                styleClass="mr-1"
                size="normal"
                shape="circle"
            ></p-avatar>
            <div class="">
                <div class="flex flex-wrap min-w-[200px] max-w-[260px]  gap-2">
                    @for (item of currentMenu(); track item.label) {
                        <p-button
                            [label]="item.label"
                            severity="secondary"
                            (onClick)="addLog(item)"
                        />
                    }
                </div>
            </div>
        </div>
    `,
})
export class MessageOption {
    currentMenu = input<any>();
    messageService = inject(ChatBotService);

    ngOnInit() {}
    ngOnChanges() {}
    addLog(value: any) {
        if (value.label === 'Inbound') {
            const newMessage: message = {
                name: 'user',
                Type: 'menu',
                Items: InboundMenu,
            };
            this.messageService.storelog(newMessage);
            this.messageService.SetOption.set(false);
        } else if (value.label === 'Outbound') {
            const newMessage: message = {
                name: 'user',
                Type: 'menu',
                Items: OutboundMenu,
            };
            this.messageService.storelog(newMessage);
            this.messageService.SetOption.set(false);
        } else if (value.label === 'Inventory') {
            const newMessage: message = {
                name: 'user',
                Type: 'menu',
                Items: InventoryMenu,
            };
            this.messageService.storelog(newMessage);
            this.messageService.SetOption.set(false);
        } else if (value.label === 'Masters') {
            const newMessage: message = {
                name: 'user',
                Type: 'menu',
                Items: MastersMenu,
            };
            this.messageService.storelog(newMessage);
            this.messageService.SetOption.set(false);
        } else if (value.title === 'ASNEnquiry') {
            this.messageService.SetOption.set(true);
            this.messageService.option.set(value);
        } else if (value.title === 'OrderEnquiry') {
            this.messageService.SetOption.set(true);
            this.messageService.option.set(value);
        } else if (value.title === 'InventoryEnquiry') {
            this.messageService.SetOption.set(true);
            this.messageService.option.set(value);
        } else if (value.title === 'PalletEnquiry') {
            this.messageService.SetOption.set(true);
            this.messageService.option.set(value);
        } else if (value.title === 'ItemEnquiry') {
            this.messageService.SetOption.set(true);
            this.messageService.option.set(value);
        } else if (value.title === 'LocationEnquiry') {
            this.messageService.SetOption.set(true);
            this.messageService.option.set(value);
        } else if (value.title === 'LocationHeaderEnquiry') {
            this.messageService.SetOption.set(true);
            this.messageService.option.set(value);
        } else if (value.title === 'InbStatusEnquiry') {
            let common = 'dashboard';
            const logEntry: message = {
                name: 'user',
                Type: 'Request',
                value: value.label,
            };
            this.messageService.storelog(logEntry);
            const subscription = this.messageService.getInbAnalyticsEnquiry(
                value.title,
                value.label,
                common,
            );
        } else if (value.title === 'OutStatusEnquiry') {
            let common = 'dashboard';
            const logEntry: message = {
                name: 'user',
                Type: 'Request',
                value: value.label,
            };
            this.messageService.storelog(logEntry);
            const subscription = this.messageService.getOutAnalyticsEnquiry(
                value.title,
                value.label,
                common,
            );
        } else if (value.title === 'InvStatusEnquiry') {
            let common = 'dashboard';
            const logEntry: message = {
                name: 'user',
                Type: 'Request',
                value: value.label,
            };
            this.messageService.storelog(logEntry);
            const subscription = this.messageService.getInvAnalyticsEnquiry(
                value.title,
                value.label,
                common,
            );
        } else if (value.title === 'LocStatusEnquiry') {
            let common = 'location';
            const logEntry: message = {
                name: 'user',
                Type: 'Request',
                value: value.label,
            };
            this.messageService.storelog(logEntry);
            const subscription = this.messageService.getLocAnalyticsEnquiry(
                value.title,
                value.label,
                common,
            );
        }
    }
}
