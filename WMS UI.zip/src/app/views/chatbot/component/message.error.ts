import { Component, inject, input, Input } from '@angular/core';
import { InputTextModule } from 'primeng/inputtext';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { message } from '../chatbot.model';
import { ChatBotService } from '../chatbot.service';
import { AvatarModule } from 'primeng/avatar';
import {
    InboundMenu,
    InventoryMenu,
    MastersMenu,
    OutboundMenu,
} from './message.menu';

@Component({
    selector: 'app-message-error',
    standalone: true,
    imports: [
        InputTextModule,
        FormsModule,
        ReactiveFormsModule,
        ButtonModule,
        AvatarModule,
    ],
    template: `
        <div class="flex items-end ml-2 p-1">
            <p-avatar
                label="V"
                styleClass="mr-1"
                size="normal"
                shape="circle"
            ></p-avatar>
            <div class="">
                <div class="flex flex-wrap min-w-[200px] max-w-[260px]  gap-2">
                    {{ ErrorMessage() }}
                </div>
            </div>
        </div>
    `,
})
export class ErrorMessage {
    ErrorMessage = input<any>();

    ngOnInit() {}
    ngOnChanges() {}
}
