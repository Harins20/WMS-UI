import { CommonModule } from '@angular/common';
import {
    Component,
    ElementRef,
    inject,
    input,
    Input,
    signal,
    ViewChild,
} from '@angular/core';
import { MenuItem } from 'primeng/api';
import { AvatarModule } from 'primeng/avatar';
import { ButtonModule } from 'primeng/button';
import { ChatBotService } from '../chatbot.service';
import { MessageResponse } from '../component/message.Response';
import { MessageOption } from '../component/message.option';
import { LoadingChat } from '../component/loading.chat';
import { ErrorMessage } from '../component/message.error';

@Component({
    selector: 'app-message',
    imports: [
        ButtonModule,
        CommonModule,
        AvatarModule,
        MessageResponse,
        MessageOption,
        LoadingChat,
        ErrorMessage,
    ],
    templateUrl: './message.component.html',
    styleUrl: './message.component.scss',
})
export class MessageComponent {
    @Input() items: MenuItem[] | undefined;
    @ViewChild('scrollContainer') private scrollContainer!: ElementRef;

    Message = input<any | undefined>(
        "Hello👋 Welcome to Vyapi Bot. I'm your Enquiry assistant. How may I assist you today?",
    );
    menuItems = signal<MenuItem[] | undefined>(undefined);
    messageService = inject(ChatBotService);

    ngAfterViewChecked() {
        if (this.messageService.messageLog()) {
            this.scrollToBottom();
        }
    }

    private scrollToBottom(): void {
        const element = this.scrollContainer?.nativeElement;
        element.scrollTop = element.scrollHeight;
    }
}
