import { ChatMenu } from './component/message.menu';
import { Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenuItem } from 'primeng/api';
import { finalize } from 'rxjs';
import { OptionMenu } from '../../layout/service/action.service';
import { MenuService } from '../../layout/service/menu.service';
import { AuthService } from '../../common/services';
import { TranslateService } from '@ngx-translate/core';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { ButtonModule } from 'primeng/button';
import { AvatarModule } from 'primeng/avatar';
import { ChipModule } from 'primeng/chip';
import { CardModule } from 'primeng/card';
import { MenuModule } from 'primeng/menu';
import { PanelMenuModule } from 'primeng/panelmenu';
import { MessageComponent } from './message/message.component';
import { ChatBotService } from './chatbot.service';
import { MessageInput } from './component/message.input';
import { TooltipModule } from 'primeng/tooltip';
import { AiMessageComponent } from '../aiChat/message/aiMessage.component';
import { AiMessageInput } from '../aiChat/component/message.input';
import { AiChatService } from '../aiChat/aiChat.service';

@Component({
    selector: 'app-chatbot',
    imports: [
        OverlayPanelModule,
        ButtonModule,
        AvatarModule,
        ChipModule,
        CardModule,
        MenuModule,
        PanelMenuModule,
        MessageComponent,
        MessageInput,
        TooltipModule,
        CommonModule,
        AiMessageComponent,
        AiMessageInput,
    ],
    templateUrl: './chatbot.component.html',
    styleUrl: './chatbot.component.scss',
})
export class ChatbotComponent {
    private translate = inject(TranslateService);
    language = sessionStorage.getItem('language');
    private authService = inject(AuthService);
    private menuService = inject(MenuService);
    Menus = signal<OptionMenu[]>([]);
    messageService = inject(ChatBotService);
    AimessageService = inject(AiChatService);
    activeTab = 0;
    isCommentsOpen = signal(false);

    ngOnInit() {
        this.getMenus();
    }

    getMenus() {
        this.menuService
            .getMenus()
            .pipe(finalize(() => {}))
            .subscribe({
                next: (data) => {
                    if (!data || data.length === 0) {
                        this.authService.Logout();
                        return;
                    } else {
                        this.Menus.set(data);
                    }
                },
                error: (error) => {
                    console.error('Error fetching menus', error);
                },
            });
    }

    treeMenus = computed(() => {
        const mapped: { [key: number]: MenuItem } = {};
        const traderId = this.Menus().find(
            (menu) => menu.Name == 'Traders',
        )?.Id;

        this.Menus().forEach((item) => {
            if (item.IsClickable && item.ParentId === traderId)
                mapped[item.Id] = {
                    id: item.Id.toString(),
                    label: this.translate.instant(item.Name),
                    icon: item.IconClass,
                };
            else if (item.IsClickable)
                mapped[item.Id] = {
                    id: item.Id.toString(),
                    label: this.translate.instant(item.Name),
                    icon: item.IconClass,
                };
            else
                mapped[item.Id] = {
                    id: item.Id.toString(),
                    label: this.translate.instant(item.Name),
                    icon: item.IconClass,
                    items: [],
                };
        });

        const tree: MenuItem[] = [];
        const treeBase = { items: [] as MenuItem[] };

        this.Menus().forEach((item) => {
            if (item.ParentId === 0) {
                treeBase.items.push(mapped[item.Id]);
            } else {
                mapped[item.ParentId]?.items?.push(mapped[item.Id]);
            }
        });

        tree.push(treeBase);
        return tree;
    });

    toggleIcon() {
        this.isCommentsOpen.set(!this.isCommentsOpen());
    }

    SetMenu() {
        const logEntry = {
            name: 'bot',
            Type: 'menu',
            Items: ChatMenu,
        };
        this.messageService.storelog(logEntry);
        this.messageService.SetOption.set(false);
    }

    /** Clears only the Request tab messages */

    ClearRequest() {
        this.messageService.ClearMessage();
        this.messageService.SetOption.set(false);
    }

    ClearAiChat() {
        this.messageService.aiMessageLog.set([]);
    }

    ClearMenu() {
        this.messageService.ClearMessage();
        this.messageService.SetOption.set(false);
    }
}
