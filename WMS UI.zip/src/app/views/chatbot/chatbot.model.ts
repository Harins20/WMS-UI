import { MenuItem } from 'primeng/api';

export interface message {
    name: String;
    Message?: string;
    Items?: MenuItem | undefined;
    Title?: string;
    value?: string;
    Type?: string;
    image?: any;
    Response?: any[];
}
