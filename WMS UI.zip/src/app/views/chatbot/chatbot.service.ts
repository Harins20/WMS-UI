import { ChatMenu } from './component/message.menu';
import { inject, Injectable, signal } from '@angular/core';
import { message } from './chatbot.model';
import { AppConfigService } from '../../../app.config.service';
import { HttpClient } from '@angular/common/http';
import { MenuItem } from 'primeng/api';
import { AuthService } from '../../common/services';

@Injectable({
    providedIn: 'root',
})
export class ChatBotService {
    addMessage(arg0: { Type: string; value: string }) {
        throw new Error('Method not implemented.');
    }
    audioFile = new Audio(
        'https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/success.mp3',
    );
    SetOption = signal(false);
    Loading = signal(false);
    messageLog = signal<any[]>([
        {
            name: 'bot',
            Type: 'menu',
            Items: ChatMenu,
        },
    ]);
    aiMessageLog = signal<any[]>([]);

    storeAiLog(newMessage: any) {
        const current = this.aiMessageLog();
        this.aiMessageLog.set([...current, newMessage]);
    }

    private config = inject(AppConfigService);
    private authService = inject(AuthService);
    private httpClient = inject(HttpClient);
    option = signal<MenuItem[] | undefined>(undefined);

    storelog(newMessage: message) {
        const currentMessage = this.messageLog();
        this.messageLog.set([...currentMessage, newMessage]);
    }
    ClearMessage() {
        this.messageLog.set([
            {
                name: 'bot',
                Type: 'menu',
                Items: ChatMenu,
            },
        ]);
    }

    getInbAnalyticsEnquiry(Id: any, label: string, common: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(this.config.appConfig()?.InbUrl + `dashboard`, {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe()
            .subscribe({
                next: (response: any) => {
                    this.getInbAnalytics(Id, label, response);
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `Error fetching the Analytics data. Please try again with a valid input.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
    getInbAnalytics(Id: any, label: string, response: any) {
        const rawData = response?.Response || [];

        if (!Array.isArray(rawData)) {
            this.storelog({
                name: 'bot',
                Type: 'Error',
                Message:
                    'Unexpected data format received. Unable to process analytics.',
            });
            this.Loading.set(false);
            return;
        }

        if (Id === 'InbStatusEnquiry') {
            const renamed = rawData
                .filter((item: any) => item.count > 0)
                .map((item: any) => ({
                    'ASN Status': item.description,
                    'Total Orders': item.count,
                }));

            this.storelog({
                name: 'bot',
                Type: 'Response',
                Response: renamed,
                value: Id,
                Title: label,
            });

            this.Loading.set(false);
        }
    }
    getOutAnalyticsEnquiry(Id: any, label: string, common: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(this.config.appConfig()?.OutUrl + `dashboard`, {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe()
            .subscribe({
                next: (response: any) => {
                    this.getOutAnalytics(Id, label, response);
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `Error fetching the Analytics data. Please try again with a valid input.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
    getOutAnalytics(Id: any, label: string, response: any) {
        const rawData = response?.Response || [];

        if (!Array.isArray(rawData)) {
            this.storelog({
                name: 'bot',
                Type: 'Error',
                Message:
                    'Unexpected data format received. Unable to process analytics.',
            });
            this.Loading.set(false);
            return;
        }

        if (Id === 'OutStatusEnquiry') {
            const renamed = rawData
                .filter((item: any) => item.count > 0)
                .map((item: any) => ({
                    'Order Status': item.description,
                    'Total Orders': item.count,
                }));

            this.storelog({
                name: 'bot',
                Type: 'Response',
                Response: renamed,
                value: Id,
                Title: label,
            });

            this.Loading.set(false);
        }
    }
    getInvAnalyticsEnquiry(Id: any, label: string, common: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(this.config.appConfig()?.InvUrl + `dashboard`, {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe()
            .subscribe({
                next: (response: any) => {
                    this.getInvAnalytics(Id, label, response);
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `Error fetching the Analytics data. Please try again with a valid input.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
    getInvAnalytics(Id: any, label: string, response: any) {
        const rawData = response?.Response || [];

        if (!Array.isArray(rawData)) {
            this.storelog({
                name: 'bot',
                Type: 'Error',
                Message:
                    'Unexpected data format received. Unable to process analytics.',
            });
            this.Loading.set(false);
            return;
        }

        if (Id === 'InvStatusEnquiry') {
            const renamed = rawData
                .filter((item: any) => item.count > 0)
                .map((item: any) => ({
                    'Inventory Status': item.DESCRIPTION,
                    'Total Inventories': item.count,
                }));

            this.storelog({
                name: 'bot',
                Type: 'Response',
                Response: renamed,
                value: Id,
                Title: label,
            });

            this.Loading.set(false);
        }
    }
    getLocAnalyticsEnquiry(Id: any, label: string, common: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(this.config.appConfig()?.MasterUrl + `locations/count`, {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe()
            .subscribe({
                next: (response: any) => {
                    this.getLocAnalytics(Id, label, response);
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `Error fetching the Analytics data. Please try again with a valid input.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
    getLocAnalytics(Id: any, label: string, response: any) {
        if (Id === 'LocStatusEnquiry') {
            const rawData = response;

            const titleMap: Record<string, string> = {
                AvailableLocations: 'Available',
                UsedLocations: 'Occupied',
                UnusedLocations: 'Empty',
            };

            const renamed = Object.entries(rawData)
                .filter(([_, count]) => typeof count === 'number' && count > 0)
                .map(([status, count]) => ({
                    'Location Status': titleMap[status] || status,
                    'Total Locations': count,
                }));

            this.storelog({
                name: 'bot',
                Type: 'Response',
                Response: renamed,
                value: Id,
                Title: label,
            });

            this.Loading.set(false);
        }
    }

    getAsnEnquiry(Id: any, label: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(
                this.config.appConfig()?.EnquiryUrl +
                    `ASNEnquiry?receiptKey=${Id}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe()
            .subscribe({
                next: (response: any) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Response',
                        Response: response,
                        value: Id,
                        Title: label,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `${Id} Error fetching ASN enquiry data. Please try again valid receipt key.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
    getOrderEnquiry(Id: any, label: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(
                this.config.appConfig()?.EnquiryUrl +
                    `OrderEnquiry?orderKey=${Id}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe()
            .subscribe({
                next: (response: any) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Response',
                        Response: response,
                        value: Id,
                        Title: label,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `${Id} Error fetching Order Details data. Please try again valid key.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
    getInventoryEnquiry(Id: any, label: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(
                this.config.appConfig()?.EnquiryUrl +
                    `InventoryEnquiry?searchValue=${Id}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe()
            .subscribe({
                next: (response: any) => {
                    const renamedResponse = response.map((item: any) => ({
                        Location: item.location,
                        'Available Quantity': item.availableQty,
                        UOM: item.uom,
                        Status: item.status,
                    }));

                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Response',
                        Response: renamedResponse,
                        value: Id,
                        Title: label,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `${Id} Error fetching Available Quantity data. Please try again with a valid key.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }

    getPalletHeaderEnquiry(Id: any, label: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(
                this.config.appConfig()?.EnquiryUrl +
                    `PalletHeaderEnquiry?palletId=${Id}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe()
            .subscribe({
                next: (response: any) => {
                    this.getPalletEnquiry(Id, response, label);
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `${Id} Error fetching Inventory ASN data. Please try again valid key.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
    getPalletEnquiry(Id: any, ResponseData: any, label: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(
                this.config.appConfig()?.EnquiryUrl +
                    `PalletEnquiry?pallet=${Id}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe()
            .subscribe({
                next: (response: any) => {
                    if (response && ResponseData) {
                        const MergedResponse = {
                            ...ResponseData[0],
                            ...response[0],
                        };
                        const logEntry2: message = {
                            name: 'bot',
                            Type: 'Response',
                            Response: [MergedResponse],
                            value: Id,
                            Title: label,
                        };
                        this.storelog(logEntry2);
                        this.Loading.set(false);
                    }
                },
                error: (error) => {
                    // const logEntry2: message = {
                    //     name: 'bot',
                    //     Type: 'Error',
                    //     Message: `${Id} Error fetching Inventory Details data. Please try again valid key.`,
                    // };
                    // this.storelog(logEntry2);
                    // this.Loading.set(false);
                },
            });
    }
    getItemEnquiry(Id: any, label: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(
                this.config.appConfig()?.EnquiryUrl + `ItemEnquiry?sku=${Id}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe()
            .subscribe({
                next: (response: any) => {
                    if (response) {
                        this.getItemImageEnquiry(Id, response, label);
                    }
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `${Id} Error fetching Item Enquiry data. Please try again valid key.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
    getItemImageEnquiry(Id: any, ResponseData: any, label: string) {
        return this.httpClient
            .get(this.config.appConfig()?.EnquiryUrl + `Image?sku=${Id}`, {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe()
            .subscribe({
                next: (response: any) => {
                    if (response.fileData !== null) {
                        const logEntry2: message = {
                            name: 'bot',
                            Type: 'Response',
                            Response: [ResponseData],
                            image: response.fileData,
                            value: Id,
                            Title: label,
                        };
                        this.storelog(logEntry2);
                        this.Loading.set(false);
                        // this.playFile();
                    }
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Response',
                        Response: [ResponseData],
                        value: Id,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
    playFile() {
        this.audioFile.play();
    }

    getLocationHeaderEnquiry(Id: any, label: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(
                this.config.appConfig()?.EnquiryUrl +
                    `LocationHeaderEnquiry?location=${Id}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe()
            .subscribe({
                next: (response: any) => {
                    if (response.length > 0) {
                        this.getLocationEnquiry(Id, response, label);
                    } else {
                        const logEntry2: message = {
                            name: 'bot',
                            Type: 'Error',
                            Message: `${Id} No Location Details data found. Please try again valid key.`,
                        };
                        this.storelog(logEntry2);
                        this.Loading.set(false);
                    }
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `${Id} Error fetching Location Details data. Please try again valid key.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
    getLocationEnquiry(Id: any, ResponseData: any, label: string) {
        this.Loading.set(true);
        return this.httpClient
            .get(
                this.config.appConfig()?.EnquiryUrl +
                    `LocationEnquiry?location=${Id}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe()
            .subscribe({
                next: (response: any) => {
                    if (response.length > 0 && ResponseData) {
                        const MergedResponse = {
                            ...ResponseData[0],
                            ...response[0],
                        };
                        const logEntry2: message = {
                            name: 'bot',
                            Type: 'Response',
                            Response: [MergedResponse],
                            value: Id,
                            Title: label,
                        };
                        this.storelog(logEntry2);
                        this.Loading.set(false);
                    } else {
                        const logEntry2: message = {
                            name: 'bot',
                            Type: 'Error',
                            Message: `${Id} No Location Inventory data found. Please try again valid key.`,
                        };
                        this.storelog(logEntry2);
                        this.Loading.set(false);
                    }
                },
                error: (error) => {
                    const logEntry2: message = {
                        name: 'bot',
                        Type: 'Error',
                        Message: `${Id} Error fetching Location Inventory data. Please try again valid key.`,
                    };
                    this.storelog(logEntry2);
                    this.Loading.set(false);
                },
            });
    }
}
