import { Validators } from '@angular/forms';
import { Columns } from '../../common/models';

export const AsnDetails: Columns = {
    rowId: {
        label: 'S/No',
        field: 'rowId',
        type: 'number',
        defaultValue: '',
    },
    receiptkey: {
        label: 'Receipt Key',
        field: 'receiptkey',
        restrictInsert: true,
        restrictEdit: true,
        defaultValue: '',
        validators: [Validators.maxLength(50)],
    },
    shipFrom: {
        label: 'Supplier Name',
        field: 'shipFrom',
        validators: [Validators.maxLength(45)],
        restrictInsert: true,
        restrictEdit: true,
        defaultValue: '',
    },
    carrier: {
        label: 'Carrier Name',
        field: 'carrier',
        validators: [Validators.maxLength(45)],
        restrictInsert: true,
        restrictEdit: true,
        defaultValue: '',
    },
    receiptDate: {
        label: 'Receipt Date',
        field: 'receiptDate',
        type: 'date',
        defaultValue: null,
        restrictEdit: true,
    },
    asnDate: {
        label: 'Receipt Date',
        field: 'asnDate',
        type: 'date',
        defaultValue: null,
        restrictEdit: true,
    },
    expectedQuantity: {
        label: 'Expected Quantity',
        field: 'expectedQuantity',
        validators: [Validators.required, Validators.min(1)],
        defaultValue: 0,
    },
    receivedQuantity: {
        label: 'Received Quantity',
        field: 'receivedQuantity',
        validators: [Validators.maxLength(22)],
        defaultValue: 0,
        restrictInsert: true,
        restrictEdit: true,
    },
    status: {
        label: 'Status',
        field: 'status',
        defaultValue: 'New',
        restrictInsert: true,
        restrictEdit: true,
    },
    statusCode: {
        label: 'Status',
        field: 'statusCode',
        validators: [Validators.maxLength(10)],
        tableHidden: true,
        defaultValue: '0',
        restrictInsert: true,
        restrictEdit: true,
    },
};
