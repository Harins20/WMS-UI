import { CommonModule } from '@angular/common';
import {
    Component,
    ElementRef,
    effect,
    inject,
    input,
    Input,
    Output,
    EventEmitter,
    signal,
    ViewChild,
} from '@angular/core';
import { MenuItem } from 'primeng/api';
import { AvatarModule } from 'primeng/avatar';
import { ButtonModule } from 'primeng/button';
import { AiChatService } from '../aiChat.service';
import { AiErrorMessage } from '../component/message.error';
import { aiChatMessageResponse } from '../component/message.Response';
import { AiLoadingChat } from '../component/loading.chat';
import { HttpClient } from '@angular/common/http';
import { AppConfigService } from '../../../../app.config.service';
import { AuthService } from '../../../common/services';

@Component({
    selector: 'app-aimessage',
    imports: [
        ButtonModule,
        CommonModule,
        AvatarModule,
        AiErrorMessage,
        aiChatMessageResponse,
        AiLoadingChat,
    ],
    templateUrl: './aiMessage.component.html',
    styleUrl: './aiMessage.component.scss',
})
export class AiMessageComponent {
    @Input() items: MenuItem[] | undefined;
    @Output() suggestionSelected = new EventEmitter<string>();
    @ViewChild('scrollContainer') private scrollContainer!: ElementRef;

    Message = input<any | undefined>(
        "Hello👋 I'm Vyapi, your assistant. How may I assist you today?",
    );
    menuItems = signal<MenuItem[] | undefined>(undefined);
    messageService = inject(AiChatService);
    private http = inject(HttpClient);
    private configService = inject(AppConfigService);
    authService = inject(AuthService);
    showScrollDown = signal<boolean>(false);
    private isUserScrolledUp = false;
    private lastLogLength = 0;

    moduleOptions: {
        label: string;
        value: string;
        icon: string;
        class: string;
    }[] = [];

    TempValue = [
        {
            label: 'Hot Parts',
            value: 'hotparts',
            icon: 'fa-solid fa-fire',
            class: 'border-red-300 bg-red-50 text-red-700 hover:bg-red-100 hover:border-red-400',
        },
        {
            label: 'Daily Demand',
            value: 'daily demand',
            icon: 'fa-solid fa-calendar-day',
            class: 'border-blue-300 bg-blue-50 text-blue-700 hover:bg-blue-100 hover:border-blue-400',
        },
        {
            label: 'NCI',
            value: 'nci',
            icon: 'fa-solid fa-flask',
            class: 'border-green-300 bg-green-50 text-green-700 hover:bg-green-100 hover:border-green-400',
        },
    ];

    constructor() {
        effect(() => {
            const log = this.messageService.messageLog();
            const newLength = log.length;

            if (newLength > this.lastLogLength) {
                const newEntry = log[newLength - 1];
                this.lastLogLength = newLength;

                if (newEntry?.Type === 'Request') {
                    this.isUserScrolledUp = false;
                    this.showScrollDown.set(false);
                    setTimeout(() => this.scrollToBottom(), 50);
                } else if (
                    newEntry?.Type === 'Response' ||
                    newEntry?.Type === 'Error' ||
                    newEntry?.Type === 'ModuleSelect'
                ) {
                    if (this.isUserScrolledUp) {
                        this.showScrollDown.set(true);
                    } else {
                        this.showScrollDown.set(false);
                        setTimeout(() => this.scrollToBottom(), 50);
                    }
                }
            }
        });
    }

    onScroll() {
        const element = this.scrollContainer?.nativeElement;
        if (!element) return;
        const atBottom =
            element.scrollHeight - element.scrollTop - element.clientHeight <
            50;
        if (atBottom) {
            this.isUserScrolledUp = false;
            this.showScrollDown.set(false);
        } else {
            this.isUserScrolledUp = true;
        }
    }

    onModuleSelect(module: string) {
        this.messageService.sendWithModule(module);
    }

    scrollToBottom(): void {
        const element = this.scrollContainer?.nativeElement;
        if (element) element.scrollTop = element.scrollHeight;
    }

    scrollDownClick() {
        this.isUserScrolledUp = false;
        this.showScrollDown.set(false);
        this.scrollToBottom();
    }

    onSuggestionSelected(suggestion: string) {
        this.suggestionSelected.emit(suggestion);
    }
}
