import { Component, inject, Input, signal } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { OptionMenu } from '../../layout/service/action.service';
import { MenuService } from '../../layout/service/menu.service';
import { TranslateService } from '@ngx-translate/core';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { ButtonModule } from 'primeng/button';
import { AvatarModule } from 'primeng/avatar';
import { ChipModule } from 'primeng/chip';
import { CardModule } from 'primeng/card';
import { MenuModule } from 'primeng/menu';
import { PanelMenuModule } from 'primeng/panelmenu';
import { AiMessageInput } from './component/message.input';
import { CommonModule } from '@angular/common';
import { AiChatService } from './aiChat.service';
import { AiMessageComponent } from './message/aiMessage.component';
import { MessageInput } from '../chatbot/component/message.input';
import { AuthService } from '../../common/services';

@Component({
    selector: 'app-aichat',
    imports: [OverlayPanelModule, ButtonModule, AvatarModule, ChipModule, CardModule, MenuModule, PanelMenuModule, AiMessageComponent, AiMessageInput, CommonModule, MessageInput],
    templateUrl: './aiChat.component.html',
    styleUrl: './aiChat.component.scss'
})
export class AiChatComponent {
    language = sessionStorage.getItem('language');
    Menus = signal<OptionMenu[]>([]);
    messageService = inject(AiChatService);
    authService = inject(AuthService);
    @Input() isOpen = false;

    model: MenuItem[] = [];

    position = { bottom: '2.5rem', right: '2.5rem' };

    private isDragging = false;
    private offsetX = 0;
    private offsetY = 0;

    ngOnInit() {}
    isCommentsOpen = signal(false);

    startDrag(event: MouseEvent) {
        const element = document.getElementById('chat-button1')!;
        this.offsetX = event.clientX - element.getBoundingClientRect().left;
        this.offsetY = event.clientY - element.getBoundingClientRect().top;
        this.isDragging = true;

        document.addEventListener('mousemove', this.onDrag);
        document.addEventListener('mouseup', this.stopDrag);
    }

    onDrag = (event: MouseEvent) => {
        if (!this.isDragging) return;

        const x = event.clientX - this.offsetX;
        const y = event.clientY - this.offsetY;

        const element = document.getElementById('chat-button1')!;
        element.style.left = `${x}px`;
        element.style.top = `${y}px`;
        element.style.right = 'auto';
        element.style.bottom = 'auto';
        element.style.position = 'fixed';
    };

    stopDrag = () => {
        this.isDragging = false;
        document.removeEventListener('mousemove', this.onDrag);
        document.removeEventListener('mouseup', this.stopDrag);
    };
    toggleIcon() {
        this.isCommentsOpen.set(!this.isCommentsOpen());
    }

    ClearMenu() {
        this.messageService.ClearMessage();
        this.messageService.ClearMessage();
        this.messageService.Loading.set(false);
    }
}
