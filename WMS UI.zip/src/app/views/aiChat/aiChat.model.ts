import { MenuItem } from 'primeng/api';

export interface AiMessage {
    parentMenu?: string;
    name: String;
    Message?: string;
    Items?: MenuItem | undefined;
    Title?: string;
    value?: string;
    Type?: string;
    image?: any;
    Response?: any[];
    TotalCount?: number;
    Suggestions?: string[];
    isChartResponse?: boolean;
    originalPrompt?: string;
    moduleSelectDone?: boolean;
    Summary?: string;
    Insight?: string[];
}
