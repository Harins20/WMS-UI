import { inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AiMessage } from './aiChat.model';
import { AppConfigService } from '../../../app.config.service';
import { AuthService } from '../../common/services';

@Injectable({
    providedIn: 'root',
})
export class AiChatService {
    Loading = signal(false);
    messageLog = signal<any[]>([]);
    private config = inject(AppConfigService);
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    suggestedPrompt = signal<string>('');
    pendingPrompt = signal<string | null>(null);

    storelog(newMessage: AiMessage) {
        const currentMessage = this.messageLog();
        this.messageLog.set([...currentMessage, newMessage]);
    }

    ClearMessage() {
        this.messageLog.set([]);
        this.Loading.set(false);
    }

    isPlainPrompt(message: string): boolean {
        const moduleKeywords = [
            'hotpart',
            'hot part',
            'daily demand',
            'nci',
            'assigned to',
            'inventory',
            'sku',
            'stock',
            'warehouse',
            'inbound',
            'outbound',
            'on hand',
            'available quantity',
        ];
        return !moduleKeywords.some((k) => message.toLowerCase().includes(k));
    }

    sendWithModule(module: string) {
        const prompt = this.pendingPrompt();
        if (!prompt) return;

        const updated = this.messageLog().map((entry) =>
            entry.Type === 'ModuleSelect'
                ? { ...entry, moduleSelectDone: true }
                : entry,
        );
        this.messageLog.set(updated);

        this.pendingPrompt.set(null);

        const newPrompt = `${prompt} from ${module}`;
        this.storelog({ name: 'user', Type: 'Request', value: newPrompt });

        if (module === 'nci') {
            this.parseUserMessage(newPrompt, 'nlpparse-nci');
        } else if (module === 'daily demand') {
            this.parseUserMessage(newPrompt, 'nlpparse-dd');
        } else {
            this.parseUserMessage(newPrompt, 'nlpparse');
        }
    }

    getAiHotpartEnquiry(Comment: string) {
        this.Loading.set(true);
        const UserPrompt = { UserPrompt: Comment };
        return this.httpClient
            .post(this.config.appConfig()?.AIBotUrl + 'chat/arm', UserPrompt, {
                headers: this.authService.getAuthHeaders(),
            })
            .subscribe({
                next: (response: any) => {
                    this.storelog({
                        name: 'bot',
                        Type: 'Response',
                        Response: response.response,
                    });
                    this.Loading.set(false);
                },
                error: () => {
                    this.storelog({
                        name: 'bot',
                        Type: 'Error',
                        Message:
                            'Error fetching the Request data. Please try again with a valid input.',
                    });
                    this.Loading.set(false);
                },
            });
    }

    getAiDockIQEnquiry(Comment: string) {
        this.Loading.set(true);
        const UserPrompt = { UserPrompt: Comment };
        return this.httpClient
            .post(this.config.appConfig()?.AIBotUrl + '', UserPrompt, {
                headers: this.authService.getAuthHeaders(),
            })
            .pipe()
            .subscribe({
                next: (response: any) => {
                    this.storelog({
                        name: 'bot',
                        Type: 'Response',
                        Response: response.response,
                    });
                    this.Loading.set(false);
                },
                error: () => {
                    this.storelog({
                        name: 'bot',
                        Type: 'Error',
                        Message:
                            'Error fetching the Request data. Please try again with a valid input.',
                    });
                    this.Loading.set(false);
                },
            });
    }

    parseUserMessage(message: string, endpoint?: string) {
        this.Loading.set(true);
        const payload = { text: message };
        const url = this.config.appConfig()?.AIBotUrl + (endpoint ?? 'chat');

        this.httpClient
            .post(url, payload, {
                observe: 'response',
                responseType: 'blob',
                headers: this.authService.getAuthHeaders(),
            })
            .subscribe({
                next: (httpResponse) => {
                    const contentType =
                        httpResponse.headers.get('content-type') ?? '';
                    const blob = httpResponse.body as Blob;

                    if (
                        contentType.startsWith('image/') ||
                        !contentType.includes('application/json')
                    ) {
                        const objectURL = URL.createObjectURL(blob);
                        this.storelog({
                            name: 'bot',
                            Type: 'Response',
                            image: objectURL,
                            originalPrompt: message,
                        });
                        this.Loading.set(false);
                        return;
                    }

                    blob.text().then((text) => {
                        try {
                            const res = JSON.parse(text);
                            if (Array.isArray(res.data)) {
                                this.storelog({
                                    name: 'bot',
                                    Type: 'Response',
                                    Message: `Found ${res.totalCount ?? res.data.length} result(s) for your request.`,
                                    Response: res.data,
                                    Insight: res.insight ?? null,
                                    TotalCount:
                                        res.totalCount ?? res.data.length,
                                    Suggestions: res.suggestions ?? [],
                                    Summary: res.summary ?? null,
                                });
                            } else if (res.summary) {
                                this.storelog({
                                    name: 'bot',
                                    Type: 'Response',
                                    Message: res.summary,
                                    Suggestions: res.suggestions ?? [],
                                });
                            } else {
                                this.storelog({
                                    name: 'bot',
                                    Type: 'Response',
                                    Message:
                                        'No results found for your request.',
                                    Suggestions: res.suggestions ?? [],
                                });
                            }
                        } catch {
                            this.storelog({
                                name: 'bot',
                                Type: 'Error',
                                Message:
                                    'Received an unreadable response from the server.',
                            });
                        }
                        this.Loading.set(false);
                    });
                },
                error: (err) => {
                    const isTimeout = err.status === 0;
                    this.storelog({
                        name: 'bot',
                        Type: 'Error',
                        Message: isTimeout
                            ? 'Connection timed out. The server may be unreachable. Please try again later.'
                            : 'Error fetching the Request data. Please try again with a valid input.',
                    });
                    this.Loading.set(false);
                },
            });
    }
}
