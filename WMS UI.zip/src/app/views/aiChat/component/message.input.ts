import { AiChatService } from './../aiChat.service';
import { Component, effect, inject, signal } from '@angular/core';
import { InputTextModule } from 'primeng/inputtext';
import {
    FormControl,
    FormGroup,
    FormsModule,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { AvatarModule } from 'primeng/avatar';
import { AiMessage } from '../aiChat.model';
import { TooltipModule } from 'primeng/tooltip';
import { CommonModule } from '@angular/common';
import { StyledInputWithVoiceComponent } from '../../../common/components/styled-input-with-voice/styled-input-with-voice.component';
import { VoiceRecognitionService } from '../../../common/functions/voice-recognition.service';

@Component({
    selector: 'app-ai-message-input',
    standalone: true,
    imports: [
        InputTextModule,
        FormsModule,
        ReactiveFormsModule,
        ButtonModule,
        AvatarModule,
        TooltipModule,
        CommonModule,
        StyledInputWithVoiceComponent,
    ],
    template: `
        <div class="p-2">
            <app-styled-input-with-voice
                (onSubmitMessage)="onSubmitMessage($event)"
            >
            </app-styled-input-with-voice>
        </div>
    `,
    styles: [
        `
            .animate-pulse {
                animation: pulse 1s infinite;
            }
            @keyframes pulse {
                0% {
                    opacity: 1;
                }
                50% {
                    opacity: 0.6;
                }
                100% {
                    opacity: 1;
                }
            }
        `,
    ],
})
export class AiMessageInput {
    isRecording = signal<boolean>(false);
    isSubmitting = false;
    form!: FormGroup;
    messageService = inject(AiChatService);
    public voiceService = inject(VoiceRecognitionService);

    ngOnInit(): void {
        this.form = new FormGroup({
            name: new FormControl('', Validators.required),
        });
    }

    constructor() {
        effect(() => {
            const text = this.voiceService.transcript();
            if (
                this.isRecording() === false &&
                text &&
                text.trim().length > 0
            ) {
                this.form.patchValue({ name: text });
            }
        });
    }

    onHoldMic() {
        this.isRecording.set(true);
        this.voiceService.startListening();
    }

    async onReleaseMic() {
        this.isRecording.set(false);
        this.voiceService.stopListening();

        setTimeout(async () => {
            const text = this.voiceService.transcript();
            if (text && text.trim().length > 0) {
                await this.onSubmitMessage(text);
                this.voiceService.transcript.set('');
            }
        }, 300);
    }

    async onSubmitMessage(Value: any) {
        const message: AiMessage = {
            name: 'user',
            Type: 'Request',
            value: Value,
        };

        this.messageService.storelog(message);
        await this.messageService.parseUserMessage(Value);
    }
}
