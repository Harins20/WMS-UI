import {
    Component,
    EventEmitter,
    inject,
    input,
    Output,
    signal,
} from '@angular/core';
import { InputTextModule } from 'primeng/inputtext';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { AvatarModule } from 'primeng/avatar';
import { AsnDetails } from '../aiChat.columns';
import { AiChatService } from '../aiChat.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ViewImageDialogAIBotComponent } from '../../../common/components/view-image-dialog-aibot/view-image-dialog-aibot.component';
import { ExcelDownloadService } from '../../../pages/service/excel-download.service';

@Component({
    selector: 'app-aimessage-response',
    standalone: true,
    providers: [DialogService],
    imports: [
        InputTextModule,
        FormsModule,
        ReactiveFormsModule,
        ButtonModule,
        CardModule,
        AvatarModule,
    ],
    template: `
        @for (entry of ResData(); track entry) {
            <div class="grid grid-cols-1 m-2 pr-8 py-3">
                <div class="flex justify-start items-start ">
                    <div class="flex items-center m-1">
                        <p-avatar
                            label="V"
                            styleClass="mr-1"
                            size="normal"
                            shape="circle"
                        />
                    </div>
                    <div class="items-start flex-wrap">
                        @if (entry.image) {
                            <div class=" mt-2">
                                <div
                                    class="relative cursor-pointer w-[120px] h-[120px] border-2 border-orange-400 rounded-lg overflow-hidden shadow hover:scale-105 transition-transform"
                                    (click)="openImage(entry)"
                                >
                                    <img
                                        [src]="entry.image"
                                        class="w-full h-full object-cover"
                                    />
                                    <div
                                        class="absolute inset-0 bg-black/10 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity"
                                    >
                                        <i
                                            class="fa-solid fa-magnifying-glass text-white text-xl"
                                        ></i>
                                    </div>
                                </div>
                                <small class="text-xs text-gray-600 mt-1 block"
                                    >Click to enlarge</small
                                >
                            </div>

                            @if (entry.isChartResponse) {
                                <div class=" mt-3 mb-1 flex flex-col gap-3">
                                    <!-- Breakdown options -->
                                    <div>
                                        <div
                                            class="text-xs text-gray-600 mb-2 font-medium uppercase tracking-wide"
                                        >
                                            View breakdown by
                                        </div>
                                        <div class="flex flex-wrap gap-2">
                                            @for (
                                                option of drillDownOptions;
                                                track option.label
                                            ) {
                                                <button
                                                    type="button"
                                                    class="text-xs px-3 py-1.5 rounded-full border border-orange-200 bg-orange-50 text-orange-700 hover:bg-orange-100 hover:border-orange-400 transition-all cursor-pointer font-medium"
                                                    (click)="
                                                        onDrillDown(
                                                            entry.originalPrompt,
                                                            option.value,
                                                            option.requiresInput,
                                                            entry.activeChartType
                                                        )
                                                    "
                                                >
                                                    <i
                                                        [class]="
                                                            option.icon +
                                                            ' mr-1'
                                                        "
                                                    ></i
                                                    >{{ option.label }}
                                                </button>
                                            }
                                        </div>
                                    </div>

                                    <!-- Inline username input for By Assignee / By Created By -->
                                    <!-- @if (pendingDrillDown()) {
                                <div class="flex flex-col gap-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                    <div class="text-xs text-blue-700 font-medium">
                                        Enter username for <span class="font-bold">{{ pendingDrillDown() }}</span
                                        >:
                                    </div>
                                    <div class="flex gap-2 items-center">
                                        <input
                                            type="text"
                                            class="text-xs px-3 py-1.5 rounded-lg border border-blue-300 bg-white text-gray-700 flex-1 outline-none focus:border-blue-500"
                                            placeholder="Enter username..."
                                            [value]="drillDownInput()"
                                            (input)="drillDownInput.set($any($event.target).value)"
                                            (keydown.enter)="submitDrillDownInput()"
                                            autofocus
                                        />
                                        <button type="button" class="text-xs px-3 py-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-all font-medium" (click)="submitDrillDownInput()">
                                            <i class="fa-solid fa-paper-plane mr-1"></i>Send
                                        </button>
                                        <button type="button" class="text-xs px-3 py-1.5 rounded-lg bg-gray-200 text-gray-600 hover:bg-gray-300 transition-all" (click)="cancelDrillDownInput()">Cancel</button>
                                    </div>
                                </div>
                            } -->

                                    <!-- Chart type options -->
                                    <div>
                                        <div
                                            class="text-xs text-gray-600 mb-2 font-medium uppercase tracking-wide"
                                        >
                                            Change chart type
                                        </div>
                                        <div class="flex flex-wrap gap-2">
                                            @for (
                                                option of chartTypeOptions;
                                                track option.label
                                            ) {
                                                <button
                                                    type="button"
                                                    class="text-xs px-3 py-1.5 rounded-full border border-indigo-200 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 hover:border-indigo-400 transition-all cursor-pointer font-medium"
                                                    (click)="
                                                        sendDrillDown(
                                                            entry.originalPrompt,
                                                            option.value,
                                                            null,
                                                            entry.activeDrillDown
                                                        )
                                                    "
                                                >
                                                    <i
                                                        [class]="
                                                            option.icon +
                                                            ' mr-1'
                                                        "
                                                    ></i
                                                    >{{ option.label }}
                                                </button>
                                            }
                                        </div>
                                    </div>
                                </div>
                            }
                        }

                        @if (entry.Message) {
                            <div
                                class=" bg-slate-50 p-3 rounded-lg text-sm text-gray-700 shadow"
                            >
                                {{ entry.Message }}
                            </div>
                            @if (entry.Insight) {
                                <div
                                    class="bg-slate-50 p-3 rounded-lg text-sm text-gray-700 shadow mt-2"
                                    [innerHTML]="entry.Insight"
                                ></div>
                            }
                        }

                        @if (entry.Response?.length === 1) {
                            @for (Data0 of entry?.Response; track Data0) {
                                <div class="flex flex-col gap-2 ">
                                    <div
                                        class="bg-slate-100 p-4 m-2 rounded-lg shadow w-full"
                                    >
                                        @for (
                                            key of Object.keys(Data0);
                                            track key
                                        ) {
                                            <div
                                                class="text-sm text-gray-800 grid mb-1 gap-2"
                                                style="grid-template-columns: 42% 2% 42%"
                                            >
                                                <div class="font-semibold">
                                                    {{
                                                        userFields[key]
                                                            ? userFields[key]
                                                                  .label
                                                            : key
                                                    }}
                                                </div>
                                                <div>:</div>
                                                <div>
                                                    {{ Data0[key] ?? '—' }}
                                                </div>
                                            </div>
                                        }
                                    </div>
                                </div>
                            }
                        }

                        @if (entry.Response?.length > 1) {
                            <div class="flex  mt-1 mb-2">
                                <p-button
                                    icon="fa-solid fa-file-excel"
                                    size="small"
                                    [outlined]="true"
                                    (click)="exportExcel(entry.Response)"
                                    label="Download Excel ({{
                                        entry.TotalCount ??
                                            entry.Response.length
                                    }} records)"
                                    [style]="{
                                        'border-color': '#1D6F42',
                                        color: '#1D6F42',
                                        'font-weight': 'bold',
                                    }"
                                />
                            </div>
                        }
                        <!-- Summary block -->
                        @if (entry.Summary) {
                            <div class=" mt-2 mb-1">
                                <div
                                    class="text-xs text-gray-600 mb-1 font-medium uppercase tracking-wide"
                                >
                                    <i class="fa-solid fa-chart-simple mr-1"></i
                                    >Executive Summary
                                </div>
                                <div
                                    class="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-900 leading-relaxed"
                                >
                                    {{ entry.Summary }}
                                </div>
                            </div>
                        }
                        @if (entry.Suggestions?.length) {
                            <div class=" mt-3 mb-1">
                                <div
                                    class="text-xs text-gray-600 mb-2 font-medium uppercase tracking-wide"
                                >
                                    Suggested prompts
                                </div>
                                <div class="flex flex-wrap gap-2">
                                    @for (
                                        suggestion of entry.Suggestions;
                                        track suggestion
                                    ) {
                                        <button
                                            type="button"
                                            class="text-xs px-3 py-1.5 rounded-full border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 hover:border-blue-400 transition-all cursor-pointer"
                                            (click)="
                                                onSuggestionClick(suggestion)
                                            "
                                        >
                                            {{ suggestion }}
                                        </button>
                                    }
                                </div>
                            </div>
                        }
                    </div>
                </div>
            </div>
        }
    `,
})
export class aiChatMessageResponse {
    Response = input<any>();
    Content = input<any>();
    Insight = input<any>();
    @Output() suggestionSelected = new EventEmitter<string>();
    public userFields = AsnDetails;
    ResData = signal<any[]>([]);
    setActive = signal<boolean>(true);
    private excelDownloadService = inject(ExcelDownloadService);
    messageService = inject(AiChatService);
    private dialogService = inject(DialogService);
    private dialogRef!: DynamicDialogRef;
    Object = Object;

    // ← new signals for inline input
    pendingDrillDown = signal<string | null>(null);
    drillDownInput = signal<string>('');
    private currentOriginalPrompt = '';
    private currentChartType: string | null = null;

    drillDownOptions = [
        {
            label: 'By SKU',
            value: 'by sku',
            icon: 'fa-solid fa-barcode',
            requiresInput: false,
        },
        {
            label: 'By Status',
            value: 'by status',
            icon: 'fa-solid fa-tag',
            requiresInput: false,
        },
        {
            label: 'By Priority',
            value: 'by priority',
            icon: 'fa-solid fa-flag',
            requiresInput: false,
        },
        {
            label: 'By Assignee',
            value: 'by assignee',
            icon: 'fa-solid fa-user-check',
            requiresInput: false,
        },
        // { label: 'Created At', value: 'by created at', icon: 'fa-solid fa-calendar-day', requiresInput: false }
    ];

    chartTypeOptions = [
        {
            label: 'Pie Chart',
            value: 'as pie chart',
            icon: 'fa-solid fa-chart-pie',
        },
        {
            label: 'Bar Chart',
            value: 'as bar chart',
            icon: 'fa-solid fa-chart-bar',
        },
        {
            label: 'Donut Chart',
            value: 'as donut chart',
            icon: 'fa-solid fa-circle-half-stroke',
        },
    ];

    ngOnChanges() {
        const content = this.Content();
        const Insight = this.Insight()
            ? this.Insight().replace(/\n/g, '<br>')
            : '';
        if (content) {
            const drillDownValues = [
                'by sku',
                'by status',
                'by priority',
                'by assignee',
                'by created at',
            ];
            const chartTypeValues = [
                'as pie chart',
                'as bar chart',
                'as donut chart',
            ];

            let rawPrompt = content.originalPrompt ?? '';

            const activeChartType =
                chartTypeValues.find((ct) =>
                    new RegExp(ct, 'i').test(rawPrompt),
                ) ?? null;

            const activeDrillDown =
                drillDownValues.find((dd) =>
                    new RegExp(dd, 'i').test(rawPrompt),
                ) ?? null;

            let basePrompt = rawPrompt;
            for (const suffix of [...drillDownValues, ...chartTypeValues]) {
                basePrompt = basePrompt
                    .replace(new RegExp(`\\s*${suffix}\\s*`, 'gi'), ' ')
                    .trim();
            }
            basePrompt = basePrompt.replace(/\s+/g, ' ').trim();

            this.ResData.set([
                {
                    Message: content.Message,
                    Insight: Insight ?? null,
                    image: content.image,
                    Response: content.Response ?? [],
                    TotalCount:
                        content.TotalCount ?? content.Response?.length ?? 0,
                    Suggestions: content.Suggestions ?? [],
                    Summary: content.Summary ?? null,
                    isChartResponse: content.isChartResponse ?? false,
                    originalPrompt: basePrompt,
                    activeChartType: activeChartType,
                    activeDrillDown: activeDrillDown,
                },
            ]);

            this.pendingDrillDown.set(null);
            this.drillDownInput.set('');
        }
    }
    onDrillDown(
        originalPrompt: string,
        value: string,
        requiresInput: boolean,
        activeChartType: string | null = null,
    ) {
        if (requiresInput) {
            this.pendingDrillDown.set(value);
            this.drillDownInput.set('');
            this.currentOriginalPrompt = originalPrompt;
            this.currentChartType = activeChartType;
            return;
        }
        this.sendDrillDown(originalPrompt, value, activeChartType);
    }

    submitDrillDownInput() {
        const username = this.drillDownInput().trim();
        if (!username) return;
        const value = `${this.pendingDrillDown()} ${username}`;
        this.pendingDrillDown.set(null);
        this.drillDownInput.set('');
        this.sendDrillDown(
            this.currentOriginalPrompt,
            value,
            this.currentChartType,
        );
    }

    cancelDrillDownInput() {
        this.pendingDrillDown.set(null);
        this.drillDownInput.set('');
    }

    sendDrillDown(
        originalPrompt: string,
        breakdown: string,
        activeChartType: string | null = null,
        activeDrillDown: string | null = null, // ← new param
    ) {
        const chartTypeValues = this.chartTypeOptions.map((o) => o.value);
        const isChartTypeChange = chartTypeValues.includes(breakdown);

        if (isChartTypeChange) {
            const newPrompt = activeDrillDown
                ? `${originalPrompt} ${activeDrillDown} ${breakdown}`
                : `${originalPrompt} ${breakdown}`;
            this.messageService.storelog({
                name: 'user',
                Type: 'Request',
                value: newPrompt,
            });
            this.messageService.parseUserMessage(newPrompt);
            return;
        }

        // Drill-down change — preserve existing chart type if any
        const newPrompt = activeChartType
            ? `${originalPrompt} ${breakdown} ${activeChartType}`
            : `${originalPrompt} ${breakdown}`;

        this.messageService.storelog({
            name: 'user',
            Type: 'Request',
            value: newPrompt,
        });
        this.messageService.parseUserMessage(newPrompt);
    }

    openImage(entry: any) {
        this.dialogRef = this.dialogService.open(
            ViewImageDialogAIBotComponent,
            {
                inputValues: {
                    image: entry.image,
                    fileName: 'image.png',
                    showDownload: true,
                    showFileName: false,
                },
                header: 'Attachment',
                closable: true,
                modal: true,
                draggable: true,
                keepInViewport: true,
                width: '80rem',
                style: { height: '70rem' },
            },
        );
        this.dialogRef.onClose.subscribe(() => {});
    }

    onSuggestionClick(suggestion: string) {
        this.messageService.storelog({
            name: 'user',
            Type: 'Request',
            value: suggestion,
        });
        this.messageService.parseUserMessage(suggestion);
    }

    exportExcel(data: any[]) {
        const now = new Date();

        const date =
            now.getFullYear() +
            '-' +
            String(now.getMonth() + 1).padStart(2, '0') +
            '-' +
            String(now.getDate()).padStart(2, '0');

        const log = this.messageService.messageLog();
        const lastRequest = [...log]
            .reverse()
            .find((entry) => entry.Type === 'Request');
        const promptName =
            lastRequest?.value
                ?.trim()
                .replace(/[^a-zA-Z0-9 _-]/g, '')
                .slice(0, 40) ?? 'Chat-Response';
        this.excelDownloadService.downloadExcelFileChatbot(
            `${promptName}-${date}`,
            [],
            data,
        );
    }
}
