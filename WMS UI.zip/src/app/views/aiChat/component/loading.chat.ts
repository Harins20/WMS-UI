import { Component } from '@angular/core';
import { AvatarModule } from 'primeng/avatar';

@Component({
    selector: 'app-ailoading-chat',
    standalone: true,
    imports: [AvatarModule],
    template: ` <div class="flex items-end m-2">
        <p-avatar label="R" styleClass="mr-1" size="normal" shape="circle" />
        <div
            class="w-20 h-10 ml-1 bg-slate-300 rounded-2xl flex justify-center items-center"
        >
            <img src="assets/img/load.gif" />
        </div>
    </div>`,
})
export class AiLoadingChat {}
