import { Component, inject, signal, DestroyRef, OnInit, OnDestroy } from '@angular/core';
import { AsnService } from '../../../../../inbound';
import { DashboardService } from '../../../dashboard.service';
import { CommonModule } from '@angular/common';
import { LoadingComponent } from '../../../../../../common/components/common-loading/loading.component';
import { ChartModule } from 'primeng/chart';
import { FormsModule } from '@angular/forms';



export interface InsightItem {
    label: string;
    heading: string;
    total: number;
    growth: string;
    description: string;
    fileName: string;

    icon: string;
    iconBg: string;
    iconColor: string;
    textColor: string;

    trend: string;
}


@Component({
  selector: 'app-inbound-analytics',
  imports: [CommonModule, LoadingComponent, ChartModule, FormsModule],
  templateUrl: './inbound-analytics.component.html',
  styleUrl: './inbound-analytics.component.scss',
  styles: [`
    @keyframes floatBob1 {
      0%, 100% { transform: translateY(0px) scale(1); }
      50% { transform: translateY(-7px) scale(1.03); }
    }
    @keyframes floatBob2 {
      0%, 100% { transform: translateY(0px) scale(1); }
      50% { transform: translateY(6px) scale(0.97); }
    }
    @keyframes spinOrbit {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    @keyframes pulseRing {
      0%, 100% { opacity: 0.2; transform: scale(0.95); }
      50% { opacity: 0.75; transform: scale(1.12); }
    }
    @keyframes dashFlow {
      to { stroke-dashoffset: -100; }
    }
    .anim-float-1 { animation: floatBob1 4.2s ease-in-out infinite; transform-origin: center; }
    .anim-float-2 { animation: floatBob2 5.5s ease-in-out infinite; transform-origin: center; }
    .anim-spin-orbit { animation: spinOrbit 22s linear infinite; transform-origin: center; }
    .anim-pulse-ring { animation: pulseRing 3.2s ease-in-out infinite; transform-origin: center; }
    .anim-dash-flow { stroke-dasharray: 6 4; animation: dashFlow 6s linear infinite; }
  `]
})


export class InboundAnalyticsComponent implements OnInit, OnDestroy {

   private dashboardervice = inject(DashboardService);
    private asnService = inject(AsnService);
    private destroyRef = inject(DestroyRef);

    loading = signal(false);
    activeQuickTab: string = 'inbound';
    receiptDetailData: any = {};
    refreshSeconds: number = 30;
    insight: InsightItem[] = [];
    asns = signal<any[]>([]);

    // New properties for Receipt Details multi-chart and status breakdown
    isReceiptFullscreen = signal<boolean>(false);
    receiptChartType = signal<'bubbles' | 'orbitRing'>('bubbles');
    receiptOrbitData: any;
    hoveredReceiptOrbitRing: 'yesterday' | 'today' | null = null;
    receiptBubbles: any[] = [];
    hoveredReceiptBubble: any = null;

    syncYesterdayChartData: any;
    syncTodayChartData: any;
    syncChartOptions: any;

    isStatusFullscreen = signal<boolean>(false);
    statusChartType = signal<'doughnut' | 'bar' | 'radar'>('radar');
    statusChartData: any;
    statusChartOptions: any;

    // New properties for Putaway Details custom multi-chart views
    isPutawayFullscreen = signal<boolean>(false);
    putawayChartType = signal<'radial' | 'rose' | 'bubbles'>('radial');
    putawayRoseSectors: any[] = [];
    hoveredRoseSector: any = null;
    putawayBubbles: any[] = [];
    hoveredBubble: any = null;
    hoveredRadialRing: any = null;
    putawayData: any;
    posData: any;

    // New properties for Purchase Order Overview multi-chart
    isPoFullscreen = signal<boolean>(false);
    poChartType = signal<'radialGauge' | 'comparisonBar'>('radialGauge');
    poRadialChartData: any;
    poRadialChartOptions: any;
    poGrowthBadges: { time: string; growth: string; isUp: boolean }[] = [];
    poChartData: any;
    poChartOptions: any;

    syncYesterdayPoChartData: any;
    syncTodayPoChartData: any;
    syncPoChartOptions: any;

    isPoStatusFullscreen = signal<boolean>(false);
    poStatusChartType = signal<'hexagon' | 'sunburst'>('hexagon');
    poStatusHexagons: any[] = [];
    hoveredPoStatusHexagon: any = null;
    poStatusSunburst: any[] = [];
    hoveredPoStatusSunburst: any = null;

    // New properties for Receipt Overview (Section 1) multi-chart
    isOverviewFullscreen = signal<boolean>(false);
    overviewChartType = signal<'comparisonPeaks' | 'hourlyPeaks'>('comparisonPeaks');
    overviewComparisonPeaks: any[] = [];
    overviewHourlyPeaks: any[] = [];
    hoveredPeak: any = null;
    tooltipX = 0;
    tooltipY = 0;

    syncYesterdayOverviewChartData: any;
    syncTodayOverviewChartData: any;
    syncOverviewChartOptions: any;

    isOverviewStatusFullscreen = signal<boolean>(false);
    overviewStatusChartType = signal<'polar' | 'radar' | 'matrix'>('polar');
    overviewStatusChartData: any;
    overviewStatusChartOptions: any;

    currentInsight = 0;
    refreshInterval: any;
    interval: any;

    receiptData: any = {
        InboundSummary: {
            Yesterday: 0,
            Today: 0,
            Percentage: 0,
        },
        ReceiptOverview: {
            New: 0,
            Received: 0,
            Closed: 0,
            Cancelled: 0,
            InReceiving: 0,
        },
        ProcessingFlow: [],
        ReceiptSummary: {
            Title: '',
            Summary: '',
        },
    };

    ngOnInit() {
        this.buildOverviewChart();
        this.buildOverviewStatusChart();
        this.buildPoChart();
        this.buildPoStatusChart();
        this.buildReceiptChart();
        this.buildStatusChart();
        this.buildPutawayChart();
        this.fetchData();
        this.startRefreshTimer();
        setInterval(() => {
            if (this.insight.length > 0) {
                this.currentInsight =
                    (this.currentInsight + 1) % this.insight.length;
            }
        }, 4000);
    }

    ngOnDestroy() {
        if (this.interval) {
            clearInterval(this.interval);
        }
    }

    fetchData() {
        this.loading.set(true);
        let pending = 5;
        const checkDone = () => {
            pending--;
            if (pending <= 0) {
                this.loading.set(false);
            }
        };

        this.loadQuickInboundReceiptReport(checkDone);
        this.loadPosReport(checkDone);
        this.getReceiptDetailsReport(checkDone);
        this.loadPutawayDetails(checkDone);
        this.getAsns(checkDone);
    }

    startRefreshTimer() {
        if (this.interval) clearInterval(this.interval);
        this.interval = setInterval(() => {
            if (this.refreshSeconds > 0) {
                this.refreshSeconds--;
            } else {
                // Refresh all reports
                this.loadQuickInboundReceiptReport();
                this.loadPosReport();
                this.getReceiptDetailsReport();
                this.loadPutawayDetails();
                this.getAsns();

                // Reset Timer
                this.refreshSeconds = 30;
            }
        }, 1000);
    }

    getAsns(cb?: () => void) {
        this.dashboardervice
            .getAsnsPage({ Page: 1, PageSize: 5 })
            .subscribe({
                next: (res: any) => {
                    this.asns.set(res?.AsnLines || []);
                    if (cb) cb();
                },
                error: (err) => {
                    console.error('ASNs Page Error:', err);
                    if (cb) cb();
                }
            });
    }

    loadPutawayDetails(cb?: () => void) {
        this.dashboardervice.getQuickInboundPutawayDetailReport().subscribe({
            next: (res: any) => {
                this.putawayData = res || {};
                this.buildPutawayChart();
                if (cb) cb();
            },
            error: (err) => {
                console.error('Putaway Details Error:', err);
                this.buildPutawayChart();
                if (cb) cb();
            },
        });
    }

    getReceiptDetailsReport(cb?: () => void) {
        this.dashboardervice.getQuickInboundReceiptDetailReport().subscribe({
            next: (res: any) => {
                this.receiptDetailData = res || {};
                this.buildReceiptChart();
                this.buildStatusChart();
                if (cb) cb();
            },
            error: (err) => {
                console.error('Receipt Details Error:', err);
                this.buildReceiptChart();
                this.buildStatusChart();
                if (cb) cb();
            },
        });
    }

    loadQuickInboundReceiptReport(cb?: () => void): void {
        this.dashboardervice.getQuickInboundReceiptReport().subscribe({
            next: (res) => {
                this.receiptData = res || {};
                this.buildOverviewChart();
                this.buildOverviewStatusChart();
                if (cb) cb();
            },
            error: (err) => {
                console.error('Quick Inbound Receipt Report Error:', err);
                this.buildOverviewChart();
                this.buildOverviewStatusChart();
                if (cb) cb();
            },
        });
    }

    getProgress(item: any): number {
        const qty = item?.OPENQTY ?? 0;

        const maxQty = 100; // adjust based on warehouse capacity

        if (qty <= 0) return 0;

        return Math.min((qty / maxQty) * 100, 100);
    }

    loadPosReport(cb?: () => void) {
        this.dashboardervice.getQuickInboundPoReport().subscribe({
            next: (res: any) => {
                this.posData = res || {};
                this.buildPoChart();
                this.buildPoStatusChart();
                if (cb) cb();
            },
            error: (err) => {
                console.error('POS Report Error:', err);
                this.buildPoChart();
                this.buildPoStatusChart();
                if (cb) cb();
            },
        });
    }

    getTotalProcessingCount(): number {
        const flow = this.receiptData?.ProcessingFlow ?? this.receiptData?.processingFlow;
        if (!flow?.length) {
            return 0;
        }

        return flow.reduce(
            (total: number, item: any) => total + (item.Count ?? item.count ?? 0),
            0,
        );
    }

    getFlowWidth(count: number): number {
        const maxQuantity = 1000; // Fixed maximum

        if (!count || count <= 0) {
            return 0;
        }

        const percentage = (count / maxQuantity) * 100;

        // Prevent width from exceeding 100%
        return Math.min(percentage, 100);
    }

    // --- Layout support getters & functions ---

    get yesterdayReceipts(): number {
        const summary = this.receiptDetailData?.Summary ?? this.receiptDetailData?.summary;
        return Number(summary?.Yesterday ?? summary?.yesterday ?? 0);
    }

    get todayReceipts(): number {
        const summary = this.receiptDetailData?.Summary ?? this.receiptDetailData?.summary;
        return Number(summary?.Today ?? summary?.today ?? 0);
    }

    get receiptsDifference(): number {
        return this.todayReceipts - this.yesterdayReceipts;
    }

    get receiptsPercentage(): number {
        const summary = this.receiptDetailData?.Summary ?? this.receiptDetailData?.summary;
        const pct = summary?.Percentage ?? summary?.percentage;
        if (pct !== undefined && pct !== null) return Number(pct);
        if (this.yesterdayReceipts === 0) return 0;
        return Number(((this.receiptsDifference / this.yesterdayReceipts) * 100).toFixed(1));
    }

    get targetAchievementRatio(): number {
        if (this.yesterdayReceipts === 0) return this.todayReceipts > 0 ? 100 : 0;
        const ratio = (this.todayReceipts / this.yesterdayReceipts) * 100;
        return Number(Math.min(ratio, 200).toFixed(1));
    }

    get totalStatusReceipts(): number {
        return this.statusList.reduce((acc, curr) => acc + Number(curr.value || 0), 0);
    }

    get statusList(): any[] {
        const overview = this.receiptDetailData?.OperationalOverview ?? this.receiptDetailData?.operationalOverview;
        return [
            { label: 'New', value: Number(overview?.New ?? overview?.new ?? 0), icon: 'pi pi-plus-circle', containerClass: 'bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800', iconClass: 'text-blue-600 dark:text-blue-400' },
            { label: 'Scheduled', value: Number(overview?.Scheduled ?? overview?.scheduled ?? 0), icon: 'pi pi-calendar', containerClass: 'bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800', iconClass: 'text-indigo-600 dark:text-indigo-400' },
            { label: 'In Transit', value: Number(overview?.InTransit ?? overview?.inTransit ?? 0), icon: 'pi pi-truck', containerClass: 'bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-800', iconClass: 'text-sky-600 dark:text-sky-400' },
            { label: 'In Receiving', value: Number(overview?.InReceiving ?? overview?.inReceiving ?? 0), icon: 'pi pi-spin pi-spinner', containerClass: 'bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800', iconClass: 'text-amber-600 dark:text-amber-400' },
            { label: 'Received', value: Number(overview?.Received ?? overview?.received ?? 0), icon: 'pi pi-download', containerClass: 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800', iconClass: 'text-emerald-600 dark:text-emerald-400' },
            { label: 'Closed', value: Number(overview?.Closed ?? overview?.closed ?? 0), icon: 'pi pi-lock', containerClass: 'bg-green-50 dark:bg-green-950 text-green-600 dark:text-green-400 border-green-200 dark:border-green-800', iconClass: 'text-green-600 dark:text-green-400' },
            { label: 'Verified Close', value: Number(overview?.VerifiedClose ?? overview?.verifiedClose ?? 0), icon: 'pi pi-check-circle', containerClass: 'bg-teal-50 dark:bg-teal-950 text-teal-600 dark:text-teal-400 border-teal-200 dark:border-teal-800', iconClass: 'text-teal-600 dark:text-teal-400' },
            { label: 'Cancelled', value: Number(overview?.Cancelled ?? overview?.cancelled ?? 0), icon: 'pi pi-times-circle', containerClass: 'bg-red-50 dark:bg-red-950 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800', iconClass: 'text-red-600 dark:text-red-400' }
        ];
    }

    getStatusPercentage(value: number): number {
        const total = this.totalStatusReceipts;
        if (!total || total === 0) return 0;
        return Number(((value / total) * 100).toFixed(1));
    }

    getStatusProgressBarClass(containerClass: string): string {
        if (!containerClass) return 'bg-indigo-500';
        if (containerClass.includes('emerald')) return 'bg-emerald-500';
        if (containerClass.includes('blue')) return 'bg-blue-500';
        if (containerClass.includes('indigo')) return 'bg-indigo-500';
        if (containerClass.includes('purple')) return 'bg-purple-500';
        if (containerClass.includes('red') || containerClass.includes('rose')) return 'bg-rose-500';
        if (containerClass.includes('amber') || containerClass.includes('yellow') || containerClass.includes('orange')) return 'bg-amber-500';
        if (containerClass.includes('cyan') || containerClass.includes('sky') || containerClass.includes('teal')) return 'bg-teal-500';
        return 'bg-indigo-500';
    }

    toggleReceiptFullscreen(): void {
        this.isReceiptFullscreen.update((v) => !v);
        setTimeout(() => window.dispatchEvent(new Event('resize')), 120);
    }

    toggleStatusFullscreen(): void {
        this.isStatusFullscreen.update((v) => !v);
        setTimeout(() => window.dispatchEvent(new Event('resize')), 120);
    }

    setReceiptChartType(type: 'bubbles' | 'orbitRing'): void {
        this.receiptChartType.set(type);
        this.buildReceiptChart();
    }

    setStatusChartType(type: 'doughnut' | 'bar' | 'radar'): void {
        this.statusChartType.set(type);
        this.buildStatusChart();
    }

    private buildReceiptChart(): void {
        const yVal = Number(this.yesterdayReceipts || 0);
        const tVal = Number(this.todayReceipts || 0);
        const pace = this.targetAchievementRatio;

        // Floating Bubbles Spheres data
        this.receiptBubbles = [
            {
                label: 'Today Actual',
                value: tVal,
                subText: 'receipts',
                color: '#10B981',
                bg: 'rgba(16, 185, 129, 0.08)',
                cx: -42,
                cy: -12,
                r: 38,
                animationClass: 'animate-float-slow'
            },
            {
                label: 'Yesterday Baseline',
                value: yVal,
                subText: 'target',
                color: '#8B5CF6',
                bg: 'rgba(139, 92, 246, 0.08)',
                cx: 42,
                cy: -20,
                r: 33,
                animationClass: 'animate-float-medium'
            },
            {
                label: 'Target Pacing',
                value: `${pace}%`,
                subText: 'achieved',
                color: '#F59E0E',
                bg: 'rgba(245, 158, 14, 0.08)',
                cx: 0,
                cy: 32,
                r: 28,
                animationClass: 'animate-float-fast'
            }
        ];

        // Concentric Target Orbit Ring Calculation Data
        const maxVal = Math.max(yVal, tVal, 1);
        const outerCircumference = 439.82;
        const innerCircumference = 314.16;
        const outerRatio = Math.min(1, yVal / maxVal);
        const innerRatio = Math.min(1, tVal / maxVal);

        this.receiptOrbitData = {
            outerCircumference,
            innerCircumference,
            outerOffset: outerCircumference * (1 - outerRatio),
            innerOffset: innerCircumference * (1 - innerRatio),
            yVal,
            tVal,
            ratio: pace
        };
    }

    private buildStatusChart(): void {
        const activeStatuses = this.statusList.filter(s => Number(s.value) >= 0);
        const labels = activeStatuses.map((s) => s.label);
        const data = activeStatuses.map((s) => Number(s.value || 0));
        const type = this.statusChartType();

        const colorPalette = [
            '#3B82F6', '#6366F1', '#10B981', '#06B6D4', '#0EA5E9', '#A855F7',
            '#F59E0B', '#F97316', '#14B8A6', '#84CC16', '#EAB308', '#8B5CF6',
            '#EF4444', '#F43F5E', '#EC4899', '#D946EF', '#64748B'
        ];

        if (type === 'doughnut') {
            this.statusChartData = {
                labels: labels,
                datasets: [
                    {
                        data: data,
                        backgroundColor: colorPalette,
                        hoverBackgroundColor: colorPalette.map(c => c + 'E6'),
                        borderWidth: 3,
                        borderColor: '#ffffff',
                    },
                ],
            };
            this.statusChartOptions = {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '72%',
                plugins: {
                    legend: {
                        display: true,
                        position: 'right',
                        labels: { color: '#64748B', font: { size: 11, weight: '700' }, usePointStyle: true, boxWidth: 8, boxHeight: 8, padding: 10 }
                    },
                    tooltip: {
                        enabled: true,
                        backgroundColor: '#0F172A',
                        titleColor: '#F8FAFC',
                        bodyColor: '#38BDF8',
                        padding: 12,
                        cornerRadius: 10,
                        callbacks: {
                            label: (context: any) => {
                                const val = context.raw || 0;
                                const total = data.reduce((a, b) => a + b, 0) || 1;
                                const pct = ((val / total) * 100).toFixed(1);
                                return ` ${context.label}: ${val.toLocaleString()} receipts (${pct}%)`;
                            }
                        }
                    }
                }
            };
        } else if (type === 'bar') {
            this.statusChartData = {
                labels: labels,
                datasets: [
                    {
                        label: 'Receipt Status Count',
                        data: data,
                        backgroundColor: colorPalette,
                        borderRadius: 8,
                        borderSkipped: false,
                        barThickness: 16,
                    },
                ],
            };
            this.statusChartOptions = {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        enabled: true,
                        backgroundColor: '#0F172A',
                        titleColor: '#F8FAFC',
                        bodyColor: '#38BDF8',
                        padding: 12,
                        cornerRadius: 10,
                        callbacks: {
                            label: (context: any) => {
                                const val = context.raw || 0;
                                const total = data.reduce((a, b) => a + b, 0) || 1;
                                const pct = ((val / total) * 100).toFixed(1);
                                return ` ${context.label}: ${val.toLocaleString()} receipts (${pct}%)`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        grid: { color: 'rgba(203, 213, 225, 0.3)', drawBorder: false },
                        border: { display: false },
                        ticks: { color: '#64748B', font: { size: 10, weight: '600' } }
                    },
                    y: {
                        grid: { display: false },
                        border: { display: false },
                        ticks: { color: '#64748B', font: { size: 10, weight: '700' } }
                    }
                }
            };
        } else if (type === 'radar') {
            this.statusChartData = {
                labels: labels,
                datasets: [
                    {
                        label: 'Receipt Volume by Status',
                        data: data,
                        borderColor: '#6366F1',
                        backgroundColor: 'rgba(99, 102, 241, 0.25)',
                        pointBackgroundColor: '#6366F1',
                        pointBorderColor: '#ffffff',
                        pointHoverBackgroundColor: '#ffffff',
                        pointHoverBorderColor: '#6366F1',
                        borderWidth: 2.5,
                    },
                ],
            };
            this.statusChartOptions = {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: { color: '#64748B', font: { size: 11, weight: '700' }, usePointStyle: true }
                    },
                    tooltip: {
                        enabled: true,
                        backgroundColor: '#0F172A',
                        titleColor: '#F8FAFC',
                        bodyColor: '#38BDF8',
                        padding: 12,
                        cornerRadius: 10,
                    }
                },
                scales: {
                    r: {
                        angleLines: { color: 'rgba(148, 163, 184, 0.2)' },
                        grid: { color: 'rgba(148, 163, 184, 0.2)' },
                        pointLabels: { color: '#64748B', font: { size: 10, weight: '700' } },
                        ticks: { display: false }
                    }
                }
            };
        }
    }

    // --- Putaway Details Layout support getters & functions ---

    get yesterdayPutaway(): number {
        const summary = this.putawayData?.Summary ?? this.putawayData?.summary;
        return Number(summary?.Yesterday ?? summary?.yesterday ?? 0);
    }

    get todayPutaway(): number {
        const summary = this.putawayData?.Summary ?? this.putawayData?.summary;
        return Number(summary?.Today ?? summary?.today ?? 0);
    }

    get putawayDifference(): number {
        return this.todayPutaway - this.yesterdayPutaway;
    }

    get putawayPercentage(): number {
        const summary = this.putawayData?.Summary ?? this.putawayData?.summary;
        const pct = summary?.Percentage ?? summary?.percentage;
        if (pct !== undefined && pct !== null) return Number(pct);
        if (this.yesterdayPutaway === 0) return 0;
        return Number(((this.putawayDifference / this.yesterdayPutaway) * 100).toFixed(1));
    }

    get putawayTargetAchievementRatio(): number {
        if (this.yesterdayPutaway === 0) return this.todayPutaway > 0 ? 100 : 0;
        const ratio = (this.todayPutaway / this.yesterdayPutaway) * 100;
        return Number(Math.min(ratio, 200).toFixed(1));
    }

    get maxPutawayVal(): number {
        return Math.max(this.todayPutaway, this.yesterdayPutaway, 1);
    }

    get todayPutawayPercentage(): number {
        return Number(((this.todayPutaway / this.maxPutawayVal) * 100).toFixed(1));
    }

    get yesterdayPutawayPercentage(): number {
        return Number(((this.yesterdayPutaway / this.maxPutawayVal) * 100).toFixed(1));
    }

    get pacingPercentage(): number {
        return Number(Math.min(this.putawayTargetAchievementRatio, 100).toFixed(1));
    }

    togglePutawayFullscreen(): void {
        this.isPutawayFullscreen.update((v) => !v);
        setTimeout(() => window.dispatchEvent(new Event('resize')), 120);
    }

    setPutawayChartType(type: 'radial' | 'rose' | 'bubbles'): void {
        this.putawayChartType.set(type);
        this.buildPutawayChart();
    }

    private buildPutawayChart(): void {
        this.buildRoseSectors();
        this.buildBubbles();
    }

    private buildRoseSectors(): void {
        const yVal = this.yesterdayPutaway;
        const tVal = this.todayPutaway;
        const labels = ['08:00 AM', '11:00 AM', '02:00 PM', '05:00 PM', 'Overall'];
        
        const ySlots = [
            Math.round(yVal * 0.20),
            Math.round(yVal * 0.25),
            Math.round(yVal * 0.25),
            Math.round(yVal * 0.30),
            yVal
        ];
        const tSlots = [
            Math.round(tVal * 0.22),
            Math.round(tVal * 0.23),
            Math.round(tVal * 0.27),
            Math.round(tVal * 0.28),
            tVal
        ];

        const maxSlotVal = Math.max(...ySlots, ...tSlots, 1);
        const maxRadius = 100;

        this.putawayRoseSectors = labels.map((label, idx) => {
            const startAngleDeg = -90 + idx * 72;
            const endAngleDeg = startAngleDeg + 72;
            
            const startRad = (startAngleDeg * Math.PI) / 180;
            const endRad = (endAngleDeg * Math.PI) / 180;

            const y = ySlots[idx];
            const t = tSlots[idx];

            const rY = Math.max(15, (y / maxSlotVal) * maxRadius);
            const rT = Math.max(15, (t / maxSlotVal) * maxRadius);

            const getPath = (r: number) => {
                const x1 = (r * Math.cos(startRad)).toFixed(1);
                const y1 = (r * Math.sin(startRad)).toFixed(1);
                const x2 = (r * Math.cos(endRad)).toFixed(1);
                const y2 = (r * Math.sin(endRad)).toFixed(1);
                return `M 0 0 L ${x1} ${y1} A ${r} ${r} 0 0 1 ${x2} ${y2} Z`;
            };

            return {
                label,
                yesterday: y,
                today: t,
                yesterdayPath: getPath(rY),
                todayPath: getPath(rT),
                diff: t - y,
                ratio: Math.round((t / y) * 100),
                status: t >= y ? 'ahead' : 'behind'
            };
        });

        this.hoveredRoseSector = this.putawayRoseSectors[4];
    }

    private buildBubbles(): void {
        const yVal = this.yesterdayPutaway;
        const tVal = this.todayPutaway;
        const pace = this.putawayTargetAchievementRatio;

        this.putawayBubbles = [
            {
                label: 'Today Actual',
                value: tVal,
                subText: 'putaways',
                color: '#9F5FFE',
                bg: 'rgba(159, 95, 254, 0.08)',
                cx: -42,
                cy: -12,
                r: 38,
                animationClass: 'animate-float-slow'
            },
            {
                label: 'Yesterday Baseline',
                value: yVal,
                subText: 'target',
                color: '#3D82F7',
                bg: 'rgba(61, 130, 247, 0.08)',
                cx: 42,
                cy: -20,
                r: 33,
                animationClass: 'animate-float-medium'
            },
            {
                label: 'Target Pacing',
                value: `${pace}%`,
                subText: 'achieved',
                color: '#F59E0E',
                bg: 'rgba(245, 158, 14, 0.08)',
                cx: 0,
                cy: 32,
                r: 28,
                animationClass: 'animate-float-fast'
            }
        ];
    }

    // --- Purchase Order Details Layout support getters & functions ---

    get yesterdayPo(): number {
        const summary = this.posData?.Summary ?? this.posData?.summary;
        return Number(summary?.Yesterday ?? summary?.yesterday ?? 0);
    }

    get todayPo(): number {
        const summary = this.posData?.Summary ?? this.posData?.summary;
        return Number(summary?.Today ?? summary?.today ?? 0);
    }

    get poDifference(): number {
        return this.todayPo - this.yesterdayPo;
    }

    get poPercentage(): number {
        const summary = this.posData?.Summary ?? this.posData?.summary;
        const pct = summary?.Percentage ?? summary?.percentage;
        if (pct !== undefined && pct !== null) return Number(pct);
        if (this.yesterdayPo === 0) return 0;
        return Number(((this.poDifference / this.yesterdayPo) * 100).toFixed(1));
    }

    get poTargetAchievementRatio(): number {
        if (this.yesterdayPo === 0) return this.todayPo > 0 ? 100 : 0;
        const ratio = (this.todayPo / this.yesterdayPo) * 100;
        return Number(Math.min(ratio, 200).toFixed(1));
    }

    get poStatusList(): any[] {
        const t = this.posData?.TodayTransactions ?? this.posData?.todayTransactions ?? {};
        return [
            { label: 'Receipt Open', value: t.ReceiptOpen ?? t.receiptOpen ?? 0, icon: 'pi pi-folder-open', iconClass: 'text-green-600 dark:text-green-400', containerClass: 'bg-green-100 dark:bg-green-900/20 border-green-200' },
            { label: 'Pending', value: t.Pending ?? t.pending ?? 0, icon: 'pi pi-clock', iconClass: 'text-yellow-600 dark:text-yellow-400', containerClass: 'bg-yellow-100 dark:bg-yellow-900/20 border-yellow-200' },
            { label: 'Completed', value: t.Completed ?? t.completed ?? 0, icon: 'pi pi-check-circle', iconClass: 'text-green-600 dark:text-green-400', containerClass: 'bg-green-100 dark:bg-green-900/20 border-green-200' },
            { label: 'New', value: t.New ?? t.new ?? 0, icon: 'pi pi-plus-circle', iconClass: 'text-blue-600 dark:text-blue-400', containerClass: 'bg-blue-100 dark:bg-blue-900/20 border-blue-200' },
            { label: 'Closed', value: t.Closed ?? t.closed ?? 0, icon: 'pi pi-lock', iconClass: 'text-red-600 dark:text-red-400', containerClass: 'bg-red-100 dark:bg-red-900/20 border-red-200' },
            { label: 'Cancelled', value: t.Cancelled ?? t.cancelled ?? 0, icon: 'pi pi-times-circle', iconClass: 'text-red-600 dark:text-red-400', containerClass: 'bg-red-100 dark:bg-red-900/20 border-red-200' }
        ];
    }

    get totalPoStatusTransactions(): number {
        return this.poStatusList.reduce((sum, item) => sum + item.value, 0);
    }

    getPoStatusPercentage(value: number): number {
        const total = this.totalPoStatusTransactions;
        if (total === 0) return 0;
        return Number(((value / total) * 100).toFixed(1));
    }

    togglePoFullscreen(): void {
        this.isPoFullscreen.update((v) => !v);
        setTimeout(() => window.dispatchEvent(new Event('resize')), 120);
    }

    setPoChartType(type: 'radialGauge' | 'comparisonBar'): void {
        this.poChartType.set(type);
        this.buildPoChart();
    }

    togglePoStatusFullscreen(): void {
        this.isPoStatusFullscreen.update((v) => !v);
        setTimeout(() => window.dispatchEvent(new Event('resize')), 120);
    }

    setPoStatusChartType(type: 'hexagon' | 'sunburst'): void {
        this.poStatusChartType.set(type);
        this.buildPoStatusChart();
    }



    private buildPoChart(): void {
        const yVal = Number(this.yesterdayPo || 0);
        const tVal = Number(this.todayPo || 0);
        const remainingTarget = Math.max(0, yVal - tVal);

        // Build Radial Target Gauge Chart Data with Animated Tooltips
        this.poRadialChartData = {
            labels: [`Today Executed (${tVal} POs)`, `Remaining Target (${remainingTarget} POs)`],
            datasets: [
                {
                    data: [tVal, remainingTarget],
                    backgroundColor: ['#10B981', 'rgba(148, 163, 184, 0.2)'],
                    hoverBackgroundColor: ['#059669', 'rgba(148, 163, 184, 0.35)'],
                    borderRadius: 6,
                    borderWidth: 3,
                    borderColor: 'transparent',
                },
            ],
        };

        this.poRadialChartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '78%',
            rotation: -90,
            circumference: 360,
            animation: {
                animateRotate: true,
                animateScale: true
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: { color: '#64748B', font: { size: 11, weight: '700' }, usePointStyle: true, padding: 14 }
                },
                tooltip: {
                    enabled: true,
                    backgroundColor: '#0F172A',
                    titleColor: '#F8FAFC',
                    bodyColor: '#38BDF8',
                    padding: 12,
                    cornerRadius: 12,
                    callbacks: {
                        label: (context: any) => ` ${context.label}: ${context.raw.toLocaleString()} POs`
                    }
                }
            }
        };

        // Directly map API Summary values for Yesterday Baseline vs Today Actual
        this.poChartData = {
            labels: ['Yesterday Baseline', 'Today Executed'],
            datasets: [
                {
                    label: 'Purchase Orders Count',
                    data: [yVal, tVal],
                    backgroundColor: ['#8B5CF6', '#10B981'],
                    hoverBackgroundColor: ['#7C3AED', '#059669'],
                    borderRadius: 12,
                    borderSkipped: false,
                    barThickness: 42,
                },
            ],
        };

        this.poChartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: true,
                    backgroundColor: '#0F172A',
                    titleColor: '#F8FAFC',
                    bodyColor: '#38BDF8',
                    padding: 12,
                    cornerRadius: 12,
                    callbacks: {
                        label: (context: any) => ` ${context.label}: ${context.raw.toLocaleString()} POs`
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false },
                    border: { display: false },
                    ticks: { color: '#64748B', font: { size: 11, weight: '700' } }
                },
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(203, 213, 225, 0.3)', drawBorder: false },
                    border: { display: false },
                    ticks: { color: '#64748B', font: { size: 10, weight: '600' } }
                }
            }
        };
    }

    getStatusColor(label: string): string {
        if (!label) return '#6366F1';
        const l = label.toLowerCase();
        if (l.includes('complete') || l.includes('received') || l.includes('open')) return '#10B981';
        if (l.includes('process') || l.includes('in-progress') || l.includes('new')) return '#3B82F6';
        if (l.includes('pending')) return '#F59E0B';
        if (l.includes('hold') || l.includes('close')) return '#EF4444';
        if (l.includes('cancel')) return '#F43F5E';
        return '#8B5CF6';
    }

    private buildPoStatusChart(): void {
        const activeStatuses = (this.poStatusList || []).filter(s => Number(s.value || 0) >= 0);
        const totalVal = activeStatuses.reduce((acc, s) => acc + Number(s.value || 0), 0) || 1;

        // 1. Hexagonal Honeycomb Matrix Data
        const hexPositions = [
            { cx: -45, cy: -22 },
            { cx: 45, cy: -22 },
            { cx: 0, cy: 30 },
            { cx: -65, cy: 30 },
            { cx: 65, cy: 30 },
            { cx: 0, cy: -48 }
        ];

        this.poStatusHexagons = activeStatuses.slice(0, 6).map((item, idx) => {
            const val = Number(item.value || 0);
            const pct = ((val / totalVal) * 100).toFixed(1);
            const color = this.getStatusColor(item.label || '');
            const pos = hexPositions[idx] || { cx: 0, cy: 0 };
            const r = 26;

            const points = [0, 60, 120, 180, 240, 300].map(angle => {
                const rad = (angle - 30) * (Math.PI / 180);
                const x = (pos.cx + r * Math.cos(rad)).toFixed(2);
                const y = (pos.cy + r * Math.sin(rad)).toFixed(2);
                return `${x},${y}`;
            }).join(' ');

            return {
                label: item.label,
                value: val,
                pct: `${pct}%`,
                color,
                bg: `${color}20`,
                points,
                cx: pos.cx,
                cy: pos.cy,
                animClass: idx % 2 === 0 ? 'anim-float-1' : 'anim-float-2',
                icon: item.icon || 'pi pi-tag'
            };
        });

        // 2. Radial Sunburst Wheel Arc Data
        let startAngle = -90;
        const innerR = 40;
        const outerR = 75;

        this.poStatusSunburst = activeStatuses.map((item) => {
            const val = Number(item.value || 0);
            const pctVal = (val / totalVal) * 100;
            const angleExtent = (pctVal / 100) * 360;
            const endAngle = startAngle + angleExtent;
            const color = this.getStatusColor(item.label || '');

            const sRad = (startAngle * Math.PI) / 180;
            const eRad = (endAngle * Math.PI) / 180;

            const x1 = (outerR * Math.cos(sRad)).toFixed(2);
            const y1 = (outerR * Math.sin(sRad)).toFixed(2);
            const x2 = (outerR * Math.cos(eRad)).toFixed(2);
            const y2 = (outerR * Math.sin(eRad)).toFixed(2);
            const x3 = (innerR * Math.cos(eRad)).toFixed(2);
            const y3 = (innerR * Math.sin(eRad)).toFixed(2);
            const x4 = (innerR * Math.cos(sRad)).toFixed(2);
            const y4 = (innerR * Math.sin(sRad)).toFixed(2);

            const largeArc = angleExtent > 180 ? 1 : 0;

            const pathD = `M ${x1} ${y1} A ${outerR} ${outerR} 0 ${largeArc} 1 ${x2} ${y2} L ${x3} ${y3} A ${innerR} ${innerR} 0 ${largeArc} 0 ${x4} ${y4} Z`;

            const midAngle = startAngle + angleExtent / 2;
            const mRad = (midAngle * Math.PI) / 180;
            const labelR = (innerR + outerR) / 2;
            const labelX = (labelR * Math.cos(mRad)).toFixed(2);
            const labelY = (labelR * Math.sin(mRad)).toFixed(2);

            startAngle = endAngle;

            return {
                label: item.label,
                value: val,
                pct: `${pctVal.toFixed(1)}%`,
                color,
                pathD,
                labelX,
                labelY,
                icon: item.icon || 'pi pi-tag'
            };
        });
    }

    // --- Receipt Overview Layout support getters & methods ---

    get yesterdayOverview(): number {
        const inboundSummary = this.receiptData?.InboundSummary ?? this.receiptData?.inboundSummary;
        return Number(inboundSummary?.Yesterday ?? inboundSummary?.yesterday ?? 0);
    }

    get todayOverview(): number {
        const inboundSummary = this.receiptData?.InboundSummary ?? this.receiptData?.inboundSummary;
        return Number(inboundSummary?.Today ?? inboundSummary?.today ?? 0);
    }

    get overviewDifference(): number {
        return this.todayOverview - this.yesterdayOverview;
    }

    get overviewPercentage(): number {
        const inboundSummary = this.receiptData?.InboundSummary ?? this.receiptData?.inboundSummary;
        const pct = inboundSummary?.Percentage ?? inboundSummary?.percentage;
        if (pct !== undefined && pct !== null) return Number(pct);
        if (this.yesterdayOverview === 0) return 0;
        return Number(((this.overviewDifference / this.yesterdayOverview) * 100).toFixed(1));
    }

    get overviewTargetAchievementRatio(): number {
        if (this.yesterdayOverview === 0) return this.todayOverview > 0 ? 100 : 0;
        const ratio = (this.todayOverview / this.yesterdayOverview) * 100;
        return Number(Math.min(ratio, 200).toFixed(1));
    }

    get maxOverviewVal(): number {
        return Math.max(this.todayOverview, this.yesterdayOverview, 1);
    }

    get todayOverviewPercentage(): number {
        return Number(((this.todayOverview / this.maxOverviewVal) * 100).toFixed(1));
    }

    get yesterdayOverviewPercentage(): number {
        return Number(((this.yesterdayOverview / this.maxOverviewVal) * 100).toFixed(1));
    }

    get overviewStatusList(): any[] {
        const o = this.receiptData?.ReceiptOverview ?? this.receiptData?.receiptOverview ?? {};
        return [
            { label: 'New', value: o.New ?? o.new ?? 0, icon: 'pi pi-plus-circle', iconClass: 'text-blue-600 dark:text-blue-400', containerClass: 'bg-blue-100 dark:bg-blue-900/20 border-blue-200' },
            { label: 'Received', value: o.Received ?? o.received ?? 0, icon: 'pi pi-inbox', iconClass: 'text-green-600 dark:text-green-400', containerClass: 'bg-green-100 dark:bg-green-900/20 border-green-200' },
            { label: 'In Receiving', value: o.InReceiving ?? o.inReceiving ?? 0, icon: 'pi pi-clock', iconClass: 'text-yellow-600 dark:text-yellow-400', containerClass: 'bg-yellow-100 dark:bg-yellow-900/20 border-yellow-200' },
            { label: 'Closed', value: o.Closed ?? o.closed ?? 0, icon: 'pi pi-check-circle', iconClass: 'text-green-600 dark:text-green-400', containerClass: 'bg-green-100 dark:bg-green-900/20 border-green-200' },
            { label: 'Cancelled', value: o.Cancelled ?? o.cancelled ?? 0, icon: 'pi pi-times-circle', iconClass: 'text-red-600 dark:text-red-400', containerClass: 'bg-red-100 dark:bg-red-900/20 border-red-200' }
        ];
    }

    get totalOverviewStatusTransactions(): number {
        return this.overviewStatusList.reduce((sum, item) => sum + item.value, 0);
    }

    getOverviewStatusPercentage(value: number): number {
        const total = this.totalOverviewStatusTransactions;
        if (total === 0) return 0;
        return Number(((value / total) * 100).toFixed(1));
    }

    toggleOverviewFullscreen(): void {
        this.isOverviewFullscreen.update((v) => !v);
        setTimeout(() => window.dispatchEvent(new Event('resize')), 120);
    }

    updateTooltipPos(event: MouseEvent): void {
        const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
        this.tooltipX = event.clientX - rect.left + 15;
        this.tooltipY = event.clientY - rect.top - 50;
    }

    setOverviewChartType(type: 'comparisonPeaks' | 'hourlyPeaks'): void {
        this.overviewChartType.set(type);
        this.buildOverviewChart();
    }

    toggleOverviewStatusFullscreen(): void {
        this.isOverviewStatusFullscreen.update((v) => !v);
        setTimeout(() => window.dispatchEvent(new Event('resize')), 120);
    }

    setOverviewStatusChartType(type: 'polar' | 'radar' | 'matrix'): void {
        this.overviewStatusChartType.set(type);
        this.buildOverviewStatusChart();
    }

    getPeakPath(cx: number, cy: number, w: number, h: number): string {
        const xStart = cx - w / 2;
        const xEnd = cx + w / 2;
        const yBase = cy;
        const yTop = cy - h;

        // Cubic bezier curves to make a gorgeous mountain peak flare out at base
        return `M ${xStart.toFixed(1)} ${yBase.toFixed(1)} ` +
               `C ${(cx - w * 0.28).toFixed(1)} ${yBase.toFixed(1)}, ` +
               `${(cx - w * 0.08).toFixed(1)} ${yTop.toFixed(1)}, ` +
               `${cx.toFixed(1)} ${yTop.toFixed(1)} ` +
               `C ${(cx + w * 0.08).toFixed(1)} ${yTop.toFixed(1)}, ` +
               `${(cx + w * 0.28).toFixed(1)} ${yBase.toFixed(1)}, ` +
               `${xEnd.toFixed(1)} ${yBase.toFixed(1)} Z`;
    }

    private buildOverviewChart(): void {
        const yVal = Number(this.yesterdayOverview || 0);
        const tVal = Number(this.todayOverview || 0);
        const totalComp = Math.max(1, yVal + tVal);
        const flowList = this.receiptData?.ProcessingFlow ?? this.receiptData?.processingFlow ?? [];

        // 1. Build Comparison Peaks (Yesterday vs Today)
        // SVG view dimensions: width 320, height 160. Baseline at y = 140.
        // Yesterday peak centered at x = 100, Today peak centered at x = 220.
        const maxVal = Math.max(yVal, tVal, 1);
        const maxH = 110; // Max peak height

        const hY = Math.max(8, (yVal / maxVal) * maxH);
        const hT = Math.max(8, (tVal / maxVal) * maxH);

        this.overviewComparisonPeaks = [
            {
                label: 'Yesterday Baseline',
                value: yVal,
                pct: `${((yVal / totalComp) * 100).toFixed(1)}%`,
                color: '#3B82F6', // Blue
                fill: 'url(#bluePeakGrad)',
                cx: 100,
                cy: 140,
                w: 120,
                h: hY,
                pathD: this.getPeakPath(100, 140, 120, hY)
            },
            {
                label: 'Today Executed',
                value: tVal,
                pct: `${((tVal / totalComp) * 100).toFixed(1)}%`,
                color: '#10B981', // Emerald
                fill: 'url(#emeraldPeakGrad)',
                cx: 220,
                cy: 140,
                w: 120,
                h: hT,
                pathD: this.getPeakPath(220, 140, 120, hT)
            }
        ];

        // 2. Build Hourly Activity Peaks (aggregated into 4 ranges: 00-06hr, 06-12hr, 12-18hr, 18-24hr)
        const bins = [
            { label: '00-06hr', start: 0, end: 5, count: 0 },
            { label: '06-12hr', start: 6, end: 11, count: 0 },
            { label: '12-18hr', start: 12, end: 17, count: 0 },
            { label: '18-24hr', start: 18, end: 23, count: 0 }
        ];

        if (flowList.length > 0) {
            flowList.forEach((f: any) => {
                const rawSlot = String(f.TimeSlot ?? f.timeSlot ?? '');
                const hourNum = parseInt(rawSlot, 10);
                if (!isNaN(hourNum)) {
                    const bin = bins.find(b => hourNum >= b.start && hourNum <= b.end);
                    if (bin) {
                        bin.count += Number(f.Count ?? f.count ?? 0);
                    }
                }
            });
        } else {
            // Fallback baseline for demo
            bins[1].count = 570; // 06-12hr (120 + 450)
            bins[2].count = 1110; // 12-18hr (310 + 520 + 280)
            bins[3].count = 410; // 18-24hr (410)
        }

        const totalHourly = Math.max(1, bins.reduce((sum, b) => sum + b.count, 0));
        const maxHourlyVal = Math.max(1, ...bins.map(b => b.count));

        // SVG width 400, height 160. Baseline at y = 140.
        // For 4 peaks, we place them at cx = 50, 150, 250, 350.
        const peakWidth = 110;

        const colors = ['#10B981', '#3B82F6', '#8B5CF6', '#F59E0B'];
        const grads = ['url(#emeraldPeakGrad)', 'url(#bluePeakGrad)', 'url(#purplePeakGrad)', 'url(#amberPeakGrad)'];

        this.overviewHourlyPeaks = bins.map((b, idx) => {
            const cx = 50 + idx * 100;
            const h = Math.max(6, (b.count / maxHourlyVal) * maxH);

            return {
                label: b.label,
                value: b.count,
                pct: `${((b.count / totalHourly) * 100).toFixed(1)}%`,
                color: colors[idx],
                fill: grads[idx],
                cx,
                cy: 140,
                w: peakWidth,
                h,
                pathD: this.getPeakPath(cx, 140, peakWidth, h)
            };
        });
    }

    private buildOverviewStatusChart(): void {
        const stats = this.overviewStatusList;
        const labels = stats.map(s => s.label);
        const dataValues = stats.map(s => s.value);

        this.overviewStatusChartData = {
            labels: labels,
            datasets: [
                {
                    label: 'Receipts by Current Status',
                    data: dataValues,
                    backgroundColor: [
                        'rgba(59, 130, 246, 0.7)',
                        'rgba(16, 185, 129, 0.7)',
                        'rgba(245, 158, 11, 0.7)',
                        'rgba(34, 197, 94, 0.7)',
                        'rgba(239, 68, 68, 0.7)'
                    ],
                    borderColor: [
                        '#3B82F6',
                        '#10B981',
                        '#F59E0B',
                        '#22C55E',
                        '#EF4444'
                    ],
                    borderWidth: 2
                }
            ]
        };

        this.overviewStatusChartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: { color: '#94A3B8', font: { size: 11, weight: '600' }, usePointStyle: true }
                },
                tooltip: {
                    enabled: true,
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    titleColor: '#F8FAFC',
                    bodyColor: '#CBD5E1',
                    padding: 11,
                    cornerRadius: 8
                }
            }
        };

        this.overviewStatusChartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: { color: '#94A3B8', font: { size: 11, weight: '600' }, usePointStyle: true }
                },
                tooltip: {
                    enabled: true,
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    titleColor: '#F8FAFC',
                    bodyColor: '#CBD5E1',
                    padding: 11,
                    cornerRadius: 8
                }
            },
            scales: {
                r: {
                    angleLines: { color: 'rgba(148, 163, 184, 0.15)' },
                    grid: { color: 'rgba(148, 163, 184, 0.15)' },
                    pointLabels: { color: '#94A3B8', font: { size: 10, weight: '600' } },
                    ticks: { display: false }
                }
            }
        };
    }
}
