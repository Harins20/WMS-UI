import { Component, inject, signal } from '@angular/core';
import { DashboardService } from '../../dashboard.service';
import { CommonModule } from '@angular/common';
import { LoadingComponent } from '../../../../../common/components/common-loading/loading.component';
import { AsnService } from '../../../../inbound/asns/asn.service';

export interface InsightItem {
    label: string;
    heading: string;
    total: number;
    growth: string;
    description: string;
    fileName: string;

    icon: string;
    iconBg: string;
    iconColor: string;
    textColor: string;

    trend: string;
}

@Component({
    selector: 'app-quickinbound',
    standalone: true,
    imports: [CommonModule, LoadingComponent],
    templateUrl: './quickinbound.component.html',
    styleUrls: ['./quickinbound.component.scss'],
})
export class QuickInboundComponent {
    private dashboardervice = inject(DashboardService);
    private asnService = inject(AsnService);

    loading = signal(false);
    activeQuickTab: string = 'inbound';
    receiptDetailData: any = {};
    refreshSeconds: number = 30;
    insight: InsightItem[] = [];
    asns = signal<any[]>([]);

    putawayData: any;
    posData: any;

    currentInsight = 0;
    refreshInterval: any;
    interval: any;

    receiptData: any = {
        InboundSummary: {
            Yesterday: 0,
            Today: 0,
            Percentage: 0,
        },
        ReceiptOverview: {
            New: 0,
            Received: 0,
            Closed: 0,
            Cancelled: 0,
            InReceiving: 0,
        },
        ProcessingFlow: [],
        ReceiptSummary: {
            Title: '',
            Summary: '',
        },
    };

    ngOnInit() {
        this.loading.set(true);
        setTimeout(() => {
            this.loading.set(false);
        }, 2500);
        this.startRefreshTimer();
        setInterval(() => {
            this.currentInsight =
                (this.currentInsight + 1) % this.insight.length;
        }, 4000);
        this.loadQuickInboundReceiptReport();
        this.loadPosReport();
        this.getReceiptDetailsReport();
        this.loadPutawayDetails();
    }

    startRefreshTimer() {
        this.interval = setInterval(() => {
            if (this.refreshSeconds > 0) {
                this.refreshSeconds--;
            } else {
                // API CALL
                this.getAsns();

                // Reset Timer
                this.refreshSeconds = 30;
            }
        }, 1000);
    }

    getAsns() {
        const subscription = this.dashboardervice
            .getAsnsPage({ Page: 1, PageSize: 5 })
            .pipe()
            .subscribe({
                next: (res: any) => {
                    this.asns.set(res.AsnLines);
                },
            });
    }

    loadPutawayDetails() {
        this.dashboardervice.getQuickInboundPutawayDetailReport().subscribe({
            next: (res: any) => {
                this.putawayData = res;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }

    getReceiptDetailsReport() {
        this.dashboardervice.getQuickInboundReceiptDetailReport().subscribe({
            next: (res: any) => {
                this.receiptDetailData = res;
            },
            error: (err) => {
                console.error('Receipt Details Error:', err);
            },
        });
    }

    loadQuickInboundReceiptReport(): void {
        this.dashboardervice.getQuickInboundReceiptReport().subscribe({
            next: (res) => {
                this.receiptData = res;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }

    getProgress(item: any): number {
        const qty = item?.OPENQTY ?? 0;

        const maxQty = 100; // adjust based on warehouse capacity

        if (qty <= 0) return 0;

        return Math.min((qty / maxQty) * 100, 100);
    }

    loadPosReport() {
        this.dashboardervice.getQuickInboundPoReport().subscribe({
            next: (res: any) => {
                this.posData = res;
            },
            error: (err) => {
                console.error('POS Report Error', err);
            },
        });
    }

    getTotalProcessingCount(): number {
        if (!this.receiptData?.ProcessingFlow?.length) {
            return 0;
        }

        return this.receiptData.ProcessingFlow.reduce(
            (total: number, item: any) => total + item.Count,
            0,
        );
    }

    getFlowWidth(count: number): number {
        const maxQuantity = 1000; // Fixed maximum

        if (!count || count <= 0) {
            return 0;
        }

        const percentage = (count / maxQuantity) * 100;

        // Prevent width from exceeding 100%
        return Math.min(percentage, 100);
    }
}
