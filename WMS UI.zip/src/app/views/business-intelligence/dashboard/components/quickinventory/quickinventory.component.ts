import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { LoadingComponent } from '../../../../../common/components/common-loading/loading.component';
import { DashboardService } from '../../dashboard.service';
import { AuthService } from '../../../../../common/services/auth.service';
import { InventoryAnalyticsComponent } from './inventory-analytics/inventory-analytics.component';
import { ChartModule } from 'primeng/chart';

export interface InsightItem {
    label: string;
    heading: string;
    total: number;
    growth: string;
    description: string;
    fileName: string;

    icon: string;
    iconBg: string;
    iconColor: string;
    textColor: string;

    trend: string;
}

@Component({
    selector: 'app-quickinventory',
    standalone: true,
    imports: [
        CommonModule,
        LoadingComponent,
        InventoryAnalyticsComponent,
        ChartModule,
    ],
    templateUrl: './quickinventory.component.html',
    styleUrls: ['./quickinventory.component.scss'],
})
export class QuickInventoryComponent {
    private dashboardervice = inject(DashboardService);
    public authService = inject(AuthService);

    activeQuickTab: string = 'inventory';
    activeTab: 'reports' | 'analytics' = 'reports';
    inventoryData: any;
    refreshSeconds: number = 30;
    refreshInterval: any;
    loading = signal(false);

    todayWidth: number = 0;
    yesterdayWidth: number = 0;

    comparisonChartData: any;
    comparisonChartOptions: any;
    activeComparisonChartType: 'line' | 'doughnut' | 'bar' = 'line';

    ngOnInit() {
        this.loading.set(true);
        setTimeout(() => {
            this.loading.set(false);
        }, 1000);
        this.loadInventoryReport();
    }

    loadInventoryReport(): void {
        this.dashboardervice.getQuickInventoryReport().subscribe({
            next: (res: any) => {
                this.inventoryData = res;

                const today = Number(res?.Summary?.TodayInventory || 0);
                const yesterday = Number(res?.Summary?.YesterdayInventory || 0);

                const maxValue = 5000;

                this.todayWidth =
                    today > 0 ? Math.min((today / maxValue) * 100, 100) : 0;

                this.yesterdayWidth =
                    yesterday > 0
                        ? Math.min((yesterday / maxValue) * 100, 100)
                        : 0;

                this.initComparisonChart(yesterday, today);

                console.log('Today:', today);
                console.log('Yesterday:', yesterday);
                console.log('Today Width:', this.todayWidth);
                console.log('Yesterday Width:', this.yesterdayWidth);
            },
            error: (err) => {
                console.error(err);
            },
        });
    }

    initComparisonChart(yesterday: number, today: number): void {
        const timeLabels = [
            '00:00',
            '04:00',
            '08:00',
            '12:00',
            '16:00',
            '20:00',
            '24:00',
        ];

        const yesterdayTrend = [
            Math.round(yesterday * 0.2),
            Math.round(yesterday * 0.35),
            Math.round(yesterday * 0.5),
            Math.round(yesterday * 0.7),
            Math.round(yesterday * 0.85),
            Math.round(yesterday * 0.95),
            yesterday,
        ];

        const todayTrend = [
            Math.round(today * 0.15),
            Math.round(today * 0.3),
            Math.round(today * 0.55),
            Math.round(today * 0.75),
            Math.round(today * 0.88),
            Math.round(today * 0.96),
            today,
        ];

        this.comparisonChartData = {
            labels: timeLabels,
            datasets: [
                {
                    label: 'Today Actual',
                    data: todayTrend,
                    fill: true,
                    backgroundColor: (context: any) => {
                        const chart = context.chart;
                        const { ctx, chartArea } = chart;
                        if (!chartArea) return 'rgba(16, 185, 129, 0.15)';
                        const gradient = ctx.createLinearGradient(
                            0,
                            chartArea.top,
                            0,
                            chartArea.bottom,
                        );
                        gradient.addColorStop(0, 'rgba(16, 185, 129, 0.35)');
                        gradient.addColorStop(1, 'rgba(16, 185, 129, 0.02)');
                        return gradient;
                    },
                    borderColor: '#10B981',
                    borderWidth: 3,
                    tension: 0.4,
                    pointBackgroundColor: '#FFFFFF',
                    pointBorderColor: '#10B981',
                    pointBorderWidth: 3,
                    pointRadius: 4,
                    pointHoverRadius: 7,
                    pointHoverBackgroundColor: '#10B981',
                    pointHoverBorderColor: '#FFFFFF',
                },
                {
                    label: 'Yesterday Baseline',
                    data: yesterdayTrend,
                    fill: true,
                    backgroundColor: (context: any) => {
                        const chart = context.chart;
                        const { ctx, chartArea } = chart;
                        if (!chartArea) return 'rgba(59, 130, 246, 0.08)';
                        const gradient = ctx.createLinearGradient(
                            0,
                            chartArea.top,
                            0,
                            chartArea.bottom,
                        );
                        gradient.addColorStop(0, 'rgba(59, 130, 246, 0.15)');
                        gradient.addColorStop(1, 'rgba(59, 130, 246, 0.01)');
                        return gradient;
                    },
                    borderColor: '#3B82F6',
                    borderWidth: 2,
                    borderDash: [4, 4],
                    tension: 0.4,
                    pointBackgroundColor: '#FFFFFF',
                    pointBorderColor: '#3B82F6',
                    pointBorderWidth: 2,
                    pointRadius: 3,
                    pointHoverRadius: 6,
                    pointHoverBackgroundColor: '#3B82F6',
                    pointHoverBorderColor: '#FFFFFF',
                },
            ],
        };

        this.comparisonChartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    align: 'end',
                    labels: {
                        boxWidth: 8,
                        boxHeight: 8,
                        usePointStyle: true,
                        pointStyle: 'circle',
                        font: { size: 11, weight: '600' },
                        color: '#64748b',
                    },
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    titleFont: { size: 13, weight: '600' },
                    bodyFont: { size: 12 },
                    padding: 10,
                    cornerRadius: 8,
                    usePointStyle: true,
                },
            },
            scales: {
                x: {
                    ticks: {
                        color: '#64748b',
                        font: { weight: '500', size: 11 },
                    },
                    grid: { display: false, drawBorder: false },
                },
                y: {
                    beginAtZero: true,
                    ticks: { color: '#94a3b8', font: { size: 11 } },
                    grid: {
                        color: 'rgba(226, 232, 240, 0.5)',
                        drawBorder: false,
                    },
                },
            },
        };
    }
}
