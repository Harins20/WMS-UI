import {
    Component,
    inject,
    OnInit,
    OnDestroy,
    signal,
    HostListener,
    DestroyRef,
} from '@angular/core';
import { ChartModule } from 'primeng/chart';
import { DashboardService } from '../../../dashboard.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LoadingComponent } from '../../../../../../common/components/common-loading/loading.component';

@Component({
    selector: 'app-inventory-analytics',
    standalone: true,
    imports: [ChartModule, CommonModule, FormsModule, LoadingComponent],
    templateUrl: './inventory-analytics.component.html',
    styleUrl: './inventory-analytics.component.scss',
})
export class InventoryAnalyticsComponent implements OnInit, OnDestroy {
    private dashboardService = inject(DashboardService);
    private destroyRef = inject(DestroyRef);

    // Signals for UI State
    loading = signal<boolean>(false);
    activeQuickTab: string = 'inventory';
    activeTab = signal<'overview' | 'trajectory' | 'holds' | 'distribution'>('overview');
    comparisonChartType = signal<'bar' | 'line' | 'area'>('bar');
    distributionChartType = signal<'doughnut' | 'polarArea' | 'bar' | 'pie'>('doughnut');
    holdChartType = signal<'bar' | 'pie' | 'doughnut'>('bar');
    timeframe = signal<'today' | '7d' | '30d'>('today');

    isFullscreen = signal<boolean>(false);
    isHoldFullscreen = signal<boolean>(false);
    isTrendFullscreen = signal<boolean>(false);

    // Refresh & Auto-Sync
    refreshSeconds = signal<number>(30);
    lastRefreshedAt = signal<Date>(new Date());
    private timerId: any;

    // Backend & Chart Data
    inventoryData: any = null;
    holdReportData: any = null;

    pieData: any;
    pieOptions: any;
    holdChartData: any;
    holdChartOptions: any;
    comparisonChartData: any;
    comparisonChartOptions: any;

    totalHolds: number = 0;
    lpnHold: number = 0;
    lotHold: number = 0;
    combinedHold: number = 0;

    ngOnInit(): void {
        this.initDefaultCharts();
        this.fetchData(false);
        this.startAutoRefreshTimer();
    }

    ngOnDestroy(): void {
        if (this.timerId) {
            clearInterval(this.timerId);
        }
        this.syncBodyScroll();
    }

    startAutoRefreshTimer(): void {
        if (this.timerId) clearInterval(this.timerId);
        this.timerId = setInterval(() => {
            this.refreshSeconds.update((sec) => {
                if (sec <= 1) {
                    this.fetchData(true);
                    return 30;
                }
                return sec - 1;
            });
        }, 1000);
    }

    fetchData(isSilent: boolean = false): void {
        if (!isSilent) {
            this.loading.set(true);
        }

        let pending = 2;
        const checkDone = () => {
            pending--;
            if (pending <= 0) {
                if (!isSilent) {
                    setTimeout(() => this.loading.set(false), 200);
                }
            }
        };

        // 1. Load Main Quick Inventory Overview Report
        this.dashboardService.getQuickInventoryReport().subscribe({
            next: (res: any) => {
                this.inventoryData = res || {};
                this.lastRefreshedAt.set(new Date());
                this.processHoldData(this.holdReportData);
                this.initCharts(this.inventoryData);
                checkDone();
            },
            error: (err) => {
                console.error('Failed to load inventory report', err);
                this.initCharts(this.inventoryData);
                checkDone();
            },
        });

        // 2. Load Hold Insights Report
        this.dashboardService.getHoldReport().subscribe({
            next: (res: any) => {
                this.holdReportData = res || {};
                this.processHoldData(res);
                this.buildHoldChart(this.inventoryData?.HoldBreakdown);
                checkDone();
            },
            error: (err) => {
                console.error('Failed to load hold report', err);
                this.processHoldData(null);
                this.buildHoldChart(this.inventoryData?.HoldBreakdown);
                checkDone();
            },
        });
    }

    processHoldData(res: any): void {
        const breakdown = this.inventoryData?.HoldBreakdown;
        if (breakdown) {
            this.lotHold = Number(breakdown.LotHold ?? breakdown.lotHold ?? 0);
            this.lpnHold = Number(breakdown.LpnHold ?? breakdown.lpnHold ?? 0);
            this.combinedHold = Number(breakdown.LpnLotHold ?? breakdown.lpnLotHold ?? 0);
            this.totalHolds = this.lotHold + this.lpnHold + this.combinedHold;
            return;
        }

        const holdData = res?.HoldData || [];
        let lpn = 0;
        let lot = 0;
        let combined = 0;

        if (Array.isArray(holdData) && holdData.length > 0) {
            holdData.forEach((item: any) => {
                const status = (item.Status || '').toLowerCase();
                const count = Number(item.Count || item.Qty || item.Quantity || 0);

                if (status.includes('lpn') && !status.includes('lot')) {
                    lpn += count;
                } else if (status.includes('lot') && !status.includes('lpn')) {
                    lot += count;
                } else if (status.includes('lpn') && status.includes('lot')) {
                    combined += count;
                } else {
                    lpn += count;
                }
            });
        }

        this.lpnHold = lpn;
        this.lotHold = lot;
        this.combinedHold = combined;
        this.totalHolds = lpn + lot + combined;
    }

    manualRefresh(): void {
        this.refreshSeconds.set(30);
        this.fetchData(false);
    }

    // Modal & Fullscreen controls
    toggleFullscreen(): void {
        this.isFullscreen.update((v) => !v);
        this.syncBodyScroll();
        this.triggerResize();
    }

    toggleHoldFullscreen(): void {
        this.isHoldFullscreen.update((v) => !v);
        this.syncBodyScroll();
        this.triggerResize();
    }

    toggleTrendFullscreen(): void {
        this.isTrendFullscreen.update((v) => !v);
        this.syncBodyScroll();
        this.triggerResize();
    }

    private triggerResize(): void {
        setTimeout(() => window.dispatchEvent(new Event('resize')), 50);
        setTimeout(() => window.dispatchEvent(new Event('resize')), 150);
    }

    private syncBodyScroll(): void {
        if (typeof document !== 'undefined') {
            const anyActive =
                this.isFullscreen() ||
                this.isHoldFullscreen() ||
                this.isTrendFullscreen();
            if (anyActive) {
                document.body.classList.add('overflow-hidden');
            } else {
                document.body.classList.remove('overflow-hidden');
            }
        }
    }

    @HostListener('document:keydown.escape')
    onEscapePress(): void {
        if (this.isFullscreen()) this.toggleFullscreen();
        if (this.isHoldFullscreen()) this.toggleHoldFullscreen();
        if (this.isTrendFullscreen()) this.toggleTrendFullscreen();
    }

    // Tab Switcher
    setActiveTab(tab: 'overview' | 'trajectory' | 'holds' | 'distribution'): void {
        this.activeTab.set(tab);
    }

    // Chart Type Switcher for Comparison
    setComparisonChartType(type: 'bar' | 'line' | 'area'): void {
        this.comparisonChartType.set(type);
        const yesterday = this.yesterdayInventory;
        const today = this.todayInventory;
        const percentage = this.baselinePercentage;
        this.buildComparisonChart(yesterday, today, percentage);
    }

    // Chart Type Switcher for Distribution
    setDistributionChartType(type: 'doughnut' | 'polarArea' | 'bar' | 'pie'): void {
        this.distributionChartType.set(type);
        this.buildDistributionChart(this.inventoryData?.InventoryStatus);
    }

    // Chart Type Switcher for Holds
    setHoldChartType(type: 'bar' | 'pie' | 'doughnut'): void {
        this.holdChartType.set(type);
        this.buildHoldChart(this.inventoryData?.HoldBreakdown);
    }

    // Calculated KPI Indicators
    get TotalInventory(): number {
        return this.totalInventoryQty;
    }

    get totalInventoryQty(): number {
        const status = this.inventoryData?.InventoryStatus;
        if (status?.TotalInventory !== undefined && status?.TotalInventory !== null) {
            return Number(status.TotalInventory);
        }
        const movement = Number(status?.Movement ?? status?.movement ?? 0);
        const adjustment = Number(status?.Adjustment ?? status?.adjustment ?? 0);
        const holdQty = this.totalHoldQty;
        return movement + adjustment + holdQty;
    }

    get movementQty(): number {
        const status = this.inventoryData?.InventoryStatus;
        return Number(status?.Movement ?? status?.movement ?? 0);
    }

    get adjustmentQty(): number {
        const status = this.inventoryData?.InventoryStatus;
        return Number(status?.Adjustment ?? status?.adjustment ?? 0);
    }

    get lotHoldQty(): number {
        const hold = this.inventoryData?.HoldBreakdown;
        if (hold) {
            return Number(hold.LotHold ?? hold.lotHold ?? 0);
        }
        return this.lotHold;
    }

    get lpnHoldQty(): number {
        const hold = this.inventoryData?.HoldBreakdown;
        if (hold) {
            return Number(hold.LpnHold ?? hold.lpnHold ?? 0);
        }
        return this.lpnHold;
    }

    get lpnLotHoldQty(): number {
        const hold = this.inventoryData?.HoldBreakdown;
        if (hold) {
            return Number(hold.LpnLotHold ?? hold.lpnLotHold ?? 0);
        }
        return this.combinedHold;
    }

    get totalHoldQty(): number {
        const sum = this.lotHoldQty + this.lpnHoldQty + this.lpnLotHoldQty;
        if (sum > 0) return sum;
        const statusHold = this.inventoryData?.InventoryStatus?.HoldQty ?? this.inventoryData?.InventoryStatus?.holdQty ?? this.inventoryData?.InventoryStatus?.Hold;
        if (statusHold !== undefined && statusHold !== null) {
            return Number(statusHold);
        }
        return 0;
    }

    get yesterdayInventory(): number {
        const val = this.inventoryData?.Summary?.YesterdayInventory ?? this.inventoryData?.Summary?.Yesterday;
        return val !== undefined && val !== null ? Number(val) : 0;
    }

    get YesterdayInventory(): number {
        return this.yesterdayInventory;
    }

    get todayInventory(): number {
        const val = this.inventoryData?.Summary?.TodayInventory ?? this.inventoryData?.Summary?.Today;
        return val !== undefined && val !== null ? Number(val) : 0;
    }

    get TodayInventory(): number {
        return this.todayInventory;
    }

    get baselinePercentage(): number {
        const pct = this.inventoryData?.Summary?.Percentage;
        if (pct !== undefined && pct !== null) return Number(pct);
        if (this.yesterdayInventory === 0) return this.todayInventory > 0 ? 100 : 0;
        const diff = this.todayInventory - this.yesterdayInventory;
        return Number(((diff / this.yesterdayInventory) * 100).toFixed(1));
    }

    get inventorySummary() {
        const status = this.inventoryData?.InventoryStatus;
        const movement = Number(status?.Movement ?? status?.movement ?? 0);
        const adjustment = Math.abs(Number(status?.Adjustment ?? status?.adjustment ?? 0));
        const holdQty = Number(status?.HoldQty ?? status?.holdQty ?? status?.Hold ?? this.totalHoldQty ?? 0);

        const counts = [movement, adjustment, holdQty];
        const total = counts.reduce((a, b) => a + b, 0);

        const configs = [
            {
                label: 'Movement',
                color: '#3B82F6',
                gradient: 'from-blue-500 to-indigo-600',
                dotClass: 'bg-blue-500 shadow-blue-500/50',
                badgeClass: 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800/40',
                icon: 'pi pi-sync'
            },
            {
                label: 'Adjustments',
                color: '#8B5CF6',
                gradient: 'from-purple-500 to-violet-600',
                dotClass: 'bg-purple-500 shadow-purple-500/50',
                badgeClass: 'bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800/40',
                icon: 'pi pi-sliders-h'
            },
            {
                label: 'Hold Quantity',
                color: '#EF4444',
                gradient: 'from-red-500 to-rose-600',
                dotClass: 'bg-red-500 shadow-red-500/50',
                badgeClass: 'bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800/40',
                icon: 'pi pi-lock'
            },
        ];

        return configs.map((cfg, idx) => {
            const count = counts[idx] || 0;
            const pct = total > 0 ? ((count / total) * 100).toFixed(1) : '0';
            return { ...cfg, count, pct };
        });
    }

    get holdSummary() {
        const lot = this.lotHoldQty;
        const lpn = this.lpnHoldQty;
        const dual = this.lpnLotHoldQty;

        const vals = [lot, lpn, dual];
        const total = vals.reduce((a, b) => a + b, 0);

        const configs = [
            {
                label: 'Lot Hold',
                color: '#EF4444',
                bgColor: 'bg-red-500/10 dark:bg-red-500/15',
                borderColor: 'border-red-200/70 dark:border-red-900/40',
                hoverBorder: 'hover:border-red-300 dark:hover:border-red-700',
                dotClass: 'bg-red-500 shadow-red-500/50',
                badgeClass: 'bg-red-500/15 text-red-700 dark:text-red-300 border-red-300/40 dark:border-red-800/40',
                riskBadge: 'bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-800/50',
                iconBg: 'bg-red-500 text-white shadow-md shadow-red-500/25',
                icon: 'pi pi-tag'
            },
            {
                label: 'LPN Hold',
                color: '#F59E0B',
                bgColor: 'bg-amber-500/10 dark:bg-amber-500/15',
                borderColor: 'border-amber-200/70 dark:border-amber-900/40',
                hoverBorder: 'hover:border-amber-300 dark:hover:border-amber-700',
                dotClass: 'bg-amber-500 shadow-amber-500/50',
                badgeClass: 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-300/40 dark:border-amber-800/40',
                riskBadge: 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800/50',
                iconBg: 'bg-amber-500 text-white shadow-md shadow-amber-500/25',
                icon: 'pi pi-box'
            },
            {
                label: 'LPN / Lot Hold',
                color: '#FB923C',
                bgColor: 'bg-orange-500/10 dark:bg-orange-500/15',
                borderColor: 'border-orange-200/70 dark:border-orange-900/40',
                hoverBorder: 'hover:border-orange-300 dark:hover:border-orange-700',
                dotClass: 'bg-orange-500 shadow-orange-500/50',
                badgeClass: 'bg-orange-500/15 text-orange-700 dark:text-orange-300 border-orange-300/40 dark:border-orange-800/40',
                riskBadge: 'bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-400 border border-orange-200 dark:border-orange-800/50',
                iconBg: 'bg-orange-500 text-white shadow-md shadow-orange-500/25',
                icon: 'pi pi-exclamation-circle'
            },
        ];

        return configs.map((cfg, idx) => {
            const val = vals[idx] || 0;
            const pct = total > 0 ? ((val / total) * 100).toFixed(1) : '0';
            return { ...cfg, val, pct };
        });
    }

    private initDefaultCharts(): void {
        this.buildDistributionChart(null);
        this.buildHoldChart(null);
        this.buildComparisonChart(0, 0, 0);
    }

    // Initialize Chart Options & Datasets
    private initCharts(res: any): void {
        const status = res?.InventoryStatus;
        const hold = res?.HoldBreakdown;
        const yesterday = this.yesterdayInventory;
        const today = this.todayInventory;
        const percentage = this.baselinePercentage;

        // 1. Volume Distribution Chart
        this.buildDistributionChart(status);

        // 2. Hold Breakdown Chart
        this.buildHoldChart(hold);

        // 3. Direct Yesterday vs Today Comparison Chart
        this.buildComparisonChart(yesterday, today, percentage);
    }

    private buildDistributionChart(status: any): void {
        const type = this.distributionChartType();
        const movement = Number(status?.Movement ?? status?.movement ?? 0);
        const adjustment = Math.abs(Number(status?.Adjustment ?? status?.adjustment ?? 0));
        const holdQty = Number(status?.HoldQty ?? status?.holdQty ?? status?.Hold ?? this.totalHoldQty ?? 0);

        const counts = [movement, adjustment, holdQty];

        const colors = ['#3B82F6', '#8B5CF6', '#EF4444'];
        const hoverColors = ['#2563EB', '#7C3AED', '#DC2626'];

        this.pieData = {
            labels: ['Movement', 'Adjustments', 'Hold Quantity'],
            datasets: [
                {
                    data: counts,
                    backgroundColor: colors,
                    hoverBackgroundColor: hoverColors,
                    borderWidth: type === 'bar' ? 0 : 2,
                    borderColor: '#ffffff',
                    borderRadius: type === 'bar' ? 8 : 0,
                    barThickness: type === 'bar' ? 36 : undefined,
                    hoverOffset: type === 'bar' ? 0 : 6,
                },
            ],
        };

        const isBar = type === 'bar';
        const isPolar = type === 'polarArea';

        this.pieOptions = {
            responsive: true,
            maintainAspectRatio: false,
            cutout: type === 'doughnut' ? '68%' : 0,
            plugins: {
                legend: {
                    display: isPolar || type === 'pie' || isBar,
                    position: isBar ? 'top' : 'bottom',
                    labels: {
                        color: '#94A3B8',
                        font: { size: 12, weight: '600' },
                        usePointStyle: true,
                        padding: 14,
                    },
                },
                tooltip: {
                    enabled: true,
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    titleColor: '#F8FAFC',
                    bodyColor: '#CBD5E1',
                    titleFont: { size: 13, weight: '700', family: 'Inter, sans-serif' },
                    bodyFont: { size: 12, family: 'Inter, sans-serif' },
                    padding: 12,
                    cornerRadius: 10,
                    borderColor: 'rgba(148, 163, 184, 0.2)',
                    borderWidth: 1,
                    displayColors: true,
                    callbacks: {
                        label: (context: any) => {
                            const value = context.raw || 0;
                            const datasetTotal = context.dataset?.data?.reduce((a: number, b: number) => (a || 0) + (b || 0), 0) || 0;
                            const pct = datasetTotal > 0 ? ((value / datasetTotal) * 100).toFixed(1) : '0';
                            return ` ${context.label}: ${Number(value).toLocaleString()} units (${pct}%)`;
                        },
                    },
                },
            },
            scales: isBar ? {
                x: {
                    ticks: { color: '#94A3B8', font: { size: 11, weight: '600' } },
                    grid: { color: 'rgba(148, 163, 184, 0.12)' },
                },
                y: {
                    beginAtZero: true,
                    ticks: { color: '#94A3B8', font: { size: 11, weight: '600' } },
                    grid: { color: 'rgba(148, 163, 184, 0.12)' },
                },
            } : (isPolar ? {
                r: {
                    grid: { color: 'rgba(148, 163, 184, 0.15)' },
                    ticks: { display: false },
                }
            } : {}),
        };
    }

    private buildHoldChart(hold?: any): void {
        const type = this.holdChartType();
        const lot = this.lotHoldQty;
        const lpn = this.lpnHoldQty;
        const dual = this.lpnLotHoldQty;

        const vals = [lot, lpn, dual];
        const colors = ['#EF4444', '#F59E0B', '#FB923C'];
        const hoverColors = ['#DC2626', '#D97706', '#EA580C'];

        const isBar = type === 'bar';

        this.holdChartData = {
            labels: ['Lot Hold', 'LPN Hold', 'LPN / Lot Hold'],
            datasets: [
                {
                    label: 'Units On Hold',
                    data: vals,
                    backgroundColor: colors,
                    hoverBackgroundColor: hoverColors,
                    borderRadius: isBar ? 8 : 0,
                    barThickness: isBar ? 28 : undefined,
                    borderWidth: isBar ? 0 : 2,
                    borderColor: '#ffffff',
                },
            ],
        };

        this.holdChartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: isBar ? 'y' : 'x',
            cutout: type === 'doughnut' ? '65%' : 0,
            layout: { padding: { top: 10, bottom: 10, left: 10, right: 20 } },
            plugins: {
                legend: {
                    display: !isBar,
                    position: 'bottom',
                    labels: {
                        color: '#94A3B8',
                        font: { size: 12, weight: '600' },
                        usePointStyle: true,
                        padding: 12,
                    },
                },
                tooltip: {
                    enabled: true,
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    titleColor: '#F8FAFC',
                    bodyColor: '#CBD5E1',
                    titleFont: { size: 13, weight: '700' },
                    bodyFont: { size: 12 },
                    padding: 12,
                    cornerRadius: 10,
                    borderColor: 'rgba(148, 163, 184, 0.2)',
                    borderWidth: 1,
                    callbacks: {
                        label: (context: any) => ` ${context.label}: ${Number(context.raw || 0).toLocaleString()} units`,
                    },
                },
            },
            scales: isBar ? {
                x: {
                    beginAtZero: true,
                    ticks: {
                        color: '#94A3B8',
                        font: { size: 11, weight: '600' },
                    },
                    grid: { color: 'rgba(148, 163, 184, 0.12)' },
                },
                y: {
                    ticks: {
                        color: '#94A3B8',
                        font: { size: 12, weight: '700' },
                    },
                    grid: { display: false },
                },
            } : {},
        };
    }

    private buildComparisonChart(yesterday: number, today: number, percentage: number = 0): void {
        const yVal = Number(yesterday ?? 0);
        const tVal = Number(today ?? 0);

        const labels = ['Yesterday', 'Today'];
        const type = this.comparisonChartType();
        const isArea = type === 'area';
        const isBar = type === 'bar';

        const isIncrease = tVal >= yVal;

        if (isBar) {
            this.comparisonChartData = {
                labels,
                datasets: [
                    {
                        label: 'Inventory',
                        data: [yVal, tVal],
                        backgroundColor: [
                            '#3B82F6',
                            isIncrease ? '#10B981' : '#EF4444',
                        ],
                        hoverBackgroundColor: [
                            '#2563EB',
                            isIncrease ? '#059669' : '#DC2626',
                        ],
                        borderRadius: 10,
                        barThickness: 50,
                    },
                ],
            };
        } else {
            this.comparisonChartData = {
                labels,
                datasets: [
                    {
                        label: 'Inventory',
                        data: [yVal, tVal],
                        borderColor: isIncrease ? '#10B981' : '#EF4444',
                        backgroundColor: isArea
                            ? (isIncrease
                                ? 'rgba(16,185,129,0.2)'
                                : 'rgba(239,68,68,0.2)')
                            : 'transparent',
                        fill: isArea,
                        tension: 0.35,
                        borderWidth: 3,
                        pointRadius: 6,
                        pointHoverRadius: 8,
                        pointBackgroundColor: [
                            '#3B82F6',
                            isIncrease ? '#10B981' : '#EF4444',
                        ],
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                    },
                ],
            };
        }

        this.comparisonChartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    display: false,
                },
                tooltip: {
                    backgroundColor: 'rgba(15,23,42,0.95)',
                    titleColor: '#ffffff',
                    bodyColor: '#CBD5E1',
                    padding: 12,
                    cornerRadius: 8,
                    callbacks: {
                        label: (context: any) => {
                            return `${context.label}: ${Number(context.raw || 0).toLocaleString()}`;
                        },
                        afterLabel: () => {
                            return `Change: ${Number(percentage || 0).toFixed(2)}%`;
                        },
                    },
                },
            },
            scales: {
                x: {
                    ticks: {
                        color: '#94A3B8',
                    },
                    grid: {
                        display: false,
                    },
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#94A3B8',
                        precision: 0,
                    },
                    grid: {
                        color: 'rgba(148,163,184,0.12)',
                    },
                },
            },
        };
    }
}
