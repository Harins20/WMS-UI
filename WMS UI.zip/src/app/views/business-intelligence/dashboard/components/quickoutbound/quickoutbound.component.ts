import { CommonModule } from '@angular/common';
import { Component, DestroyRef, inject, signal } from '@angular/core';
import { LoadingComponent } from '../../../../../common/components/common-loading/loading.component';
import { DashboardService } from '../../dashboard.service';
import { MessageService } from 'primeng/api';
import { AuthService } from '../../../../../common/services/auth.service';
import { AsnService } from '../../../../inbound/asns/asn.service';

export interface InsightItem {
    label: string;
    heading: string;
    total: number;
    growth: string;
    description: string;
    fileName: string;

    icon: string;
    iconBg: string;
    iconColor: string;
    textColor: string;

    trend: string;
}

@Component({
    selector: 'quick-outbound',
    standalone: true,
    imports: [CommonModule, LoadingComponent],
    templateUrl: './quickoutbound.component.html',
    styleUrls: ['./quickoutbound.component.scss'],
})
export class QuickOutboundComponent {
    private dashboardervice = inject(DashboardService);
    private messageService = inject(MessageService);
    private destoryRef = inject(DestroyRef);
    public authService = inject(AuthService);
    private asnService = inject(AsnService);

    activeQuickTab: string = 'outbound';
    loadReport: any = {};
    returnReport: any = {};
    quickOutboundOrderData: any;

    currentInsight = 0;
    insight: InsightItem[] = [];
    refreshSeconds: number = 30;
    refreshInterval: any;
    interval: any;
    loading = signal(false);
    asns = signal<any[]>([]);
    statusList: any[] = [];

    ngOnInit() {
        this.loading.set(true);
        setTimeout(() => {
            this.loading.set(false);
        }, 4000);
        this.startRefreshTimer();
        setInterval(() => {
            this.currentInsight =
                (this.currentInsight + 1) % this.insight.length;
        }, 4000);

        this.getQuickOutboundOrderData();
        this.getLoadReport();
        this.getReturnReport();
        this.loadStatusData();
    }

    loadStatusData() {
        this.statusList = [
            {
                label: 'Created Internally',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.CreatedInternally || 0,
                icon: 'pi pi-file',
                containerClass:
                    'bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800',
                iconClass: 'text-blue-600 dark:text-blue-400',
                labelClass: 'text-blue-700 dark:text-blue-300',
                countClass:
                    'bg-blue-100 dark:bg-blue-800 text-blue-700 dark:text-blue-200',
            },
            {
                label: 'Created Externally',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.CreatedExternally || 0,
                icon: 'pi pi-globe',
                containerClass:
                    'bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800',
                iconClass: 'text-indigo-600 dark:text-indigo-400',
                labelClass: 'text-indigo-700 dark:text-indigo-300',
                countClass:
                    'bg-indigo-100 dark:bg-indigo-800 text-indigo-700 dark:text-indigo-200',
            },
            {
                label: 'Allocated',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.Allocated || 0,
                icon: 'pi pi-box',
                containerClass:
                    'bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800',
                iconClass: 'text-emerald-600 dark:text-emerald-400',
                labelClass: 'text-emerald-700 dark:text-emerald-300',
                countClass:
                    'bg-emerald-100 dark:bg-emerald-800 text-emerald-700 dark:text-emerald-200',
            },
            {
                label: 'Part Allocated',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.PartAllocated || 0,
                icon: 'pi pi-inbox',
                containerClass:
                    'bg-cyan-50 dark:bg-cyan-900/20 border border-cyan-200 dark:border-cyan-800',
                iconClass: 'text-cyan-600 dark:text-cyan-400',
                labelClass: 'text-cyan-700 dark:text-cyan-300',
                countClass:
                    'bg-cyan-100 dark:bg-cyan-800 text-cyan-700 dark:text-cyan-200',
            },
            {
                label: 'Part Allocated / Part Picked',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.PartAllocatedPartPicked || 0,
                icon: 'pi pi-arrow-right-arrow-left',
                containerClass:
                    'bg-sky-50 dark:bg-sky-900/20 border border-sky-200 dark:border-sky-800',
                iconClass: 'text-sky-600 dark:text-sky-400',
                labelClass: 'text-sky-700 dark:text-sky-300',
                countClass:
                    'bg-sky-100 dark:bg-sky-800 text-sky-700 dark:text-sky-200',
            },
            {
                label: 'Part Allocated / Part Shipped',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.PartAllocatedPartShipped || 0,
                icon: 'pi pi-send',
                containerClass:
                    'bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800',
                iconClass: 'text-purple-600 dark:text-purple-400',
                labelClass: 'text-purple-700 dark:text-purple-300',
                countClass:
                    'bg-purple-100 dark:bg-purple-800 text-purple-700 dark:text-purple-200',
            },
            {
                label: 'Part Picked',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.PartPicked || 0,
                icon: 'pi pi-shopping-bag',
                containerClass:
                    'bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800',
                iconClass: 'text-amber-600 dark:text-amber-400',
                labelClass: 'text-amber-700 dark:text-amber-300',
                countClass:
                    'bg-amber-100 dark:bg-amber-800 text-amber-700 dark:text-amber-200',
            },
            {
                label: 'Part Picked / Part Shipped',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.PartPickedPartShipped || 0,
                icon: 'pi pi-shopping-cart',
                containerClass:
                    'bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800',
                iconClass: 'text-orange-600 dark:text-orange-400',
                labelClass: 'text-orange-700 dark:text-orange-300',
                countClass:
                    'bg-orange-100 dark:bg-orange-800 text-orange-700 dark:text-orange-200',
            },
            {
                label: 'Picked Complete',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.PickedComplete || 0,
                icon: 'pi pi-check-circle',
                containerClass:
                    'bg-teal-50 dark:bg-teal-900/20 border border-teal-200 dark:border-teal-800',
                iconClass: 'text-teal-600 dark:text-teal-400',
                labelClass: 'text-teal-700 dark:text-teal-300',
                countClass:
                    'bg-teal-100 dark:bg-teal-800 text-teal-700 dark:text-teal-200',
            },
            {
                label: 'Loaded',
                value:
                    this.quickOutboundOrderData?.OperationalOverview?.Loaded ||
                    0,
                icon: 'pi pi-truck',
                containerClass:
                    'bg-lime-50 dark:bg-lime-900/20 border border-lime-200 dark:border-lime-800',
                iconClass: 'text-lime-600 dark:text-lime-400',
                labelClass: 'text-lime-700 dark:text-lime-300',
                countClass:
                    'bg-lime-100 dark:bg-lime-800 text-lime-700 dark:text-lime-200',
            },
            {
                label: 'Part Shipped',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.PartShipped || 0,
                icon: 'pi pi-send',
                containerClass:
                    'bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800',
                iconClass: 'text-yellow-600 dark:text-yellow-400',
                labelClass: 'text-yellow-700 dark:text-yellow-300',
                countClass:
                    'bg-yellow-100 dark:bg-yellow-800 text-yellow-700 dark:text-yellow-200',
            },
            {
                label: 'Shipped Complete',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.ShippedComplete || 0,
                icon: 'pi pi-truck',
                containerClass:
                    'bg-violet-50 dark:bg-violet-900/20 border border-violet-200 dark:border-violet-800',
                iconClass: 'text-violet-600 dark:text-violet-400',
                labelClass: 'text-violet-700 dark:text-violet-300',
                countClass:
                    'bg-violet-100 dark:bg-violet-800 text-violet-700 dark:text-violet-200',
            },
            {
                label: 'Returned',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.Returned || 0,
                icon: 'pi pi-refresh',
                containerClass:
                    'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800',
                iconClass: 'text-red-600 dark:text-red-400',
                labelClass: 'text-red-700 dark:text-red-300',
                countClass:
                    'bg-red-100 dark:bg-red-800 text-red-700 dark:text-red-200',
            },
            {
                label: 'Part Returned',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.PartReturned || 0,
                icon: 'pi pi-replay',
                containerClass:
                    'bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800',
                iconClass: 'text-rose-600 dark:text-rose-400',
                labelClass: 'text-rose-700 dark:text-rose-300',
                countClass:
                    'bg-rose-100 dark:bg-rose-800 text-rose-700 dark:text-rose-200',
            },
            {
                label: 'Unshipped',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.Unshipped || 0,
                icon: 'pi pi-times-circle',
                containerClass:
                    'bg-pink-50 dark:bg-pink-900/20 border border-pink-200 dark:border-pink-800',
                iconClass: 'text-pink-600 dark:text-pink-400',
                labelClass: 'text-pink-700 dark:text-pink-300',
                countClass:
                    'bg-pink-100 dark:bg-pink-800 text-pink-700 dark:text-pink-200',
            },
            {
                label: 'Out Of Sync',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.OutOfSync || 0,
                icon: 'pi pi-exclamation-triangle',
                containerClass:
                    'bg-fuchsia-50 dark:bg-fuchsia-900/20 border border-fuchsia-200 dark:border-fuchsia-800',
                iconClass: 'text-fuchsia-600 dark:text-fuchsia-400',
                labelClass: 'text-fuchsia-700 dark:text-fuchsia-300',
                countClass:
                    'bg-fuchsia-100 dark:bg-fuchsia-800 text-fuchsia-700 dark:text-fuchsia-200',
            },
            {
                label: 'Order Closed',
                value:
                    this.quickOutboundOrderData?.OperationalOverview
                        ?.OrderClosed || 0,
                icon: 'pi pi-lock',
                containerClass:
                    'bg-slate-50 dark:bg-slate-900/20 border border-slate-200 dark:border-slate-700',
                iconClass: 'text-slate-600 dark:text-slate-400',
                labelClass: 'text-slate-700 dark:text-slate-300',
                countClass:
                    'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200',
            },
        ].sort((a, b) => {
            const aHasValue = a.value > 0 ? 1 : 0;
            const bHasValue = b.value > 0 ? 1 : 0;

            if (aHasValue !== bHasValue) {
                return bHasValue - aHasValue;
            }

            return b.value - a.value;
        });
    }

    getReturnReport() {
        this.dashboardervice.getQuickOutboundReportReport().subscribe({
            next: (res: any) => {
                this.returnReport = res;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }

    getLoadReport() {
        this.dashboardervice.getQuickOutboundLoadReport().subscribe({
            next: (res: any) => {
                this.loadReport = res;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }

    getQuickOutboundOrderData() {
        this.dashboardervice.getQuickOutboundOrderReport().subscribe({
            next: (response: any) => {
                this.quickOutboundOrderData = response;

                // IMPORTANT
                this.loadStatusData();
            },
            error: (error) => {
                console.error('Quick Outbound Error', error);
            },
        });
    }

    getAsns() {
        this.loading.set(true);
        const subscription = this.dashboardervice
            .getAsnsPage({ Page: 1, PageSize: 5 })
            .pipe()
            .subscribe({
                next: (res: any) => {
                    this.loading.set(false);

                    this.asns.set(res.AsnLines);
                },
            });
    }

    startRefreshTimer() {
        this.interval = setInterval(() => {
            if (this.refreshSeconds > 0) {
                this.refreshSeconds--;
            } else {
                // API CALL
                this.getAsns();

                // Reset Timer
                this.refreshSeconds = 30;
            }
        }, 1000);
    }
}
