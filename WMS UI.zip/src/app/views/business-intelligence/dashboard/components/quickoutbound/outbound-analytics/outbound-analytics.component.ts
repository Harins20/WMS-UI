import { CommonModule } from '@angular/common';
import { Component, DestroyRef, ElementRef, inject, signal, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { LoadingComponent } from '../../../../../../common/components/common-loading/loading.component';
import { MessageService } from 'primeng/api';
import { AuthService } from '../../../../../../common/services';
import { AsnService } from '../../../../../inbound';
import { DashboardService } from '../../../dashboard.service';
import { ChartModule } from 'primeng/chart';
import { FormsModule } from '@angular/forms';
import * as echarts from 'echarts';

export interface InsightItem {
  label: string;
  heading: string;
  total: number;
  growth: string;
  description: string;
  fileName: string;

  icon: string;
  iconBg: string;
  iconColor: string;
  textColor: string;

  trend: string;
}

@Component({
  selector: 'app-outbound-analytics',
  imports: [CommonModule, LoadingComponent, ChartModule, FormsModule],
  templateUrl: './outbound-analytics.component.html',
  styleUrl: './outbound-analytics.component.scss'
})
export class OutboundAnalyticsComponent implements OnInit, OnDestroy {
  private dashboardervice = inject(DashboardService);
  private messageService = inject(MessageService);
  private destoryRef = inject(DestroyRef);
  public authService = inject(AuthService);
  private asnService = inject(AsnService);

  activeQuickTab: string = 'outbound';
  loadReport: any = {
    LoadsOverview: {
      YesterdayLoads: 0,
      TodayLoads: 0,
      Percentage: 0,
    },
    LoadStatusCards: {
      NewLoads: 0,
      OpenLoads: 0,
      LoadedLoads: 0,
      ShippedLoads: 0,
    },
    LoadExecutionStatus: {
      ActiveLoads: 0,
      LoadedToday: 0,
      UnLoadedToday: 0,
    },
  };
  returnReport: any = {
    ReturnOrdersOverview: {
      YesterdayReturns: 0,
      TodayReturns: 0,
      Percentage: 0,
    },
    ReturnStatusOverview: {
      Accepted: 0,
      NewReturns: 0,
      Pending: 0,
      Rejected: 0,
      TotalReturnsToday: 0,
    },
  };
  quickOutboundOrderData: any = {
    BillingSummary: {
      Yesterday: 0,
      Today: 0,
      Percentage: 0,
    },
    OperationalOverview: {
      CreatedInternally: 0,
      CreatedExternally: 0,
      Allocated: 0,
      PartAllocated: 0,
      PartAllocatedPartPicked: 0,
      PartAllocatedPartShipped: 0,
      PartPicked: 0,
      PartPickedPartShipped: 0,
      PickedComplete: 0,
      Loaded: 0,
      PartShipped: 0,
      ShippedComplete: 0,
      Returned: 0,
      PartReturned: 0,
      Unshipped: 0,
      OutOfSync: 0,
      OrderClosed: 0,
      Total: 0,
    },
    OrderAllocationSummary: {
      AllocatedOrders: 0,
      UnallocatedOrders: 0,
    },
    PickPerformanceOverview: {
      PickedOrders: 0,
      UnpickedOrders: 0,
    },
  };

  isOrdersFullscreen = signal<boolean>(false);
  ordersChartType = signal<'radialRing' | 'totalComparison'>('radialRing');
  @ViewChild('ordersEchartContainer') ordersEchartContainer?: ElementRef;
  ordersEchartInstance?: echarts.ECharts;

  isStatusFullscreen = signal<boolean>(false);
  statusChartType = signal<'bar' | 'polar' | 'radar' | 'matrix'>('bar');
  statusChartData: any;
  statusChartOptions: any;

  isAllocationFullscreen = signal<boolean>(false);
  allocationChartType = signal<'donut' | 'stackedBar' | 'radial'>('stackedBar');
  allocationChartData: any;
  allocationChartOptions: any;
  @ViewChild('allocationEchartContainer') allocationEchartContainer?: ElementRef;
  allocationEchartInstance?: echarts.ECharts;

  isPickFullscreen = signal<boolean>(false);
  pickChartType = signal<'fulfillmentGauge' | 'distributionRing'>('distributionRing');
  @ViewChild('pickEchartContainer') pickEchartContainer?: ElementRef;
  pickEchartInstance?: echarts.ECharts;

  isReturnFullscreen = signal<boolean>(false);
  returnChartType = signal<'radar' | 'funnel'>('radar');
  @ViewChild('returnEchartContainer') returnEchartContainer?: ElementRef;
  returnEchartInstance?: echarts.ECharts;

  isLoadsFullscreen = signal<boolean>(false);
  loadsChartType = signal<'statusDonut' | 'executionSummary'>('statusDonut');
  @ViewChild('loadsEchartContainer') loadsEchartContainer?: ElementRef;
  loadsEchartInstance?: echarts.ECharts;

  currentInsight = 0;
  insight: InsightItem[] = [];
  refreshSeconds: number = 30;
  refreshInterval: any;
  interval: any;
  loading = signal(false);
  asns = signal<any[]>([]);
  statusList: any[] = [];

  get yesterdayOrders(): number {
    return Number(this.quickOutboundOrderData?.BillingSummary?.Yesterday ?? 0);
  }

  get todayOrders(): number {
    return Number(this.quickOutboundOrderData?.BillingSummary?.Today ?? 0);
  }

  get ordersDifference(): number {
    return this.todayOrders - this.yesterdayOrders;
  }

  get ordersPercentage(): number {
    const pct = this.quickOutboundOrderData?.BillingSummary?.Percentage;
    if (pct !== undefined && pct !== null) return Number(pct);
    if (this.yesterdayOrders === 0) return 0;
    return Number(((this.ordersDifference / this.yesterdayOrders) * 100).toFixed(1));
  }

  get targetAchievementRatio(): number {
    if (this.yesterdayOrders === 0) return this.todayOrders > 0 ? 100 : 0;
    const ratio = (this.todayOrders / this.yesterdayOrders) * 100;
    return Number(Math.min(ratio, 200).toFixed(1));
  }

  get returnPercentage(): number {
    const pct = Number(this.returnReport?.ReturnOrdersOverview?.Percentage ?? 0);
    return Math.max(0, pct);
  }

  get loadsPercentage(): number {
    const pct = this.loadReport?.LoadsOverview?.Percentage;
    if (pct !== undefined && pct !== null) return Number(pct);
    return 0;
  }

  toggleLoadsFullscreen(): void {
    this.isLoadsFullscreen.update((v) => !v);
    setTimeout(() => {
      this.loadsEchartInstance?.resize();
      window.dispatchEvent(new Event('resize'));
    }, 120);
  }

  setLoadsChartType(type: 'statusDonut' | 'executionSummary'): void {
    this.loadsChartType.set(type);
    this.buildLoadsChart();
  }

  public buildLoadsChart(): void {
    setTimeout(() => {
      this.renderLoadsEchart();
    }, 50);
  }

  renderLoadsEchart(): void {
    const container = this.loadsEchartContainer?.nativeElement;
    if (!container) return;

    if (!this.loadsEchartInstance || this.loadsEchartInstance.isDisposed()) {
      this.loadsEchartInstance = echarts.getInstanceByDom(container) || echarts.init(container);
      window.addEventListener('resize', () => {
        this.loadsEchartInstance?.resize();
      });
    }

    const newLoads = Number(this.loadReport?.LoadStatusCards?.NewLoads ?? 0);
    const openLoads = Number(this.loadReport?.LoadStatusCards?.OpenLoads ?? 0);
    const loadedLoads = Number(this.loadReport?.LoadStatusCards?.LoadedLoads ?? 0);
    const shippedLoads = Number(this.loadReport?.LoadStatusCards?.ShippedLoads ?? 0);
    const yesterdayLoads = Number(this.loadReport?.LoadsOverview?.YesterdayLoads ?? 0);
    const todayLoads = Number(this.loadReport?.LoadsOverview?.TodayLoads ?? 0);
    const activeLoads = Number(this.loadReport?.LoadExecutionStatus?.ActiveLoads ?? 0);
    const loadedToday = Number(this.loadReport?.LoadExecutionStatus?.LoadedToday ?? 0);
    const unloadedToday = Number(this.loadReport?.LoadExecutionStatus?.UnLoadedToday ?? 0);
    const type = this.loadsChartType();

    let option: any = {};

    if (type === 'statusDonut') {
      option = {
        tooltip: {
          trigger: 'item',
          backgroundColor: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.2)',
          textStyle: { color: '#F8FAFC', fontSize: 12 },
          formatter: '{b}: <b>{c}</b> loads ({d}%)'
        },
        legend: {
          show: true,
          position: 'right',
          right: '8%',
          top: 'center',
          orient: 'vertical',
          textStyle: { color: '#94A3B8', fontWeight: 600, fontSize: 11 },
          itemWidth: 10,
          itemHeight: 10,
          itemGap: 12
        },
        series: [
          {
            name: 'Loads Distribution',
            type: 'pie',
            radius: ['52%', '75%'],
            center: ['40%', '50%'],
            avoidLabelOverlap: false,
            padAngle: 3,
            itemStyle: {
              borderRadius: 8
            },
            label: {
              show: false
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 13,
                fontWeight: 'bold',
                color: '#A855F7',
                formatter: '{b}\n{c} loads'
              }
            },
            data: [
              { value: newLoads, name: 'New Loads', itemStyle: { color: '#3B82F6' } },
              { value: openLoads, name: 'Open Loads', itemStyle: { color: '#F59E0B' } },
              { value: loadedLoads, name: 'Loaded Loads', itemStyle: { color: '#A855F7' } },
              { value: shippedLoads, name: 'Shipped Loads', itemStyle: { color: '#10B981' } }
            ]
          }
        ]
      };
    } else if (type === 'executionSummary') {
      option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'shadow' },
          backgroundColor: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.2)',
          textStyle: { color: '#F8FAFC', fontSize: 12 },
          formatter: function(params: any) {
            return `${params[0].name}: <b>${params[0].value.toLocaleString()}</b> loads`;
          }
        },
        grid: {
          left: '4%',
          right: '4%',
          bottom: '8%',
          top: '12%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: ['Yesterday', 'Today', 'Active', 'Loaded', 'Unloaded'],
          axisLine: { show: false },
          axisTick: { show: false },
          axisLabel: { color: '#94A3B8', fontWeight: 600, fontSize: 11 }
        },
        yAxis: {
          type: 'value',
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.1)' } },
          axisLabel: { color: '#94A3B8', fontWeight: 600, fontSize: 11 }
        },
        series: [
          {
            name: 'Execution Volumes',
            type: 'bar',
            barWidth: 24,
            itemStyle: {
              color: function (params: any) {
                const colors = ['#6366F1', '#10B981', '#A855F7', '#3B82F6', '#F59E0B'];
                return colors[params.dataIndex];
              },
              borderRadius: 6
            },
            data: [yesterdayLoads, todayLoads, activeLoads, loadedToday, unloadedToday]
          }
        ]
      };
    }

    this.loadsEchartInstance.setOption(option, true);
    this.loadsEchartInstance.resize();
  }

  toggleOrdersFullscreen(): void {
    this.isOrdersFullscreen.update((v) => !v);
    setTimeout(() => {
      this.ordersEchartInstance?.resize();
      window.dispatchEvent(new Event('resize'));
    }, 120);
  }

  setOrdersChartType(type: 'radialRing' | 'totalComparison'): void {
    this.ordersChartType.set(type);
    this.buildOrdersChart();
  }

  toggleStatusFullscreen(): void {
    this.isStatusFullscreen.update((v) => !v);
    setTimeout(() => window.dispatchEvent(new Event('resize')), 120);
  }

  setStatusChartType(type: 'bar' | 'polar' | 'radar' | 'matrix'): void {
    this.statusChartType.set(type);
    this.buildStatusChart();
  }

  toggleAllocationFullscreen(): void {
    this.isAllocationFullscreen.update((v) => !v);
    setTimeout(() => {
      this.allocationEchartInstance?.resize();
      window.dispatchEvent(new Event('resize'));
    }, 120);
  }

  setAllocationChartType(type: 'donut' | 'stackedBar' | 'radial'): void {
    this.allocationChartType.set(type);
    this.buildAllocationChart();
  }

  get allocatedOrdersCount(): number {
    return Number(this.quickOutboundOrderData?.OrderAllocationSummary?.AllocatedOrders ?? 0);
  }

  get unallocatedOrdersCount(): number {
    return Number(this.quickOutboundOrderData?.OrderAllocationSummary?.UnallocatedOrders ?? 0);
  }

  get totalAllocationOrders(): number {
    return this.allocatedOrdersCount + this.unallocatedOrdersCount;
  }

  get allocationRatio(): number {
    if (this.totalAllocationOrders === 0) return 0;
    return Number(((this.allocatedOrdersCount / this.totalAllocationOrders) * 100).toFixed(1));
  }

  public buildAllocationChart(): void {
    const allocated = this.allocatedOrdersCount;
    const unallocated = this.unallocatedOrdersCount;
    const type = this.allocationChartType();

    if (type === 'donut') {
      this.allocationChartData = {
        labels: ['Allocated Orders', 'Unallocated Orders'],
        datasets: [
          {
            data: [allocated, unallocated],
            backgroundColor: ['#10B981', '#F43F5E'],
            hoverBackgroundColor: ['#059669', '#E11D48'],
            borderWidth: 3,
            borderColor: '#ffffff',
            borderRadius: 8,
          },
        ],
      };
      this.allocationChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '72%',
        plugins: {
          legend: {
            display: true,
            position: 'bottom',
            labels: { color: '#94A3B8', font: { size: 12, weight: '600' }, usePointStyle: true, padding: 14 }
          },
          tooltip: {
            enabled: true,
            backgroundColor: 'rgba(15, 23, 42, 0.95)',
            titleColor: '#F8FAFC',
            bodyColor: '#CBD5E1',
            padding: 12,
            cornerRadius: 10,
            callbacks: {
              label: (context: any) => ` ${context.label}: ${context.raw.toLocaleString()} orders`
            }
          }
        }
      };
    } else if (type === 'stackedBar') {
      this.allocationChartData = {
        labels: ['Allocation Share'],
        datasets: [
          {
            label: 'Allocated Orders',
            data: [allocated],
            backgroundColor: '#10B981',
            hoverBackgroundColor: '#059669',
            borderRadius: 8,
            borderSkipped: false,
            barThickness: 28,
          },
          {
            label: 'Unallocated Orders',
            data: [unallocated],
            backgroundColor: '#F43F5E',
            hoverBackgroundColor: '#E11D48',
            borderRadius: 8,
            borderSkipped: false,
            barThickness: 28,
          }
        ]
      };
      this.allocationChartOptions = {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'bottom',
            labels: { color: '#94A3B8', font: { size: 12, weight: '600' }, usePointStyle: true, padding: 14 }
          },
          tooltip: {
            enabled: true,
            backgroundColor: 'rgba(15, 23, 42, 0.95)',
            titleColor: '#F8FAFC',
            bodyColor: '#CBD5E1',
            padding: 12,
            cornerRadius: 10,
            callbacks: {
              label: (context: any) => ` ${context.dataset.label}: ${context.raw.toLocaleString()} orders`
            }
          }
        },
        scales: {
          x: {
            stacked: true,
            grid: { color: 'rgba(148, 163, 184, 0.15)' },
            ticks: { color: '#94A3B8', font: { size: 11, weight: '600' } }
          },
          y: {
            stacked: true,
            grid: { display: false },
            ticks: { color: '#94A3B8', font: { size: 12, weight: '700' } }
          }
        }
      };
    } else if (type === 'radial') {
      setTimeout(() => {
        this.renderAllocationEchart();
      }, 50);
    }
  }

  renderAllocationEchart(): void {
    const container = this.allocationEchartContainer?.nativeElement;
    if (!container) return;

    if (!this.allocationEchartInstance || this.allocationEchartInstance.isDisposed()) {
      this.allocationEchartInstance = echarts.getInstanceByDom(container) || echarts.init(container);
      window.addEventListener('resize', () => {
        this.allocationEchartInstance?.resize();
      });
    }

    const ratio = this.allocationRatio;

    const option: any = {
      tooltip: {
        backgroundColor: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.2)',
        textStyle: { color: '#F8FAFC', fontSize: 12 },
        formatter: () => `Allocation Rate: <b>${ratio}%</b>`
      },
      series: [
        {
          type: 'gauge',
          startAngle: 90,
          endAngle: -270,
          pointer: { show: false },
          progress: {
            show: true,
            overlap: false,
            roundCap: true,
            clip: false,
            itemStyle: {
              color: {
                type: 'linear',
                x: 0, y: 0, x2: 1, y2: 1,
                colorStops: [
                  { offset: 0, color: '#10B981' },
                  { offset: 1, color: '#14B8A6' }
                ]
              }
            }
          },
          axisLine: {
            lineStyle: {
              width: 18,
              color: [[1, 'rgba(244, 63, 94, 0.2)']]
            }
          },
          splitLine: { show: false },
          axisTick: { show: false },
          axisLabel: { show: false },
          data: [
            {
              value: ratio,
              name: 'Allocation Rate',
              title: {
                offsetCenter: ['0%', '-18%'],
                fontSize: 12,
                fontWeight: 600,
                color: '#94A3B8'
              },
              detail: {
                valueAnimation: true,
                offsetCenter: ['0%', '16%'],
                fontSize: 24,
                fontWeight: 'bold',
                color: '#10B981',
                formatter: '{value}%'
              }
            }
          ]
        }
      ]
    };

    this.allocationEchartInstance.setOption(option, true);
    this.allocationEchartInstance.resize();
  }

  togglePickFullscreen(): void {
    this.isPickFullscreen.update((v) => !v);
    setTimeout(() => {
      this.pickEchartInstance?.resize();
      window.dispatchEvent(new Event('resize'));
    }, 120);
  }

  setPickChartType(type: 'fulfillmentGauge' | 'distributionRing'): void {
    this.pickChartType.set(type);
    this.buildPickChart();
  }

  get pickedOrdersCount(): number {
    return Number(this.quickOutboundOrderData?.PickPerformanceOverview?.PickedOrders ?? 0);
  }

  get unpickedOrdersCount(): number {
    return Number(this.quickOutboundOrderData?.PickPerformanceOverview?.UnpickedOrders ?? 0);
  }

  get totalPickOrders(): number {
    return this.pickedOrdersCount + this.unpickedOrdersCount;
  }

  get pickRate(): number {
    if (this.totalPickOrders === 0) return 0;
    return Number(((this.pickedOrdersCount / this.totalPickOrders) * 100).toFixed(1));
  }

  public buildPickChart(): void {
    setTimeout(() => {
      this.renderPickEchart();
    }, 50);
  }

  renderPickEchart(): void {
    const container = this.pickEchartContainer?.nativeElement;
    if (!container) return;

    if (!this.pickEchartInstance || this.pickEchartInstance.isDisposed()) {
      this.pickEchartInstance = echarts.getInstanceByDom(container) || echarts.init(container);
      window.addEventListener('resize', () => {
        this.pickEchartInstance?.resize();
      });
    }

    const picked = this.pickedOrdersCount;
    const unpicked = this.unpickedOrdersCount;
    const rate = this.pickRate;
    const type = this.pickChartType();

    let option: any = {};

    if (type === 'fulfillmentGauge') {
      option = {
        series: [
          {
            type: 'gauge',
            startAngle: 180,
            endAngle: 0,
            min: 0,
            max: 100,
            radius: '95%',
            center: ['50%', '65%'],
            splitNumber: 5,
            itemStyle: {
              color: '#10B981',
              shadowColor: 'rgba(16, 185, 129, 0.3)',
              shadowBlur: 8
            },
            progress: {
              show: true,
              roundCap: true,
              width: 16
            },
            pointer: {
              show: false
            },
            axisLine: {
              roundCap: true,
              lineStyle: {
                width: 16,
                color: [[1, 'rgba(244, 63, 94, 0.15)']]
              }
            },
            axisTick: { show: false },
            splitLine: { show: false },
            axisLabel: { show: false },
            title: {
              show: true,
              offsetCenter: [0, '-22%'],
              fontSize: 11,
              color: '#94A3B8',
              fontWeight: 'bold'
            },
            detail: {
              valueAnimation: true,
              offsetCenter: [0, '15%'],
              fontSize: 24,
              fontWeight: 'bold',
              color: '#10B981',
              formatter: '{value}%'
            },
            data: [
              {
                value: rate,
                name: 'Pick Fulfillment'
              }
            ]
          }
        ]
      };
    } else if (type === 'distributionRing') {
      option = {
        tooltip: {
          trigger: 'item',
          backgroundColor: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.2)',
          textStyle: { color: '#F8FAFC', fontSize: 12 },
          formatter: '{b}: <b>{c}</b> ({d}%)'
        },
        legend: {
          show: true,
          bottom: '0%',
          left: 'center',
          textStyle: { color: '#94A3B8', fontWeight: 600, fontSize: 11 },
          itemWidth: 10,
          itemHeight: 10
        },
        series: [
          {
            name: 'Pick Distribution',
            type: 'pie',
            radius: ['52%', '75%'],
            center: ['50%', '42%'],
            avoidLabelOverlap: false,
            padAngle: 4,
            itemStyle: {
              borderRadius: 8
            },
            label: {
              show: false
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 13,
                fontWeight: 'bold',
                color: '#10B981',
                formatter: '{b}\n{c} orders'
              }
            },
            data: [
              {
                value: picked,
                name: 'Picked Orders',
                itemStyle: { color: '#10B981' }
              },
              {
                value: unpicked,
                name: 'Unpicked Pending',
                itemStyle: { color: '#F43F5E' }
              }
            ]
          }
        ]
      };
    }

    this.pickEchartInstance.setOption(option, true);
    this.pickEchartInstance.resize();
  }

  toggleReturnFullscreen(): void {
    this.isReturnFullscreen.update((v) => !v);
    setTimeout(() => {
      this.returnEchartInstance?.resize();
      window.dispatchEvent(new Event('resize'));
    }, 120);
  }

  setReturnChartType(type: 'radar' | 'funnel'): void {
    this.returnChartType.set(type);
    this.buildReturnChart();
  }

  public buildReturnChart(): void {
    setTimeout(() => {
      this.renderReturnEchart();
    }, 50);
  }

  renderReturnEchart(): void {
    const container = this.returnEchartContainer?.nativeElement;
    if (!container) return;

    if (!this.returnEchartInstance || this.returnEchartInstance.isDisposed()) {
      this.returnEchartInstance = echarts.getInstanceByDom(container) || echarts.init(container);
      window.addEventListener('resize', () => {
        this.returnEchartInstance?.resize();
      });
    }

    const acceptedVal = Number(this.returnReport?.ReturnStatusOverview?.Accepted ?? 0);
    const newVal = Number(this.returnReport?.ReturnStatusOverview?.NewReturns ?? 0);
    const pendingVal = Number(this.returnReport?.ReturnStatusOverview?.Pending ?? 0);
    const rejectedVal = Number(this.returnReport?.ReturnStatusOverview?.Rejected ?? 0);
    const type = this.returnChartType();

    let option: any = {};

    if (type === 'radar') {
      option = {
        tooltip: {
          trigger: 'item',
          backgroundColor: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.2)',
          textStyle: { color: '#F8FAFC', fontSize: 12 }
        },
        radar: {
          indicator: [
            { name: 'New Requests', max: Math.max(newVal, acceptedVal, pendingVal, rejectedVal, 10) * 1.1 },
            { name: 'Pending Review', max: Math.max(newVal, acceptedVal, pendingVal, rejectedVal, 10) * 1.1 },
            { name: 'Accepted', max: Math.max(newVal, acceptedVal, pendingVal, rejectedVal, 10) * 1.1 },
            { name: 'Rejected', max: Math.max(newVal, acceptedVal, pendingVal, rejectedVal, 10) * 1.1 }
          ],
          radius: '75%',
          center: ['50%', '52%'],
          axisName: {
            color: '#94A3B8',
            fontSize: 10,
            fontWeight: 'bold'
          },
          splitArea: {
            areaStyle: {
              color: ['rgba(255, 138, 0, 0.02)', 'rgba(255, 138, 0, 0.06)', 'rgba(255, 138, 0, 0.08)', 'rgba(255, 138, 0, 0.03)']
            }
          },
          splitLine: {
            lineStyle: {
              color: 'rgba(148, 163, 184, 0.15)'
            }
          },
          axisLine: {
            lineStyle: {
              color: 'rgba(148, 163, 184, 0.15)'
            }
          }
        },
        series: [
          {
            name: 'Return Process status',
            type: 'radar',
            data: [
              {
                value: [newVal, pendingVal, acceptedVal, rejectedVal],
                name: 'Return Volume',
                itemStyle: { color: '#EA580C' },
                lineStyle: { width: 2.5, color: '#EA580C' },
                areaStyle: { color: 'rgba(234, 88, 12, 0.25)' }
              }
            ]
          }
        ]
      };
    } else if (type === 'funnel') {
      option = {
        tooltip: {
          trigger: 'item',
          backgroundColor: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.2)',
          textStyle: { color: '#F8FAFC', fontSize: 12 },
          formatter: '{b}: <b>{c}</b> returns ({d}%)'
        },
        legend: {
          show: true,
          bottom: '0%',
          left: 'center',
          textStyle: { color: '#94A3B8', fontWeight: 600, fontSize: 11 },
          itemWidth: 10,
          itemHeight: 10
        },
        series: [
          {
            name: 'Return Pipeline',
            type: 'funnel',
            left: '12%',
            top: '8%',
            bottom: '18%',
            width: '76%',
            min: 0,
            minSize: '12%',
            maxSize: '100%',
            sort: 'descending',
            gap: 4,
            label: {
              show: true,
              position: 'inside',
              formatter: '{b}: {c}',
              fontWeight: 'bold',
              color: '#fff',
              fontSize: 10
            },
            itemStyle: {
              borderColor: 'transparent',
              borderWidth: 0,
              borderRadius: 6
            },
            data: [
              { value: newVal, name: 'New Requests', itemStyle: { color: '#3B82F6' } },
              { value: pendingVal, name: 'Pending Review', itemStyle: { color: '#F59E0B' } },
              { value: acceptedVal, name: 'Accepted', itemStyle: { color: '#10B981' } },
              { value: rejectedVal, name: 'Rejected', itemStyle: { color: '#EF4444' } }
            ]
          }
        ]
      };
    }

    this.returnEchartInstance.setOption(option, true);
    this.returnEchartInstance.resize();
  }

  get totalStatusOrders(): number {
    if (this.quickOutboundOrderData?.OperationalOverview?.Total) {
      return Number(this.quickOutboundOrderData.OperationalOverview.Total);
    }
    return this.statusList.reduce((acc, curr) => acc + Number(curr.value || 0), 0);
  }

  getStatusPercentage(value: number): number {
    const total = this.totalStatusOrders;
    if (!total || total === 0) return 0;
    return Number(((value / total) * 100).toFixed(1));
  }

  getStatusProgressBarClass(containerClass: string): string {
    if (!containerClass) return 'bg-indigo-500';
    if (containerClass.includes('emerald')) return 'bg-emerald-500';
    if (containerClass.includes('blue')) return 'bg-blue-500';
    if (containerClass.includes('indigo')) return 'bg-indigo-500';
    if (containerClass.includes('purple')) return 'bg-purple-500';
    if (containerClass.includes('red') || containerClass.includes('rose')) return 'bg-rose-500';
    if (containerClass.includes('amber') || containerClass.includes('yellow') || containerClass.includes('orange')) return 'bg-amber-500';
    if (containerClass.includes('cyan') || containerClass.includes('sky') || containerClass.includes('teal')) return 'bg-teal-500';
    return 'bg-indigo-500';
  }

  public buildStatusChart(): void {
    const activeStatuses = this.statusList.filter(s => Number(s.value) >= 0);
    const labels = activeStatuses.map((s) => s.label);
    const data = activeStatuses.map((s) => Number(s.value || 0));
    const type = this.statusChartType();

    const colorPalette = [
      '#3B82F6', '#8B5CF6', '#6366F1', '#A855F7', '#10B981', '#F97316',
      '#F59E0B', '#64748B', '#06B6D4', '#0EA5E9', '#14B8A6', '#84CC16',
      '#EF4444', '#F43F5E', '#EC4899', '#D946EF', '#94A3B8'
    ];

    if (type === 'bar') {
      this.statusChartData = {
        labels: labels,
        datasets: [
          {
            label: 'Order Count',
            data: data,
            backgroundColor: colorPalette.slice(0, labels.length),
            hoverBackgroundColor: colorPalette.slice(0, labels.length),
            borderRadius: 8,
            borderSkipped: 'bottom',
          },
        ],
      };
      this.statusChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
          tooltip: {
            enabled: true,
            backgroundColor: 'rgba(15, 23, 42, 0.95)',
            titleColor: '#F8FAFC',
            bodyColor: '#CBD5E1',
            padding: 12,
            cornerRadius: 10,
            callbacks: {
              label: (context: any) => ` ${context.label}: ${context.raw.toLocaleString()} orders`
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: {
              color: '#94A3B8',
              font: { size: 10, weight: '700' },
              maxRotation: 45,
              minRotation: 45,
              autoSkip: false
            }
          },
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(148, 163, 184, 0.15)' },
            ticks: {
              color: '#94A3B8',
              font: { size: 11, weight: '600' }
            }
          }
        }
      };
    } else if (type === 'polar') {
      this.statusChartData = {
        labels: labels,
        datasets: [
          {
            data: data,
            backgroundColor: colorPalette.map(c => c + 'D9'),
            hoverBackgroundColor: colorPalette,
            borderWidth: 2,
            borderColor: '#ffffff',
          },
        ],
      };
      this.statusChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'right',
            labels: { color: '#94A3B8', font: { size: 11, weight: '600' }, usePointStyle: true, padding: 12 }
          },
          tooltip: {
            enabled: true,
            backgroundColor: 'rgba(15, 23, 42, 0.95)',
            titleColor: '#F8FAFC',
            bodyColor: '#CBD5E1',
            padding: 12,
            cornerRadius: 10,
            callbacks: {
              label: (context: any) => ` ${context.label}: ${context.raw.toLocaleString()} orders`
            }
          }
        },
        scales: {
          r: {
            ticks: { display: false },
            grid: { color: 'rgba(148, 163, 184, 0.15)' }
          }
        }
      };
    } else if (type === 'radar') {
      this.statusChartData = {
        labels: labels,
        datasets: [
          {
            label: 'Order Volume by Status',
            data: data,
            borderColor: '#6366F1',
            backgroundColor: 'rgba(99, 102, 241, 0.35)',
            pointBackgroundColor: '#6366F1',
            pointBorderColor: '#ffffff',
            pointHoverBackgroundColor: '#ffffff',
            pointHoverBorderColor: '#6366F1',
            borderWidth: 2.5,
          },
        ],
      };
      this.statusChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: { color: '#94A3B8', font: { size: 12, weight: '600' }, usePointStyle: true }
          },
          tooltip: {
            enabled: true,
            backgroundColor: 'rgba(15, 23, 42, 0.95)',
            titleColor: '#F8FAFC',
            bodyColor: '#CBD5E1',
            padding: 12,
            cornerRadius: 10,
          }
        },
        scales: {
          r: {
            angleLines: { color: 'rgba(148, 163, 184, 0.2)' },
            grid: { color: 'rgba(148, 163, 184, 0.2)' },
            pointLabels: { color: '#94A3B8', font: { size: 10, weight: '600' } },
            ticks: { display: false }
          }
        }
      };
    }
  }

  private buildOrdersChart(): void {
    setTimeout(() => {
      this.renderOrdersEchart();
    }, 50);
  }

  renderOrdersEchart(): void {
    const container = this.ordersEchartContainer?.nativeElement;
    if (!container) return;

    if (!this.ordersEchartInstance || this.ordersEchartInstance.isDisposed()) {
      this.ordersEchartInstance = echarts.getInstanceByDom(container) || echarts.init(container);
      window.addEventListener('resize', () => {
        this.ordersEchartInstance?.resize();
      });
    }

    const yVal = this.yesterdayOrders;
    const tVal = this.todayOrders;
    const type = this.ordersChartType();

    const timeLabels = ['08:00 AM', '11:00 AM', '02:00 PM', '05:00 PM', 'Total Volume'];
    const yTrack = [
      Math.round(yVal * 0.20),
      Math.round(yVal * 0.45),
      Math.round(yVal * 0.70),
      Math.round(yVal * 0.90),
      yVal
    ];
    const tTrack = [
      Math.round(tVal * 0.25),
      Math.round(tVal * 0.50),
      Math.round(tVal * 0.75),
      Math.round(tVal * 0.92),
      tVal
    ];

    let option: any = {};

    if (type === 'radialRing') {
      const maxVal = Math.max(yVal, tVal, 1);
      
      option = {
        tooltip: {
          trigger: 'item',
          backgroundColor: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.2)',
          textStyle: { color: '#F8FAFC', fontSize: 12 },
          formatter: '{b}: <b>{c}</b> orders'
        },
        angleAxis: {
          max: maxVal * 1.15,
          startAngle: 90,
          clockwise: true,
          axisLine: { show: false },
          axisTick: { show: false },
          axisLabel: { show: false },
          splitLine: { show: false }
        },
        radiusAxis: {
          type: 'category',
          data: ['Yesterday Baseline', 'Today Actual'],
          axisLine: { show: false },
          axisTick: { show: false },
          axisLabel: {
            show: true,
            color: '#94A3B8',
            fontSize: 11,
            fontWeight: 'bold',
            interval: 0
          }
        },
        polar: {
          radius: ['45%', '85%'],
          center: ['50%', '50%']
        },
        series: [
          {
            type: 'bar',
            data: [
              {
                value: yVal,
                itemStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                    { offset: 0, color: '#6366F1' },
                    { offset: 1, color: '#4F46E5' }
                  ]),
                  borderRadius: 10
                }
              },
              {
                value: tVal,
                itemStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                    { offset: 0, color: '#10B981' },
                    { offset: 1, color: '#059669' }
                  ]),
                  borderRadius: 10
                }
              }
            ],
            coordinateSystem: 'polar',
            barWidth: 14,
            showBackground: true,
            backgroundStyle: {
              color: 'rgba(148, 163, 184, 0.1)'
            }
          }
        ]
      };
    } else if (type === 'totalComparison') {
      option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'shadow' },
          backgroundColor: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.2)',
          textStyle: { color: '#F8FAFC', fontSize: 12 },
          formatter: function(params: any) {
            let res = `<div class="font-bold text-xs mb-1.5">${params[0].name}</div>`;
            params.forEach((p: any) => {
              res += `<div class="flex items-center gap-2 mb-1">
                <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background-color:${p.color}"></span>
                <span>${p.seriesName}:</span>
                <span class="font-extrabold ml-auto">${p.value.toLocaleString()} orders</span>
              </div>`;
            });
            return res;
          }
        },
        legend: {
          show: true,
          top: '0%',
          left: 'center',
          textStyle: { color: '#94A3B8', fontWeight: 600, fontSize: 12 },
          itemWidth: 12,
          itemHeight: 12
        },
        grid: {
          left: '6%',
          right: '6%',
          bottom: '8%',
          top: '16%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: ['Volume Comparison'],
          axisLine: { show: false },
          axisTick: { show: false },
          axisLabel: { color: '#94A3B8', fontWeight: 600, fontSize: 11 }
        },
        yAxis: {
          type: 'value',
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.1)' } },
          axisLabel: { color: '#94A3B8', fontWeight: 600, fontSize: 11 }
        },
        series: [
          {
            name: 'Yesterday Baseline',
            type: 'bar',
            barWidth: 40,
            itemStyle: {
              color: 'rgba(99, 102, 241, 0.15)',
              borderColor: '#6366F1',
              borderWidth: 2.5,
              borderRadius: 8
            },
            data: [yVal]
          },
          {
            name: 'Today Actual',
            type: 'bar',
            barWidth: 20,
            barGap: '-75%',
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: '#10B981' },
                { offset: 1, color: '#059669' }
              ]),
              borderRadius: 6
            },
            data: [tVal]
          }
        ]
      };
    }

    this.ordersEchartInstance.setOption(option, true);
    this.ordersEchartInstance.resize();
  }

  ngOnInit() {
    this.loadStatusData();
    this.buildOrdersChart();
    this.buildStatusChart();
    this.buildAllocationChart();
    this.buildPickChart();
    this.buildLoadsChart();
    this.buildReturnChart();
    this.fetchData();
    this.startRefreshTimer();
    this.refreshInterval = setInterval(() => {
      if (this.insight.length > 0) {
        this.currentInsight =
          (this.currentInsight + 1) % this.insight.length;
      }
    }, 4000);
  }

  ngOnDestroy() {
    if (this.interval) {
      clearInterval(this.interval);
    }
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
    this.ordersEchartInstance?.dispose();
    this.allocationEchartInstance?.dispose();
    this.pickEchartInstance?.dispose();
    this.loadsEchartInstance?.dispose();
    this.returnEchartInstance?.dispose();
  }

  fetchData(isSilent: boolean = false) {
    if (!isSilent) {
      this.loading.set(true);
    }
    let pending = 4;
    const checkDone = () => {
      pending--;
      if (pending <= 0) {
        this.loading.set(false);
      }
    };

    this.getQuickOutboundOrderData(checkDone);
    this.getLoadReport(checkDone);
    this.getReturnReport(checkDone);
    this.getAsns(checkDone);
  }

  loadStatusData() {
    this.statusList = [
      {
        label: 'Created Internally',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.CreatedInternally || 0,
        icon: 'pi pi-file',
        containerClass:
          'bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800',
        iconClass: 'text-blue-600 dark:text-blue-400',
        labelClass: 'text-blue-700 dark:text-blue-300',
        countClass:
          'bg-blue-100 dark:bg-blue-800 text-blue-700 dark:text-blue-200',
      },
      {
        label: 'Created Externally',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.CreatedExternally || 0,
        icon: 'pi pi-globe',
        containerClass:
          'bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800',
        iconClass: 'text-indigo-600 dark:text-indigo-400',
        labelClass: 'text-indigo-700 dark:text-indigo-300',
        countClass:
          'bg-indigo-100 dark:bg-indigo-800 text-indigo-700 dark:text-indigo-200',
      },
      {
        label: 'Allocated',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.Allocated || 0,
        icon: 'pi pi-box',
        containerClass:
          'bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800',
        iconClass: 'text-emerald-600 dark:text-emerald-400',
        labelClass: 'text-emerald-700 dark:text-emerald-300',
        countClass:
          'bg-emerald-100 dark:bg-emerald-800 text-emerald-700 dark:text-emerald-200',
      },
      {
        label: 'Part Allocated',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.PartAllocated || 0,
        icon: 'pi pi-inbox',
        containerClass:
          'bg-cyan-50 dark:bg-cyan-900/20 border border-cyan-200 dark:border-cyan-800',
        iconClass: 'text-cyan-600 dark:text-cyan-400',
        labelClass: 'text-cyan-700 dark:text-cyan-300',
        countClass:
          'bg-cyan-100 dark:bg-cyan-800 text-cyan-700 dark:text-cyan-200',
      },
      {
        label: 'Part Allocated / Part Picked',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.PartAllocatedPartPicked || 0,
        icon: 'pi pi-arrow-right-arrow-left',
        containerClass:
          'bg-sky-50 dark:bg-sky-900/20 border border-sky-200 dark:border-sky-800',
        iconClass: 'text-sky-600 dark:text-sky-400',
        labelClass: 'text-sky-700 dark:text-sky-300',
        countClass:
          'bg-sky-100 dark:bg-sky-800 text-sky-700 dark:text-sky-200',
      },
      {
        label: 'Part Allocated / Part Shipped',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.PartAllocatedPartShipped || 0,
        icon: 'pi pi-send',
        containerClass:
          'bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800',
        iconClass: 'text-purple-600 dark:text-purple-400',
        labelClass: 'text-purple-700 dark:text-purple-300',
        countClass:
          'bg-purple-100 dark:bg-purple-800 text-purple-700 dark:text-purple-200',
      },
      {
        label: 'Part Picked',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.PartPicked || 0,
        icon: 'pi pi-shopping-bag',
        containerClass:
          'bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800',
        iconClass: 'text-amber-600 dark:text-amber-400',
        labelClass: 'text-amber-700 dark:text-amber-300',
        countClass:
          'bg-amber-100 dark:bg-amber-800 text-amber-700 dark:text-amber-200',
      },
      {
        label: 'Part Picked / Part Shipped',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.PartPickedPartShipped || 0,
        icon: 'pi pi-shopping-cart',
        containerClass:
          'bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800',
        iconClass: 'text-orange-600 dark:text-orange-400',
        labelClass: 'text-orange-700 dark:text-orange-300',
        countClass:
          'bg-orange-100 dark:bg-orange-800 text-orange-700 dark:text-orange-200',
      },
      {
        label: 'Picked Complete',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.PickedComplete || 0,
        icon: 'pi pi-check-circle',
        containerClass:
          'bg-teal-50 dark:bg-teal-900/20 border border-teal-200 dark:border-teal-800',
        iconClass: 'text-teal-600 dark:text-teal-400',
        labelClass: 'text-teal-700 dark:text-teal-300',
        countClass:
          'bg-teal-100 dark:bg-teal-800 text-teal-700 dark:text-teal-200',
      },
      {
        label: 'Loaded',
        value:
          this.quickOutboundOrderData?.OperationalOverview?.Loaded ||
          0,
        icon: 'pi pi-truck',
        containerClass:
          'bg-lime-50 dark:bg-lime-900/20 border border-lime-200 dark:border-lime-800',
        iconClass: 'text-lime-600 dark:text-lime-400',
        labelClass: 'text-lime-700 dark:text-lime-300',
        countClass:
          'bg-lime-100 dark:bg-lime-800 text-lime-700 dark:text-lime-200',
      },
      {
        label: 'Part Shipped',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.PartShipped || 0,
        icon: 'pi pi-send',
        containerClass:
          'bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800',
        iconClass: 'text-yellow-600 dark:text-yellow-400',
        labelClass: 'text-yellow-700 dark:text-yellow-300',
        countClass:
          'bg-yellow-100 dark:bg-yellow-800 text-yellow-700 dark:text-yellow-200',
      },
      {
        label: 'Shipped Complete',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.ShippedComplete || 0,
        icon: 'pi pi-truck',
        containerClass:
          'bg-violet-50 dark:bg-violet-900/20 border border-violet-200 dark:border-violet-800',
        iconClass: 'text-violet-600 dark:text-violet-400',
        labelClass: 'text-violet-700 dark:text-violet-300',
        countClass:
          'bg-violet-100 dark:bg-violet-800 text-violet-700 dark:text-violet-200',
      },
      {
        label: 'Returned',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.Returned || 0,
        icon: 'pi pi-refresh',
        containerClass:
          'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800',
        iconClass: 'text-red-600 dark:text-red-400',
        labelClass: 'text-red-700 dark:text-red-300',
        countClass:
          'bg-red-100 dark:bg-red-800 text-red-700 dark:text-red-200',
      },
      {
        label: 'Part Returned',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.PartReturned || 0,
        icon: 'pi pi-replay',
        containerClass:
          'bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800',
        iconClass: 'text-rose-600 dark:text-rose-400',
        labelClass: 'text-rose-700 dark:text-rose-300',
        countClass:
          'bg-rose-100 dark:bg-rose-800 text-rose-700 dark:text-rose-200',
      },
      {
        label: 'Unshipped',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.Unshipped || 0,
        icon: 'pi pi-times-circle',
        containerClass:
          'bg-pink-50 dark:bg-pink-900/20 border border-pink-200 dark:border-pink-800',
        iconClass: 'text-pink-600 dark:text-pink-400',
        labelClass: 'text-pink-700 dark:text-pink-300',
        countClass:
          'bg-pink-100 dark:bg-pink-800 text-pink-700 dark:text-pink-200',
      },
      {
        label: 'Out Of Sync',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.OutOfSync || 0,
        icon: 'pi pi-exclamation-triangle',
        containerClass:
          'bg-fuchsia-50 dark:bg-fuchsia-900/20 border border-fuchsia-200 dark:border-fuchsia-800',
        iconClass: 'text-fuchsia-600 dark:text-fuchsia-400',
        labelClass: 'text-fuchsia-700 dark:text-fuchsia-300',
        countClass:
          'bg-fuchsia-100 dark:bg-fuchsia-800 text-fuchsia-700 dark:text-fuchsia-200',
      },
      {
        label: 'Order Closed',
        value:
          this.quickOutboundOrderData?.OperationalOverview
            ?.OrderClosed || 0,
        icon: 'pi pi-lock',
        containerClass:
          'bg-slate-50 dark:bg-slate-900/20 border border-slate-200 dark:border-slate-700',
        iconClass: 'text-slate-600 dark:text-slate-400',
        labelClass: 'text-slate-700 dark:text-slate-300',
        countClass:
          'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200',
      },
    ].sort((a, b) => {
      const aHasValue = a.value > 0 ? 1 : 0;
      const bHasValue = b.value > 0 ? 1 : 0;

      if (aHasValue !== bHasValue) {
        return bHasValue - aHasValue;
      }

      return b.value - a.value;
    });

    this.buildStatusChart();
  }

  getReturnReport(cb?: () => void) {
    this.dashboardervice.getQuickOutboundReportReport().subscribe({
      next: (res: any) => {
        this.returnReport = res || this.returnReport;
        this.buildReturnChart();
        if (cb) cb();
      },
      error: (err) => {
        console.error('Quick Outbound Return Report Error:', err);
        this.buildReturnChart();
        if (cb) cb();
      },
    });
  }

  getLoadReport(cb?: () => void) {
    this.dashboardervice.getQuickOutboundLoadReport().subscribe({
      next: (res: any) => {
        this.loadReport = res || this.loadReport;
        this.buildLoadsChart();
        if (cb) cb();
      },
      error: (err) => {
        console.error('Quick Outbound Load Report Error:', err);
        this.buildLoadsChart();
        if (cb) cb();
      },
    });
  }

  getQuickOutboundOrderData(cb?: () => void) {
    this.dashboardervice.getQuickOutboundOrderReport().subscribe({
      next: (response: any) => {
        this.quickOutboundOrderData = response || this.quickOutboundOrderData;

        // IMPORTANT
        this.loadStatusData();
        this.buildOrdersChart();
        this.buildAllocationChart();
        this.buildPickChart();
        if (cb) cb();
      },
      error: (error) => {
        console.error('Quick Outbound Order Report Error:', error);
        this.loadStatusData();
        this.buildOrdersChart();
        this.buildAllocationChart();
        this.buildPickChart();
        if (cb) cb();
      },
    });
  }

  getAsns(cb?: () => void) {
    this.dashboardervice
      .getAsnsPage({ Page: 1, PageSize: 5 })
      .subscribe({
        next: (res: any) => {
          this.asns.set(res?.AsnLines || []);
          if (cb) cb();
        },
        error: (err) => {
          console.error('ASNs Page Error:', err);
          if (cb) cb();
        },
      });
  }

  startRefreshTimer() {
    if (this.interval) clearInterval(this.interval);
    this.interval = setInterval(() => {
      if (this.refreshSeconds > 0) {
        this.refreshSeconds--;
      } else {
        // API CALL - Silent refresh
        this.fetchData(true);

        // Reset Timer
        this.refreshSeconds = 30;
      }
    }, 1000);
  }
}
