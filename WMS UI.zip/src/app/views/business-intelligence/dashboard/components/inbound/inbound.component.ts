import { DestroyRef, inject, signal, ViewChild } from '@angular/core';
import { DashboardService } from '../../dashboard.service';
import { Component } from '@angular/core';
import { StatusComponent } from '../../StatusCount/status.component';
import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { PieComponent } from '../../Pie/pie.component';
import { formatDate } from '@angular/common';
import { SidebarModule } from 'primeng/sidebar';
import { OverlayPanel, OverlayPanelModule } from 'primeng/overlaypanel';
import { CommonModule } from '@angular/common';
import { HorizontalBarComponent } from '../../bar copy/horizontal-bar.component';
import { MessageService } from 'primeng/api';
import { AsnService } from '../../../../inbound/asns/asn.service';
import { Overlay, OverlayModule } from '@angular/cdk/overlay';
import { LoadingComponent } from '../../../../../common/components';

interface DashboardData {
    title: string;
    labels: string[];
    values: any[];
}
@Component({
    selector: 'app-inbound',
    templateUrl: './inbound.component.html',
    styleUrls: ['./inbound.component.scss'],
    standalone: true,
    imports: [
        StatusComponent,
        AppTranslatePipe,
        SidebarModule,
        HorizontalBarComponent,
        OverlayPanelModule,
        CommonModule,
        OverlayModule,
        LoadingComponent,
    ],
})
export class InboundComponent {
    showInboundPopup = false;
    loading = signal(false);
    refreshSeconds: number = 30;
    sidebarVisible2: boolean = false;
    asnsView = signal<any>({});
    asns = signal<any[]>([]);
    currentDate: string = '';
    private pendingRequests = 0;
    selectedReceiptType: any = null;
    @ViewChild('ap') ap!: OverlayPanel;
    private messageService = inject(MessageService);
    private asnService = inject(AsnService);
    private dashboardervice = inject(DashboardService);
    private destoryRef = inject(DestroyRef);
    rangeDates = signal<Date[] | undefined>(undefined);

    insights: any[] = [];

    inboundData = signal<DashboardData>({} as DashboardData);

    isGeneralOpen = true;
    isShipFromOpen = false;
    isCarrierOpen = false;
    isUserDefinedOpen = false;
    isRemarksOpen = false;

    private intervalId: any;

    stats = [
        { field: 'today', label: "Today's Receipt", value: 0, color: 'cyan' },
        {
            field: 'thisweek',
            label: 'This Week Receipt',
            value: 0,
            color: 'blue',
        },
        {
            field: 'thismonth',
            label: 'This Month Receipt',
            value: 0,
            color: 'green',
        },
        {
            field: 'thisyear',
            label: 'This Year Receipt',
            value: 0,
            color: 'purple',
        },
    ];

    ngOnInit() {
        // this.startCountdown();
        this.currentDate = new Date().toLocaleDateString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
        });
        this.loadInsights();
    }

    loadInsights() {
        this.dashboardervice.getInboundInsightsReport().subscribe({
            next: (res: any) => {
                this.insights = Array.isArray(res) ? res : res?.data || [];
            },
            error: (err) => {
                console.error('Insights API Error:', err);
            },
        });
    }

    getIcon(status: string): string {
        switch ((status || '').toLowerCase()) {
            case 'positive':
                return 'ti ti-trending-up';

            case 'alert':
                return 'ti ti-alert-circle';

            case 'high volume':
                return 'ti ti-package';

            case 'receiving':
                return 'ti ti-arrow-down-circle';

            case 'backlog':
                return 'ti ti-clock-hour-4';

            default:
                return 'ti ti-info-circle';
        }
    }

    getIconBg(status: string): string {
        switch ((status || '').toLowerCase()) {
            case 'positive':
                return 'bg-green-100';

            case 'alert':
                return 'bg-red-100';

            case 'high volume':
                return 'bg-lime-100';

            case 'receiving':
                return 'bg-blue-100';

            case 'backlog':
                return 'bg-orange-100';

            default:
                return 'bg-gray-100';
        }
    }

    getIconColor(status: string): string {
        switch ((status || '').toLowerCase()) {
            case 'positive':
                return 'text-green-600';

            case 'alert':
                return 'text-red-600';

            case 'high volume':
                return 'text-lime-600';

            case 'receiving':
                return 'text-blue-600';

            case 'backlog':
                return 'text-orange-600';

            default:
                return 'text-gray-600';
        }
    }

    getBadgeClass(status: string): string {
        switch ((status || '').toLowerCase()) {
            case 'positive':
                return 'bg-green-100 text-green-700';

            case 'alert':
                return 'bg-red-100 text-red-700';

            case 'high volume':
                return 'bg-lime-100 text-lime-700';

            case 'receiving':
                return 'bg-blue-100 text-blue-700';

            case 'backlog':
                return 'bg-orange-100 text-orange-700';

            default:
                return 'bg-gray-100 text-gray-700';
        }
    }

    startCountdown() {
        this.intervalId = setInterval(() => {
            if (this.refreshSeconds > 0) {
                this.refreshSeconds--;
            } else {
                // optional: reset after reaching 0
                this.getAsns();

                this.refreshSeconds = 30;
            }
        }, 1000);
    }

    ngOnDestroy() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
        }
    }

    onOpenInboundPopup() {
        this.showInboundPopup = true;
        this.inboundData.set({
            title: '',
            labels: [],
            values: [],
        });
        this.getInboundchartReport('today');
        this.getAsns();
        this.loadInsights();
    }

    selectReceiptType(item: any) {
        this.selectedReceiptType = item;
        this.getInboundchartReport(item.field);

        // Call API here
        // this.getReceiptData(item.label);
    }

    getInbound() {
        const StartDate = this.rangeDates()?.[0]
            ? formatDate(this.rangeDates()![0], 'yyyyMMdd', 'en-US')
            : '';
        const EndDate = this.rangeDates()?.[1]
            ? formatDate(this.rangeDates()![1], 'yyyyMMdd', 'en-US')
            : '';

        this.startLoading(); // ✅
        const subscription = this.dashboardervice
            .getInbound(StartDate, EndDate)
            .subscribe({
                next: (res) => {
                    this.inboundData.set(res);
                },
                error: () => this.finishLoading(), // ✅ also stop on error
                complete: () => this.finishLoading(), // ✅
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    getInboundchartReport(type: any) {
        const subscription = this.dashboardervice
            .getInboundchartReport(type)
            .subscribe({
                next: (res: any) => {
                    this.stats = this.stats.map((x: any) => {
                        if (x.field === 'today') {
                            return {
                                ...x,
                                value: res.ReceiptsCreatedToday,
                            };
                        }

                        if (x.field === 'thisweek') {
                            return {
                                ...x,
                                value: res.ReceiptsCreatedThisWeek,
                            };
                        }

                        if (x.field === 'thismonth') {
                            return {
                                ...x,
                                value: res.ReceiptsCreatedThisMonth,
                            };
                        }

                        if (x.field === 'thisyear') {
                            return {
                                ...x,
                                value: res.DistinctReceiptsThisYear,
                            };
                        }

                        return x;
                    });
                    let labels: any = [];
                    let values: any = [];
                    res.ChartData.map((data: any) => {
                        labels.push(data.Status);
                        values.push(data.Count);
                    });
                    let ChartData = {
                        title: 'Inbound',
                        labels: labels,
                        values: values,
                    };
                    this.inboundData.set(ChartData);
                },
                error: () => this.finishLoading(),
                complete: () => this.finishLoading(),
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    toggle(event: Event) {
        this.ap.toggle(event);
    }

    toggleGeneral() {
        this.isGeneralOpen = !this.isGeneralOpen;
    }

    // SHIP FROM
    toggleShipFrom() {
        this.isShipFromOpen = !this.isShipFromOpen;
    }

    // CARRIER
    toggleCarrier() {
        this.isCarrierOpen = !this.isCarrierOpen;
    }

    // USER DEFINED
    toggleUserDefined() {
        this.isUserDefinedOpen = !this.isUserDefinedOpen;
    }

    // REMARKS
    toggleRemarks() {
        this.isRemarksOpen = !this.isRemarksOpen;
    }

    OnviewInbound(Data: any) {
        this.asnsView.set(Data);
        this.sidebarVisible2 = true;
    }

    getAsns() {
        this.loading.set(true);
        const subscription = this.dashboardervice
            .getAsnsPage({ Page: 1, PageSize: 5 })
            .pipe()
            .subscribe({
                next: (res: any) => {
                    this.loading.set(false);

                    this.asns.set(res.AsnLines);
                },
            });
    }

    getAsnFields() {
        const data = this.asnsView(); // call once safely

        if (!data) return [];

        return [
            { label: 'Owner', value: data.TRADERKEY },
            { label: 'Type', value: data.Type_Desc },
            {
                label: 'Status',
                value: data.Status_Desc,
                type: 'status',
            },
            { label: 'External Ref.No', value: data.EXTERNRECEIPTKEY },
            { label: 'Vendor Reference', value: data.EXTERNALRECEIPTKEY2 },
            { label: 'Expected Receipt Date', value: data.EXPECTEDRECEIPTDATE },
            { label: 'Reference Number', value: data.EXTERNALRECEIPTKEY2 },
            { label: 'Gate Entry', value: data.Type_Desc },
            { label: 'Pro Number', value: data.Type_Desc },
            { label: 'Insurance Number', value: data.InsuranceNo },
        ];
    }

    getShipFromFields() {
        const data = this.asnsView(); // call once safely

        if (!data) return [];

        return [
            {
                label: 'Supplier Code',
                value: data.SUPPLIERCODE,
            },
            {
                label: 'Supplier Name',
                value: data.SUPPLIERNAME,
            },
            {
                label: 'Supplier Address 1',
                value: data.SHIPFROMADDRESSLINE1,
            },
            {
                label: 'Supplier Address 2',
                value: data.SHIPFROMADDRESSLINE2,
            },
            {
                label: 'Supplier Address 3',
                value: data.SHIPFROMADDRESSLINE3,
            },
            {
                label: 'Supplier Address 4',
                value: data.SHIPFROMADDRESSLINE4,
            },
            {
                label: 'Supplier City',
                value: data.SHIPFROMCITY,
            },
            {
                label: 'Supplier State',
                value: data.SHIPFROMSTATE,
            },
            {
                label: 'Supplier ZIP',
                value: data.SHIPFROMZIP,
            },
            {
                label: 'Supplier Contact',
                value: data.SHIPFROMCONTACT,
            },
            {
                label: 'Supplier Email',
                value: data.SHIPFROMEMAIL,
                type: 'email',
            },
            {
                label: 'Supplier Phone',
                value: data.SHIPFROMPHONE,
            },
        ];
    }

    getCarrierFields() {
        const data = this.asnsView();

        if (!data) return [];

        return [
            {
                label: 'Carrier Code',
                value: data.CARRIERKEY,
            },
            {
                label: 'Carrier Name',
                value: data.CARRIERNAME,
            },
            {
                label: 'Carrier Reference',
                value: data.CARRIERREFERENCE,
            },
            {
                label: 'Carrier Address 2',
                value: data.CARRIERADDRESS1,
            },
            {
                label: 'Carrier Address 2',
                value: data.CARRIERADDRESS2,
            },
            {
                label: 'Carrier City',
                value: data.CARRIERCITY,
            },
            {
                label: 'Carrier State',
                value: data.CARRIERSTATE,
            },
            {
                label: 'Carrier Country',
                value: data.CarrierCountry,
            },
            {
                label: 'Carrier ZIP',
                value: data.CARRIERZIP,
            },
            {
                label: 'Carrier Phone',
                value: data.CarrierPhone,
            },
            {
                label: 'Driver Name',
                value: data.DriverName,
            },
            {
                label: 'Trailer Number',
                value: data.TrailerNumber,
            },
            {
                label: 'Trailer Owner',
                value: data.TrailerOwner,
            },
            {
                label: 'Container Number',
                value: data.CONTAINERKEY,
            },
        ];
    }

    getUserDefinedFields() {
        const data = this.asnsView();

        if (!data) return [];

        return [
            {
                label: 'UDF 1',
                value: data.UDFSTR1,
            },
            {
                label: 'UDF 2',
                value: data.UDFSTR2,
            },
            {
                label: 'UDF 3',
                value: data.UDFSTR3,
            },
            {
                label: 'UDF 4',
                value: data.UDFSTR4,
            },
            {
                label: 'UDF 5',
                value: data.UDFSTR5,
            },
        ];
    }

    onCancel(ap: OverlayPanel): void {
        this.asnService
            .cancelAsn({ ReceiptKey: [this.asnsView().RECEIPTKEY] })
            .subscribe({
                next: () => {
                    ap.hide();
                    this.getAsns();
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'ASN cancelled successfully',
                    });
                },
                error: () => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: 'Failed to cancel ASN',
                    });
                },
            });
    }

    onClose(ap: OverlayPanel): void {
        this.asnService
            .closeAsn({ ReceiptKey: [this.asnsView().RECEIPTKEY] })
            .subscribe({
                next: () => {
                    ap.hide();
                    this.getAsns();
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'ASN closed successfully',
                    });
                },
                error: () => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: 'Failed to close ASN',
                    });
                },
            });
    }

    onReopen(ap: OverlayPanel): void {
        this.asnService
            .reopenAsn({ ReceiptKey: [this.asnsView().RECEIPTKEY] })
            .subscribe({
                next: () => {
                    ap.hide();
                    this.getAsns();
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'ASN reopened successfully',
                    });
                },
                error: () => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: 'Failed to reopen ASN',
                    });
                },
            });
    }

    onDelete(ap: OverlayPanel): void {
        this.asnService
            .deleteAsn({ ReceiptKey: [this.asnsView().RECEIPTKEY] })
            .subscribe({
                next: () => {
                    ap.hide();
                    this.getAsns();
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'ASN deleted successfully',
                    });
                },
                error: () => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: 'Failed to delete ASN',
                    });
                },
            });
    }

    getQtyLabel(item: any): string {
        const qty = item?.OPENQTY ?? 0;

        if (qty <= 0) return 'No Qty';
        if (qty < 10) return `Low - ${qty}`;
        return `${qty} Qty`;
    }
    getProgress(item: any): number {
        const qty = item?.OPENQTY ?? 0;

        const maxQty = 100; // adjust based on warehouse capacity

        if (qty <= 0) return 0;

        return Math.min((qty / maxQty) * 100, 100);
    }

    private startLoading() {
        this.pendingRequests++;
        this.loading.set(true);
    }
    private finishLoading() {
        this.pendingRequests--;
        if (this.pendingRequests <= 0) {
            this.pendingRequests = 0;
            this.loading.set(false);
        }
    }
}
