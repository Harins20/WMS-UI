import { Component, DestroyRef, inject, signal, ViewChildren, QueryList, ElementRef, AfterViewInit, OnDestroy, ViewChild, ChangeDetectorRef, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MessageService } from 'primeng/api';
import { DashboardService } from '../../../dashboard.service';
import { AuthService } from '../../../../../../common/services';
import { AsnService } from '../../../../../inbound';
import * as echarts from 'echarts';
import { LoadingComponent } from '../../../../../../common/components/common-loading/loading.component';

export interface InsightItem {
  type?: string;
  label: string;
  heading: string;
  total: number;
  growth: string;
  description: string;
  fileName: string;

  icon: string;
  iconBg: string;
  iconColor: string;
  textColor: string;

  trend: string;
  chartType?: 'yesterdayToday' | 'outboundComparison' | 'inventoryComparison' | 'gauge' | 'wave' | 'radar' | 'inbound3DBar' | 'inboundGauge';
  chartBadge?: string;
  yesterday?: number;
  today?: number;
}

@Component({
  selector: 'app-quicksummary-analytics',
  standalone: true,
  imports: [CommonModule, LoadingComponent],
  templateUrl: './quicksummary-analytics.component.html',
  styleUrl: './quicksummary-analytics.component.scss'
})
export class QuicksummaryAnalyticsComponent implements AfterViewInit, OnDestroy {
  private dashboardervice = inject(DashboardService);
  private messageService = inject(MessageService);
  private destoryRef = inject(DestroyRef);
  public authService = inject(AuthService);
  private asnService = inject(AsnService);
  private cdr = inject(ChangeDetectorRef);

  asnsView = signal<any>({});
  asns = signal<any[]>([]);
  activeTab: 'reports' | 'analytics' = 'reports';
  loading = signal(false);
  isGenerating = false;
  summaryGenerated = false;

  loadingShipment: boolean = false;
  insight: InsightItem[] = [];

  activeQuickTab: string = 'summary';
  refreshSeconds: number = 30;

  currentInsight = 0;

  @ViewChildren('insightChartContainer') chartContainers!: QueryList<ElementRef>;
  @ViewChild('modalChartContainer') modalChartContainer?: ElementRef;
  @ViewChild('appointmentChartContainer') appointmentChartContainer?: ElementRef;
  @ViewChild('appointmentFullscreenChartContainer') appointmentFullscreenChartContainer?: ElementRef;
  @ViewChild('holdChartContainer') holdChartContainer?: ElementRef;
  @ViewChild('holdFullscreenChartContainer') holdFullscreenChartContainer?: ElementRef;
  @ViewChild('shipmentChartContainer') shipmentChartContainer?: ElementRef;
  @ViewChild('shipmentFullscreenChartContainer') shipmentFullscreenChartContainer?: ElementRef;
  @ViewChild('locationChartContainer') locationChartContainer?: ElementRef;
  @ViewChild('locationFullscreenChartContainer') locationFullscreenChartContainer?: ElementRef;
  @ViewChild('dockChartContainer') dockChartContainer?: ElementRef;
  @ViewChild('dockFullscreenChartContainer') dockFullscreenChartContainer?: ElementRef;
  @ViewChild('skuChartContainer') skuChartContainer?: ElementRef;
  @ViewChild('skuFullscreenChartContainer') skuFullscreenChartContainer?: ElementRef;

  chartInstances: Map<number, echarts.ECharts> = new Map();
  modalChartInstance?: echarts.ECharts;
  isModalOpen = false;
  selectedModalInsight: InsightItem | null = null;
  resizeObserver?: ResizeObserver;

  isAppointmentFullscreen = signal<boolean>(false);
  selectedAppointmentChartType: 'step' | 'spline' | 'combo' = 'step';
  appointmentChartInstance?: echarts.ECharts;
  appointmentFullscreenChartInstance?: echarts.ECharts;

  isShipmentFullscreen = signal<boolean>(false);
  selectedShipmentChartType: 'bar' | 'donut' | 'gauge' = 'donut';
  shipmentChartInstance?: echarts.ECharts;
  shipmentFullscreenChartInstance?: echarts.ECharts;

  isLocationFullscreen = signal<boolean>(false);
  selectedLocationChartType: 'bar' | 'pie' | 'radar' = 'pie';
  locationChartInstance?: echarts.ECharts;
  locationFullscreenChartInstance?: echarts.ECharts;

  isDockFullscreen = signal<boolean>(false);
  selectedDockChartType: 'bar' | 'donut' | 'radar' = 'radar';
  dockChartInstance?: echarts.ECharts;
  dockFullscreenChartInstance?: echarts.ECharts;

  isSkuFullscreen = signal<boolean>(false);
  selectedSkuChartType: 'bar' | 'donut' | 'radar' = 'bar';
  skuChartInstance?: echarts.ECharts;
  skuFullscreenChartInstance?: echarts.ECharts;

  selectedInboundChartType: 'customAngle' | 'dashedLine' = 'customAngle';

  isHoldFullscreen = signal<boolean>(false);
  selectedHoldChartType: 'mixed' | 'stacked' | 'confidence' = 'mixed';
  holdChartInstance?: echarts.ECharts;
  holdFullscreenChartInstance?: echarts.ECharts;

  totalHolds: number = 0;
  lpnHold: number = 0;
  lotHold: number = 0;
  combinedHold: number = 0;

  locationsUsed: any[] = [];
  appointmentFlow: any[] = [];
  docks: any[] = [];
  topsMovingSkus: any[] = [];
  isSkuLoading = false;
  refreshInterval: any;
  interval: any;

  shipmentData: any = {
    TotalOrders: 0,
    TotalShippedQty: 0,
    TopSku: '',
    TopSkuQty: 0,
  };

  receiptData: any = {
    InboundSummary: {
      Yesterday: 0,
      Today: 0,
      Percentage: 0,
    },
    ReceiptOverview: {
      New: 0,
      Received: 0,
      Closed: 0,
      Cancelled: 0,
      InReceiving: 0,
    },
    ProcessingFlow: [],
    ReceiptSummary: {
      Title: '',
      Summary: '',
    },
  };

  generateReport() {
    this.isGenerating = true;

    // API call here
    setTimeout(() => {
      this.isGenerating = false;
      this.summaryGenerated = true;
    }, 2000);
    this.loadQuickReport();
    this.getAppointmentReport();
    this.getLocationReport();
    this.loadHoldReport();
    this.getSkuReport();
    this.loadShipmentReport();
    this.loadDockReport();
  }

  ngOnInit() {
    this.loading.set(true);
    setTimeout(() => {
      this.loading.set(false);
      this.cdr.detectChanges();
      setTimeout(() => {
        this.initAllCharts();
        this.renderAppointmentChart();
        this.renderHoldChart();
        this.renderShipmentChart();
        this.renderLocationChart();
        this.renderDockChart();
        this.renderSkuChart();
      }, 150);
    }, 2500);

    this.loadQuickReport();
    this.getAppointmentReport();
    this.getLocationReport();
    this.loadHoldReport();
    this.getSkuReport();
    this.loadShipmentReport();
    this.loadDockReport();
  }

  @HostListener('document:keydown.escape', ['$event'])
  handleEscapeKey(event: KeyboardEvent): void {
    if (this.isAppointmentFullscreen()) {
      this.toggleAppointmentFullscreen();
    }
    if (this.isHoldFullscreen()) {
      this.toggleHoldFullscreen();
    }
    if (this.isShipmentFullscreen()) {
      this.toggleShipmentFullscreen();
    }
    if (this.isLocationFullscreen()) {
      this.toggleLocationFullscreen();
    }
    if (this.isDockFullscreen()) {
      this.toggleDockFullscreen();
    }
    if (this.isSkuFullscreen()) {
      this.toggleSkuFullscreen();
    }
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.initAllCharts();
      this.renderAppointmentChart();
      this.renderHoldChart();
      this.renderShipmentChart();
      this.renderLocationChart();
      this.renderDockChart();
      this.renderSkuChart();
    }, 300);

    if (typeof window !== 'undefined' && 'ResizeObserver' in window) {
      this.resizeObserver = new ResizeObserver(() => {
        this.resizeAllCharts();
      });
      this.chartContainers?.changes?.subscribe(() => {
        this.initAllCharts();
      });
    }
  }

  ngOnDestroy(): void {
    this.destroyAllCharts();
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
  }

  initAllCharts(): void {
    this.destroyAllCharts();
    if (!this.chartContainers || !this.insight.length) return;

    const containersArray = this.chartContainers.toArray();
    this.insight.forEach((item, index) => {
      const containerEl = containersArray[index]?.nativeElement;
      if (!containerEl) return;

      let chart = echarts.getInstanceByDom(containerEl);
      if (!chart) {
        chart = echarts.init(containerEl);
      }
      const option = this.getOptionForInsight(item, index);
      chart.setOption(option);
      this.chartInstances.set(index, chart);

      if (this.resizeObserver) {
        this.resizeObserver.observe(containerEl);
      }
    });
  }

  resizeAllCharts(): void {
    this.chartInstances.forEach((chart) => chart?.resize());
    if (this.modalChartInstance) {
      this.modalChartInstance.resize();
    }
    if (this.appointmentChartInstance) {
      this.appointmentChartInstance.resize();
    }
    if (this.appointmentFullscreenChartInstance) {
      this.appointmentFullscreenChartInstance.resize();
    }
    if (this.holdChartInstance) {
      this.holdChartInstance.resize();
    }
    if (this.holdFullscreenChartInstance) {
      this.holdFullscreenChartInstance.resize();
    }
    if (this.shipmentChartInstance) {
      this.shipmentChartInstance.resize();
    }
    if (this.shipmentFullscreenChartInstance) {
      this.shipmentFullscreenChartInstance.resize();
    }
    if (this.locationChartInstance) {
      this.locationChartInstance.resize();
    }
    if (this.locationFullscreenChartInstance) {
      this.locationFullscreenChartInstance.resize();
    }
    if (this.dockChartInstance) {
      this.dockChartInstance.resize();
    }
    if (this.dockFullscreenChartInstance) {
      this.dockFullscreenChartInstance.resize();
    }
    if (this.skuChartInstance) {
      this.skuChartInstance.resize();
    }
    if (this.skuFullscreenChartInstance) {
      this.skuFullscreenChartInstance.resize();
    }
  }

  destroyAllCharts(): void {
    this.chartInstances.forEach((chart) => chart?.dispose());
    this.chartInstances.clear();
    if (this.modalChartInstance) {
      this.modalChartInstance.dispose();
      this.modalChartInstance = undefined;
    }
    if (this.appointmentChartInstance) {
      this.appointmentChartInstance.dispose();
      this.appointmentChartInstance = undefined;
    }
    if (this.appointmentFullscreenChartInstance) {
      this.appointmentFullscreenChartInstance.dispose();
      this.appointmentFullscreenChartInstance = undefined;
    }
    if (this.holdChartInstance) {
      this.holdChartInstance.dispose();
      this.holdChartInstance = undefined;
    }
    if (this.holdFullscreenChartInstance) {
      this.holdFullscreenChartInstance.dispose();
      this.holdFullscreenChartInstance = undefined;
    }
    if (this.shipmentChartInstance) {
      this.shipmentChartInstance.dispose();
      this.shipmentChartInstance = undefined;
    }
    if (this.shipmentFullscreenChartInstance) {
      this.shipmentFullscreenChartInstance.dispose();
      this.shipmentFullscreenChartInstance = undefined;
    }
    if (this.locationChartInstance) {
      this.locationChartInstance.dispose();
      this.locationChartInstance = undefined;
    }
    if (this.locationFullscreenChartInstance) {
      this.locationFullscreenChartInstance.dispose();
      this.locationFullscreenChartInstance = undefined;
    }
    if (this.dockChartInstance) {
      this.dockChartInstance.dispose();
      this.dockChartInstance = undefined;
    }
    if (this.dockFullscreenChartInstance) {
      this.dockFullscreenChartInstance.dispose();
      this.dockFullscreenChartInstance = undefined;
    }
    if (this.skuChartInstance) {
      this.skuChartInstance.dispose();
      this.skuChartInstance = undefined;
    }
    if (this.skuFullscreenChartInstance) {
      this.skuFullscreenChartInstance.dispose();
      this.skuFullscreenChartInstance = undefined;
    }
  }



  toggleHoldFullscreen(): void {
    this.isHoldFullscreen.update((v) => !v);
    this.renderHoldChart();
  }

  setHoldChartType(type: 'mixed' | 'stacked' | 'confidence'): void {
    this.selectedHoldChartType = type;
    this.renderHoldChart();
  }

  renderHoldChart(): void {
    this.cdr.detectChanges();
    setTimeout(() => {
      if (this.holdChartContainer?.nativeElement) {
        const container = this.holdChartContainer.nativeElement;
        if (this.holdChartInstance) {
          this.holdChartInstance.dispose();
        }
        this.holdChartInstance = echarts.init(container);
        this.holdChartInstance.setOption(this.getHoldChartOption());
        this.holdChartInstance.resize();
      } else {
        setTimeout(() => {
          if (this.holdChartContainer?.nativeElement) {
            const container = this.holdChartContainer.nativeElement;
            if (this.holdChartInstance) {
              this.holdChartInstance.dispose();
            }
            this.holdChartInstance = echarts.init(container);
            this.holdChartInstance.setOption(this.getHoldChartOption());
            this.holdChartInstance.resize();
          }
        }, 300);
      }

      if (this.isHoldFullscreen() && this.holdFullscreenChartContainer?.nativeElement) {
        const container = this.holdFullscreenChartContainer.nativeElement;
        if (this.holdFullscreenChartInstance) {
          this.holdFullscreenChartInstance.dispose();
        }
        this.holdFullscreenChartInstance = echarts.init(container);
        this.holdFullscreenChartInstance.setOption(this.getHoldChartOption());
        this.holdFullscreenChartInstance.resize();
      }
    }, 100);
  }

  getHoldChartOption(): any {
    const lpn = this.lpnHold || 0;
    const lot = this.lotHold || 0;
    const comb = this.combinedHold || 0;
    const total = this.totalHolds || (lpn + lot + comb) || 1;

    const categories = ['LPN Hold', 'Lot Hold', 'LPN/LOT Hold'];
    const counts = [lpn, lot, comb];
    const type = this.selectedHoldChartType;

    // =========================================================================
    // 1. UNIQUE 3D CYLINDER COLUMN & SPLINE CHART
    // =========================================================================
    if (type === 'mixed') {
      return {
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'shadow' },
          backgroundColor: '#0f172a',
          borderColor: '#f97316',
          textStyle: { color: '#f8fafc' },
          formatter: (params: any[]) => {
            let res = `<div class="font-bold text-orange-400 mb-1">3D Cylinder Hold Breakdown</div>`;
            params.forEach(p => {
              if (p.seriesType === 'bar' || p.seriesType === 'pictorialBar') {
                if (p.seriesName === 'Cylinder Body') {
                  res += `<div style="display:flex;justify-content:space-between;gap:15px;margin-bottom:2px;">
                            <span style="color:#94a3b8;">${p.name}:</span>
                            <b style="color:#f97316;">${p.value} units</b>
                          </div>`;
                }
              }
            });
            return res;
          }
        },
        legend: {
          top: '0%',
          left: 'center',
          textStyle: { color: '#94a3b8', fontSize: 11 },
        },
        grid: {
          top: '16%',
          left: '3%',
          right: '4%',
          bottom: '10%',
          containLabel: true,
        },
        xAxis: {
          type: 'category',
          data: categories,
          axisLine: { lineStyle: { color: '#334155' } },
          axisLabel: { color: '#f8fafc', fontSize: 11, fontWeight: 'bold' },
        },
        yAxis: [
          {
            type: 'value',
            name: '3D Cylinder Count',
            nameTextStyle: { color: '#94a3b8', fontSize: 10 },
            axisLabel: { color: '#94a3b8', fontSize: 11 },
            splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.1)', type: 'dashed' } },
          },
          {
            type: 'value',
            name: 'Spline Flow',
            nameTextStyle: { color: '#38bdf8', fontSize: 10 },
            axisLabel: { color: '#38bdf8', fontSize: 11 },
            splitLine: { show: false },
          },
        ],
        series: [
          {
            name: 'Cylinder Body',
            type: 'bar',
            barWidth: '34%',
            yAxisIndex: 0,
            itemStyle: {
              color: (params: any) => {
                const colors = [
                  new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                    { offset: 0, color: '#ea580c' },
                    { offset: 0.5, color: '#fb923c' },
                    { offset: 1, color: '#c2410c' }
                  ]),
                  new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                    { offset: 0, color: '#dc2626' },
                    { offset: 0.5, color: '#f87171' },
                    { offset: 1, color: '#991b1b' }
                  ]),
                  new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                    { offset: 0, color: '#9333ea' },
                    { offset: 0.5, color: '#c084fc' },
                    { offset: 1, color: '#6b21a8' }
                  ])
                ];
                return colors[params.dataIndex];
              },
              borderRadius: [6, 6, 0, 0]
            },
            label: {
              show: true,
              position: 'top',
              color: '#f97316',
              fontWeight: 'bold',
              fontSize: 11,
              formatter: '{c} units'
            },
            data: counts,
          },
          {
            name: 'Hold Spline Flow',
            type: 'line',
            smooth: true,
            yAxisIndex: 1,
            symbolSize: 10,
            lineStyle: { width: 3.5, color: '#38bdf8' },
            itemStyle: { color: '#38bdf8', borderWidth: 2, borderColor: '#ffffff' },
            data: counts,
          },
        ],
      };
    }
    // =========================================================================
    // 2. UNIQUE TRIPLE CONCENTRIC RADIAL GAUGE ARCS
    // =========================================================================
    else if (type === 'stacked') {
      const lpnPct = Math.round((lpn / total) * 100);
      const lotPct = Math.round((lot / total) * 100);
      const combPct = Math.round((comb / total) * 100);

      return {
        tooltip: {
          trigger: 'item',
          backgroundColor: '#0f172a',
          borderColor: '#f97316',
          textStyle: { color: '#f8fafc' },
          formatter: (params: any) => {
            return `<div class="font-bold text-orange-400 mb-1">${params.name}</div>
                    <div style="display:flex;justify-content:space-between;gap:15px;">
                      <span style="color:#94a3b8;">Volume:</span>
                      <b style="color:#f8fafc;">${params.value} units (${params.data.pct}%)</b>
                    </div>`;
          }
        },
        legend: {
          top: '0%',
          left: 'center',
          textStyle: { color: '#94a3b8', fontSize: 11 }
        },
        series: [
          {
            name: 'Triple Radial Arc Gauge',
            type: 'pie',
            radius: ['38%', '80%'],
            center: ['50%', '55%'],
            roseType: 'radius',
            itemStyle: {
              borderRadius: 10,
              borderColor: '#0f172a',
              borderWidth: 3
            },
            label: {
              show: true,
              formatter: '{b}\n{c} units',
              color: '#f8fafc',
              fontWeight: 'bold',
              fontSize: 11
            },
            labelLine: {
              length: 12,
              length2: 14,
              lineStyle: { color: '#94a3b8', width: 1.5 }
            },
            data: [
              {
                value: lpn,
                name: 'LPN Hold',
                pct: lpnPct,
                itemStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                    { offset: 0, color: '#f97316' },
                    { offset: 1, color: '#fdba74' }
                  ])
                }
              },
              {
                value: lot,
                name: 'Lot Hold',
                pct: lotPct,
                itemStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                    { offset: 0, color: '#ef4444' },
                    { offset: 1, color: '#fca5a5' }
                  ])
                }
              },
              {
                value: comb,
                name: 'LPN/LOT Hold',
                pct: combPct,
                itemStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                    { offset: 0, color: '#a855f7' },
                    { offset: 1, color: '#d8b4fe' }
                  ])
                }
              }
            ]
          }
        ]
      };
    }
    // =========================================================================
    // 3. UNIQUE SPIDER RADAR RISK MATRIX
    // =========================================================================
    else {
      const maxVal = Math.max(lpn, lot, comb, 10);
      const radarMax = Math.ceil(maxVal * 1.3);

      return {
        tooltip: {
          trigger: 'item',
          backgroundColor: '#0f172a',
          borderColor: '#f97316',
          textStyle: { color: '#f8fafc' },
        },
        legend: {
          top: '0%',
          left: 'center',
          textStyle: { color: '#94a3b8', fontSize: 11 }
        },
        radar: {
          indicator: [
            { name: 'LPN Hold', max: radarMax },
            { name: 'Lot Hold', max: radarMax },
            { name: 'LPN/LOT Hold', max: radarMax },
            { name: 'Risk Level', max: radarMax },
            { name: 'Capacity', max: radarMax }
          ],
          center: ['50%', '55%'],
          radius: '68%',
          splitNumber: 4,
          axisName: {
            color: '#38bdf8',
            fontWeight: 'bold',
            fontSize: 11
          },
          splitLine: {
            lineStyle: {
              color: ['rgba(56, 189, 248, 0.2)', 'rgba(56, 189, 248, 0.4)', 'rgba(56, 189, 248, 0.6)']
            }
          },
          splitArea: {
            areaStyle: {
              color: ['rgba(15, 23, 42, 0.4)', 'rgba(30, 41, 59, 0.6)']
            }
          },
          axisLine: {
            lineStyle: { color: 'rgba(56, 189, 248, 0.4)' }
          }
        },
        series: [
          {
            name: 'Hold Operations Radar',
            type: 'radar',
            data: [
              {
                value: [lpn, lot, comb, Math.round((lpn + lot) * 0.7), Math.round(total * 1.1)],
                name: 'Current Hold Profile',
                symbol: 'circle',
                symbolSize: 8,
                itemStyle: { color: '#f97316' },
                lineStyle: { width: 3, color: '#f97316' },
                areaStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: 'rgba(249, 115, 22, 0.6)' },
                    { offset: 1, color: 'rgba(249, 115, 22, 0.1)' }
                  ])
                }
              }
            ]
          }
        ]
      };
    }
  }

  getOptionForInsight(item: InsightItem, index: number): echarts.EChartsOption {
    if (item.chartType === 'inboundGauge' || item.chartType === 'inbound3DBar' || (item.type === 'Inbound' && item.chartType !== 'radar')) {
      return this.getInboundComparativeGaugeOption(item);
    } else if (item.chartType === 'inventoryComparison' || item.type === 'Inventory' || index === 2) {
      return this.getInventoryComparisonChartOption(item);
    } else if (item.chartType === 'outboundComparison' || (item.type === 'Outbound' && item.chartType !== 'radar')) {
      return this.getOutboundComparisonChartOption(item);
    } else if (item.chartType === 'yesterdayToday' || item.chartType === 'gauge') {
      return this.getYesterdayTodayChartOption(item);
    } else if (item.chartType === 'wave') {
      return this.getWaveChartOption(item);
    } else if (item.chartType === 'radar') {
      return this.getRadarChartOption(item);
    } else {
      return this.getYesterdayTodayChartOption(item);
    }
  }

  getInventoryComparisonChartOption(item: InsightItem): any {
    const todayVal = Number(item.today ?? item.total ?? 0);

    const growthMatch = String(item.growth || '').match(/([+-]?\d+(?:\.\d+)?)/);
    const growthNum = growthMatch ? parseFloat(growthMatch[1]) : 0;

    let yesterdayVal = Number(item.yesterday);
    if (item.yesterday === undefined || item.yesterday === null || isNaN(yesterdayVal)) {
      if (growthNum !== 0 && (1 + growthNum / 100) !== 0) {
        yesterdayVal = Math.round(todayVal / (1 + growthNum / 100));
      } else {
        yesterdayVal = Math.round(todayVal * 0.85);
      }
    }

    const diff = todayVal - yesterdayVal;
    const diffSign = diff >= 0 ? '+' : '';
    const arrow = diff >= 0 ? '▲' : '▼';
    const calcPercent = yesterdayVal > 0 ? ((diff / yesterdayVal) * 100).toFixed(1) : '0';
    const percentSign = parseFloat(calcPercent) >= 0 ? '+' : '';

    // Checkpoint labels across daytime operations
    const timeCategories = ['08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00'];

    // Generate smooth wave data points relative to total inventory values
    const yesterdayWave = [
      Math.round(yesterdayVal * 0.72),
      Math.round(yesterdayVal * 0.84),
      Math.round(yesterdayVal * 0.96),
      Math.round(yesterdayVal * 0.88),
      Math.round(yesterdayVal * 0.94),
      Math.round(yesterdayVal * 0.98),
      yesterdayVal
    ];

    const todayWave = [
      Math.round(todayVal * 0.68),
      Math.round(todayVal * 0.82),
      Math.round(todayVal * 0.98),
      Math.round(todayVal * 1.04),
      Math.round(todayVal * 0.96),
      Math.round(todayVal * 1.02),
      todayVal
    ];

    // Upper and lower confidence threshold band
    const thresholdLower = yesterdayWave.map((v, i) => Math.min(v, todayWave[i]) * 0.92);
    const thresholdUpper = yesterdayWave.map((v, i) => Math.max(v, todayWave[i]) * 1.08);
    const thresholdBand = thresholdUpper.map((upper, i) => upper - thresholdLower[i]);

    return {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          crossStyle: { color: '#c084fc' },
          label: { backgroundColor: '#0f172a' }
        },
        backgroundColor: 'rgba(15, 23, 42, 0.95)',
        borderColor: '#a855f7',
        borderWidth: 1,
        padding: [10, 14],
        extraCssText: 'z-index: 1000; box-shadow: 0 15px 30px -5px rgba(0, 0, 0, 0.6); backdrop-filter: blur(12px);',
        textStyle: { color: '#fff', fontSize: 11 },
        formatter: (params: any[]) => {
          const time = params[0]?.name || 'Current';
          const todayItem = params.find(p => p.seriesName === 'Today Inventory');
          const yestItem = params.find(p => p.seriesName === 'Yesterday Baseline');

          const tVal = todayItem ? Number(todayItem.value) : todayVal;
          const yVal = yestItem ? Number(yestItem.value) : yesterdayVal;
          const subDiff = tVal - yVal;
          const subSign = subDiff >= 0 ? '+' : '';
          const subPerc = yVal > 0 ? ((subDiff / yVal) * 100).toFixed(1) : '0';

          return `
            <div style="font-weight:bold;margin-bottom:6px;color:#f8fafc;display:flex;align-items:center;justify-content:space-between;gap:12px;">
              <span>Inventory Wave (${time})</span>
              <span style="font-size:10px;padding:2px 6px;border-radius:4px;background:rgba(168,85,247,0.2);color:#c084fc;">Fluid Area</span>
            </div>
            <div style="display:flex;justify-content:space-between;gap:15px;margin-bottom:3px;">
              <span style="color:#94a3b8;">Yesterday Baseline:</span>
              <b style="color:#cbd5e1;">${yVal.toLocaleString()} units</b>
            </div>
            <div style="display:flex;justify-content:space-between;gap:15px;margin-bottom:4px;">
              <span style="color:#c084fc;">Today Wave:</span>
              <b style="color:#c084fc;">${tVal.toLocaleString()} units</b>
            </div>
            <div style="border-top:1px solid rgba(255,255,255,0.1);padding-top:4px;display:flex;justify-content:space-between;gap:15px;">
              <span style="color:#94a3b8;">Variance at ${time}:</span>
              <b style="color:${subDiff >= 0 ? '#4ade80' : '#f87171'};">${subSign}${subDiff.toLocaleString()} units (${subSign}${subPerc}%)</b>
            </div>
          `;
        }
      },
      legend: {
        show: true,
        top: '0%',
        right: '2%',
        itemWidth: 10,
        itemHeight: 10,
        textStyle: { color: '#94a3b8', fontSize: 10 }
      },
      grid: {
        top: '18%',
        left: '2%',
        right: '4%',
        bottom: '4%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: timeCategories,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 }
      },
      yAxis: {
        type: 'value',
        splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.1)', type: 'dashed' } },
        axisLabel: { color: '#94a3b8', fontSize: 10 }
      },
      series: [
        // Yesterday Baseline Wave
        {
          name: 'Yesterday Baseline',
          type: 'line',
          smooth: 0.45,
          showSymbol: false,
          symbolSize: 6,
          lineStyle: {
            width: 2,
            color: '#94a3b8',
            type: 'dashed'
          },
          itemStyle: { color: '#94a3b8' },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(148, 163, 184, 0.2)' },
              { offset: 1, color: 'rgba(148, 163, 184, 0.02)' }
            ])
          },
          data: yesterdayWave
        },
        // Today Glowing Fluid Wave
        {
          name: 'Today Inventory',
          type: 'line',
          smooth: 0.45,
          showSymbol: true,
          symbolSize: 6,
          lineStyle: {
            width: 3.5,
            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
              { offset: 0, color: '#a855f7' },
              { offset: 0.5, color: '#c084fc' },
              { offset: 1, color: '#e879f9' }
            ]),
            shadowColor: 'rgba(168, 85, 247, 0.6)',
            shadowBlur: 10
          },
          itemStyle: {
            color: '#c084fc',
            borderWidth: 2,
            borderColor: '#ffffff'
          },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(168, 85, 247, 0.45)' },
              { offset: 0.6, color: 'rgba(147, 51, 234, 0.18)' },
              { offset: 1, color: 'rgba(126, 34, 206, 0.01)' }
            ])
          },
          data: todayWave
        }
      ]
    };
  }

  getOutboundComparisonChartOption(item: InsightItem): any {
    const todayVal = Number(item.today ?? item.total ?? 0);

    const growthMatch = String(item.growth || '').match(/([+-]?\d+(?:\.\d+)?)/);
    const growthNum = growthMatch ? parseFloat(growthMatch[1]) : 0;

    let yesterdayVal = Number(item.yesterday);
    if (item.yesterday === undefined || item.yesterday === null || isNaN(yesterdayVal)) {
      if (growthNum !== 0 && (1 + growthNum / 100) !== 0) {
        yesterdayVal = Math.round(todayVal / (1 + growthNum / 100));
      } else {
        yesterdayVal = Math.round(todayVal * 0.85);
      }
    }

    const diff = todayVal - yesterdayVal;
    const diffSign = diff >= 0 ? '+' : '';
    const calcPercent = yesterdayVal > 0 ? ((diff / yesterdayVal) * 100).toFixed(1) : '0';
    const percentSign = parseFloat(calcPercent) >= 0 ? '+' : '';

    const maxVal = Math.max(todayVal, yesterdayVal, 10);
    const targetLimit = Math.round(maxVal * 1.25);

    return {
      grid: { top: 28, bottom: 22, left: 35, right: 25, containLabel: false },
      tooltip: {
        trigger: 'axis',
        confine: true,
        backgroundColor: 'rgba(15, 23, 42, 0.95)',
        borderColor: '#f97316',
        borderWidth: 1,
        padding: [8, 12],
        extraCssText: 'z-index: 1000; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);',
        textStyle: { color: '#fff', fontSize: 11 },
        formatter: () => {
          return `
            <div style="font-weight:bold;margin-bottom:4px;color:#f8fafc;">Outbound Operations Summary</div>
            <div style="display:flex;justify-content:space-between;gap:15px;margin-bottom:2px;">
              <span style="color:#94a3b8;">Yesterday Total:</span>
              <b style="color:#cbd5e1;">${yesterdayVal.toLocaleString()} units</b>
            </div>
            <div style="display:flex;justify-content:space-between;gap:15px;margin-bottom:4px;">
              <span style="color:#fb923c;">Today Total:</span>
              <b style="color:#fb923c;">${todayVal.toLocaleString()} units</b>
            </div>
            <div style="border-top:1px solid rgba(255,255,255,0.1);padding-top:4px;display:flex;justify-content:space-between;gap:15px;">
              <span style="color:#94a3b8;">Variance vs Yesterday:</span>
              <b style="color:${diff >= 0 ? '#4ade80' : '#f87171'};">${diffSign}${diff.toLocaleString()} units (${percentSign}${calcPercent}%)</b>
            </div>
          `;
        }
      },
      xAxis: {
        type: 'category',
        data: ['Yesterday', 'Today'],
        axisLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.2)' } },
        axisTick: { show: false },
        axisLabel: {
          color: (val: string) => (val === 'Today' ? '#fb923c' : '#94a3b8'),
          fontSize: 11,
          fontWeight: 'bold'
        }
      },
      yAxis: {
        type: 'value',
        max: targetLimit,
        splitLine: { lineStyle: { type: 'dashed', color: 'rgba(148, 163, 184, 0.12)' } },
        axisLabel: { color: '#94a3b8', fontSize: 9 }
      },
      series: [
        {
          name: 'Yesterday Baseline',
          type: 'line',
          step: 'middle',
          data: [yesterdayVal, yesterdayVal],
          lineStyle: { width: 2, type: 'dashed', color: '#64748b' },
          itemStyle: { color: '#64748b' },
          symbol: 'none',
          areaStyle: {
            color: 'rgba(100, 116, 139, 0.08)'
          },
          tooltip: { show: false }
        },
        {
          name: 'Today Stepped Volume',
          type: 'line',
          step: 'end',
          data: [yesterdayVal, todayVal],
          symbol: 'circle',
          symbolSize: 7,
          itemStyle: { color: '#f97316', borderWidth: 2, borderColor: '#fff' },
          lineStyle: { width: 3, color: '#f97316' },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(249, 115, 22, 0.42)' },
              { offset: 1, color: 'rgba(249, 115, 22, 0.02)' }
            ])
          },
          label: {
            show: true,
            position: 'top',
            formatter: (params: any) => {
              const val = params.value;
              if (params.dataIndex === 1) {
                return `{today|${val.toLocaleString()}} {diff|(${diffSign}${calcPercent}%)}`;
              }
              return `{yesterday|${val.toLocaleString()}}`;
            },
            rich: {
              today: { color: '#fb923c', fontWeight: 'bold', fontSize: 10 },
              yesterday: { color: '#cbd5e1', fontWeight: 'semibold', fontSize: 10 },
              diff: { color: diff >= 0 ? '#4ade80' : '#f87171', fontWeight: 'bold', fontSize: 9 }
            }
          }
        }
      ]
    };
  }

  getYesterdayTodayChartOption(item: InsightItem): any {
    const todayVal = Number(item.today ?? item.total ?? 0);

    const growthMatch = String(item.growth || '').match(/([+-]?\d+(?:\.\d+)?)/);
    const growthNum = growthMatch ? parseFloat(growthMatch[1]) : 0;

    let yesterdayVal = Number(item.yesterday);
    if (item.yesterday === undefined || item.yesterday === null || isNaN(yesterdayVal)) {
      if (growthNum !== 0 && (1 + growthNum / 100) !== 0) {
        yesterdayVal = Math.round(todayVal / (1 + growthNum / 100));
      } else {
        yesterdayVal = Math.round(todayVal * 0.85);
      }
    }

    const diff = todayVal - yesterdayVal;
    const diffSign = diff >= 0 ? '+' : '';
    const calcPercent = yesterdayVal > 0 ? ((diff / yesterdayVal) * 100).toFixed(1) : '0';
    const percentSign = parseFloat(calcPercent) >= 0 ? '+' : '';

    const maxVal = Math.max(todayVal, yesterdayVal, 10);
    const targetLimit = Math.round(maxVal * 1.25);

    const isOutbound = item?.heading?.toLowerCase().includes('outbound') || item?.label?.toLowerCase().includes('outbound');

    const accentColor = isOutbound ? '#fb923c' : '#38bdf8';
    const gradientStart = isOutbound ? '#ea580c' : '#0284c7';
    const gradientEnd = isOutbound ? '#fb923c' : '#38bdf8';
    const tooltipBorder = isOutbound ? '#f97316' : '#3b82f6';
    const bandBg = isOutbound ? 'rgba(249, 115, 22, 0.06)' : 'rgba(59, 130, 246, 0.06)';
    const bandBorder = isOutbound ? 'rgba(249, 115, 22, 0.25)' : 'rgba(59, 130, 246, 0.25)';
    const titleText = isOutbound ? 'Outbound Operations Summary' : 'Inbound Operations Summary';
    const volumeName = isOutbound ? 'Outbound Volume' : 'Inbound Volume';

    return {
      grid: { top: 28, bottom: 15, left: 10, right: 10, containLabel: true },
      tooltip: {
        trigger: 'axis',
        confine: true,
        axisPointer: { type: 'shadow' },
        backgroundColor: 'rgba(15, 23, 42, 0.95)',
        borderColor: tooltipBorder,
        borderWidth: 1,
        padding: [8, 12],
        textStyle: { color: '#fff', fontSize: 11 },
        formatter: () => {
          return `
            <div style="font-weight:bold;margin-bottom:4px;color:#f8fafc;">${titleText}</div>
            <div style="display:flex;justify-content:space-between;gap:15px;margin-bottom:2px;">
              <span style="color:#94a3b8;">Yesterday Total:</span>
              <b style="color:#cbd5e1;">${yesterdayVal.toLocaleString()} units</b>
            </div>
            <div style="display:flex;justify-content:space-between;gap:15px;margin-bottom:4px;">
              <span style="color:${accentColor};">Today Total:</span>
              <b style="color:${accentColor};">${todayVal.toLocaleString()} units</b>
            </div>
            <div style="border-top:1px solid rgba(255,255,255,0.1);padding-top:4px;display:flex;justify-content:space-between;gap:15px;">
              <span style="color:#94a3b8;">Variance vs Yesterday:</span>
              <b style="color:${diff >= 0 ? '#4ade80' : '#f87171'};">${diffSign}${diff.toLocaleString()} units (${percentSign}${calcPercent}%)</b>
            </div>
          `;
        }
      },
      xAxis: {
        type: 'category',
        data: [
          { value: 'Yesterday', textStyle: { color: '#94a3b8', fontSize: 11, fontWeight: 'bold' } },
          { value: 'Today', textStyle: { color: accentColor, fontSize: 11, fontWeight: 'bold' } }
        ],
        axisLine: { show: false },
        axisTick: { show: false }
      },
      yAxis: {
        type: 'value',
        splitLine: { lineStyle: { type: 'dashed', color: 'rgba(148, 163, 184, 0.12)' } },
        axisLabel: { color: '#94a3b8', fontSize: 9 }
      },
      series: [
        {
          name: 'Expected Confidence Band',
          type: 'bar',
          barWidth: '46%',
          barGap: '-100%',
          data: [targetLimit, targetLimit],
          itemStyle: {
            color: bandBg,
            borderColor: bandBorder,
            borderWidth: 1,
            borderType: 'dashed',
            borderRadius: [8, 8, 0, 0]
          },
          tooltip: { show: false }
        },
        {
          name: volumeName,
          type: 'bar',
          barWidth: '34%',
          data: [
            {
              value: yesterdayVal,
              itemStyle: {
                color: {
                  type: 'linear',
                  x: 0,
                  y: 1,
                  x2: 0,
                  y2: 0,
                  colorStops: [
                    { offset: 0, color: '#334155' },
                    { offset: 1, color: '#94a3b8' }
                  ]
                },
                borderRadius: [6, 6, 0, 0]
              }
            },
            {
              value: todayVal,
              itemStyle: {
                color: {
                  type: 'linear',
                  x: 0,
                  y: 1,
                  x2: 0,
                  y2: 0,
                  colorStops: [
                    { offset: 0, color: gradientStart },
                    { offset: 1, color: gradientEnd }
                  ]
                },
                borderRadius: [6, 6, 0, 0]
              }
            }
          ],
          label: {
            show: true,
            position: 'top',
            formatter: (params: any) => {
              const val = params.value;
              if (params.dataIndex === 1) {
                return `{today|${val.toLocaleString()}} {diff|(${diffSign}${diff})}`;
              }
              return `{yesterday|${val.toLocaleString()}}`;
            },
            rich: {
              today: { color: accentColor, fontWeight: 'bold', fontSize: 10 },
              yesterday: { color: '#cbd5e1', fontWeight: 'semibold', fontSize: 10 },
              diff: { color: diff >= 0 ? '#4ade80' : '#f87171', fontWeight: 'bold', fontSize: 9 }
            }
          }
        }
      ]
    };
  }

  setInboundChartType(type: 'customAngle' | 'dashedLine'): void {
    this.selectedInboundChartType = type;
    this.initAllCharts();
    if (this.modalChartInstance && this.selectedModalInsight) {
      this.openChartModal(this.selectedModalInsight, 0);
    }
  }

  getInboundComparativeGaugeOption(item: InsightItem): any {
    const todayVal = Number(item.today ?? item.total ?? 0);

    const growthMatch = String(item.growth || '').match(/([+-]?\d+(?:\.\d+)?)/);
    const growthNum = growthMatch ? parseFloat(growthMatch[1]) : 0;

    let yesterdayVal = Number(item.yesterday);
    if (item.yesterday === undefined || item.yesterday === null || isNaN(yesterdayVal)) {
      if (growthNum !== 0 && (1 + growthNum / 100) !== 0) {
        yesterdayVal = Math.round(todayVal / (1 + growthNum / 100));
      } else {
        yesterdayVal = Math.round(todayVal * 0.85);
      }
    }

    const diff = todayVal - yesterdayVal;
    const diffSign = diff >= 0 ? '+' : '';
    const calcPercent = yesterdayVal > 0 ? ((diff / yesterdayVal) * 100).toFixed(1) : '0';
    const percentSign = parseFloat(calcPercent) >= 0 ? '+' : '';

    const categories = ['Yesterday', 'Today'];
    const values = [yesterdayVal, todayVal];

    return {
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0f172a',
        borderColor: '#38bdf8',
        textStyle: { color: '#f8fafc' },
        formatter: () => {
          return `
            <div style="font-weight:bold;margin-bottom:4px;color:#38bdf8;">Inbound Operations (Yesterday vs Today)</div>
            <div style="display:flex;justify-content:space-between;gap:15px;margin-bottom:2px;">
              <span style="color:#94a3b8;">Yesterday Baseline:</span>
              <b style="color:#cbd5e1;">${yesterdayVal.toLocaleString()} units</b>
            </div>
            <div style="display:flex;justify-content:space-between;gap:15px;margin-bottom:3px;">
              <span style="color:#38bdf8;">Today Total:</span>
              <b style="color:#38bdf8;">${todayVal.toLocaleString()} units</b>
            </div>
            <div style="border-top:1px solid rgba(255,255,255,0.1);padding-top:3px;display:flex;justify-content:space-between;gap:15px;">
              <span style="color:#94a3b8;">Growth Variance:</span>
              <b style="color:${diff >= 0 ? '#4ade80' : '#f87171'};">${diffSign}${diff.toLocaleString()} units (${percentSign}${calcPercent}%)</b>
            </div>
          `;
        }
      },
      legend: {
        show: true,
        top: '0%',
        left: 'center',
        textStyle: { color: '#94a3b8', fontSize: 11 }
      },
      grid: {
        top: '22%',
        left: '4%',
        right: '6%',
        bottom: '2%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: categories,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#f8fafc', fontSize: 11, fontWeight: 'bold' }
      },
      yAxis: {
        type: 'value',
        nameTextStyle: { color: '#94a3b8', fontSize: 10 },
        axisLabel: { color: '#94a3b8', fontSize: 10 },
        splitLine: { lineStyle: { color: 'rgba(56, 189, 248, 0.15)', type: 'dashed' } }
      },
      series: [
        {
          name: 'Yesterday vs Today Inbound Flow',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 12,
          lineStyle: {
            width: 4,
            type: 'dashed',
            color: '#38bdf8'
          },
          itemStyle: {
            color: (params: any) => {
              return params.dataIndex === 0 ? '#94a3b8' : '#38bdf8';
            },
            borderWidth: 3,
            borderColor: '#ffffff'
          },
          label: {
            show: true,
            position: 'top',
            color: '#38bdf8',
            fontWeight: 'bold',
            fontSize: 11,
            formatter: (params: any) => {
              return `${params.name}: ${params.value.toLocaleString()} units`;
            }
          },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(56, 189, 248, 0.35)' },
              { offset: 1, color: 'rgba(56, 189, 248, 0.02)' }
            ])
          },
          data: values
        }
      ]
    };
  }

  getWaveChartOption(item: InsightItem): echarts.EChartsOption {
    const baseVal = item.total || 450;
    return {
      grid: { top: 12, bottom: 22, left: 30, right: 12 },
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(15, 23, 42, 0.9)',
        borderColor: '#f97316',
        textStyle: { color: '#fff', fontSize: 11 },
        formatter: (params: any) => `${params[0].name}: <b style="color:#fb923c">${params[0].value} units</b>`
      },
      xAxis: {
        type: 'category',
        data: ['06:00', '09:00', '12:00', '15:00', '18:00', '21:00'],
        axisLine: { show: false },
        axisTick: { show: false },
        axisLabel: { color: '#94a3b8', fontSize: 9 }
      },
      yAxis: {
        type: 'value',
        splitLine: { lineStyle: { type: 'dashed', color: 'rgba(148, 163, 184, 0.12)' } },
        axisLabel: { color: '#94a3b8', fontSize: 8 }
      },
      series: [
        {
          data: [
            Math.round(baseVal * 0.35),
            Math.round(baseVal * 0.7),
            Math.round(baseVal * 0.95),
            Math.round(baseVal * 1.25),
            Math.round(baseVal * 0.8),
            Math.round(baseVal * 0.45)
          ],
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 5,
          itemStyle: { color: '#f97316' },
          lineStyle: { width: 3, color: '#f97316' },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: 'rgba(249, 115, 22, 0.45)' },
              { offset: 1, color: 'rgba(249, 115, 22, 0.02)' }
            ])
          }
        }
      ]
    };
  }

  getRadarChartOption(item: InsightItem): echarts.EChartsOption {
    return {
      radar: {
        indicator: [
          { name: 'Capacity', max: 100 },
          { name: 'Accuracy', max: 100 },
          { name: 'Turnover', max: 100 },
          { name: 'Health', max: 100 },
          { name: 'On-Time', max: 100 }
        ],
        shape: 'polygon',
        radius: '62%',
        center: ['50%', '50%'],
        splitNumber: 3,
        axisName: { color: '#9333ea', fontSize: 9, fontWeight: 'bold' },
        splitLine: { lineStyle: { color: 'rgba(168, 85, 247, 0.15)' } },
        splitArea: { show: false },
        axisLine: { lineStyle: { color: 'rgba(168, 85, 247, 0.2)' } }
      },
      series: [
        {
          type: 'radar',
          data: [
            {
              value: [88, 95, 76, 92, 85],
              name: 'Stock Metrics',
              symbol: 'circle',
              symbolSize: 4,
              itemStyle: { color: '#a855f7' },
              lineStyle: { width: 2, color: '#9333ea' },
              areaStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                  { offset: 0, color: 'rgba(168, 85, 247, 0.45)' },
                  { offset: 1, color: 'rgba(147, 51, 234, 0.05)' }
                ])
              }
            }
          ]
        }
      ]
    };
  }

  openChartModal(item: InsightItem, index: number): void {
    this.selectedModalInsight = item;
    this.isModalOpen = true;
    this.cdr.detectChanges();
    setTimeout(() => {
      if (this.modalChartContainer?.nativeElement) {
        const containerEl = this.modalChartContainer.nativeElement;
        if (this.modalChartInstance) {
          this.modalChartInstance.dispose();
        }
        this.modalChartInstance = echarts.getInstanceByDom(containerEl) || echarts.init(containerEl);
        const opt: any = this.getOptionForInsight(item, index);
        if (opt && opt.series && Array.isArray(opt.series) && opt.series.length > 0) {
          if (opt.series[0].type === 'gauge') {
            opt.series[0].radius = '90%';
            opt.series[0].center = ['50%', '54%'];
            if (opt.series[0].detail) {
              opt.series[0].detail.textStyle = { ...opt.series[0].detail.textStyle, fontSize: 26 };
            }
            if (opt.series[1]) {
              opt.series[1].radius = '70%';
              opt.series[1].center = ['50%', '54%'];
            }
          } else if (item.chartType === 'yesterdayToday' || index === 0 || index === 1) {
            if (opt.grid) {
              opt.grid.left = 20;
              opt.grid.right = 20;
            }
          }
        }
        if (opt && opt.radar) {
          if (Array.isArray(opt.radar) && opt.radar.length > 0) {
            opt.radar[0].radius = '75%';
          } else {
            opt.radar.radius = '75%';
          }
        }
        this.modalChartInstance.setOption(opt, true);
        this.modalChartInstance.resize();

        setTimeout(() => {
          this.modalChartInstance?.resize();
          window.dispatchEvent(new Event('resize'));
        }, 120);
      }
    }, 50);
  }

  closeChartModal(): void {
    this.isModalOpen = false;
    if (this.modalChartInstance) {
      this.modalChartInstance.dispose();
      this.modalChartInstance = undefined;
    }
    this.selectedModalInsight = null;
  }

  getGrowthArrow(growth: any): string {
    const value = parseFloat(String(growth).replace('%', ''));

    return value >= 0 ? '↗' : '↘';
  }

  getActivityPercentage(): number {
    return this.receiptData?.InboundSummary?.Percentage || 0;
  }

  loadShipmentReport() {
    this.loadingShipment = true;

    this.dashboardervice.getShipmentReport().subscribe({
      next: (res: any) => {
        this.shipmentData = {
          TotalOrders: res?.TotalOrders ?? 0,
          TotalShippedQty: res?.TotalShippedQty ?? 0,
          TopSku: res?.TopSku ?? 'N/A',
          TopSkuQty: res?.TopSkuQty ?? 0,
        };

        this.loadingShipment = false;
        this.renderShipmentChart();
      },
      error: (err) => {
        console.error('Shipment API Error:', err);
        this.loadingShipment = false;
      },
    });
  }

  toggleShipmentFullscreen(): void {
    this.isShipmentFullscreen.update((v) => !v);
    this.cdr.detectChanges();
    this.renderShipmentChart();
  }

  setShipmentChartType(type: 'bar' | 'donut' | 'gauge'): void {
    this.selectedShipmentChartType = type;
    this.renderShipmentChart();
  }

  renderShipmentChart(): void {
    this.cdr.detectChanges();
    setTimeout(() => {
      const isFS = this.isShipmentFullscreen();
      if (!isFS) {
        if (this.shipmentFullscreenChartInstance) {
          this.shipmentFullscreenChartInstance.dispose();
          this.shipmentFullscreenChartInstance = undefined;
        }
        if (this.shipmentChartContainer?.nativeElement) {
          const container = this.shipmentChartContainer.nativeElement;
          if (this.shipmentChartInstance) {
            this.shipmentChartInstance.dispose();
          }
          this.shipmentChartInstance = echarts.init(container);
          this.shipmentChartInstance.setOption(this.getShipmentChartOption());
          this.shipmentChartInstance.resize();
        }
      } else {
        if (this.shipmentChartInstance) {
          this.shipmentChartInstance.dispose();
          this.shipmentChartInstance = undefined;
        }
        if (this.shipmentFullscreenChartContainer?.nativeElement) {
          const container = this.shipmentFullscreenChartContainer.nativeElement;
          if (this.shipmentFullscreenChartInstance) {
            this.shipmentFullscreenChartInstance.dispose();
          }
          this.shipmentFullscreenChartInstance = echarts.init(container);
          this.shipmentFullscreenChartInstance.setOption(this.getShipmentChartOption());
          this.shipmentFullscreenChartInstance.resize();
        }
      }

      setTimeout(() => {
        if (isFS && this.shipmentFullscreenChartInstance) {
          this.shipmentFullscreenChartInstance.resize();
        } else if (!isFS && this.shipmentChartInstance) {
          this.shipmentChartInstance.resize();
        }
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new Event('resize'));
        }
      }, 150);
    }, 100);
  }

  getShipmentChartOption(): any {
    const totalOrders = Number(this.shipmentData?.TotalOrders ?? 0);
    const totalShippedQty = Number(this.shipmentData?.TotalShippedQty ?? 0);
    const topSku = this.shipmentData?.TopSku || 'Top SKU';
    const topSkuQty = Number(this.shipmentData?.TopSkuQty ?? 0);
    const remainingQty = Math.max(0, totalShippedQty - topSkuQty);

    const type = this.selectedShipmentChartType;
    const isFS = this.isShipmentFullscreen();

    // 1. BAR CHART (Shipped Volume Gradient Bar Chart)
    if (type === 'bar') {
      return {
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'shadow' },
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc', fontSize: isFS ? 13 : 11 },
          formatter: (params: any[]) => {
            const item = params[0];
            return `<div class="font-bold text-blue-400 mb-1">${item.name}</div>Volume: <b>${Number(item.value).toLocaleString()}</b>`;
          }
        },
        grid: {
          top: isFS ? '10%' : '12%',
          left: '4%',
          right: '4%',
          bottom: isFS ? '10%' : '12%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: ['Total Orders', 'Total Shipped Qty', `Top SKU (${topSku})`],
          axisLine: { lineStyle: { color: '#334155' } },
          axisLabel: { color: '#94a3b8', fontSize: isFS ? 13 : 11, fontWeight: 'bold' }
        },
        yAxis: {
          type: 'value',
          axisLine: { show: false },
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.1)', type: 'dashed' } },
          axisLabel: { color: '#94a3b8', fontSize: isFS ? 12 : 11 }
        },
        series: [
          {
            name: 'Volume',
            type: 'bar',
            barWidth: isFS ? '44%' : '36%',
            data: [
              {
                value: totalOrders,
                itemStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#3b82f6' },
                    { offset: 1, color: '#1d4ed8' }
                  ]),
                  borderRadius: [8, 8, 0, 0]
                }
              },
              {
                value: totalShippedQty,
                itemStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#10b981' },
                    { offset: 1, color: '#047857' }
                  ]),
                  borderRadius: [8, 8, 0, 0]
                }
              },
              {
                value: topSkuQty,
                itemStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#a855f7' },
                    { offset: 1, color: '#6b21a8' }
                  ]),
                  borderRadius: [8, 8, 0, 0]
                }
              }
            ],
            label: {
              show: true,
              position: 'top',
              color: '#94a3b8',
              fontSize: isFS ? 13 : 11,
              fontWeight: 'bold'
            }
          }
        ]
      };
    }

    // 2. DONUT CHART (Distribution Donut Ring)
    if (type === 'donut') {
      return {
        tooltip: {
          trigger: 'item',
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc', fontSize: isFS ? 13 : 11 },
          formatter: '{b}: <b>{c}</b> ({d}%)'
        },
        legend: {
          orient: 'horizontal',
          bottom: '0',
          textStyle: { color: '#94a3b8', fontSize: isFS ? 12 : 11, fontWeight: 'bold' }
        },
        series: [
          {
            name: 'Shipment Distribution',
            type: 'pie',
            radius: isFS ? ['48%', '75%'] : ['45%', '72%'],
            center: ['50%', isFS ? '46%' : '44%'],
            avoidLabelOverlap: true,
            itemStyle: {
              borderRadius: 8,
              borderColor: '#0f172a',
              borderWidth: 2
            },
            label: {
              show: true,
              formatter: '{b}\n{c} units',
              color: '#94a3b8',
              fontSize: isFS ? 12 : 10,
              fontWeight: 'bold'
            },
            data: [
              {
                value: topSkuQty,
                name: `Top SKU: ${topSku}`,
                itemStyle: { color: '#a855f7' }
              },
              {
                value: remainingQty,
                name: 'Other Shipped Units',
                itemStyle: { color: '#10b981' }
              },
              {
                value: totalOrders,
                name: 'Total Orders',
                itemStyle: { color: '#3b82f6' }
              }
            ]
          }
        ]
      };
    }

    // 3. GAUGE CHART (Speedometer Execution Gauge)
    if (type === 'gauge') {
      const targetPacing = totalOrders > 0 ? Math.min(Math.round((totalShippedQty / (totalOrders * 10)) * 100), 100) : 0;
      return {
        tooltip: {
          formatter: '{a} <br/>Pace: <b>{c}%</b>'
        },
        series: [
          {
            name: 'Shipment Pace',
            type: 'gauge',
            center: ['50%', isFS ? '55%' : '60%'],
            radius: isFS ? '95%' : '90%',
            startAngle: 180,
            endAngle: 0,
            min: 0,
            max: 100,
            splitNumber: 5,
            itemStyle: {
              color: '#3b82f6'
            },
            progress: {
              show: true,
              width: isFS ? 24 : 18,
              itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                  { offset: 0, color: '#3b82f6' },
                  { offset: 0.5, color: '#10b981' },
                  { offset: 1, color: '#a855f7' }
                ])
              }
            },
            pointer: {
              icon: 'path://M12.8,0.7l12,40.1H0.7L12.8,0.7z',
              length: '60%',
              width: isFS ? 8 : 6,
              offsetCenter: [0, '5%'],
              itemStyle: { color: 'auto' }
            },
            axisLine: {
              lineStyle: {
                width: isFS ? 24 : 18,
                color: [[1, 'rgba(148, 163, 184, 0.15)']]
              }
            },
            axisTick: { show: false },
            splitLine: { length: isFS ? 16 : 12, lineStyle: { color: 'auto', width: 2 } },
            axisLabel: { color: '#94a3b8', fontSize: isFS ? 12 : 10, distance: -40 },
            title: {
              offsetCenter: [0, '-20%'],
              fontSize: isFS ? 15 : 12,
              fontWeight: 'bold',
              color: '#94a3b8'
            },
            detail: {
              valueAnimation: true,
              offsetCenter: [0, '25%'],
              fontSize: isFS ? 32 : 22,
              fontWeight: 'extrabold',
              formatter: '{value}%',
              color: '#3b82f6'
            },
            data: [
              {
                value: targetPacing,
                name: 'Outbound Efficiency'
              }
            ]
          }
        ]
      };
    }

    return {};
  }

  getSkuReport(): void {
    this.isSkuLoading = true;

    this.dashboardervice.getSkuReport().subscribe({
      next: (res: any) => {
        if (res?.FastMovingSkus?.length) {
          const maxQty = Math.max(
            ...res.FastMovingSkus.map(
              (item: any) => Number(item.Quantity) || 0,
            ),
            1,
          );

          this.topsMovingSkus = res.FastMovingSkus.map(
            (item: any, index: number) => ({
              rank: index + 1,
              sku: item.Sku,
              name: item.Name,
              qty: Number(item.Quantity) || 0,
              change: item.Change,
              trendColor: item.TrendColor,
            }),
          );
        } else {
          this.topsMovingSkus = [];
        }

        this.isSkuLoading = false;
        this.renderSkuChart();
      },
      error: (err) => {
        console.error('SKU Error:', err);
        this.topsMovingSkus = [];
        this.isSkuLoading = false;
      },
    });
  }

  toggleSkuFullscreen(): void {
    this.isSkuFullscreen.update((v) => !v);
    this.renderSkuChart();
  }

  setSkuChartType(type: 'bar' | 'donut' | 'radar'): void {
    this.selectedSkuChartType = type;
    this.renderSkuChart();
  }

  renderSkuChart(): void {
    setTimeout(() => {
      if (this.skuChartContainer?.nativeElement) {
        const container = this.skuChartContainer.nativeElement;
        if (this.skuChartInstance) {
          this.skuChartInstance.dispose();
        }
        this.skuChartInstance = echarts.init(container);
        this.skuChartInstance.setOption(this.getSkuChartOption());
        this.skuChartInstance.resize();
      }

      if (this.isSkuFullscreen() && this.skuFullscreenChartContainer?.nativeElement) {
        const container = this.skuFullscreenChartContainer.nativeElement;
        if (this.skuFullscreenChartInstance) {
          this.skuFullscreenChartInstance.dispose();
        }
        this.skuFullscreenChartInstance = echarts.init(container);
        this.skuFullscreenChartInstance.setOption(this.getSkuChartOption());
        this.skuFullscreenChartInstance.resize();
      }
    }, 100);
  }

  getSkuChartOption(): any {
    const data = this.topsMovingSkus || [];
    const labels = data.map((item: any) => item.sku || 'SKU');
    const quantities = data.map((item: any) => Number(item.qty) || 0);

    const palette = ['#3b82f6', '#10b981', '#a855f7', '#f59e0b', '#ec4899', '#06b6d4', '#6366f1', '#14b8a6'];

    const type = this.selectedSkuChartType;

    // 1. BAR CHART (Horizontal SKU Volume Bar Spectrum)
    if (type === 'bar') {
      const barData = data.map((item: any, idx: number) => ({
        value: Number(item.qty) || 0,
        itemStyle: {
          color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [
            { offset: 0, color: palette[idx % palette.length] },
            { offset: 1, color: palette[idx % palette.length] + '44' }
          ]),
          borderRadius: [0, 6, 6, 0]
        }
      }));

      return {
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'shadow' },
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc' },
          formatter: (params: any[]) => {
            const item = params[0];
            return `<div class="font-bold text-blue-400">SKU: ${item.name}</div>Quantity: <b>${Number(item.value).toLocaleString()} Units</b>`;
          }
        },
        grid: {
          top: '8%',
          left: '4%',
          right: '8%',
          bottom: '8%',
          containLabel: true
        },
        xAxis: {
          type: 'value',
          axisLine: { show: false },
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.1)', type: 'dashed' } },
          axisLabel: { color: '#94a3b8', fontSize: 10 }
        },
        yAxis: {
          type: 'category',
          inverse: true,
          data: labels,
          axisLine: { lineStyle: { color: '#334155' } },
          axisLabel: { color: '#94a3b8', fontSize: 11, fontWeight: 'bold' }
        },
        series: [
          {
            name: 'Shipped Qty',
            type: 'bar',
            barWidth: '50%',
            data: barData,
            label: {
              show: true,
              position: 'right',
              color: '#94a3b8',
              fontSize: 11,
              fontWeight: 'bold',
              formatter: '{c} units'
            }
          }
        ]
      };
    }

    // 2. DONUT CHART (SKU Volume Share Donut Ring)
    if (type === 'donut') {
      const pieData = data.map((item: any, idx: number) => ({
        name: item.sku,
        value: Number(item.qty) || 0,
        itemStyle: { color: palette[idx % palette.length] }
      }));

      return {
        tooltip: {
          trigger: 'item',
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc' },
          formatter: '{b}<br/>Volume: <b>{c}</b> ({d}%)'
        },
        legend: {
          orient: 'horizontal',
          bottom: 0,
          textStyle: { color: '#94a3b8', fontSize: 10, fontWeight: 'bold' }
        },
        series: [
          {
            name: 'Top SKU Volume Share',
            type: 'pie',
            radius: ['45%', '72%'],
            center: ['50%', '44%'],
            avoidLabelOverlap: true,
            itemStyle: {
              borderRadius: 8,
              borderColor: '#0f172a',
              borderWidth: 2
            },
            label: {
              show: true,
              formatter: '{b}\n{c} units',
              color: '#94a3b8',
              fontSize: 10,
              fontWeight: 'bold'
            },
            data: pieData
          }
        ]
      };
    }

    // 3. RADAR CHART (SKU Velocity Radar Spider Web)
    if (type === 'radar') {
      const maxQty = Math.max(...quantities, 10);
      const indicator = labels.map((sku: string) => ({ name: sku, max: maxQty * 1.15 }));

      return {
        tooltip: {
          trigger: 'item',
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc' }
        },
        radar: {
          indicator: indicator,
          center: ['50%', '52%'],
          radius: '68%',
          axisName: { color: '#94a3b8', fontSize: 11, fontWeight: 'bold' },
          splitArea: {
            areaStyle: {
              color: ['rgba(168, 85, 247, 0.05)', 'rgba(168, 85, 247, 0.1)']
            }
          },
          axisLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.2)' } },
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.2)' } }
        },
        series: [
          {
            name: 'SKU Velocity',
            type: 'radar',
            data: [
              {
                value: quantities,
                name: 'Volume Velocity',
                symbol: 'circle',
                symbolSize: 6,
                lineStyle: { width: 2, color: '#a855f7' },
                areaStyle: { color: 'rgba(168, 85, 247, 0.35)' },
                itemStyle: { color: '#a855f7' }
              }
            ]
          }
        ]
      };
    }

    return {};
  }

  loadDockReport(): void {
    this.dashboardervice.getDockReport().subscribe({
      next: (response: any) => {
        const appointments = response?.Appointments || [];

        // Sort by AppointmentDate (Newest → Oldest)
        const sortedAppointments = [...appointments].sort(
          (a: any, b: any) => {
            const dateA = new Date(
              a.AppointmentDate ||
              a.CreatedDate ||
              a.CreatedOn ||
              0,
            ).getDate();

            const dateB = new Date(
              b.AppointmentDate ||
              b.CreatedDate ||
              b.CreatedOn ||
              0,
            ).getDate();

            return dateB - dateA;
          },
        );

        // Take only latest 10
        this.docks = sortedAppointments
          .slice(0, 10)
          .map((item: any, index: number) => {
            const ui = this.getDockConfig(item.Status);

            return {
              name:
                item.Door ||
                item.DockName ||
                item.Dock ||
                `Dock ${index + 1}`,

              status: item.Status,

              vehicle:
                item.VehicleNumber ||
                item.VehicleNo ||
                item.Vehicle ||
                item.TruckNo ||
                '-',

              appointmentNo:
                item.AppointmentID || item.AppointmentNo || '-',

              carrier: item.CarrierName || item.Carrier || '-',

              startTime: item.AppointmentDate
                ? new Date(
                  item.AppointmentDate,
                ).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                  hour12: true,
                })
                : '-',

              ...ui,
            };
          });

        console.table(this.docks);
        this.renderDockChart();
      },
      error: (err) => {
        console.error(err);
        this.docks = [];
      },
    });
  }

  toggleDockFullscreen(): void {
    this.isDockFullscreen.update((v) => !v);
    this.renderDockChart();
  }

  setDockChartType(type: 'bar' | 'donut' | 'radar'): void {
    this.selectedDockChartType = type;
    this.renderDockChart();
  }

  renderDockChart(): void {
    setTimeout(() => {
      if (this.dockChartContainer?.nativeElement) {
        const container = this.dockChartContainer.nativeElement;
        if (this.dockChartInstance) {
          this.dockChartInstance.dispose();
        }
        this.dockChartInstance = echarts.init(container);
        this.dockChartInstance.setOption(this.getDockChartOption());
        this.dockChartInstance.resize();
      }

      if (this.isDockFullscreen() && this.dockFullscreenChartContainer?.nativeElement) {
        const container = this.dockFullscreenChartContainer.nativeElement;
        if (this.dockFullscreenChartInstance) {
          this.dockFullscreenChartInstance.dispose();
        }
        this.dockFullscreenChartInstance = echarts.init(container);
        this.dockFullscreenChartInstance.setOption(this.getDockChartOption());
        this.dockFullscreenChartInstance.resize();
      }
    }, 100);
  }

  getDockChartOption(): any {
    const data = this.docks || [];

    const statusMap = new Map<string, number>();
    const doorMap = new Map<string, number>();

    data.forEach((item: any) => {
      const st = item.status || 'Scheduled';
      statusMap.set(st, (statusMap.get(st) || 0) + 1);

      const door = item.name || 'Dock';
      doorMap.set(door, (doorMap.get(door) || 0) + 1);
    });

    const statusLabels = Array.from(statusMap.keys());
    const doorLabels = Array.from(doorMap.keys());
    const doorCounts = Array.from(doorMap.values());

    const statusColors: Record<string, string> = {
      Arrived: '#f59e0b',
      InProgress: '#10b981',
      'In Progress': '#10b981',
      Loading: '#3b82f6',
      Unloading: '#06b6d4',
      Completed: '#22c55e',
      Scheduled: '#6366f1',
      Rescheduled: '#a855f7',
      Cancelled: '#ef4444',
    };

    const type = this.selectedDockChartType;

    // 1. BAR CHART (Dock Status Bar Chart)
    if (type === 'bar') {
      const barData = statusLabels.map((st) => ({
        value: statusMap.get(st) || 0,
        itemStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: statusColors[st] || '#3b82f6' },
            { offset: 1, color: (statusColors[st] || '#3b82f6') + '66' }
          ]),
          borderRadius: [8, 8, 0, 0]
        }
      }));

      return {
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'shadow' },
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc' },
          formatter: (params: any[]) => {
            const item = params[0];
            return `<div class="font-bold text-blue-400">Status: ${item.name}</div>Count: <b>${item.value} Docks</b>`;
          }
        },
        grid: {
          top: '12%',
          left: '4%',
          right: '4%',
          bottom: '12%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: statusLabels,
          axisLine: { lineStyle: { color: '#334155' } },
          axisLabel: { color: '#94a3b8', fontSize: 11, fontWeight: 'bold' }
        },
        yAxis: {
          type: 'value',
          axisLine: { show: false },
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.1)', type: 'dashed' } },
          axisLabel: { color: '#94a3b8', fontSize: 11 }
        },
        series: [
          {
            name: 'Dock Operations',
            type: 'bar',
            barWidth: '35%',
            data: barData,
            label: {
              show: true,
              position: 'top',
              color: '#94a3b8',
              fontSize: 11,
              fontWeight: 'bold'
            }
          }
        ]
      };
    }

    // 2. DONUT CHART (Dock Status Occupancy Ring)
    if (type === 'donut') {
      const pieData = statusLabels.map((st) => ({
        name: st,
        value: statusMap.get(st) || 0,
        itemStyle: { color: statusColors[st] || '#3b82f6' }
      }));

      return {
        tooltip: {
          trigger: 'item',
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc' },
          formatter: '{b}: <b>{c}</b> ({d}%)'
        },
        legend: {
          orient: 'horizontal',
          bottom: '0',
          textStyle: { color: '#94a3b8', fontSize: 11, fontWeight: 'bold' }
        },
        series: [
          {
            name: 'Dock Status Allocation',
            type: 'pie',
            radius: ['45%', '72%'],
            center: ['50%', '44%'],
            avoidLabelOverlap: true,
            itemStyle: {
              borderRadius: 8,
              borderColor: '#0f172a',
              borderWidth: 2
            },
            label: {
              show: true,
              formatter: '{b}\n{c} Docks',
              color: '#94a3b8',
              fontSize: 10,
              fontWeight: 'bold'
            },
            data: pieData
          }
        ]
      };
    }

    // 3. RADAR CHART (Door Activity Radar Matrix)
    if (type === 'radar') {
      const maxCount = Math.max(...doorCounts, 5);
      const indicator = doorLabels.map((door) => ({ name: door, max: maxCount * 1.2 }));

      return {
        tooltip: {
          trigger: 'item',
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc' }
        },
        radar: {
          indicator: indicator,
          center: ['50%', '52%'],
          radius: '68%',
          axisName: { color: '#94a3b8', fontSize: 11, fontWeight: 'bold' },
          splitArea: {
            areaStyle: {
              color: ['rgba(59, 130, 246, 0.05)', 'rgba(59, 130, 246, 0.1)']
            }
          },
          axisLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.2)' } },
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.2)' } }
        },
        series: [
          {
            name: 'Door Activity',
            type: 'radar',
            data: [
              {
                value: doorCounts,
                name: 'Active Appointments',
                symbol: 'circle',
                symbolSize: 6,
                lineStyle: { width: 2, color: '#3b82f6' },
                areaStyle: { color: 'rgba(59, 130, 246, 0.35)' },
                itemStyle: { color: '#3b82f6' }
              }
            ]
          }
        ]
      };
    }

    return {};
  }

  getDockConfig(status: string) {
    const currentStatus = (status || '').toLowerCase().trim();

    if (currentStatus.includes('rescheduled')) {
      return {
        icon: 'pi pi-refresh',
        bg: 'bg-orange-50 dark:bg-orange-500/10',
        iconColor: 'text-orange-500',
        textColor: 'text-orange-700 dark:text-orange-400',
        subText: 'text-orange-500/70',
        dot: 'bg-orange-500',
        glow: 'bg-orange-500',
      };
    }

    if (currentStatus.includes('scheduled')) {
      return {
        icon: 'pi pi-calendar',
        bg: 'bg-blue-50 dark:bg-blue-500/10',
        iconColor: 'text-blue-500',
        textColor: 'text-blue-700 dark:text-blue-400',
        subText: 'text-blue-500/70',
        dot: 'bg-blue-500',
        glow: 'bg-blue-500',
      };
    }

    if (currentStatus.includes('arrived')) {
      return {
        icon: 'pi pi-truck',
        bg: 'bg-cyan-50 dark:bg-cyan-500/10',
        iconColor: 'text-cyan-500',
        textColor: 'text-cyan-700 dark:text-cyan-400',
        subText: 'text-cyan-500/70',
        dot: 'bg-cyan-500',
        glow: 'bg-cyan-500',
      };
    }

    if (currentStatus.includes('progress')) {
      return {
        icon: 'pi pi-spin pi-spinner',
        bg: 'bg-violet-50 dark:bg-violet-500/10',
        iconColor: 'text-violet-500',
        textColor: 'text-violet-700 dark:text-violet-400',
        subText: 'text-violet-500/70',
        dot: 'bg-violet-500',
        glow: 'bg-violet-500',
      };
    }

    if (currentStatus.includes('completed')) {
      return {
        icon: 'pi pi-check-circle',
        bg: 'bg-emerald-50 dark:bg-emerald-500/10',
        iconColor: 'text-emerald-500',
        textColor: 'text-emerald-700 dark:text-emerald-400',
        subText: 'text-emerald-500/70',
        dot: 'bg-emerald-500',
        glow: 'bg-emerald-500',
      };
    }

    if (currentStatus.includes('cancel')) {
      return {
        icon: 'pi pi-times-circle',
        bg: 'bg-red-50 dark:bg-red-500/10',
        iconColor: 'text-red-500',
        textColor: 'text-red-700 dark:text-red-400',
        subText: 'text-red-500/70',
        dot: 'bg-red-500',
        glow: 'bg-red-500',
      };
    }

    if (currentStatus.includes('inbound')) {
      return {
        icon: 'pi pi-download',
        bg: 'bg-blue-50 dark:bg-blue-500/10',
        iconColor: 'text-blue-500',
        textColor: 'text-blue-700 dark:text-blue-400',
        subText: 'text-blue-500/70',
        dot: 'bg-blue-500',
        glow: 'bg-blue-500',
      };
    }

    if (currentStatus.includes('outbound')) {
      return {
        icon: 'pi pi-upload',
        bg: 'bg-green-50 dark:bg-green-500/10',
        iconColor: 'text-green-500',
        textColor: 'text-green-700 dark:text-green-400',
        subText: 'text-green-500/70',
        dot: 'bg-green-500',
        glow: 'bg-green-500',
      };
    }

    // Default
    return {
      icon: 'pi pi-calendar',
      bg: 'bg-gray-50',
      iconColor: 'text-gray-500',
      textColor: 'text-gray-700',
      subText: 'text-gray-500',
      dot: 'bg-gray-500',
      glow: 'bg-gray-500',
    };
  }

  getAppointmentReport() {
    this.dashboardervice.getAppointmentReport().subscribe({
      next: (res: any) => {
        const statuses = res?.Statuses || [];

        const iconMap: any = {
          Scheduled: {
            icon: 'pi pi-calendar',
            bg: 'bg-blue-50 dark:bg-blue-500/10',
            iconColor: 'text-blue-500',
            textColor: 'text-blue-600',
            line: 'bg-gradient-to-r from-blue-400 to-orange-400',
          },
          Rescheduled: {
            icon: 'pi pi-refresh',
            bg: 'bg-orange-50 dark:bg-orange-500/10',
            iconColor: 'text-orange-500',
            textColor: 'text-orange-600',
            line: 'bg-gradient-to-r from-orange-400 to-cyan-400',
          },
          Arrived: {
            icon: 'pi pi-truck',
            bg: 'bg-cyan-50 dark:bg-cyan-500/10',
            iconColor: 'text-cyan-500',
            textColor: 'text-cyan-600',
            line: 'bg-gradient-to-r from-cyan-400 to-violet-400',
          },
          InProgress: {
            icon: 'pi pi-spin pi-spinner',
            bg: 'bg-violet-50 dark:bg-violet-500/10',
            iconColor: 'text-violet-500',
            textColor: 'text-violet-600',
            line: 'bg-gradient-to-r from-violet-400 to-emerald-400',
          },
          Completed: {
            icon: 'pi pi-check-circle',
            bg: 'bg-emerald-50 dark:bg-emerald-500/10',
            iconColor: 'text-emerald-500',
            textColor: 'text-emerald-600',
            line: 'bg-gradient-to-r from-emerald-400 to-red-400',
          },
          Cancelled: {
            icon: 'pi pi-times-circle',
            bg: 'bg-red-50 dark:bg-red-500/10',
            iconColor: 'text-red-500',
            textColor: 'text-red-600',
            line: '',
          },
        };

        // ✅ FIXED ORDER
        const order = [
          'Scheduled',
          'Rescheduled',
          'Arrived',
          'InProgress',
          'Completed',
          'Cancelled',
        ];

        // convert API to lookup
        const apiMap = new Map(
          statuses.map((s: any) => [s.Status, s.Count]),
        );

        // build ordered flow
        this.appointmentFlow = order.map((status) => {
          const style = iconMap[status];

          return {
            label: status,
            count: apiMap.get(status) ?? 0,
            ...style,
          };
        });

        this.renderAppointmentChart();
      },
      error: (err) => {
        console.error('API error:', err);
      },
    });
  }

  toggleAppointmentFullscreen(): void {
    this.isAppointmentFullscreen.update((v) => !v);
    this.cdr.detectChanges();
    this.renderAppointmentChart();
  }

  setAppointmentChartType(type: 'step' | 'spline' | 'combo'): void {
    this.selectedAppointmentChartType = type;
    this.renderAppointmentChart();
  }

  renderAppointmentChart(): void {
    this.cdr.detectChanges();
    setTimeout(() => {
      const isFS = this.isAppointmentFullscreen();
      if (!isFS) {
        if (this.appointmentFullscreenChartInstance) {
          this.appointmentFullscreenChartInstance.dispose();
          this.appointmentFullscreenChartInstance = undefined;
        }
        if (this.appointmentChartContainer?.nativeElement) {
          const container = this.appointmentChartContainer.nativeElement;
          if (this.appointmentChartInstance) {
            this.appointmentChartInstance.dispose();
          }
          this.appointmentChartInstance = echarts.init(container);
          this.appointmentChartInstance.setOption(this.getAppointmentChartOption());
          this.appointmentChartInstance.resize();
        }
      } else {
        if (this.appointmentChartInstance) {
          this.appointmentChartInstance.dispose();
          this.appointmentChartInstance = undefined;
        }
        if (this.appointmentFullscreenChartContainer?.nativeElement) {
          const container = this.appointmentFullscreenChartContainer.nativeElement;
          if (this.appointmentFullscreenChartInstance) {
            this.appointmentFullscreenChartInstance.dispose();
          }
          this.appointmentFullscreenChartInstance = echarts.init(container);
          this.appointmentFullscreenChartInstance.setOption(this.getAppointmentChartOption());
          this.appointmentFullscreenChartInstance.resize();
        }
      }

      setTimeout(() => {
        if (isFS && this.appointmentFullscreenChartInstance) {
          this.appointmentFullscreenChartInstance.resize();
        } else if (!isFS && this.appointmentChartInstance) {
          this.appointmentChartInstance.resize();
        }
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new Event('resize'));
        }
      }, 150);
    }, 100);
  }

  getAppointmentChartOption(): any {
    const flow = this.appointmentFlow || [];
    const labels = flow.map((item: any) => item.label || 'Stage');
    const counts = flow.map((item: any) => Number(item.count) || 0);

    const type = this.selectedAppointmentChartType;
    const isFS = this.isAppointmentFullscreen();

    if (type === 'step') {
      return {
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'line' },
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc', fontSize: isFS ? 13 : 11 },
          formatter: (params: any[]) => {
            const item = params[0];
            return `<div class="font-bold text-blue-400 mb-1">Stage: ${item.name}</div>Count: <b>${Number(item.value).toLocaleString()} Appointments</b>`;
          }
        },
        grid: {
          top: isFS ? '10%' : '14%',
          left: '4%',
          right: '4%',
          bottom: isFS ? '10%' : '14%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: labels,
          axisLine: { lineStyle: { color: '#334155' } },
          axisLabel: {
            color: '#94a3b8',
            fontSize: isFS ? 12 : 10,
            fontWeight: 'bold',
            interval: 0
          }
        },
        yAxis: {
          type: 'value',
          axisLine: { show: false },
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.15)', type: 'dashed' } },
          axisLabel: { color: '#94a3b8', fontSize: isFS ? 12 : 11 }
        },
        series: [
          {
            name: 'Appointment Flow',
            type: 'line',
            step: 'middle',
            data: counts,
            symbol: 'circle',
            symbolSize: isFS ? 10 : 8,
            lineStyle: { width: 3, color: '#3b82f6' },
            itemStyle: { color: '#3b82f6', borderWidth: 2, borderColor: '#ffffff' },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(59, 130, 246, 0.35)' },
                { offset: 1, color: 'rgba(59, 130, 246, 0.02)' }
              ])
            },
            label: {
              show: true,
              position: 'top',
              color: '#3b82f6',
              fontSize: isFS ? 12 : 10,
              fontWeight: 'bold'
            }
          }
        ]
      };
    }

    if (type === 'spline') {
      return {
        tooltip: {
          trigger: 'axis',
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc', fontSize: isFS ? 13 : 11 }
        },
        grid: {
          top: isFS ? '10%' : '14%',
          left: '4%',
          right: '4%',
          bottom: isFS ? '10%' : '14%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: labels,
          axisLine: { lineStyle: { color: '#334155' } },
          axisLabel: {
            color: '#94a3b8',
            fontSize: isFS ? 12 : 10,
            fontWeight: 'bold',
            interval: 0
          }
        },
        yAxis: {
          type: 'value',
          axisLine: { show: false },
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.15)', type: 'dashed' } },
          axisLabel: { color: '#94a3b8', fontSize: isFS ? 12 : 11 }
        },
        series: [
          {
            name: 'Appointment Flow',
            type: 'line',
            smooth: true,
            data: counts,
            symbol: 'circle',
            symbolSize: isFS ? 10 : 8,
            lineStyle: { width: 3.5, color: '#6366f1' },
            itemStyle: { color: '#6366f1' },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(99, 102, 241, 0.35)' },
                { offset: 1, color: 'rgba(99, 102, 241, 0.02)' }
              ])
            },
            label: {
              show: true,
              position: 'top',
              color: '#818cf8',
              fontSize: isFS ? 12 : 10,
              fontWeight: 'bold'
            }
          }
        ]
      };
    }

    if (type === 'combo') {
      return {
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'cross' },
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc', fontSize: isFS ? 13 : 11 }
        },
        grid: {
          top: isFS ? '10%' : '14%',
          left: '4%',
          right: '4%',
          bottom: isFS ? '10%' : '14%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: labels,
          axisLine: { lineStyle: { color: '#334155' } },
          axisLabel: {
            color: '#94a3b8',
            fontSize: isFS ? 12 : 10,
            fontWeight: 'bold',
            interval: 0
          }
        },
        yAxis: {
          type: 'value',
          axisLine: { show: false },
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.15)', type: 'dashed' } },
          axisLabel: { color: '#94a3b8', fontSize: isFS ? 12 : 11 }
        },
        series: [
          {
            name: 'Stage Count',
            type: 'bar',
            barWidth: isFS ? '40%' : '32%',
            data: counts,
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: '#3b82f6' },
                { offset: 1, color: '#1e3a8a' }
              ]),
              borderRadius: [6, 6, 0, 0]
            }
          },
          {
            name: 'Trend Line',
            type: 'line',
            smooth: true,
            data: counts,
            symbol: 'circle',
            symbolSize: isFS ? 8 : 6,
            lineStyle: { width: 2.5, color: '#06b6d4' },
            itemStyle: { color: '#06b6d4' }
          }
        ]
      };
    }

    return {};
  }

  getLocationReport() {
    this.dashboardervice.getLocationReport().subscribe({
      next: (response: any) => {
        const colors = [
          'bg-green-500',
          'bg-blue-500',
          'bg-orange-500',
          'bg-purple-500',
          'bg-pink-500',
          'bg-cyan-500',
        ];

        this.locationsUsed = response?.Locations?.map(
          (item: any, index: number) => ({
            location: item.Location,
            zone: `Inventory: ${item.CurrentInventory}`,
            count: item.TotalMoves,
            color: colors[index % colors.length],
          }),
        );

        this.renderLocationChart();
      },
      error: (error) => {
        console.error('Location report error:', error);
      },
    });
  }

  toggleLocationFullscreen(): void {
    this.isLocationFullscreen.update((v) => !v);
    this.cdr.detectChanges();
    this.renderLocationChart();
  }

  setLocationChartType(type: 'bar' | 'pie' | 'radar'): void {
    this.selectedLocationChartType = type;
    this.renderLocationChart();
  }

  renderLocationChart(): void {
    this.cdr.detectChanges();
    setTimeout(() => {
      const isFS = this.isLocationFullscreen();
      if (!isFS) {
        if (this.locationFullscreenChartInstance) {
          this.locationFullscreenChartInstance.dispose();
          this.locationFullscreenChartInstance = undefined;
        }
        if (this.locationChartContainer?.nativeElement) {
          const container = this.locationChartContainer.nativeElement;
          if (this.locationChartInstance) {
            this.locationChartInstance.dispose();
          }
          this.locationChartInstance = echarts.init(container);
          this.locationChartInstance.setOption(this.getLocationChartOption());
          this.locationChartInstance.resize();
        }
      } else {
        if (this.locationChartInstance) {
          this.locationChartInstance.dispose();
          this.locationChartInstance = undefined;
        }
        if (this.locationFullscreenChartContainer?.nativeElement) {
          const container = this.locationFullscreenChartContainer.nativeElement;
          if (this.locationFullscreenChartInstance) {
            this.locationFullscreenChartInstance.dispose();
          }
          this.locationFullscreenChartInstance = echarts.init(container);
          this.locationFullscreenChartInstance.setOption(this.getLocationChartOption());
          this.locationFullscreenChartInstance.resize();
        }
      }

      setTimeout(() => {
        if (isFS && this.locationFullscreenChartInstance) {
          this.locationFullscreenChartInstance.resize();
        } else if (!isFS && this.locationChartInstance) {
          this.locationChartInstance.resize();
        }
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new Event('resize'));
        }
      }, 150);
    }, 100);
  }

  getLocationChartOption(): any {
    const data = this.locationsUsed || [];
    const labels = data.map((item: any) => item.location || 'Loc');
    const moveCounts = data.map((item: any) => Number(item.count) || 0);
    const inventoryCounts = data.map((item: any) => {
      const invMatch = String(item.zone || '').match(/\d+/);
      return invMatch ? Number(invMatch[0]) : 0;
    });

    const palette = ['#3b82f6', '#10b981', '#f59e0b', '#a855f7', '#ec4899', '#06b6d4', '#6366f1'];

    const type = this.selectedLocationChartType;

    // 1. BAR CHART (Horizontal Movement & Inventory Bar Chart)
    if (type === 'bar') {
      return {
        tooltip: {
          trigger: 'axis',
          axisPointer: { type: 'shadow' },
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc' },
          formatter: (params: any[]) => {
            let res = `<div class="font-bold text-blue-400 mb-1">${params[0].name}</div>`;
            params.forEach((p: any) => {
              res += `${p.marker} ${p.seriesName}: <b>${p.value}</b><br/>`;
            });
            return res;
          }
        },
        legend: {
          data: ['Total Moves', 'Current Inventory'],
          top: 0,
          textStyle: { color: '#94a3b8', fontSize: 11, fontWeight: 'bold' }
        },
        grid: {
          top: '16%',
          left: '3%',
          right: '4%',
          bottom: '8%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: labels,
          axisLine: { lineStyle: { color: '#334155' } },
          axisLabel: { color: '#94a3b8', fontSize: 10, fontWeight: 'bold' }
        },
        yAxis: {
          type: 'value',
          axisLine: { show: false },
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.1)', type: 'dashed' } },
          axisLabel: { color: '#94a3b8', fontSize: 10 }
        },
        series: [
          {
            name: 'Total Moves',
            type: 'bar',
            data: moveCounts,
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: '#3b82f6' },
                { offset: 1, color: '#1d4ed8' }
              ]),
              borderRadius: [6, 6, 0, 0]
            }
          },
          {
            name: 'Current Inventory',
            type: 'bar',
            data: inventoryCounts,
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: '#10b981' },
                { offset: 1, color: '#047857' }
              ]),
              borderRadius: [6, 6, 0, 0]
            }
          }
        ]
      };
    }

    // 2. PIE CHART (Nightingale Rose / Pie Spectrum)
    if (type === 'pie') {
      const pieData = data.map((item: any, idx: number) => ({
        name: item.location,
        value: Number(item.count) || 0,
        itemStyle: { color: palette[idx % palette.length] }
      }));

      return {
        tooltip: {
          trigger: 'item',
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc' },
          formatter: '{b}<br/>Total Moves: <b>{c}</b> ({d}%)'
        },
        legend: {
          orient: 'horizontal',
          bottom: 0,
          textStyle: { color: '#94a3b8', fontSize: 10, fontWeight: 'bold' }
        },
        series: [
          {
            name: 'Location Moves',
            type: 'pie',
            radius: ['35%', '70%'],
            roseType: 'radius',
            center: ['50%', '45%'],
            itemStyle: {
              borderRadius: 8,
              borderColor: '#0f172a',
              borderWidth: 2
            },
            label: {
              show: true,
              color: '#94a3b8',
              fontSize: 10,
              fontWeight: 'bold',
              formatter: '{b}: {c}'
            },
            data: pieData
          }
        ]
      };
    }

    // 3. RADAR CHART (Location Radar Matrix)
    if (type === 'radar') {
      const maxMove = Math.max(...moveCounts, 10);
      const indicator = labels.map((loc: string) => ({ name: loc, max: maxMove * 1.2 }));

      return {
        tooltip: {
          trigger: 'item',
          backgroundColor: '#0f172a',
          borderColor: '#334155',
          textStyle: { color: '#f8fafc' }
        },
        radar: {
          indicator: indicator,
          center: ['50%', '50%'],
          radius: '68%',
          axisName: { color: '#94a3b8', fontSize: 11, fontWeight: 'bold' },
          splitArea: {
            areaStyle: {
              color: ['rgba(59, 130, 246, 0.05)', 'rgba(59, 130, 246, 0.1)']
            }
          },
          axisLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.2)' } },
          splitLine: { lineStyle: { color: 'rgba(148, 163, 184, 0.2)' } }
        },
        series: [
          {
            name: 'Location Dynamics',
            type: 'radar',
            data: [
              {
                value: moveCounts,
                name: 'Total Moves',
                symbol: 'circle',
                symbolSize: 6,
                lineStyle: { width: 2, color: '#3b82f6' },
                areaStyle: { color: 'rgba(59, 130, 246, 0.35)' },
                itemStyle: { color: '#3b82f6' }
              },
              {
                value: inventoryCounts,
                name: 'Inventory Levels',
                symbol: 'rect',
                symbolSize: 6,
                lineStyle: { width: 2, color: '#10b981' },
                areaStyle: { color: 'rgba(16, 185, 129, 0.25)' },
                itemStyle: { color: '#10b981' }
              }
            ]
          }
        ]
      };
    }

    return {};
  }

  loadHoldReport(): void {
    this.dashboardervice.getHoldReport().subscribe({
      next: (res: any) => {
        const holdData = res?.HoldData || [];

        this.lpnHold = 0;
        this.lotHold = 0;
        this.combinedHold = 0;

        holdData.forEach((item: any) => {
          const status = (item.Status || '').toLowerCase();

          if (status.includes('lpn') && !status.includes('lot')) {
            this.lpnHold += Number(item.Count || 0);
          } else if (
            status.includes('lot') &&
            !status.includes('lpn')
          ) {
            this.lotHold += Number(item.Count || 0);
          } else if (
            status.includes('lpn') &&
            status.includes('lot')
          ) {
            this.combinedHold += Number(item.Count || 0);
          }
        });

        this.totalHolds =
          this.lpnHold + this.lotHold + this.combinedHold;
        this.renderHoldChart();
      },
      error: (err) => {
        console.error(err);
      },
    });
  }
  loadQuickReport(): void {
    this.dashboardervice.getQuickReport().subscribe({
      next: (res: any) => {
        this.insight =
          res?.Data?.map((item: any) => {
            let total = 0;
            let description = '';
            let fileName = '';
            let label = '';
            let heading = '';

            const change = item?.ChangePercentage ?? 0;
            const trendSign = change >= 0 ? '+' : '';

            switch (item?.Type) {
              case 'Inbound': {
                const metrics = item?.Metrics || {};

                total = item?.CurrentValue ?? 0;

                fileName = 'inbound_report.xlsx';
                label = "Today's Inbound";
                heading = 'Inbound Operations';

                description = item?.Description || '';

                break;
              }

              case 'Outbound': {
                total = item?.CurrentValue ?? 0;

                fileName = 'outbound_report.xlsx';
                label = "Today's Outbound";
                heading = 'Outbound Operations';

                description = item?.Description || '';

                break;
              }

              case 'Inventory': {
                total = item?.CurrentValue ?? 0;

                fileName = 'inventory_report.xlsx';
                label = "Today's Inventory";
                heading = 'Inventory Overview';

                description = item?.Description || '';

                break;
              }

              default:
                total = item?.CurrentValue ?? 0;
                label = item?.Type ?? 'Unknown';
                heading = 'Summary';
                description =
                  'No additional details available.';
                break;
            }

            return {
              type: item.Type,
              label,
              heading,
              total,
              growth: `${trendSign}${change}% vs yesterday`,
              description,
              fileName,

              // PrimeNG Icons
              icon:
                item.Type === 'Inbound'
                  ? 'pi pi-arrow-down-left'
                  : item.Type === 'Outbound'
                    ? 'pi pi-send'
                    : 'pi pi-box',

              // Light + Dark Mode Background
              iconBg:
                item.Type === 'Inbound'
                  ? 'border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-500/10'
                  : item.Type === 'Outbound'
                    ? 'border border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-500/10'
                    : 'border border-purple-200 dark:border-purple-800 bg-purple-50 dark:bg-purple-500/10',

              // Icon Colors
              iconColor:
                item.Type === 'Inbound'
                  ? 'text-blue-600 dark:text-blue-400'
                  : item.Type === 'Outbound'
                    ? 'text-orange-600 dark:text-orange-400'
                    : 'text-purple-600 dark:text-purple-400',

              // Growth Colors
              textColor:
                change > 0
                  ? 'text-green-600 dark:text-green-400'
                  : change < 0
                    ? 'text-red-600 dark:text-red-400'
                    : 'text-slate-600 dark:text-slate-400',

              trend: item?.Trend ?? 'Stable',
              chartType: item.Type === 'Inbound' ? 'inboundGauge' : item.Type === 'Outbound' ? 'outboundComparison' : item.Type === 'Inventory' ? 'inventoryComparison' : 'radar',
              chartBadge: item.Type === 'Inbound' ? 'Yesterday vs Today Arc' : item.Type === 'Outbound' ? 'Target Step Area' : item.Type === 'Inventory' ? 'Fluid Dual-Area Wave' : 'Radar Performance Matrix',
              yesterday: item?.PreviousValue,
              today: item?.CurrentValue
            };
          }) || [];

        setTimeout(() => {
          this.initAllCharts();
        }, 200);
      },
      error: (err) => {
        console.error('Quick Report API Error:', err);
        this.insight = [];
      },
    });
  }

  downloadReports(item: any): void { }
}
