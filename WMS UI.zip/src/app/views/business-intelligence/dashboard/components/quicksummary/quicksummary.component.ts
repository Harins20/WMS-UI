import { Component, DestroyRef, inject, signal } from '@angular/core';
import { DashboardService } from '../../dashboard.service';
import { CommonModule } from '@angular/common';
import { MessageService } from 'primeng/api';
import { AuthService } from '../../../../../common/services';
import { LoadingComponent } from '../../../../../common/components/common-loading/loading.component';
import { AsnService } from '../../../../inbound/asns/asn.service';

export interface InsightItem {
    label: string;
    heading: string;
    total: number;
    growth: string;
    description: string;
    fileName: string;

    icon: string;
    iconBg: string;
    iconColor: string;
    textColor: string;

    trend: string;
}

@Component({
    selector: 'app-quicksummary',
    standalone: true,
    imports: [CommonModule, LoadingComponent],
    templateUrl: './quicksummary.component.html',
    styleUrls: ['./quicksummary.component.scss'],
})
export class QuickSummaryComponent {
    private dashboardervice = inject(DashboardService);
    private messageService = inject(MessageService);
    private destoryRef = inject(DestroyRef);
    public authService = inject(AuthService);
    private asnService = inject(AsnService);

    asnsView = signal<any>({});
    asns = signal<any[]>([]);
    activeTab: 'reports' | 'analytics' = 'reports';
    loading = signal(false);
    isGenerating = false;
    summaryGenerated = false;

    loadingShipment: boolean = false;
    insight: InsightItem[] = [];

    activeQuickTab: string = 'summary';
    refreshSeconds: number = 30;

    currentInsight = 0;

    totalHolds: number = 0;
    lpnHold: number = 0;
    lotHold: number = 0;
    combinedHold: number = 0;

    locationsUsed: any[] = [];
    appointmentFlow: any[] = [];
    docks: any[] = [];
    topsMovingSkus: any[] = [];
    isSkuLoading = false;
    refreshInterval: any;
    interval: any;

    shipmentData: any = {
        TotalOrders: 0,
        TotalShippedQty: 0,
        TopSku: '',
        TopSkuQty: 0,
    };

    receiptData: any = {
        InboundSummary: {
            Yesterday: 0,
            Today: 0,
            Percentage: 0,
        },
        ReceiptOverview: {
            New: 0,
            Received: 0,
            Closed: 0,
            Cancelled: 0,
            InReceiving: 0,
        },
        ProcessingFlow: [],
        ReceiptSummary: {
            Title: '',
            Summary: '',
        },
    };

    generateReport() {
        this.isGenerating = true;

        // API call here
        setTimeout(() => {
            this.isGenerating = false;
            this.summaryGenerated = true;
        }, 2000);
        this.loadQuickReport();
        this.getAppointmentReport();
        this.getLocationReport();
        this.loadHoldReport();
        this.getSkuReport();
        this.loadShipmentReport();
        this.loadDockReport();
    }

    ngOnInit() {
        this.loading.set(true);
        setTimeout(() => {
            this.loading.set(false);
        }, 2500);

        this.loadQuickReport();
        this.getAppointmentReport();
        this.getLocationReport();
        this.loadHoldReport();
        this.getSkuReport();
        this.loadShipmentReport();
        this.loadDockReport();
    }

    getGrowthArrow(growth: any): string {
        const value = parseFloat(String(growth).replace('%', ''));

        return value >= 0 ? '↗' : '↘';
    }

    getActivityPercentage(): number {
        return this.receiptData?.InboundSummary?.Percentage || 0;
    }

    loadShipmentReport() {
        this.loadingShipment = true;

        this.dashboardervice.getShipmentReport().subscribe({
            next: (res: any) => {
                this.shipmentData = {
                    TotalOrders: res?.TotalOrders ?? 0,
                    TotalShippedQty: res?.TotalShippedQty ?? 0,
                    TopSku: res?.TopSku ?? 'N/A',
                    TopSkuQty: res?.TopSkuQty ?? 0,
                };

                this.loadingShipment = false;
            },
            error: (err) => {
                console.error('Shipment API Error:', err);
                this.loadingShipment = false;
            },
        });
    }

    getSkuReport(): void {
        this.isSkuLoading = true;

        this.dashboardervice.getSkuReport().subscribe({
            next: (res: any) => {
                if (res?.FastMovingSkus?.length) {
                    const maxQty = Math.max(
                        ...res.FastMovingSkus.map(
                            (item: any) => Number(item.Quantity) || 0,
                        ),
                        1,
                    );

                    this.topsMovingSkus = res.FastMovingSkus.map(
                        (item: any, index: number) => ({
                            rank: index + 1,
                            sku: item.Sku,
                            name: item.Name,
                            qty: Number(item.Quantity) || 0,
                            change: item.Change,
                            trendColor: item.TrendColor,
                        }),
                    );
                } else {
                    this.topsMovingSkus = [];
                }

                this.isSkuLoading = false;
            },
            error: (err) => {
                console.error('SKU Error:', err);
                this.topsMovingSkus = [];
                this.isSkuLoading = false;
            },
        });
    }

    loadDockReport(): void {
        this.dashboardervice.getDockReport().subscribe({
            next: (response: any) => {
                const appointments = response?.Appointments || [];

                // Sort by AppointmentDate (Newest → Oldest)
                const sortedAppointments = [...appointments].sort(
                    (a: any, b: any) => {
                        const dateA = new Date(
                            a.AppointmentDate ||
                                a.CreatedDate ||
                                a.CreatedOn ||
                                0,
                        ).getDate();

                        const dateB = new Date(
                            b.AppointmentDate ||
                                b.CreatedDate ||
                                b.CreatedOn ||
                                0,
                        ).getDate();

                        return dateB - dateA;
                    },
                );

                // Take only latest 10
                this.docks = sortedAppointments
                    .slice(0, 10)
                    .map((item: any, index: number) => {
                        const ui = this.getDockConfig(item.Status);

                        return {
                            name:
                                item.Door ||
                                item.DockName ||
                                item.Dock ||
                                `Dock ${index + 1}`,

                            status: item.Status,

                            vehicle:
                                item.VehicleNumber ||
                                item.VehicleNo ||
                                item.Vehicle ||
                                item.TruckNo ||
                                '-',

                            appointmentNo:
                                item.AppointmentID || item.AppointmentNo || '-',

                            carrier: item.CarrierName || item.Carrier || '-',

                            startTime: item.AppointmentDate
                                ? new Date(
                                      item.AppointmentDate,
                                  ).toLocaleTimeString([], {
                                      hour: '2-digit',
                                      minute: '2-digit',
                                      hour12: true,
                                  })
                                : '-',

                            ...ui,
                        };
                    });

                console.table(this.docks);
            },
            error: (err) => {
                console.error(err);
                this.docks = [];
            },
        });
    }

    getDockConfig(status: string) {
        const currentStatus = (status || '').toLowerCase().trim();

        if (currentStatus.includes('rescheduled')) {
            return {
                icon: 'pi pi-refresh',
                bg: 'bg-orange-50 dark:bg-orange-500/10',
                iconColor: 'text-orange-500',
                textColor: 'text-orange-700 dark:text-orange-400',
                subText: 'text-orange-500/70',
                dot: 'bg-orange-500',
                glow: 'bg-orange-500',
            };
        }

        if (currentStatus.includes('scheduled')) {
            return {
                icon: 'pi pi-calendar',
                bg: 'bg-blue-50 dark:bg-blue-500/10',
                iconColor: 'text-blue-500',
                textColor: 'text-blue-700 dark:text-blue-400',
                subText: 'text-blue-500/70',
                dot: 'bg-blue-500',
                glow: 'bg-blue-500',
            };
        }

        if (currentStatus.includes('arrived')) {
            return {
                icon: 'pi pi-truck',
                bg: 'bg-cyan-50 dark:bg-cyan-500/10',
                iconColor: 'text-cyan-500',
                textColor: 'text-cyan-700 dark:text-cyan-400',
                subText: 'text-cyan-500/70',
                dot: 'bg-cyan-500',
                glow: 'bg-cyan-500',
            };
        }

        if (currentStatus.includes('progress')) {
            return {
                icon: 'pi pi-spin pi-spinner',
                bg: 'bg-violet-50 dark:bg-violet-500/10',
                iconColor: 'text-violet-500',
                textColor: 'text-violet-700 dark:text-violet-400',
                subText: 'text-violet-500/70',
                dot: 'bg-violet-500',
                glow: 'bg-violet-500',
            };
        }

        if (currentStatus.includes('completed')) {
            return {
                icon: 'pi pi-check-circle',
                bg: 'bg-emerald-50 dark:bg-emerald-500/10',
                iconColor: 'text-emerald-500',
                textColor: 'text-emerald-700 dark:text-emerald-400',
                subText: 'text-emerald-500/70',
                dot: 'bg-emerald-500',
                glow: 'bg-emerald-500',
            };
        }

        if (currentStatus.includes('cancel')) {
            return {
                icon: 'pi pi-times-circle',
                bg: 'bg-red-50 dark:bg-red-500/10',
                iconColor: 'text-red-500',
                textColor: 'text-red-700 dark:text-red-400',
                subText: 'text-red-500/70',
                dot: 'bg-red-500',
                glow: 'bg-red-500',
            };
        }

        if (currentStatus.includes('inbound')) {
            return {
                icon: 'pi pi-download',
                bg: 'bg-blue-50 dark:bg-blue-500/10',
                iconColor: 'text-blue-500',
                textColor: 'text-blue-700 dark:text-blue-400',
                subText: 'text-blue-500/70',
                dot: 'bg-blue-500',
                glow: 'bg-blue-500',
            };
        }

        if (currentStatus.includes('outbound')) {
            return {
                icon: 'pi pi-upload',
                bg: 'bg-green-50 dark:bg-green-500/10',
                iconColor: 'text-green-500',
                textColor: 'text-green-700 dark:text-green-400',
                subText: 'text-green-500/70',
                dot: 'bg-green-500',
                glow: 'bg-green-500',
            };
        }

        // Default
        return {
            icon: 'pi pi-calendar',
            bg: 'bg-gray-50',
            iconColor: 'text-gray-500',
            textColor: 'text-gray-700',
            subText: 'text-gray-500',
            dot: 'bg-gray-500',
            glow: 'bg-gray-500',
        };
    }

    getAppointmentReport() {
        this.dashboardervice.getAppointmentReport().subscribe({
            next: (res: any) => {
                const statuses = res?.Statuses || [];

                const iconMap: any = {
                    Scheduled: {
                        icon: 'pi pi-calendar',
                        bg: 'bg-blue-50 dark:bg-blue-500/10',
                        iconColor: 'text-blue-500',
                        textColor: 'text-blue-600',
                        line: 'bg-gradient-to-r from-blue-400 to-orange-400',
                    },
                    Rescheduled: {
                        icon: 'pi pi-refresh',
                        bg: 'bg-orange-50 dark:bg-orange-500/10',
                        iconColor: 'text-orange-500',
                        textColor: 'text-orange-600',
                        line: 'bg-gradient-to-r from-orange-400 to-cyan-400',
                    },
                    Arrived: {
                        icon: 'pi pi-truck',
                        bg: 'bg-cyan-50 dark:bg-cyan-500/10',
                        iconColor: 'text-cyan-500',
                        textColor: 'text-cyan-600',
                        line: 'bg-gradient-to-r from-cyan-400 to-violet-400',
                    },
                    InProgress: {
                        icon: 'pi pi-spin pi-spinner',
                        bg: 'bg-violet-50 dark:bg-violet-500/10',
                        iconColor: 'text-violet-500',
                        textColor: 'text-violet-600',
                        line: 'bg-gradient-to-r from-violet-400 to-emerald-400',
                    },
                    Completed: {
                        icon: 'pi pi-check-circle',
                        bg: 'bg-emerald-50 dark:bg-emerald-500/10',
                        iconColor: 'text-emerald-500',
                        textColor: 'text-emerald-600',
                        line: 'bg-gradient-to-r from-emerald-400 to-red-400',
                    },
                    Cancelled: {
                        icon: 'pi pi-times-circle',
                        bg: 'bg-red-50 dark:bg-red-500/10',
                        iconColor: 'text-red-500',
                        textColor: 'text-red-600',
                        line: '',
                    },
                };

                // ✅ FIXED ORDER
                const order = [
                    'Scheduled',
                    'Rescheduled',
                    'Arrived',
                    'InProgress',
                    'Completed',
                    'Cancelled',
                ];

                // convert API to lookup
                const apiMap = new Map(
                    statuses.map((s: any) => [s.Status, s.Count]),
                );

                // build ordered flow
                this.appointmentFlow = order.map((status) => {
                    const style = iconMap[status];

                    return {
                        label: status,
                        count: apiMap.get(status) ?? 0,
                        ...style,
                    };
                });
            },
            error: (err) => {
                console.error('API error:', err);
            },
        });
    }

    getLocationReport() {
        this.dashboardervice.getLocationReport().subscribe({
            next: (response: any) => {
                const colors = [
                    'bg-green-500',
                    'bg-blue-500',
                    'bg-orange-500',
                    'bg-purple-500',
                    'bg-pink-500',
                    'bg-cyan-500',
                ];

                this.locationsUsed = response?.Locations?.map(
                    (item: any, index: number) => ({
                        location: item.Location,
                        zone: `Inventory: ${item.CurrentInventory}`,
                        count: item.TotalMoves,
                        color: colors[index % colors.length],
                    }),
                );
            },
            error: (error) => {
                console.error('Location report error:', error);
            },
        });
    }

    loadHoldReport(): void {
        this.dashboardervice.getHoldReport().subscribe({
            next: (res: any) => {
                const holdData = res?.HoldData || [];

                this.lpnHold = 0;
                this.lotHold = 0;
                this.combinedHold = 0;

                holdData.forEach((item: any) => {
                    const status = (item.Status || '').toLowerCase();

                    if (status.includes('lpn') && !status.includes('lot')) {
                        this.lpnHold += Number(item.Count || 0);
                    } else if (
                        status.includes('lot') &&
                        !status.includes('lpn')
                    ) {
                        this.lotHold += Number(item.Count || 0);
                    } else if (
                        status.includes('lpn') &&
                        status.includes('lot')
                    ) {
                        this.combinedHold += Number(item.Count || 0);
                    }
                });

                this.totalHolds =
                    this.lpnHold + this.lotHold + this.combinedHold;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }
    loadQuickReport(): void {
        this.dashboardervice.getQuickReport().subscribe({
            next: (res: any) => {
                this.insight =
                    res?.Data?.map((item: any) => {
                        let total = 0;
                        let description = '';
                        let fileName = '';
                        let label = '';
                        let heading = '';

                        const change = item?.ChangePercentage ?? 0;
                        const trendSign = change >= 0 ? '+' : '';

                        switch (item?.Type) {
                            case 'Inbound': {
                                const metrics = item?.Metrics || {};

                                total = item?.CurrentValue ?? 0;

                                fileName = 'inbound_report.xlsx';
                                label = "Today's Inbound";
                                heading = 'Inbound Operations';

                                description = item?.Description || '';

                                break;
                            }

                            case 'Outbound': {
                                total = item?.CurrentValue ?? 0;

                                fileName = 'outbound_report.xlsx';
                                label = "Today's Outbound";
                                heading = 'Outbound Operations';

                                description = item?.Description || '';

                                break;
                            }

                            case 'Inventory': {
                                total = item?.CurrentValue ?? 0;

                                fileName = 'inventory_report.xlsx';
                                label = "Today's Inventory";
                                heading = 'Inventory Overview';

                                description = item?.Description || '';

                                break;
                            }

                            default:
                                total = item?.CurrentValue ?? 0;
                                label = item?.Type ?? 'Unknown';
                                heading = 'Summary';
                                description =
                                    'No additional details available.';
                                break;
                        }

                        return {
                            label,
                            heading,
                            total,
                            growth: `${trendSign}${change}% vs yesterday`,
                            description,
                            fileName,

                            // PrimeNG Icons
                            icon:
                                item.Type === 'Inbound'
                                    ? 'pi pi-arrow-down-left'
                                    : item.Type === 'Outbound'
                                      ? 'pi pi-send'
                                      : 'pi pi-box',

                            // Light + Dark Mode Background
                            iconBg:
                                item.Type === 'Inbound'
                                    ? 'border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-500/10'
                                    : item.Type === 'Outbound'
                                      ? 'border border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-500/10'
                                      : 'border border-purple-200 dark:border-purple-800 bg-purple-50 dark:bg-purple-500/10',

                            // Icon Colors
                            iconColor:
                                item.Type === 'Inbound'
                                    ? 'text-blue-600 dark:text-blue-400'
                                    : item.Type === 'Outbound'
                                      ? 'text-orange-600 dark:text-orange-400'
                                      : 'text-purple-600 dark:text-purple-400',

                            // Growth Colors
                            textColor:
                                change > 0
                                    ? 'text-green-600 dark:text-green-400'
                                    : change < 0
                                      ? 'text-red-600 dark:text-red-400'
                                      : 'text-slate-600 dark:text-slate-400',

                            trend: item?.Trend ?? 'Stable',
                        };
                    }) || [];
            },
            error: (err) => {
                console.error('Quick Report API Error:', err);
                this.insight = [];
            },
        });
    }

    downloadReports(item: any): void {}
}
