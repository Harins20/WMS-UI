import { DestroyRef, inject, signal } from '@angular/core';
import { DashboardService } from '../../dashboard.service';
import { Component } from '@angular/core';
import { StatusComponent } from '../../StatusCount/status.component';
import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { DoughnutComponent } from '../../doughnut/doughnut.component';

interface DashboardData {
    title: string;
    labels: string[];
    values: any[];
}

@Component({
    selector: 'app-inventory',
    templateUrl: './inventory.component.html',
    styleUrls: ['./inventory.component.scss'],
    standalone: true,
    imports: [StatusComponent, AppTranslatePipe, DoughnutComponent],
})
export class InventoryComponent {
    dashboardService = inject(DashboardService);
    private destoryRef = inject(DestroyRef);
    private dashboardervice = inject(DashboardService);
    loading = signal(false);
    InventoryData = signal<DashboardData>({} as DashboardData);
    private pendingRequests = 0;

    ngOnInit() {
        this.getInventory();
    }

    getInventory() {
        this.startLoading(); // ✅
        const subscription = this.dashboardervice.getInventory().subscribe({
            next: (res) => this.InventoryData.set(res),
            error: () => this.finishLoading(), // ✅
            complete: () => this.finishLoading(), // ✅
        });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    private startLoading() {
        this.pendingRequests++;
        this.loading.set(true);
    }
    private finishLoading() {
        this.pendingRequests--;
        if (this.pendingRequests <= 0) {
            this.pendingRequests = 0;
            this.loading.set(false);
        }
    }
}
