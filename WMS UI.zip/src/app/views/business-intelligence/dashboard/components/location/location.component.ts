import { DestroyRef, inject, signal } from '@angular/core';
import { DashboardService } from '../../dashboard.service';
import { Component } from '@angular/core';
import { StatusComponent } from '../../StatusCount/status.component';
import { BarComponent } from '../../bar/bar.component';
import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';

interface DashboardData {
    title: string;
    labels: string[];
    values: any[];
}

@Component({
    selector: 'app-location',
    templateUrl: './location.component.html',
    imports: [StatusComponent, BarComponent, AppTranslatePipe],
})
export class LocationComponent {
    LocationData = signal<DashboardData>({} as DashboardData);
    private destoryRef = inject(DestroyRef);
    private dashboardervice = inject(DashboardService);
    loading = signal(false);

    private pendingRequests = 0;

    ngOnInit() {
        this.getLocation();
    }
    getLocation() {
        this.startLoading(); // ✅
        const subscription = this.dashboardervice.getLocation().subscribe({
            next: (res: any) => this.LocationData.set(res),
            error: () => this.finishLoading(), // ✅
            complete: () => this.finishLoading(), // ✅
        });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    private startLoading() {
        this.pendingRequests++;
        this.loading.set(true);
    }
    private finishLoading() {
        this.pendingRequests--;
        if (this.pendingRequests <= 0) {
            this.pendingRequests = 0;
            this.loading.set(false);
        }
    }
}
