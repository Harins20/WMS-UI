import { DestroyRef, inject, signal, ViewChild } from '@angular/core';
import { DashboardService } from '../../dashboard.service';
import { Component } from '@angular/core';
import { StatusComponent } from '../../StatusCount/status.component';
import { AppTranslatePipe } from '../../../../../common/pipes/translate.pipe';
import { formatDate } from '@angular/common';
import { SidebarModule } from 'primeng/sidebar';
import { OverlayPanel, OverlayPanelModule } from 'primeng/overlaypanel';
import { CommonModule } from '@angular/common';
import { OrderService } from '../../../../outbound/orders/order.service';
import { MessageService } from 'primeng/api';
import { LoadingComponent } from '../../../../../common/components';
import { PieComponent } from '../../Pie/pie.component';

interface DashboardData {
    title: string;
    labels: string[];
    values: any[];
}

@Component({
    selector: 'app-outbound',
    templateUrl: './outbound.component.html',
    styleUrls: ['./outbound.component.scss'],
    standalone: true,
    imports: [
        StatusComponent,
        AppTranslatePipe,
        PieComponent,
        SidebarModule,
        CommonModule,
        OverlayPanelModule,
        LoadingComponent,
    ],
})
export class OutboundComponent {
    showOutboundPopup = false;
    refreshSeconds: number = 30;
    sidebarVisible2: boolean = false;
    currentDate: string = '';
    @ViewChild('ap') ap!: OverlayPanel;

    rangeDates = signal<Date[] | undefined>(undefined);
    dashboardService = inject(DashboardService);
    private destoryRef = inject(DestroyRef);
    private dashboardervice = inject(DashboardService);
    private orderService = inject(OrderService);
    private messageService = inject(MessageService);
    loading = signal(false);
    OutboundData = signal<DashboardData>({} as DashboardData);
    private pendingRequests = 0;
    selectedReceiptType: any = null;
    insights: any[] = [];
    private intervalId: any;

    orders = signal<any[]>([]);
    OrderView = signal<any>({});
    isGeneralOpen = true;
    isShipFromOpen = false;
    isCarrierOpen = false;
    isUserDefinedOpen = false;
    isRemarksOpen = false;

    stats = [
        { field: 'today', label: "Today's Orders", value: 0, color: 'cyan' },
        {
            field: 'thisweek',
            label: 'This Week Orders',
            value: 0,
            color: 'blue',
        },
        {
            field: 'thismonth',
            label: 'This Month Orders',
            value: 0,
            color: 'green',
        },
        {
            field: 'thisyear',
            label: 'This Year Orders',
            value: 0,
            color: 'purple',
        },
    ];

    ngOnInit() {
        this.startCountdown();
        this.getOutbound();
        this.updateCurrentDate();
        this.GetOutboundData();
    }

    GetOutboundData() {
        this.orderService
            .getOrderPage({
                Page: 1,
                PageSize: 5,
            })
            .pipe()
            .subscribe({
                next: (res: any) => {
                    this.loading.set(false);

                    this.orders.set(res.Orders);
                },
            });
    }

    startCountdown() {
        this.intervalId = setInterval(() => {
            if (this.refreshSeconds > 0) {
                this.refreshSeconds--;
            } else {
                // optional: reset after reaching 0
                this.refreshSeconds = 30;
            }
        }, 1000);
    }
    ngOnDestroy() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
        }
    }

    getOrderFields() {
        const data = this.OrderView(); // call once safely

        if (!data) return [];

        return [
            { label: 'Owner', value: data.TRADERKEY },

            { label: 'External OrderKey', value: data.EXTERNORDERKEY },

            {
                label: 'Expected Ship Date',
                value: data.EXPECTEDSHIPDATE,
            },

            {
                label: 'Order Date',
                value: data.OrderDate,
            },

            {
                label: 'OrderKey',
                value: data.ORDERKEY,
            },

            {
                label: 'Priority',
                value: data.PRIORITY,
            },

            {
                label: 'Status',
                value: data.Status_Desc,
                type: 'status',
            },

            {
                label: 'Order Type',
                value: data.Type_Desc,
            },

            {
                label: 'Load Id',
                value: data.LOADID,
            },

            {
                label: 'Total Quantity',
                value: data.TOTALQTY,
            },

            {
                label: 'BOE',
                value: data.BOE,
            },

            {
                label: 'Expected Delivery Date',
                value: data.ExpectedDeliveryDate,
            },

            {
                label: 'Insurance Number',
                value: data.InsuranceNo,
            },
        ];
    }

    getShipFromFields() {
        const data = this.OrderView(); // call once safely

        if (!data) return [];

        return [
            {
                label: 'Ship To',
                value: data.CONSIGNEEKEY,
            },
            {
                label: 'Ship To Name',
                value: data.C_COMPANY,
            },
            {
                label: 'Address 1',
                value: data.C_ADDRESS1,
            },
            {
                label: 'Address 2',
                value: data.C_ADDRESS2,
            },
            {
                label: 'Address 3',
                value: data.C_ADDRESS3,
            },
            {
                label: 'Address 4',
                value: data.C_ADDRESS4,
            },
            {
                label: 'City',
                value: data.C_CITY,
            },
            {
                label: 'State',
                value: data.C_STATE,
            },
            {
                label: 'ZIP',
                value: data.C_ZIP,
            },
            {
                label: 'Country',
                value: data.C_COUNTRY,
            },
            {
                label: 'Email',
                value: data.C_EMAIL1,
                type: 'email',
            },
            {
                label: 'Phone',
                value: data.C_PHONE1,
            },
        ];
    }

    getCarrierFields() {
        const data = this.OrderView();

        if (!data) return [];

        return [
            {
                label: 'Carrier Code',
                value: data.CarrierCode,
            },
            {
                label: 'Carrier Name',
                value: data.CarrierName,
            },
            {
                label: 'Address 1',
                value: data.CarrierAddress1,
            },
            {
                label: 'Address 2',
                value: data.CarrierAddress2,
            },

            {
                label: 'City',
                value: data.CarrierCity,
            },
            {
                label: 'State',
                value: data.CarrierState,
            },
            {
                label: 'Country',
                value: data.CarrierCountry,
            },
            {
                label: 'ZIP',
                value: data.CarrierZip,
            },
            {
                label: 'Phone',
                value: data.CarrierPhone,
            },

            {
                label: 'Trailer Number',
                value: data.TrailerNumber,
            },
            {
                label: 'Trailer Owner',
                value: data.TrailerOwner,
            },
            {
                label: 'Trailer Key',
                value: data.TRAILERKEY,
            },
            {
                label: 'Transportation Mode',
                value: data.TRANSPORTATIONMODE,
            },
        ];
    }

    getUserDefinedFields() {
        const data = this.OrderView();

        if (!data) return [];

        return [
            {
                label: 'UDF 1',
                value: data.UDFSTR1,
            },
            {
                label: 'UDF 2',
                value: data.UDFSTR2,
            },
            {
                label: 'UDF 3',
                value: data.UDFSTR3,
            },
            {
                label: 'UDF 4',
                value: data.UDFSTR4,
            },
            {
                label: 'UDF 5',
                value: data.UDFSTR5,
            },
        ];
    }

    getQtyLabel(item: any): string {
        const qty = item?.TOTALQTY ?? 0;

        if (qty <= 0) return 'No Qty';
        if (qty < 10) return `Qty - ${qty}`;
        return `${qty} Qty`;
    }

    getProgress(item: any): number {
        const qty = item?.TOTALQTY ?? 0;

        const maxQty = 300;

        if (qty <= 0) return 0;

        return Math.min((qty / maxQty) * 100, 100);
    }

    toggle(event: Event) {
        this.ap.toggle(event);
    }

    toggleGeneral() {
        this.isGeneralOpen = !this.isGeneralOpen;
    }

    toggleShipFrom() {
        this.isShipFromOpen = !this.isShipFromOpen;
    }

    // CARRIER
    toggleCarrier() {
        this.isCarrierOpen = !this.isCarrierOpen;
    }

    // USER DEFINED
    toggleUserDefined() {
        this.isUserDefinedOpen = !this.isUserDefinedOpen;
    }

    // REMARKS
    toggleRemarks() {
        this.isRemarksOpen = !this.isRemarksOpen;
    }

    updateCurrentDate() {
        const today = new Date();

        this.currentDate = today.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
        });
    }

    onSelect() {
        if (this.rangeDates()?.[0] && this.rangeDates()?.[1]) {
            this.getOutbound();
        }
    }

    onClear() {
        this.getOutbound();
    }

    onClose(ap: OverlayPanel): void {
        this.orderService
            .CreateBackOrders({ TRADERKEY: [this.OrderView().TRADERKEY] })
            .subscribe({
                next: () => {
                    ap.hide();
                    this.getOutbound();
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'Order closed successfully',
                    });
                },
                error: () => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: 'Failed to close Order',
                    });
                },
            });
    }

    onDelete(ap: OverlayPanel): void {
        this.orderService
            .deleteOrder({ TRADERKEY: [this.OrderView().TRADERKEY] })
            .subscribe({
                next: () => {
                    ap.hide();
                    this.getOutbound();
                    this.messageService.add({
                        severity: 'success',
                        summary: 'Success',
                        detail: 'Order deleted successfully',
                    });
                },
                error: () => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: 'Failed to delete Order',
                    });
                },
            });
    }

    getOutbound() {
        const StartDate = this.rangeDates()?.[0]
            ? formatDate(this.rangeDates()![0], 'yyyyMMdd', 'en-US')
            : '';
        const EndDate = this.rangeDates()?.[1]
            ? formatDate(this.rangeDates()![1], 'yyyyMMdd', 'en-US')
            : '';

        this.startLoading(); // ✅
        const subscription = this.dashboardervice
            .getOutbound(StartDate, EndDate)
            .subscribe({
                next: (res) => this.OutboundData.set(res),
                error: () => this.finishLoading(), // ✅
                complete: () => this.finishLoading(), // ✅
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    OnviewOutbound(Data: any) {
        this.OrderView.set(Data);
        this.sidebarVisible2 = true;
    }

    getIcon(status: string): string {
        switch ((status || '').toLowerCase()) {
            case 'positive':
                return 'ti ti-trending-up';

            case 'alert':
                return 'ti ti-alert-circle';

            case 'high volume':
                return 'ti ti-package';

            case 'receiving':
                return 'ti ti-arrow-down-circle';

            case 'backlog':
                return 'ti ti-clock-hour-4';

            default:
                return 'ti ti-info-circle';
        }
    }

    getIconBg(status: string): string {
        switch ((status || '').toLowerCase()) {
            case 'positive':
                return 'bg-green-100';

            case 'alert':
                return 'bg-red-100';

            case 'high volume':
                return 'bg-lime-100';

            case 'receiving':
                return 'bg-blue-100';

            case 'backlog':
                return 'bg-orange-100';

            default:
                return 'bg-gray-100';
        }
    }

    getIconColor(status: string): string {
        switch ((status || '').toLowerCase()) {
            case 'positive':
                return 'text-green-600';

            case 'alert':
                return 'text-red-600';

            case 'high volume':
                return 'text-lime-600';

            case 'receiving':
                return 'text-blue-600';

            case 'backlog':
                return 'text-orange-600';

            default:
                return 'text-gray-600';
        }
    }

    getBadgeClass(status: string): string {
        switch ((status || '').toLowerCase()) {
            case 'positive':
                return 'bg-green-100 text-green-700';

            case 'alert':
                return 'bg-red-100 text-red-700';

            case 'high volume':
                return 'bg-lime-100 text-lime-700';

            case 'receiving':
                return 'bg-blue-100 text-blue-700';

            case 'backlog':
                return 'bg-orange-100 text-orange-700';

            default:
                return 'bg-gray-100 text-gray-700';
        }
    }

    getOutboundchartReport(type: any) {
        const subscription = this.dashboardervice
            .getOutboundchartReport(type)
            .subscribe({
                next: (res: any) => {
                    this.stats = this.stats.map((x: any) => {
                        if (x.field === 'today') {
                            return {
                                ...x,
                                value: res.OrdersCreatedToday,
                            };
                        }

                        if (x.field === 'thisweek') {
                            return {
                                ...x,
                                value: res.OrdersCreatedThisWeek,
                            };
                        }

                        if (x.field === 'thismonth') {
                            return {
                                ...x,
                                value: res.OrdersCreatedThisMonth,
                            };
                        }

                        if (x.field === 'thisyear') {
                            return {
                                ...x,
                                value: res.DistinctOrdersThisYear,
                            };
                        }

                        return x;
                    });
                    let labels: any = [];
                    let values: any = [];
                    res.ChartData.map((data: any) => {
                        labels.push(data.Status);
                        values.push(data.Count);
                    });
                    let ChartData = {
                        title: 'Inbound',
                        labels: labels,
                        values: values,
                    };
                    this.OutboundData.set(ChartData);
                },
                error: () => this.finishLoading(),
                complete: () => this.finishLoading(),
            });

        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    loadInsights() {
        this.dashboardervice.getOutboundInsightsReport().subscribe({
            next: (res: any) => {
                this.insights = Array.isArray(res) ? res : res?.data || [];
            },
            error: (err) => {
                console.error('Outbound Insights API Error:', err);
            },
        });
    }

    private startLoading() {
        this.pendingRequests++;
        this.loading.set(true);
    }
    private finishLoading() {
        this.pendingRequests--;
        if (this.pendingRequests <= 0) {
            this.pendingRequests = 0;
            this.loading.set(false);
        }
    }
    onOpenOutboundPopup() {
        this.showOutboundPopup = true;
        this.OutboundData.set({
            title: '',
            labels: [],
            values: [],
        });
        this.getOutboundchartReport(this.selectedReceiptType?.field || 'today');
        this.GetOutboundData();
        this.loadInsights();
    }
    selectReceiptType(item: any) {
        this.selectedReceiptType = item;
        this.getOutboundchartReport(item.field);

        // Call API here
        // this.getReceiptData(item.label);
    }
}
