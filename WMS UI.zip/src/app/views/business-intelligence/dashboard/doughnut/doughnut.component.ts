import { Component, inject, input } from '@angular/core';
import Chart from 'chart.js/auto';
import { ChartModule } from 'primeng/chart';
import { Subscription, debounceTime } from 'rxjs';
import { LayoutService } from '../../../../layout/service/layout.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'app-doughnut-chart',
    imports: [ChartModule],
    templateUrl: './doughnut.component.html',
    standalone: true,
})
export class DoughnutComponent {
    private translate = inject(TranslateService);
    data = input.required<{ title: string; labels: any[]; values: any[] }>();
    pieData: any;
    pieOptions: any;
  colors = [
  '#CC3A63',
  '#10B981',
  '#F59E0B',
  '#215E61',
  '#8B5CF6',
  '#06B6D4'
];
    subscription: Subscription;
    constructor(private layoutService: LayoutService) {
        this.subscription = this.layoutService.configUpdate$
            .pipe(debounceTime(25))
            .subscribe(() => {
                this.initCharts();
            });
    }
    ngOnChanges() {
        this.initCharts();
    }
    initCharts() {
        const documentStyle = getComputedStyle(document.documentElement);
        const textColor = documentStyle.getPropertyValue('--text-color');

        this.pieData = {
            labels: this.data()?.labels?.map((label) =>
                this.translate.instant(label),
            ),
            datasets: [
                {
                    data: this.data().values,
                    backgroundColor: this.colors,
                    borderRadius: 6,
                },
            ],
        };
        const selectedFont = this.layoutService.selectedFontFamily();
        this.pieOptions = {
            plugins: {
                legend: { display: false },
                tooltip: { enabled: true },
                datalabels: {
                    anchor: 'center',
                    align: 'center',
                    color: '#fff',
                    font: {
                        family: selectedFont,
                        weight: 'bold',
                    },
                    formatter: (value: any, context: any) => {
                        const data = context.chart.data.datasets[0]
                            .data as number[];
                        const total = data.reduce((sum, v) => sum + v, 0);
                        const percentage = (value / total) * 100;

                        // Show percentage only if >= 5
                        return percentage >= 5
                            ? `${percentage.toFixed(1)}%`
                            : '';
                    },
                },
            },
        };
    }
}
