import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Inbound, Outbound, Inventory, LocationType } from './model.model';
import { map, tap } from 'rxjs';
import { AppConfigService } from '../../../../app.config.service';
import { ResponseDto } from '../../../common/models';
import { AuthService } from '../../../common/services';

@Injectable({
    providedIn: 'root',
})
export class DashboardService {
    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);
    encodedFacility = sessionStorage.getItem('Facility');
    facility = this.encodedFacility ? atob(this.encodedFacility) : null;

    InboundLabel = ['New', 'In Receiving', 'Received', 'Closed', 'Cancelled'];
    OutLabel = [
        'Created Internally',
        'Created Externally',
        'Picked Complete',
        'Allocated',
        'Shipped Complete',
        'Returned',
    ];
    getInbound(StartDate: string, EndDate: string) {
        return this.httpClient
            .get<
                ResponseDto<Inbound[]>
            >(this.config.appConfig()?.InbUrl + `dashboard?StartDate=${StartDate}&EndDate=${EndDate}`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((data) => {
                    let labels: any = [];
                    let values: any = [];
                    data.Response.filter((x) =>
                        this.InboundLabel.includes(x.description),
                    ).map((data: any) => {
                        labels.push(data.description);
                        values.push(data.count);
                    });
                    return {
                        title: 'Inbound',
                        labels: labels,
                        values: values,
                    };
                }),
            );
    }

    getOutbound(StartDate: string, EndDate: string) {
        return this.httpClient
            .get<
                ResponseDto<Outbound[]>
            >(this.config.appConfig()?.OutUrl + `dashboard?StartDate=${StartDate}&EndDate=${EndDate}`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((data) => {
                    let labels: any = [];
                    let values: any = [];
                    data.Response.filter((x) =>
                        this.OutLabel.includes(x.description),
                    ).map((data: any) => {
                        labels.push(data.description);
                        values.push(data.count);
                    });
                    return {
                        title: 'Outbound',
                        labels: labels,
                        values: values,
                    };
                }),
            );
    }

    getInventory() {
        return this.httpClient
            .get<
                ResponseDto<Inventory[]>
            >(this.config.appConfig()?.InvUrl + 'dashboard', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((data) => {
                    let labels: any = [];
                    let values: any = [];
                    data.Response.map((data: any) => {
                        labels.push(data.DESCRIPTION);
                        values.push(data.count);
                    });
                    return {
                        title: 'Inventory',
                        labels: labels,
                        values: values,
                    };
                }),
            );
    }

    getLocation() {
        return this.httpClient
            .get<
                ResponseDto<LocationType>
            >(this.config.appConfig()?.MasterUrl + 'locations/count', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((data: any) => {
                    let values: any = [
                        data?.AvailableLocations,
                        data?.UsedLocations,
                        data?.UnusedLocations,
                    ];
                    return {
                        title: 'Location',
                        labels: ['Available Loc', 'Used Loc', 'Un Used Loc'],
                        values: values,
                    };
                }),
            );
    }
    getAsnsPage(data: any) {
        return this.httpClient.post<any>(
            this.config.appConfig()?.InbUrl + 'Asn/paged',
            data,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getQuickReport() {
        return this.httpClient.get<any>(
            this.config.appConfig()?.MasterUrl +
                `dashboard/operational-insights?Facility=${this.facility}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    private getInventoryInsights() {
        return this.httpClient.get<any>(
            this.config.appConfig()?.MasterUrl +
                `dashboard/inventory-insights?Facility=${this.facility}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getHoldReport() {
        return this.getInventoryInsights();
    }

    getSkuReport() {
        return this.getInventoryInsights();
    }

    getShipmentReport() {
        return this.httpClient.get<any>(
            this.config.appConfig()?.MasterUrl +
                `dashboard/shipment-insights?Facility=${this.facility}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getDockReport() {
        return this.httpClient.get<any>(
            this.config.appConfig()?.MasterUrl +
                `dashboard/upcoming-appointments?Facility=${this.facility}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getLocationReport() {
        return this.httpClient.get<any>(
            this.config.appConfig()?.MasterUrl +
                `dashboard/warehouse-movement?Facility=${this.facility}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getAppointmentReport() {
        return this.httpClient.get<any>(
            this.config.appConfig()?.MasterUrl +
                `dashboard/appointment-status?Facility=${this.facility}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getInboundchartReport(type: any) {
        return this.httpClient.get<any>(
            this.config.appConfig()?.MasterUrl +
                `dashboard/receipt-insights?Facility=${this.facility}&Period=${type}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    // New method for Multi-Facility Comparison receipt chart
    getReceiptChart(Period: any) {
        return this.httpClient.get<any>(
            this.config.appConfig()?.MasterUrl +
                `api/dashboard/receipt?Period=${Period}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getInboundInsightsReport() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.InbUrl + 'Asn/AIInsights',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getQuickInboundReceiptReport() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.InbUrl + 'QuickReport/Receipt',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getQuickInboundPoReport() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.InbUrl + 'QuickReport/POS',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getQuickInboundReceiptDetailReport() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.InbUrl + 'QuickReport/ReceiptDetails',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getQuickInboundPutawayDetailReport() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.InbUrl + 'QuickReport/Putaway',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getOutboundchartReport(type: any) {
        return this.httpClient.get<any>(
            this.config.appConfig()?.MasterUrl +
                `dashboard/Order-insights?Period=${type}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getOutboundInsightsReport() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.OutUrl + 'sto/AIInsights',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getQuickInventoryReport() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.InvUrl + 'QuickReport/Inventory/Overview',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getQuickOutboundOrderReport() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.OutUrl + 'QuickReport/Sto',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getQuickOutboundLoadReport() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.OutUrl + 'QuickReport/Loads',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getQuickOutboundReportReport() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.OutUrl + 'QuickReport/Returns',
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getAiInsights() {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.MasterUrl + 'dashboard/live-analysis',
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getSpecialUserAnalytics(Period: any) {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.MasterUrl +
                `api/dashboard?Period=${Period}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
    getInboundPerformanceAnalytics(Period: any) {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.MasterUrl +
                `api/dashboard/metrics?Period=${Period}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getOutboundPerformanceAnalytics(Period: any) {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.MasterUrl +
                `api/dadhboard/outbound?Period=${Period}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    getInventoryPerformanceAnalytics(Period: any) {
        return this.httpClient.get<any[]>(
            this.config.appConfig()?.MasterUrl +
                `api/dadhboard/inventory?Period=${Period}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }

    GetUsers() {
        return this.httpClient.get<any[]>(this.config.AuthUrl + 'users', {
            headers: this.authService.getAuthHeadersAp(),
        });
    }
}
