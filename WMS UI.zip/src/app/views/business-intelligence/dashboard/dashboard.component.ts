import {
    Component,
    DestroyRef,
    inject,
    signal,
    ViewChild,
} from '@angular/core';
import { DashboardService } from './dashboard.service';
import { MessageService } from 'primeng/api';
import { BarComponent } from './bar/bar.component';
import { DoughnutComponent } from './doughnut/doughnut.component';
import { PieComponent } from './Pie/pie.component';
import { RadarComponent } from './radar/radar.component';
import { StatusComponent } from './StatusCount/status.component';
import { TabViewModule } from 'primeng/tabview';
import { DatePicker } from 'primeng/datepicker';
import { MultiSelectModule } from 'primeng/multiselect';
import { FormsModule } from '@angular/forms';
import { formatDate } from '@angular/common';
import { LineComponent } from './line/line.component';
import { CardModule } from 'primeng/card';
import { LoadingComponent } from '../../../common/components/common-loading/loading.component';
import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { HorizontalBarComponent } from './bar copy/horizontal-bar.component';
import { CommonModule } from '@angular/common';
import { OverlayPanel, OverlayPanelModule } from 'primeng/overlaypanel';
import { SidebarModule } from 'primeng/sidebar';
import { AsnService } from '../../inbound/asns/asn.service';
import { HttpClient } from '@angular/common/http';
import { StyleClass } from 'primeng/styleclass';
import { OrderService } from '../../outbound/orders/order.service';
import { TableLazyLoadEvent } from 'primeng/table';
import { filterQuery } from '../../../common/functions';
import { OrderColumns } from '../../outbound';
import { LocationComponent } from './components/location/location.component';
import { InventoryComponent } from './components/inventory/inventory.component';
import { OutboundComponent } from './components/outbound/outbound.component';
import { InboundComponent } from './components/inbound/inbound.component';
import { AuthService } from '../../../common/services';
import { QuickSummaryComponent } from './components/quicksummary/quicksummary.component';
import { QuickInboundComponent } from './components/quickinbound/quickinbound.component';
import { QuickInventoryComponent } from './components/quickinventory/quickinventory.component';
import { QuickOutboundComponent } from './components/quickoutbound/quickoutbound.component';
import { InventoryAnalyticsComponent } from './components/quickinventory/inventory-analytics/inventory-analytics.component';
import { OutboundAnalyticsComponent } from './components/quickoutbound/outbound-analytics/outbound-analytics.component';
import { InboundAnalyticsComponent } from './components/quickinbound/inbound-analytics/inbound-analytics.component';
import { QuicksummaryAnalyticsComponent } from './components/quicksummary/quicksummary-analytics/quicksummary-analytics.component';
import { DailyanalyticsComponent } from './components/quicksummary/dailyanalytics/dailyanalytics.component';
import {
    WorkspaceService,
    WorkspaceToolbarComponent,
    WorkspaceGridComponent,
    WidgetLibraryComponent,
    WorkspaceBuilderComponent,
} from '../../../workspace';
import { timer, concatMap, from, takeUntil } from 'rxjs';
import { interval, startWith, Subject,  } from 'rxjs';

interface AsnLine {
    RECEIPTKEY: string;
    Status_Desc: string;
    SUPPLIERNAME: string;
    SHIPFROMCITY: string;
    SHIPFROMSTATE: string;
    OPENQTY: number;
    CARRIERNAME: string;
}

interface DashboardData {
    title: string;
    labels: string[];
    values: any[];
    Asn?: AsnLine[];
}

export interface InsightItem {
    label: string;
    heading: string;
    total: number;
    growth: number;
    description: string;
    fileName: string;

    icon: string;
    iconBg: string;
    iconColor: string;
    textColor: string;

    trend: string;
}

@Component({
    selector: 'app-dashboard',
    imports: [
        FormsModule,
        BarComponent,
        DoughnutComponent,
        HorizontalBarComponent,
        PieComponent,
        LineComponent,
        StatusComponent,
        TabViewModule,
        DatePicker,
        CardModule,
        LoadingComponent,
        AppTranslatePipe, CommonModule,
        OverlayPanelModule,
        SidebarModule,
        StyleClass,
        LocationComponent,
        InventoryComponent,
        OutboundComponent,
        InboundComponent,
        QuickSummaryComponent,
        QuickInboundComponent,
        QuickInventoryComponent,
        QuickOutboundComponent,
        InventoryAnalyticsComponent,
        OutboundAnalyticsComponent,
        QuicksummaryAnalyticsComponent,
        InboundAnalyticsComponent,
        MultiSelectModule,
        DailyanalyticsComponent,
        WorkspaceBuilderComponent,
        WorkspaceToolbarComponent,
        WorkspaceGridComponent,
        WidgetLibraryComponent,
    ],
    templateUrl: './dashboard.component.html',
})
export class DashboardComponent {
    public workspaceService = inject(WorkspaceService);
    loading = signal(false);
    showInboundPopup = false;
    showOutboundPopup = false;
    showQuickReport: boolean = false;
    showForecastReport: boolean = false;
    showQuickAnalytics: boolean = false;

    isGeneratingReport = false;
    encodedFacility = sessionStorage.getItem('Facility');
    facilityCache = this.encodedFacility ? atob(this.encodedFacility) : null;
    activeQuickTab: string = 'summary';
    quickReport: any;

    insight: InsightItem[] = [];
    private dashboardervice = inject(DashboardService);
    private destoryRef = inject(DestroyRef);
    rangeDates = signal<Date[] | undefined>(undefined);
    private asnService = inject(AsnService);
    private orderService = inject(OrderService);
    private messageService = inject(MessageService);
    public authService = inject(AuthService);
    private destroy$ = new Subject<void>();


    facilityOptions = signal<any[]>([]);
    selectedFacilities: string[] = [];
    reportFunctions: any;

    get facility() {
        return this.dashboardervice.facility;
    }

    inboundData = signal<DashboardData>({} as DashboardData);
    OutboundData = signal<DashboardData>({} as DashboardData);
    InventoryData = signal<DashboardData>({} as DashboardData);
    LocationData = signal<DashboardData>({} as DashboardData);
    asns = signal<any[]>([]);
    orders = signal<any[]>([]);
    asnsView = signal<any>({});
    OrderView = signal<any>({});
    asnData: any[] = [];
    docks: any[] = [];
    locationsUsed: any[] = [];
    appointmentFlow: any[] = [];
    posData: any;
    receiptDetailData: any = {};
    putawayData: any;
    inventoryData: any;
    quickOutboundOrderData: any;
    loadReport: any = {};
    returnReport: any = {};

    isGenerating = false;
    summaryGenerated = false;
    progressValue = 0;
    autoGenTimer: any;

    receivingCount = 0;
    completedCount = 0;
    cancelledCount = 0;

    totalHolds: number = 0;
    lpnHold: number = 0;
    lotHold: number = 0;
    combinedHold: number = 0;

    topsMovingSkus: any[] = [];
    isSkuLoading = false;

    maxQty: number = 0;

    totalCount = signal(0);

    refreshInterval: any;

    currentTime: Date = new Date();
    currentDate: string = '';

    aiInsights: any[] = [];
    currentInsight = 0;

    // LIVE OVERVIEW DATA
    overview: any = {
        total: 0,
        active: 0,
        new: 0,
        received: 0,
    };

    shipmentData: any = {
        TotalOrders: 0,
        TotalShippedQty: 0,
        TopSku: '',
        TopSkuQty: 0,
    };

    receiptData: any = {
        InboundSummary: {
            Yesterday: 0,
            Today: 0,
            Percentage: 0,
        },
        ReceiptOverview: {
            New: 0,
            Received: 0,
            Closed: 0,
            Cancelled: 0,
            InReceiving: 0,
        },
        ProcessingFlow: [],
        ReceiptSummary: {
            Title: '',
            Summary: '',
        },
    };

    loadingShipment: boolean = false;

    // LIVE INSIGHTS
    insights: any[] = [];

    constructor(private http: HttpClient) {}

    // ✅ Track pending requests
    private pendingRequests = 0;

    refreshSeconds: number = 30;
    interval: any;

    sidebarVisible2: boolean = false;
    @ViewChild('ap') ap!: OverlayPanel;
    toggle(event: Event) {
        this.ap.toggle(event);
    }
    toggleQuickReport() {
        this.showQuickReport = true;
        this.loadQuickInboundReceiptReport();
        this.loadPosReport();
        this.getReceiptDetailsReport();
        this.loadPutawayDetails();
        this.loadInventoryReport();
        this.getQuickOutboundOrderData();
        this.getLoadReport();
        this.getReturnReport();
        this.loadAiInsights();
    }
    
    toggleQuickAnalytics() {
        console.log('hi1')
        this.showQuickAnalytics = true;
        this.summaryGenerated = false;
        this.isGenerating = true;
        this.progressValue = 0;

        if (this.autoGenTimer) {
            clearInterval(this.autoGenTimer);
        }

      timer(0, 10000)
    .pipe(
      concatMap(index => {
console.log('hi2' , this.reportFunctions.length)
        if (index >= this.reportFunctions.length) {
          return from([]);
        }

        return from([this.reportFunctions[index]()]);
      }),
      takeUntil(this.destroy$)
    )
    .subscribe();

        // Increment progressValue up to 100 over 5 seconds
        // 50ms * 100 = 5000ms (5 seconds)
        this.autoGenTimer = setInterval(() => {
            if (this.progressValue < 100) {
                this.progressValue += 2;
            } else {
                clearInterval(this.autoGenTimer);
                this.isGenerating = false;
                this.summaryGenerated = true;
            }
        }, 50);
    }
    toggleInsightHub() {
        this.showForecastReport = true;
        this.summaryGenerated = false;
        this.isGenerating = true;
        this.progressValue = 0;

        if (this.autoGenTimer) {
            clearInterval(this.autoGenTimer);
        }

        this.loadQuickReport();
        this.getAppointmentReport();
        this.getLocationReport();
        this.loadReceivedInsight();
        this.loadHoldReport();
        this.getSkuReport();
        this.loadShipmentReport();
        this.loadDockReport();
        this.loadInventoryReport();
        this.getQuickOutboundOrderData();
        this.getLoadReport();
        this.getReturnReport();
        this.loadQuickInboundReceiptReport();
        this.loadPosReport();
        this.getReceiptDetailsReport();
        this.loadPutawayDetails();
        this.loadAiInsights();

        // Increment progressValue up to 100 over 5 seconds
        // 50ms * 100 = 5000ms (5 seconds)
        this.autoGenTimer = setInterval(() => {
            if (this.progressValue < 100) {
                this.progressValue += 2;
            } else {
                clearInterval(this.autoGenTimer);
                this.isGenerating = false;
                this.summaryGenerated = true;
            }
        }, 50);
    }

    // TOGGLES
    isGeneralOpen = true;
    isShipFromOpen = false;
    isCarrierOpen = false;
    isUserDefinedOpen = false;
    isRemarksOpen = false;

    private startLoading() {
        this.pendingRequests++;
        this.loading.set(true);
    }
    OnAtiveQuickTab(event: any) {
        this.activeQuickTab = event;
    }
    OnviewInbound(Data: any) {
        this.asnsView.set(Data);
        this.sidebarVisible2 = true;
    }

    OnviewOutbound(Data: any) {
        this.OrderView.set(Data);
        this.sidebarVisible2 = true;
    }

    closeQuickReport() {
        this.showQuickReport = false;
        this.showForecastReport = false;
        this.showQuickAnalytics = false;
        this.summaryGenerated = false;
        if (this.autoGenTimer) {
            clearInterval(this.autoGenTimer);
        }
        this.progressValue = 0;
        this.isGenerating = false;
    }

    generateReport() {
        this.activeQuickTab = 'summary';
        this.isGenerating = true;

        // API call here
        setTimeout(() => {
            this.isGenerating = false;
            this.summaryGenerated = true;
        }, 4000);
        this.loadQuickReport();
        this.getAppointmentReport();
        this.getLocationReport();
        this.loadReceivedInsight();
        this.loadHoldReport();
        this.getSkuReport();
        this.loadShipmentReport();
        this.loadDockReport();
        this.loadInventoryReport();
        this.getQuickOutboundOrderData();
        this.getLoadReport();
        this.getReturnReport();
        this.loadQuickInboundReceiptReport();
        this.loadPosReport();
        this.getReceiptDetailsReport();
        this.loadPutawayDetails();
        this.loadAiInsights();
    }

    // GENERAL
    toggleGeneral() {
        this.isGeneralOpen = !this.isGeneralOpen;
    }

    // SHIP FROM
    toggleShipFrom() {
        this.isShipFromOpen = !this.isShipFromOpen;
    }

    // CARRIER
    toggleCarrier() {
        this.isCarrierOpen = !this.isCarrierOpen;
    }

    // USER DEFINED
    toggleUserDefined() {
        this.isUserDefinedOpen = !this.isUserDefinedOpen;
    }

    // REMARKS
    toggleRemarks() {
        this.isRemarksOpen = !this.isRemarksOpen;
    }

    getAsnFields() {
        const data = this.asnsView(); // call once safely

        if (!data) return [];

        return [
            { label: 'Owner', value: data.TRADERKEY },
            { label: 'Type', value: data.Type_Desc },
            {
                label: 'Status',
                value: data.Status_Desc,
                type: 'status',
            },
            { label: 'External Ref.No', value: data.EXTERNRECEIPTKEY },
            { label: 'Vendor Reference', value: data.EXTERNALRECEIPTKEY2 },
            { label: 'Expected Receipt Date', value: data.EXPECTEDRECEIPTDATE },
            { label: 'Reference Number', value: data.EXTERNALRECEIPTKEY2 },
            { label: 'Gate Entry', value: data.Type_Desc },
            { label: 'Pro Number', value: data.Type_Desc },
            { label: 'Insurance Number', value: data.InsuranceNo },
        ];
    }

    getShipFromFields() {
        const data = this.asnsView(); // call once safely

        if (!data) return [];

        return [
            {
                label: 'Supplier Code',
                value: data.SUPPLIERCODE,
            },
            {
                label: 'Supplier Name',
                value: data.SUPPLIERNAME,
            },
            {
                label: 'Supplier Address 1',
                value: data.SHIPFROMADDRESSLINE1,
            },
            {
                label: 'Supplier Address 2',
                value: data.SHIPFROMADDRESSLINE2,
            },
            {
                label: 'Supplier Address 3',
                value: data.SHIPFROMADDRESSLINE3,
            },
            {
                label: 'Supplier Address 4',
                value: data.SHIPFROMADDRESSLINE4,
            },
            {
                label: 'Supplier City',
                value: data.SHIPFROMCITY,
            },
            {
                label: 'Supplier State',
                value: data.SHIPFROMSTATE,
            },
            {
                label: 'Supplier ZIP',
                value: data.SHIPFROMZIP,
            },
            {
                label: 'Supplier Contact',
                value: data.SHIPFROMCONTACT,
            },
            {
                label: 'Supplier Email',
                value: data.SHIPFROMEMAIL,
                type: 'email',
            },
            {
                label: 'Supplier Phone',
                value: data.SHIPFROMPHONE,
            },
        ];
    }

    getCarrierFields() {
        const data = this.asnsView();

        if (!data) return [];

        return [
            {
                label: 'Carrier Code',
                value: data.CARRIERKEY,
            },
            {
                label: 'Carrier Name',
                value: data.CARRIERNAME,
            },
            {
                label: 'Carrier Reference',
                value: data.CARRIERREFERENCE,
            },
            {
                label: 'Carrier Address 2',
                value: data.CARRIERADDRESS1,
            },
            {
                label: 'Carrier Address 2',
                value: data.CARRIERADDRESS2,
            },
            {
                label: 'Carrier City',
                value: data.CARRIERCITY,
            },
            {
                label: 'Carrier State',
                value: data.CARRIERSTATE,
            },
            {
                label: 'Carrier Country',
                value: data.CarrierCountry,
            },
            {
                label: 'Carrier ZIP',
                value: data.CARRIERZIP,
            },
            {
                label: 'Carrier Phone',
                value: data.CarrierPhone,
            },
            {
                label: 'Driver Name',
                value: data.DriverName,
            },
            {
                label: 'Trailer Number',
                value: data.TrailerNumber,
            },
            {
                label: 'Trailer Owner',
                value: data.TrailerOwner,
            },
            {
                label: 'Container Number',
                value: data.CONTAINERKEY,
            },
        ];
    }

    getUserDefinedFields() {
        const data = this.asnsView();

        if (!data) return [];

        return [
            {
                label: 'UDF 1',
                value: data.UDFSTR1,
            },
            {
                label: 'UDF 2',
                value: data.UDFSTR2,
            },
            {
                label: 'UDF 3',
                value: data.UDFSTR3,
            },
            {
                label: 'UDF 4',
                value: data.UDFSTR4,
            },
            {
                label: 'UDF 5',
                value: data.UDFSTR5,
            },
        ];
    }

    getOrderFields() {
        const data = this.OrderView(); // call once safely

        if (!data) return [];

        return [
            { label: 'Owner', value: data.TRADERKEY },

            { label: 'External OrderKey', value: data.EXTERNORDERKEY },

            {
                label: 'Expected Ship Date',
                value: data.EXPECTEDSHIPDATE,
            },

            {
                label: 'Order Date',
                value: data.OrderDate,
            },

            {
                label: 'OrderKey',
                value: data.ORDERKEY,
            },

            {
                label: 'Priority',
                value: data.PRIORITY,
            },

            {
                label: 'Status',
                value: data.Status_Desc,
                type: 'status',
            },

            {
                label: 'Order Type',
                value: data.Type_Desc,
            },

            {
                label: 'Load Id',
                value: data.LOADID,
            },

            {
                label: 'Total Quantity',
                value: data.TOTALQTY,
            },

            {
                label: 'BOE',
                value: data.BOE,
            },

            {
                label: 'Expected Delivery Date',
                value: data.ExpectedDeliveryDate,
            },

            {
                label: 'Insurance Number',
                value: data.InsuranceNo,
            },
        ];
    }

    getProgress(item: any): number {
        const qty = item?.OPENQTY ?? 0;

        const maxQty = 100; // adjust based on warehouse capacity

        if (qty <= 0) return 0;

        return Math.min((qty / maxQty) * 100, 100);
    }

    getQtyLabel(item: any): string {
        const qty = item?.OPENQTY ?? 0;

        if (qty <= 0) return 'No Qty';
        if (qty < 10) return `Low - ${qty}`;
        return `${qty} Qty`;
    }

    getQty(item: any): string {
        const qty = item?.TOTALQTY ?? 0;

        if (qty <= 0) return 'No Qty';
        if (qty < 10) return `Low - ${qty}`;

        return `${qty} Qty`;
    }

    getProgressQty(item: any): number {
        const qty = item?.TOTALQTY ?? 0;

        const maxQty = 100;

        if (qty <= 0) return 0;

        return Math.min((qty / maxQty) * 100, 100);
    }

    private finishLoading() {
        this.pendingRequests--;
        if (this.pendingRequests <= 0) {
            this.pendingRequests = 0;
            this.loading.set(false);
        }
    }

    openLeftToRightPanel(op: OverlayPanel, event: Event) {
        op.show(event);

        setTimeout(() => {
            const overlay = document.querySelector(
                '.custom-overlay',
            ) as HTMLElement;

            if (overlay) {
                overlay.style.marginLeft = '20px';
                overlay.style.transformOrigin = 'left center';
            }
        });
    }

    quickTabs = [
        { key: 'summary', label: 'Summary', icon: 'pi pi-chart-pie' },
        { key: 'inbound', label: 'Inbound', icon: 'pi pi-download' },
        { key: 'outbound', label: 'Outbound', icon: 'pi pi-upload' },
        { key: 'inventory', label: 'Inventory', icon: 'pi pi-box' },
        // { key: 'alerts', label: 'Alerts', icon: 'pi pi-exclamation-circle' },
    ];

    // aiInsights: string[] = [
    //     'Low inventory alert',
    //     'ASN/Order priority updated',
    //     'Shipment Pick Complete and ready for dispatch',
    //     'Shipment shipped',
    //     'For Inventory Move',
    //     'Inventory hold',
    //     'Inventory hold release',
    //     'Truck Arrived',
    //     'Truck Started',
    //     'ASN status to Received',
    // ];

    receiptCard: any;

    posCard: any;

    putawayCard: any;
    receivedCard: any;

    loadReceivedInsight() {
        this.receivedCard = {
            title: 'Received Status',

            value: 640,

            status: 'Stable Flow',

            icon: '📦',

            description:
                '640 receipts have been successfully received and verified today. This represents the completed stage of inbound processing.',
        };
    }
    downloadReport() {
        window.print();
    }

    startInsightRotation() {
        setInterval(() => {
            if (this.aiInsights.length > 0) {
                this.currentInsight =
                    (this.currentInsight + 1) % this.aiInsights.length;
            }
        }, 2000);
    }

    setUserDetails = signal<any>({});

    ngOnInit() {
        this.getInbound();
        this.GetOutboundData();
        this.getOutbound();
        this.getInventory();
        this.getLocation();
        this.updateCurrentDate();
        setInterval(() => {
            if (this.aiInsights.length > 0) {
                this.currentInsight =
                    (this.currentInsight + 1) % this.aiInsights.length;
            }
        }, 4000);

        this.GetUsers();
        this.reportFunctions  = [
    () => this.loadQuickReport(),
    () => this.getAppointmentReport(),
    () => this.getLocationReport(),
    () => this.loadReceivedInsight(),
    () => this.loadHoldReport(),
    () => this.getSkuReport(),
    () => this.loadShipmentReport(),
    () => this.loadDockReport(),
    () => this.loadInventoryReport(),
    () => this.getQuickOutboundOrderData(),
    () => this.getLoadReport(),
    () => this.getReturnReport(),
    () => this.loadQuickInboundReceiptReport(),
    () => this.loadPosReport(),
    () => this.getReceiptDetailsReport(),
    () => this.loadPutawayDetails(),
    () => this.loadAiInsights()
  ];
    }
    GetUsers() {
        const Subscription = this.dashboardervice
            .GetUsers()
            .pipe()
            .subscribe({
                next: (data: any) => {
                    if (data) {
                        const encodedUsername =
                            sessionStorage.getItem('Username');
                        const username = encodedUsername
                            ? atob(encodedUsername)
                            : '';

                        console.log(username);
                        const user = data.find(
                            (x: any) =>
                                x.UserName?.toLowerCase() ===
                                username?.toLowerCase(),
                        );

                        console.log('Users data:', user);

                        this.setUserDetails.set(user);

                        console.log('User details:', this.setUserDetails());
                    }
                },
                error: (error: any) => {},
            });
        this.destoryRef.onDestroy(() => Subscription.unsubscribe());
    }
    refreshDashboardData() {
        this.getInbound();
        this.GetOutboundData();
        this.getOutbound();
        this.getInventory();
        this.getLocation();
        this.loadQuickReport();
        this.getAppointmentReport();
        this.getLocationReport();
        this.loadReceivedInsight();
        this.loadHoldReport();
        this.getSkuReport();
        this.loadShipmentReport();
        this.loadDockReport();
        this.loadQuickInboundReceiptReport();
        this.loadPosReport();
        this.getReceiptDetailsReport();
        this.loadPutawayDetails();
        this.loadInventoryReport();
        this.getQuickOutboundOrderData();
        this.getLoadReport();
        this.getReturnReport();
        this.loadAiInsights();
    }

    loadAiInsights() {
        this.dashboardervice.getAiInsights().subscribe({
            next: (res: any[]) => {
                this.aiInsights = res || [];
            },
            error: (err) => {
                console.error('Failed to load AI Insights', err);
            },
        });
    }

    getReturnReport() {
        this.dashboardervice.getQuickOutboundReportReport().subscribe({
            next: (res: any) => {
                this.returnReport = res;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }

    getLoadReport() {
        this.dashboardervice.getQuickOutboundLoadReport().subscribe({
            next: (res: any) => {
                this.loadReport = res;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }

    getQuickOutboundOrderData() {
        this.dashboardervice.getQuickOutboundOrderReport().subscribe({
            next: (response) => {
                this.quickOutboundOrderData = response;
            },
            error: (error) => {
                console.error(error);
            },
        });
    }

    loadInventoryReport() {
        this.dashboardervice.getQuickInventoryReport().subscribe({
            next: (res: any) => {
                this.inventoryData = res;
            },
            error: (err) => {
                console.error('Inventory Report Error', err);
            },
        });
    }

    loadPutawayDetails() {
        this.dashboardervice.getQuickInboundPutawayDetailReport().subscribe({
            next: (res: any) => {
                this.putawayData = res;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }

    getReceiptDetailsReport() {
        this.dashboardervice.getQuickInboundReceiptDetailReport().subscribe({
            next: (res: any) => {
                this.receiptDetailData = res;
            },
            error: (err) => {
                console.error('Receipt Details Error:', err);
            },
        });
    }

    loadPosReport() {
        this.dashboardervice.getQuickInboundPoReport().subscribe({
            next: (res: any) => {
                this.posData = res;
            },
            error: (err) => {
                console.error('POS Report Error', err);
            },
        });
    }

    loadQuickInboundReceiptReport(): void {
        this.loading.set(true);

        this.dashboardervice.getQuickInboundReceiptReport().subscribe({
            next: (res) => {
                this.receiptData = res;
                this.loading.set(false);
            },
            error: (err) => {
                console.error(err);
                this.loading.set(false);
            },
        });
    }

    getFlowWidth(count: number): number {
        const maxQuantity = 1000; // Fixed maximum

        if (!count || count <= 0) {
            return 0;
        }

        const percentage = (count / maxQuantity) * 100;

        // Prevent width from exceeding 100%
        return Math.min(percentage, 100);
    }

    getTotalProcessingCount(): number {
        if (!this.receiptData?.ProcessingFlow?.length) {
            return 0;
        }

        return this.receiptData.ProcessingFlow.reduce(
            (total: number, item: any) => total + item.Count,
            0,
        );
    }

    getActivityPercentage(): number {
        return this.receiptData?.InboundSummary?.Percentage || 0;
    }

    refreshDashboard(): void {
        this.loadQuickInboundReceiptReport();
    }

    getAppointmentReport() {
        this.dashboardervice.getAppointmentReport().subscribe({
            next: (res: any) => {
                const statuses = res?.Statuses || [];

                const iconMap: any = {
                    Scheduled: {
                        icon: 'pi pi-calendar',
                        bg: 'bg-blue-50 dark:bg-blue-500/10',
                        iconColor: 'text-blue-500',
                        textColor: 'text-blue-600',
                        line: 'bg-gradient-to-r from-blue-400 to-orange-400',
                    },
                    Rescheduled: {
                        icon: 'pi pi-refresh',
                        bg: 'bg-orange-50 dark:bg-orange-500/10',
                        iconColor: 'text-orange-500',
                        textColor: 'text-orange-600',
                        line: 'bg-gradient-to-r from-orange-400 to-cyan-400',
                    },
                    Arrived: {
                        icon: 'pi pi-truck',
                        bg: 'bg-cyan-50 dark:bg-cyan-500/10',
                        iconColor: 'text-cyan-500',
                        textColor: 'text-cyan-600',
                        line: 'bg-gradient-to-r from-cyan-400 to-violet-400',
                    },
                    InProgress: {
                        icon: 'pi pi-spin pi-spinner',
                        bg: 'bg-violet-50 dark:bg-violet-500/10',
                        iconColor: 'text-violet-500',
                        textColor: 'text-violet-600',
                        line: 'bg-gradient-to-r from-violet-400 to-emerald-400',
                    },
                    Completed: {
                        icon: 'pi pi-check-circle',
                        bg: 'bg-emerald-50 dark:bg-emerald-500/10',
                        iconColor: 'text-emerald-500',
                        textColor: 'text-emerald-600',
                        line: 'bg-gradient-to-r from-emerald-400 to-red-400',
                    },
                    Cancelled: {
                        icon: 'pi pi-times-circle',
                        bg: 'bg-red-50 dark:bg-red-500/10',
                        iconColor: 'text-red-500',
                        textColor: 'text-red-600',
                        line: '',
                    },
                };

                // ✅ FIXED ORDER
                const order = [
                    'Scheduled',
                    'Rescheduled',
                    'Arrived',
                    'InProgress',
                    'Completed',
                    'Cancelled',
                ];

                // convert API to lookup
                const apiMap = new Map(
                    statuses.map((s: any) => [s.Status, s.Count]),
                );

                // build ordered flow
                this.appointmentFlow = order.map((status) => {
                    const style = iconMap[status];

                    return {
                        label: status,
                        count: apiMap.get(status) ?? 0,
                        ...style,
                    };
                });
            },
            error: (err) => {
                console.error('API error:', err);
            },
        });
    }

    getLocationReport() {
        this.dashboardervice.getLocationReport().subscribe({
            next: (response: any) => {
                const colors = [
                    'bg-green-500',
                    'bg-blue-500',
                    'bg-orange-500',
                    'bg-purple-500',
                    'bg-pink-500',
                    'bg-cyan-500',
                ];

                this.locationsUsed = response?.Locations?.map(
                    (item: any, index: number) => ({
                        location: item.Location,
                        zone: `Inventory: ${item.CurrentInventory}`,
                        count: item.TotalMoves,
                        color: colors[index % colors.length],
                    }),
                );
            },
            error: (error) => {
                console.error('Location report error:', error);
            },
        });
    }

    loadDockReport(): void {
        this.dashboardervice.getDockReport().subscribe({
            next: (response: any) => {
                this.docks = (response?.Appointments || []).map(
                    (item: any, index: number) => {
                        const ui = this.getDockConfig(item.Status);

                        return {
                            name:
                                item.DockName ||
                                item.Dock ||
                                `Dock ${index + 1}`,

                            status: item.Status,

                            vehicle:
                                item.VehicleNo ||
                                item.Vehicle ||
                                item.TruckNo ||
                                '-',

                            ...ui,

                            appointmentNo: item.AppointmentNo,
                            carrier: item.Carrier,
                            dockDoor: item.DockDoor,
                            startTime: item.StartTime,
                        };
                    },
                );
            },
            error: (error) => {
                console.error(error);
                this.docks = [];
            },
        });
    }

    getGrowthArrow(growth: any): string {
        const value = parseFloat(String(growth).replace('%', ''));

        return value >= 0 ? '↗' : '↘';
    }

    getDockConfig(status: string) {
        const currentStatus = (status || '').toLowerCase().replace(/\s/g, '');

        const config: any = {
            scheduled: {
                icon: 'pi pi-calendar',
                bg: 'bg-blue-50 dark:bg-blue-500/10',
                iconColor: 'text-blue-500',
                textColor: 'text-blue-700 dark:text-blue-400',
                subText: 'text-blue-500/70',
                dot: 'bg-blue-500',
                glow: 'bg-blue-500',
            },

            rescheduled: {
                icon: 'pi pi-refresh',
                bg: 'bg-orange-50 dark:bg-orange-500/10',
                iconColor: 'text-orange-500',
                textColor: 'text-orange-700 dark:text-orange-400',
                subText: 'text-orange-500/70',
                dot: 'bg-orange-500',
                glow: 'bg-orange-500',
            },

            arrived: {
                icon: 'pi pi-truck',
                bg: 'bg-cyan-50 dark:bg-cyan-500/10',
                iconColor: 'text-cyan-500',
                textColor: 'text-cyan-700 dark:text-cyan-400',
                subText: 'text-cyan-500/70',
                dot: 'bg-cyan-500',
                glow: 'bg-cyan-500',
            },

            inprogress: {
                icon: 'pi pi-spin pi-spinner',
                bg: 'bg-violet-50 dark:bg-violet-500/10',
                iconColor: 'text-violet-500',
                textColor: 'text-violet-700 dark:text-violet-400',
                subText: 'text-violet-500/70',
                dot: 'bg-violet-500',
                glow: 'bg-violet-500',
            },

            completed: {
                icon: 'pi pi-check-circle',
                bg: 'bg-emerald-50 dark:bg-emerald-500/10',
                iconColor: 'text-emerald-500',
                textColor: 'text-emerald-700 dark:text-emerald-400',
                subText: 'text-emerald-500/70',
                dot: 'bg-emerald-500',
                glow: 'bg-emerald-500',
            },

            cancelled: {
                icon: 'pi pi-times-circle',
                bg: 'bg-red-50 dark:bg-red-500/10',
                iconColor: 'text-red-500',
                textColor: 'text-red-700 dark:text-red-400',
                subText: 'text-red-500/70',
                dot: 'bg-red-500',
                glow: 'bg-red-500',
            },
        };

        return (
            config[currentStatus] || {
                icon: 'pi pi-calendar',
                bg: 'bg-blue-50 dark:bg-blue-500/10',
                iconColor: 'text-blue-500',
                textColor: 'text-blue-700 dark:text-blue-400',
                subText: 'text-blue-500/70',
                dot: 'bg-blue-500',
                glow: 'bg-blue-500',
            }
        );
    }

    loadShipmentReport() {
        this.loadingShipment = true;

        this.dashboardervice.getShipmentReport().subscribe({
            next: (res: any) => {
                this.shipmentData = {
                    TotalOrders: res?.TotalOrders ?? 0,
                    TotalShippedQty: res?.TotalShippedQty ?? 0,
                    TopSku: res?.TopSku ?? 'N/A',
                    TopSkuQty: res?.TopSkuQty ?? 0,
                };

                this.loadingShipment = false;
            },
            error: (err) => {
                console.error('Shipment API Error:', err);
                this.loadingShipment = false;
            },
        });
    }

    getSkuReport(): void {
        this.isSkuLoading = true;

        this.dashboardervice.getSkuReport().subscribe({
            next: (res: any) => {
                if (res?.FastMovingSkus?.length) {
                    const maxQty = Math.max(
                        ...res.FastMovingSkus.map(
                            (item: any) => Number(item.Quantity) || 0,
                        ),
                        1,
                    );

                    this.topsMovingSkus = res.FastMovingSkus.map(
                        (item: any, index: number) => ({
                            rank: index + 1,
                            sku: item.Sku,
                            name: item.Name,
                            qty: Number(item.Quantity) || 0,
                            change: item.Change,
                            trendColor: item.TrendColor,
                        }),
                    );
                } else {
                    this.topsMovingSkus = [];
                }

                this.isSkuLoading = false;
            },
            error: (err) => {
                console.error('SKU Error:', err);
                this.topsMovingSkus = [];
                this.isSkuLoading = false;
            },
        });
    }

    loadHoldReport(): void {
        this.dashboardervice.getHoldReport().subscribe({
            next: (res: any) => {
                const holdData = res?.HoldData || [];

                this.lpnHold = 0;
                this.lotHold = 0;
                this.combinedHold = 0;

                holdData.forEach((item: any) => {
                    const status = (item.Status || '').toLowerCase();

                    if (status.includes('lpn') && !status.includes('lot')) {
                        this.lpnHold += Number(item.Count || 0);
                    } else if (
                        status.includes('lot') &&
                        !status.includes('lpn')
                    ) {
                        this.lotHold += Number(item.Count || 0);
                    } else if (
                        status.includes('lpn') &&
                        status.includes('lot')
                    ) {
                        this.combinedHold += Number(item.Count || 0);
                    }
                });

                this.totalHolds =
                    this.lpnHold + this.lotHold + this.combinedHold;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }

    loadQuickReport(): void {
        this.dashboardervice.getQuickReport().subscribe({
            next: (res: any) => {
                this.insight =
                    res?.Data?.map((item: any) => {
                        let total = 0;
                        let description = '';
                        let fileName = '';
                        let label = '';
                        let heading = '';

                        const change = item?.ChangePercentage ?? 0;
                        const trendSign = change >= 0 ? '+' : '';

                        switch (item?.Type) {
                            case 'Inbound':
                                total =
                                    (item?.Metrics?.Completed ?? 0) +
                                    (item?.Metrics?.New ?? 0) +
                                    (item?.Metrics?.Receiving ?? 0);

                                fileName = 'inbound_report.xlsx';
                                label = "Today's Inbound";
                                heading = 'Inbound Operations';

                                description =
                                    `Today’s inbound operations processed ${total} receipts. ` +
                                    `${item?.Metrics?.Completed ?? 0} completed, ` +
                                    `${item?.Metrics?.New ?? 0} new, ` +
                                    `${item?.Metrics?.Receiving ?? 0} receiving.`;
                                break;

                            case 'Outbound':
                                total =
                                    item?.CurrentValue ||
                                    (item?.Metrics?.Shipped ?? 0) +
                                        (item?.Metrics?.Picked ?? 0) +
                                        (item?.Metrics?.Released ?? 0);

                                fileName = 'outbound_report.xlsx';
                                label = "Today's Outbound";
                                heading = 'Outbound Operations';

                                description =
                                    `Outbound operations processed ${total} shipments today. ` +
                                    `${item?.Metrics?.Shipped ?? 0} shipped, ` +
                                    `${item?.Metrics?.Picked ?? 0} picked, ` +
                                    `${item?.Metrics?.Released ?? 0} released.`;

                                break;

                            case 'Inventory':
                                total = item?.CurrentValue ?? 0;

                                fileName = 'inventory_report.xlsx';
                                label = "Today's Inventory";
                                heading = 'Inventory Overview';

                                description =
                                    `Warehouse inventory currently maintains ${total.toLocaleString()} stock units. ` +
                                    `${item?.Metrics?.SKUs ?? 0} SKUs, ` +
                                    `${item?.Metrics?.Locations ?? 0} locations, ` +
                                    `${item?.Metrics?.Lots ?? 0} lots.`;
                                break;

                            default:
                                total = item?.CurrentValue ?? 0;
                                label = item?.Type ?? 'Unknown';
                                heading = 'Summary';
                                description =
                                    'No additional details available.';
                                break;
                        }

                        return {
                            label,
                            heading,
                            total,
                            growth: `${trendSign}${change}% vs yesterday`,
                            description,
                            fileName,

                            icon:
                                item.Type === 'Inbound'
                                    ? '📥'
                                    : item.Type === 'Outbound'
                                      ? '🚚'
                                      : '📦',

                            iconBg:
                                item.Type === 'Inbound'
                                    ? 'border border-blue-200 bg-blue-50'
                                    : item.Type === 'Outbound'
                                      ? 'border border-orange-200 bg-orange-50'
                                      : 'border border-purple-200 bg-purple-50',

                            iconColor:
                                item.Type === 'Inbound'
                                    ? 'text-blue-600'
                                    : item.Type === 'Outbound'
                                      ? 'text-orange-600'
                                      : 'text-purple-600',

                            textColor:
                                change > 0
                                    ? 'text-green-600'
                                    : change < 0
                                      ? 'text-red-600'
                                      : 'text-slate-600',

                            trend: item?.Trend ?? 'Stable',
                        };
                    }) || [];
            },
            error: (err) => {
                console.error('Quick Report API Error:', err);
                this.insight = [];
            },
        });
    }

    downloadReports(item: any): void {}

    updateCurrentDate() {
        const today = new Date();

        this.currentDate = today.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
        });
    }

    onSelect() {
        if (this.rangeDates()?.[0] && this.rangeDates()?.[1]) {
            this.getInbound();
            this.getOutbound();
        }
    }

    onClear() {
        this.getInbound();
        this.getOutbound();
    }

    getInbound() {
        const StartDate = this.rangeDates()?.[0]
            ? formatDate(this.rangeDates()![0], 'yyyyMMdd', 'en-US')
            : '';
        const EndDate = this.rangeDates()?.[1]
            ? formatDate(this.rangeDates()![1], 'yyyyMMdd', 'en-US')
            : '';

        this.startLoading(); // ✅
        const subscription = this.dashboardervice
            .getInbound(StartDate, EndDate)
            .subscribe({
                next: (res) => this.inboundData.set(res),
                error: () => this.finishLoading(), // ✅ also stop on error
                complete: () => this.finishLoading(), // ✅
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }
    GetOutboundData() {
        this.orderService
            .getOrderPage({
                Page: 1,
                PageSize: 5,
            })
            .pipe()
            .subscribe({
                next: (res: any) => {
                    this.loading.set(false);

                    this.orders.set(res.Orders);
                },
            });
    }

    getOutbound() {
        const StartDate = this.rangeDates()?.[0]
            ? formatDate(this.rangeDates()![0], 'yyyyMMdd', 'en-US')
            : '';
        const EndDate = this.rangeDates()?.[1]
            ? formatDate(this.rangeDates()![1], 'yyyyMMdd', 'en-US')
            : '';

        this.startLoading(); // ✅
        const subscription = this.dashboardervice
            .getOutbound(StartDate, EndDate)
            .subscribe({
                next: (res) => this.OutboundData.set(res),
                error: () => this.finishLoading(), // ✅
                complete: () => this.finishLoading(), // ✅
            });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    getInventory() {
        this.startLoading(); // ✅
        const subscription = this.dashboardervice.getInventory().subscribe({
            next: (res) => this.InventoryData.set(res),
            error: () => this.finishLoading(), // ✅
            complete: () => this.finishLoading(), // ✅
        });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    getLocation() {
        this.startLoading(); // ✅
        const subscription = this.dashboardervice.getLocation().subscribe({
            next: (res: any) => this.LocationData.set(res),
            error: () => this.finishLoading(), // ✅
            complete: () => this.finishLoading(), // ✅
        });
        this.destoryRef.onDestroy(() => subscription.unsubscribe());
    }

    ngOnDestroy(): void {
        if (this.interval) {
            clearInterval(this.interval);
            this.destroy$.next();
  this.destroy$.complete();
        }
    }
}
