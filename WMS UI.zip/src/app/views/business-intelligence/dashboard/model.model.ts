export interface Inbound {
    title: string;
    labels: string;
    values: number;
    description: string;
}
export interface Outbound {
    count: any;
    title: string;
    labels: string;
    values: number;
    description: string;
}
export interface Inventory {
    title: string;
    labels: string;
    values: number;
}

export interface LocationType {
    Availablelocations: any;
    Usedlocations: any;
    Unusedlocations: any;
    [key: string]: string;
}
