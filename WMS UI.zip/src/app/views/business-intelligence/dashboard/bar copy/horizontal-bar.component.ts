import { Component, inject, input, OnDestroy, OnChanges } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import Chart from 'chart.js/auto';
import { ChartModule } from 'primeng/chart';
import { Subscription, debounceTime } from 'rxjs';
import { LayoutService } from '../../../../layout/service/layout.service';
import ChartDataLabels from 'chartjs-plugin-datalabels';

Chart.register(ChartDataLabels);

@Component({
    selector: 'app-horizontal-bar-chart',
    imports: [ChartModule],
    templateUrl: './horizontal-bar.component.html',
    standalone: true,
})
export class HorizontalBarComponent implements OnChanges, OnDestroy {
    ChartDataLabels = ChartDataLabels;
    data = input.required<{ title: string; labels: any[]; values: any[] }>();
    barOptions: any;
    barData: any;
    private translate = inject(TranslateService);
    private layoutService = inject(LayoutService);
    private subscription: Subscription;

    constructor() {
        this.subscription = this.layoutService.configUpdate$
            .pipe(debounceTime(25))
            .subscribe(() => {
                this.initCharts();
            });
    }

    getStatusColor(label: string, index: number): string {
        const colorMap: { [key: string]: string } = {
            // Inbound Statuses
            'New': '#14B8A6',            // Teal
            'In Receiving': '#3563A9',    // Blue
            'Received': '#FFD029',        // Yellow
            'Closed': '#D95117',          // Orange
            'Cancelled': '#9747FF',       // Purple

            // Outbound Statuses
            'Created Internally': '#14B8A6',  // Teal
            'Created Externally': '#3563A9',  // Blue
            'Picked Complete': '#FFD029',     // Yellow
            'Allocated': '#D95117',           // Orange
            'Shipped Complete': '#9747FF',    // Purple
            'Returned': '#EF4444',            // Red

            // Locations
            'Available Loc': '#14B8A6',       // Teal
            'Used Loc': '#3563A9',            // Blue
            'Un Used Loc': '#FFD029',         // Yellow
        };

        if (colorMap[label]) {
            return colorMap[label];
        }

        // Predefined fallback color palette
        const colors = [
            '#14B8A6', // Teal
            '#3563A9', // Blue
            '#FFD029', // Yellow
            '#D95117', // Orange
            '#9747FF', // Purple
            '#EF4444', // Red
        ];
        return colors[index % colors.length];
    }

    ngOnChanges() {
        this.initCharts();
    }

    ngOnDestroy(): void {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }

    initCharts() {
        const values = this.data()?.values || [];
        const labels = this.data()?.labels || [];
        const selectedFont = this.layoutService.selectedFontFamily();

        this.barData = {
            labels: labels.map((label) => this.translate.instant(label)),
            datasets: [
                {
                    type: 'bar',
                    label: this.translate.instant('Value Stick'),
                    data: values,
                    backgroundColor: labels.map((label: any, idx: number) => {
                        return this.getStatusColor(label, idx);
                    }),
                    borderRadius: 0,
                    borderSkipped: false,
                    borderWidth: 0,
                    barThickness: 3, // lollipop stick
                    order: 2,
                },
                {
                    type: 'line',
                    label: this.translate.instant('Value Head'),
                    data: values,
                    showLine: false, // Hide line connecting points
                    pointBackgroundColor: labels.map((label: any, idx: number) => {
                        return this.getStatusColor(label, idx);
                    }),
                    pointBorderColor: labels.map((label: any, idx: number) => {
                        return this.getStatusColor(label, idx);
                    }),
                    pointRadius: 8, // Uniform size for lollipop head
                    pointHoverRadius: 10,
                    order: 1,
                },
            ],
        };

        this.barOptions = {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 30,
                    right: 10,
                    left: 10,
                    bottom: 10,
                },
            },
            plugins: {
                legend: { display: false },
                tooltip: { enabled: true },
                datalabels: {
                    display: (context: any) => {
                        return context.dataset.type === 'line'; // Show only on points
                    },
                    anchor: 'end',
                    align: 'top',
                    offset: 4,
                    color: '#374151', // Dark slate/charcoal
                    font: {
                        family: selectedFont,
                        weight: 'bold',
                        size: 14,
                    },
                    formatter: (value: any) => {
                        return typeof value === 'number' ? value.toLocaleString() : value;
                    },
                },
            },
            scales: {
                x: {
                    grid: {
                        display: false,
                        drawTicks: false,
                    },
                    border: {
                        display: true,
                        color: '#e2e8f0',
                        width: 1,
                    },
                    ticks: {
                        color: '#4b5563', // Slate-600 tick labels
                        font: {
                            family: selectedFont,
                            size: 11,
                        },
                        minRotation: 45,
                        maxRotation: 45,
                    },
                },
                y: {
                    beginAtZero: true,
                    grace: '20%',
                    grid: {
                        display: false,
                        drawTicks: false,
                    },
                    border: {
                        display: true,
                        color: '#e2e8f0',
                        width: 1,
                    },
                    ticks: {
                        color: '#4b5563', // Slate-600 tick labels
                        font: {
                            family: selectedFont,
                            size: 11,
                        },
                    },
                },
            },
        };
    }
}

