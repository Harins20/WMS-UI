import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, inject } from '@angular/core';
import { Subscription, debounceTime } from 'rxjs';
import { LayoutService } from '../../../../layout/service/layout.service';
import * as echarts from 'echarts';

@Component({
    selector: 'app-line-race',
    imports: [],
    templateUrl: './line-race.component.html',
    styleUrl: './line-race.component.scss',
})
export class IncomeChartComponent implements AfterViewInit, OnDestroy {
    @ViewChild('chartContainer', { static: true })
    chartContainer!: ElementRef;

    chart!: echarts.ECharts;
    private layoutService = inject(LayoutService);
    private subscription: Subscription;

    constructor() {
        this.subscription = this.layoutService.configUpdate$
            .pipe(debounceTime(25))
            .subscribe(() => {
                if (this.chart) {
                    const selectedFont = this.layoutService.selectedFontFamily();
                    this.chart.setOption({
                        textStyle: {
                            fontFamily: selectedFont
                        }
                    });
                }
            });
    }

    ngAfterViewInit(): void {
        this.initializeChart();
    }

    ngOnDestroy(): void {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }

    initializeChart(): void {
        this.chart = echarts.init(this.chartContainer.nativeElement);
        const selectedFont = this.layoutService.selectedFontFamily();

        const option = {
            textStyle: {
                fontFamily: selectedFont,
            },

            title: {
                text: 'Income Analytics',
                textStyle: {
                    fontFamily: selectedFont,
                },
            },

            tooltip: {
                trigger: 'axis',
                order: 'valueDesc',
                textStyle: {
                    fontFamily: selectedFont,
                },
            },

            legend: {
                top: 10,
                textStyle: {
                    fontFamily: selectedFont,
                },
            },

            grid: {
                left: '5%',
                right: '15%',
                bottom: '10%',
                containLabel: true,
            },

            xAxis: {
                type: 'category',
                boundaryGap: false,
                axisLabel: {
                    fontFamily: selectedFont,
                },
                data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
            },

            yAxis: {
                type: 'value',
                name: 'Income',
                axisLabel: {
                    fontFamily: selectedFont,
                },
                nameTextStyle: {
                    fontFamily: selectedFont,
                },
            },

            series: [
                {
                    name: 'Germany',
                    type: 'line',
                    smooth: true,
                    showSymbol: false,

                    data: [
                        12000, 15000, 18000, 22000, 25000, 28000, 31000, 34000,
                    ],

                    endLabel: {
                        show: true,
                        formatter: 'Germany',
                        fontFamily: selectedFont,
                    },
                },

                {
                    name: 'France',
                    type: 'line',
                    smooth: true,
                    showSymbol: false,

                    data: [
                        10000, 13000, 17000, 20000, 23000, 26000, 29000, 32000,
                    ],

                    endLabel: {
                        show: true,
                        formatter: 'France',
                        fontFamily: selectedFont,
                    },
                },

                {
                    name: 'United Kingdom',
                    type: 'line',
                    smooth: true,
                    showSymbol: false,

                    data: [
                        8000, 11000, 14000, 18000, 21000, 25000, 28000, 30000,
                    ],

                    endLabel: {
                        show: true,
                        formatter: 'UK',
                        fontFamily: selectedFont,
                    },
                },
            ],
        };

        this.chart.setOption(option);

        window.addEventListener('resize', () => {
            this.chart.resize();
        });
    }
}
