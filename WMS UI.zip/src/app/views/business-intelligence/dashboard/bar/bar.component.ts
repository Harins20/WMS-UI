import { Component, inject, input, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import Chart from 'chart.js/auto';
import { ChartModule } from 'primeng/chart';
import { Subscription, debounceTime } from 'rxjs';
import { LayoutService } from '../../../../layout/service/layout.service';
import ChartDataLabels from 'chartjs-plugin-datalabels';

Chart.register(ChartDataLabels);

@Component({
    selector: 'app-bar-chart',
    imports: [ChartModule],
    templateUrl: './bar.component.html',
    standalone: true,
})
export class BarComponent implements OnChanges, OnDestroy {
    data = input.required<{ title: string; labels: any[]; values: any[] }>();
    barOptions: any;
    barData: any;

    private translate = inject(TranslateService);
    private layoutService = inject(LayoutService);
    private subscription: Subscription;

    constructor() {
        this.subscription = this.layoutService.configUpdate$
            .pipe(debounceTime(25))
            .subscribe(() => {
                this.initCharts();
            });
    }

    ngOnChanges(changes: SimpleChanges): void {
        this.initCharts();
    }

    ngOnDestroy(): void {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }

    initCharts(): void {
        if (!this.data() || !this.data().values || !this.data().values.length) {
            return;
        }

        const documentStyle = getComputedStyle(document.documentElement);
        const textColorSecondary = documentStyle.getPropertyValue('--text-color-secondary') || '#64748B';
        const selectedFont = this.layoutService.selectedFontFamily();

        const colorPairs = [
            { start: '#3B82F6', end: '#60A5FA' }, // Blue
            { start: '#10B981', end: '#34D399' }, // Emerald
            { start: '#F59E0B', end: '#FBBF24' }, // Amber
            { start: '#8B5CF6', end: '#C084FC' }, // Purple
            { start: '#EC4899', end: '#F472B6' }, // Pink
            { start: '#06B6D4', end: '#22D3EE' }, // Cyan
            { start: '#6366F1', end: '#818CF8' }, // Indigo
        ];

        const hoverColorPairs = [
            { start: '#2563EB', end: '#93C5FD' },
            { start: '#059669', end: '#6EE7B7' },
            { start: '#D97706', end: '#FDE047' },
            { start: '#7C3AED', end: '#E9D5FF' },
            { start: '#DB2777', end: '#FBCFE8' },
            { start: '#0891B2', end: '#67E8F9' },
            { start: '#4F46E5', end: '#A5B4FC' },
        ];

        this.barData = {
            labels: this.data()?.labels?.map((label) =>
                this.translate.instant(label),
            ),
            datasets: [
                {
                    label: this.data().title
                        ? this.translate.instant(this.data().title)
                        : this.translate.instant('Count'),
                    data: this.data().values,
                    borderRadius: 8,
                    borderSkipped: false,
                    barThickness: 22,
                    maxBarThickness: 28,
                    categoryPercentage: 0.75,
                    barPercentage: 0.85,
                    backgroundColor: (context: any) => {
                        const chart = context.chart;
                        const { ctx, chartArea } = chart;
                        if (!chartArea) {
                            return '#3B82F6';
                        }
                        const index = context.dataIndex % colorPairs.length;
                        const pair = colorPairs[index];
                        const gradient = ctx.createLinearGradient(chartArea.left, 0, chartArea.right, 0);
                        gradient.addColorStop(0, pair.start);
                        gradient.addColorStop(1, pair.end);
                        return gradient;
                    },
                    hoverBackgroundColor: (context: any) => {
                        const chart = context.chart;
                        const { ctx, chartArea } = chart;
                        if (!chartArea) {
                            return '#2563EB';
                        }
                        const index = context.dataIndex % hoverColorPairs.length;
                        const pair = hoverColorPairs[index];
                        const gradient = ctx.createLinearGradient(chartArea.left, 0, chartArea.right, 0);
                        gradient.addColorStop(0, pair.start);
                        gradient.addColorStop(1, pair.end);
                        return gradient;
                    },
                    hoverBorderColor: '#ffffff',
                    hoverBorderWidth: 2,
                },
            ],
        };

        this.barOptions = {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    right: 25,
                },
            },
            animation: {
                duration: 1000,
                easing: 'easeOutQuart',
                delay: (context: any) => {
                    let delay = 0;
                    if (context.type === 'data' && context.mode === 'default') {
                        delay = context.dataIndex * 120;
                    }
                    return delay;
                },
            },
            plugins: {
                legend: { display: false },
                datalabels: {
                    display: true,
                    anchor: 'end',
                    align: 'end',
                    color: textColorSecondary,
                    font: {
                        weight: '600',
                        size: 11,
                        family: selectedFont,
                    },
                    formatter: (value: any) => value.toLocaleString(),
                },
                tooltip: {
                    enabled: true,
                    mode: 'nearest',
                    intersect: true,
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    titleColor: '#F8FAFC',
                    bodyColor: '#CBD5E1',
                    borderColor: 'rgba(255, 255, 255, 0.15)',
                    borderWidth: 1,
                    padding: 12,
                    boxPadding: 6,
                    cornerRadius: 10,
                    usePointStyle: true,
                    titleFont: {
                        size: 13,
                        weight: '600',
                        family: selectedFont,
                    },
                    bodyFont: {
                        size: 12,
                        weight: '500',
                        family: selectedFont,
                    },
                    callbacks: {
                        label: (context: any) => {
                            const val = context.raw ?? 0;
                            return ` ${context.dataset.label || 'Value'}: ${val.toLocaleString()}`;
                        },
                    },
                },
            },
            scales: {
                x: {
                    beginAtZero: true,
                    grid: {
                        display: false,
                        drawTicks: false,
                    },
                    border: {
                        display: false,
                    },
                    ticks: {
                        color: textColorSecondary,
                        font: {
                            size: 11,
                            weight: '500',
                            family: selectedFont,
                        },
                    },
                },
                y: {
                    grid: {
                        display: false,
                        drawTicks: false,
                    },
                    border: {
                        display: false,
                    },
                    ticks: {
                        color: textColorSecondary,
                        font: {
                            size: 12,
                            weight: '600',
                            family: selectedFont,
                        },
                    },
                },
            },
            onHover: (event: any, chartElement: any[]) => {
                if (event?.native?.target) {
                    event.native.target.style.cursor = chartElement.length ? 'pointer' : 'default';
                }
            },
        };
    }
}

