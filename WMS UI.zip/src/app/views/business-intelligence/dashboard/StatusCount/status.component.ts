import { CommonModule } from '@angular/common';
import { Component, computed, input, OnInit } from '@angular/core';
import { AppTranslatePipe } from '../../../../common/pipes/translate.pipe';
import { ButtonModule } from 'primeng/button';

@Component({
    selector: 'app-status-count',
    imports: [ButtonModule, AppTranslatePipe],
    templateUrl: './status.component.html',
    standalone: true,
})
export class StatusComponent {
    data = input.required<{ title: string; labels: any[]; values: any[] }>();

    CountData = computed(() => {
        if (this.data())
            return this.data().labels?.map((label, index) => ({
                label: label,
                value: this.data().values[index] || 0,
                icon: this.getIconForLabel(label), // Add icon based on label
            }));
        else return [];
    });
    getIconForLabel(label: any) {
        // Map labels to appropriate PrimeNG icons
        const iconMap: { [key: string]: string } = {
            New: 'fa-solid fa-plus',
            'In Receiving': 'pi pi-times-circle',
            Received: 'pi pi-check-circle',
            Closed: 'fa-solid fa-xmark',
            Cancelled: 'fa-solid fa-ban',
            'Available Loc': 'fa-solid fa-location-dot',
            'Used Loc': 'fa-solid fa-location-pin-lock',
            'Un Used Loc': 'fa-solid fa-location-pin',
            'Created Internally': 'fa-solid fa-plus',
            'Created Externally': 'fa-solid fa-circle-plus',
            Allocated: 'fa-solid fa-check-to-slot',
            'Picked Complete': 'fa-solid fa-people-carry-box',
            'Shipped Complete': 'fa-solid fa-truck-arrow-right',
        };
        return iconMap[label] ?? 'pi pi-question-circle';
    }
}
