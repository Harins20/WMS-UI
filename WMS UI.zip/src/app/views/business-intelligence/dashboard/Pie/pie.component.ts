import { Component, inject, input } from '@angular/core';
import { Subscription, debounceTime } from 'rxjs';
import { ChartModule } from 'primeng/chart';
import { LayoutService } from '../../../../layout/service/layout.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'app-pie-chart',
    imports: [ChartModule],
    templateUrl: './pie.component.html',
    standalone: true,
})
export class PieComponent {
    data = input.required<{
        title: string;
        labels: any[];
        values: any[];
    }>();

    pieData: any;
    pieOptions: any;

    private translate = inject(TranslateService);

    subscription: Subscription;

    // Modern Dashboard Colors
    colors = [
        '#1E40AF', // Inbound
        '#059669', // Received
        '#D97706', // Putaway
        '#DC2626', // Delayed
        '#7C3AED', // Picking
        '#0891B2', // Packing
        '#65A30D', // Shipping
        '#EA580C', // Returns
        '#DB2777', // Inventory
        '#475569', // Others
    ];

    constructor(private layoutService: LayoutService) {
        this.subscription = this.layoutService.configUpdate$
            .pipe(debounceTime(25))
            .subscribe(() => {
                this.initCharts();
            });
    }

    ngOnChanges(): void {
        this.initCharts();
    }

    ngOnDestroy(): void {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }

    initCharts(): void {
        const documentStyle = getComputedStyle(document.documentElement);

        const textColorSecondary = documentStyle.getPropertyValue(
            '--text-color-secondary',
        );

        this.pieData = {
            labels: this.data()?.labels?.map((label) =>
                this.translate.instant(label),
            ),

            datasets: [
                {
                    data: this.data()?.values || [],

                    backgroundColor: this.colors.slice(
                        0,
                        this.data()?.values?.length || 0,
                    ),

                    borderColor: '#ffffff',
                    borderWidth: 2,

                    hoverBorderWidth: 4,
                    hoverOffset: 10,
                },
            ],
        };

        const selectedFont = this.layoutService.selectedFontFamily();

        this.pieOptions = {
            responsive: true,
            maintainAspectRatio: false,

            plugins: {
                legend: {
                    display: false,
                    position: 'top',

                    labels: {
                        usePointStyle: true,
                        pointStyle: 'circle',
                        padding: 20,

                        color: textColorSecondary,

                        font: {
                            family: selectedFont,
                            size: 12,
                            weight: '500',
                        },
                    },
                },

                tooltip: {
                    callbacks: {
                        label: (context: any) => {
                            const value = context.raw;

                            const data = context.chart.data.datasets[0].data;

                            const total = data.reduce(
                                (sum: number, current: number) => sum + current,
                                0,
                            );

                            const percentage = ((value / total) * 100).toFixed(
                                1,
                            );

                            return `${context.label}: ${value} (${percentage}%)`;
                        },
                    },
                },

                datalabels: {
                    color: '#ffffff',

                    font: {
                        family: selectedFont,
                        weight: 'bold',
                        size: 12,
                    },

                    formatter: (value: number, context: any) => {
                        const data = context.chart.data.datasets[0].data;

                        const total = data.reduce(
                            (sum: number, current: number) => sum + current,
                            0,
                        );

                        const percentage = (value / total) * 100;

                        return percentage >= 5
                            ? `${percentage.toFixed(1)}%`
                            : '';
                    },
                },
            },
        };
    }
}
