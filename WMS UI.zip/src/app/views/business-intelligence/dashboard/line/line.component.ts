import { Component, inject, input } from '@angular/core';
import Chart from 'chart.js/auto';
import { debounceTime, Subscription } from 'rxjs';
import { ChartModule } from 'primeng/chart';
import { LayoutService } from '../../../../layout/service/layout.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'app-lnne-chart',
    imports: [ChartModule],
    templateUrl: './line.component.html',
    standalone: true,
})
export class LineComponent {
    data = input.required<{ title: string; labels: any[]; values: any[] }>();
    lineData: any;
    lineOptions: any;
    private translate = inject(TranslateService);
    subscription: Subscription;
    constructor(private layoutService: LayoutService) {
        this.subscription = this.layoutService.configUpdate$
            .pipe(debounceTime(25))
            .subscribe(() => {
                this.initCharts();
            });
    }
    ngOnChanges() {
        this.initCharts();
    }
    initCharts() {
        const documentStyle = getComputedStyle(document.documentElement);
        const textColor = documentStyle.getPropertyValue('--text-color');
        const surfaceBorder =
            documentStyle.getPropertyValue('--surface-border');
        const textColorSecondary = documentStyle.getPropertyValue(
            '--text-color-secondary',
        );

        this.lineData = {
            labels: this.data()?.labels?.map((label) =>
                this.translate.instant(label),
            ),
            datasets: [
                {
                    label: this.data().title
                        ? this.translate.instant(this.data().title)
                        : this.data().title,
                    data: this.data().values,
                    fill: false,
                    backgroundColor:
                        documentStyle.getPropertyValue('--p-primary-500'),
                    borderColor:
                        documentStyle.getPropertyValue('--p-primary-500'),
                    tension: 0.4,
                },
            ],
        };

        const selectedFont = this.layoutService.selectedFontFamily();

        this.lineOptions = {
            maintainAspectRatio: false,
            aspectRatio: 0.8,
            plugins: {
                legend: {
                    display: false,
                    labels: {
                        color: textColor,
                        font: { family: selectedFont },
                    },
                },
            },
            scales: {
                x: {
                    ticks: {
                        color: textColorSecondary,
                        font: { family: selectedFont },
                    },
                    grid: {
                        color: surfaceBorder,
                        drawBorder: false,
                    },
                },
                y: {
                    ticks: {
                        color: textColorSecondary,
                        font: { family: selectedFont },
                    },
                    grid: {
                        color: surfaceBorder,
                        drawBorder: false,
                    },
                },
            },
        };
    }
}
