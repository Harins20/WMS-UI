import { Component, inject, input } from '@angular/core';
import Chart from 'chart.js/auto';
import { debounceTime, Subscription } from 'rxjs';
import { ChartModule } from 'primeng/chart';
import { LayoutService } from '../../../../layout/service/layout.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'app-radar-chart',
    imports: [ChartModule],
    templateUrl: './radar.component.html',
    standalone: true,
})
export class RadarComponent {
    data = input.required<{ title: string; labels: any[]; values: any[] }>();
    radarData: any;
    radarOptions: any;
    private translate = inject(TranslateService);
    subscription: Subscription;
    constructor(private layoutService: LayoutService) {
        this.subscription = this.layoutService.configUpdate$
            .pipe(debounceTime(25))
            .subscribe(() => {
                this.initCharts();
            });
    }
    ngOnChanges() {
        this.initCharts();
    }
    initCharts() {
        const documentStyle = getComputedStyle(document.documentElement);
        const textColor = documentStyle.getPropertyValue('--text-color');
        const surfaceBorder =
            documentStyle.getPropertyValue('--surface-border');

        this.radarData = {
            labels: this.data()?.labels?.map((label) =>
                this.translate.instant(label),
            ),
            datasets: [
                {
                    label: this.translate.instant('Inventory'),
                    borderColor:
                        documentStyle.getPropertyValue('--p-indigo-400'),
                    pointBackgroundColor:
                        documentStyle.getPropertyValue('--p-indigo-400'),
                    pointBorderColor:
                        documentStyle.getPropertyValue('--p-indigo-400'),
                    pointHoverBackgroundColor: textColor,
                    pointHoverBorderColor:
                        documentStyle.getPropertyValue('--p-indigo-400'),
                    data: this.data().values,
                },
            ],
        };
        const selectedFont = this.layoutService.selectedFontFamily();
        this.radarOptions = {
            plugins: {
                legend: {
                    labels: {
                        color: textColor,
                        font: { family: selectedFont },
                    },
                },
            },
            scales: {
                r: {
                    pointLabels: {
                        color: textColor,
                        font: { family: selectedFont },
                    },
                    grid: {
                        color: surfaceBorder,
                    },
                },
            },
        };
    }
}
