import { Component, computed, effect, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ReportViewerComponent } from './report-viewer/report-viewer.component';
import { AppConfigService } from '../../../../app.config.service';
import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { LoadingComponent } from '../../../common/components';

@Component({
    selector: 'app-reports',
    imports: [ButtonModule, AppTranslatePipe, LoadingComponent],
    templateUrl: './reports.component.html',
    styleUrl: './reports.component.scss',
    providers: [DialogService],
})
export class ReportsComponent {
    ref: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private appConfigService = inject(AppConfigService);
    loading = signal(false);

    reports = computed(() => {
        if (this.appConfigService && this.appConfigService.appConfig()?.Reports)
            return this.appConfigService.appConfig()!.Reports;
        else return {};
    });
    reportTypes = computed(() => {
        if (this.appConfigService && this.appConfigService.appConfig()?.Reports)
            return Object.keys(this.appConfigService.appConfig()!.Reports);
        else return [];
    });
    onReportClickX() {
        const reportName = 'ReceiptdetailPD';
        this.ref = this.dialogService.open(ReportViewerComponent, {
            inputValues: { reportName },
            header: 'Receipt Detail',
            closable: true,
            modal: true,
            draggable: true,
            keepInViewport: true,
            // duplicate: true,
            resizable: true,
            maximizable: true,
            height: '90%',
            style: { 'max-width': '90%', 'min-width': '50%' },
        });
    }
    onReportClick(reportFileName: string) {
        const width = 1000;
        const height = 600;
        const left = window.screen.width / 2 - width / 2;
        const top = window.screen.height / 2 - height / 2;
        window.open(
            `/reports/${reportFileName}`,
            '_blank',
            `resizable=no, toolbar=no, scrollbars=no, menubar=no, status=no, directories=no, location=no, width=${width}, height=${height}, left=${left}, top=${top}`,
        );
    }
}
