import { Component, inject, input, OnInit } from '@angular/core';
import { AppConfigService } from '../../../../../app.config.service';
// import receiptDetailReport from "src/assets/reports/ReceiptdetailPD.mrt";
// import * as receiptDetailReport from "../../../assets/reports/ReceiptdetailPD.mrt";

declare var Stimulsoft: any;

@Component({
    selector: 'app-report-viewer',
    template: `<div id="viewer" style="height: auto; width: 100%;"></div>`,
    providers: [],
})
export class ReportViewerComponent implements OnInit {
    reportName = input.required<string>();
    options: any = new Stimulsoft.Viewer.StiViewerOptions();
    viewer = new Stimulsoft.Viewer.StiViewer(this.options, 'StiViewer', false);
    private configService = inject(AppConfigService);

    constructor() {}

    ngOnInit(): void {
        Stimulsoft.Base.StiLicense.Key =
            '6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHnbeLC+bqPRqQ+5kkhFK29KQ+9iuHzyQojjOXTfUVm/KXZ4TwNf75psyetLPBiBfndUD7BZmK4zaHQAFah78X6NqhijqHmnqlANbaXbf6oqXdHOggFKuc56nN1QPq/iG8EpVmKzEekpF5ymIAqkEyEE7ooM88jNzMCQQ3iK8ffoV8C+BRYRNAKBVj1LouW3vCj5bTTtZhPzdtJXyAFS06G7dXNyRK2NaqYITw7HFMAB+tGvzFW7s6F0656aSVlMNSUj6Nsr3tzuFyDT/t72P8Ea4L0bXWshSRgM2kJKu1qmgE+mz4zQ4Yi7wdTI1jh3JVdEQuOeFT2yqY28VGSP7cdOcpWG+1Nv3/S+zZoRan4slHZma90QrLzIdZOOV1KS5Dt5ftiHCOC/5+ENThUiQBKg2u3wTnaWd06nqrXUY282ehdHQE/IdzxGw/NA3YVviwOWLJrzHsPifS2kvgLfZMaC65ErUTS1TcQH/WQ+PJmayG3y20+bZAe8Fx63nNwNHg0SHyQc8/uwNXjA1RxLOjOW';
        this.initializeViewer();
    }

    initializeViewer(): void {
        // Set up the report options and load the report
        const report = new Stimulsoft.Report.StiReport();

        // Load a report template (this could be a local file or URL)
        report.loadFile(`/assets/reports/${this.reportName()}.mrt`);

        const jsonDataSource = report.dictionary.databases.list;

        const reportUrl = this.configService.appConfig()?.ReportUrl;

        // Set variable value
        let facility = atob(sessionStorage.getItem('Facility') ?? '');
        let Username = atob(sessionStorage.getItem('Username') ?? '');

        jsonDataSource.forEach((source: any) => {
            // console.log('Data Source Name:', source.name);
            // console.log('PathData Source:', source.pathData);
            if (source.pathData && reportUrl) {
                const url = new URL(source.pathData);

                source.pathData = `${reportUrl.replace(/\/$/, '')}${url.pathname}${url.search}${url.hash}`;
            }

            // console.log('Updated PathData:', source.pathData);
        });

        if (!jsonDataSource) {
            throw new Error(
                'Data source "picklist" not found in report dictionary.',
            );
        }

        var variablefacility =
            report.dictionary.variables.getByName('facility');
        var variableUserName =
            report.dictionary.variables.getByName('UserName');

        variablefacility.value = facility;
        variablefacility.requestFromUser = false;

        variableUserName.value = Username;
        variableUserName.requestFromUser = false;
        this.viewer.report = report;

        // Attach the viewer to the div in the template
        this.viewer.renderHtml('viewer');
    }
}
