import { DashboardComponent } from './dashboard';
import { ReportsComponent } from './reports';
import { WorkspaceBuilderComponent } from '../../workspace';

export default [
    {
        data: { name: 'Dashboard' },
        path: 'dashboard',
        component: DashboardComponent,
    },
    {
        data: { name: 'Workspace' },
        path: 'workspace',
        component: WorkspaceBuilderComponent,
    },
    {
        data: { name: 'Reports' },
        path: 'reports',
        component: ReportsComponent,
    },
];

