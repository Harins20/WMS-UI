import { AppTranslatePipe } from '../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { Component, inject } from '@angular/core';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FacilityForm } from '../../layout/component/facility-form';
import { Router } from '@angular/router';

@Component({
    selector: 'app-facility',
    imports: [],
    templateUrl: './facility.component.html',
    styleUrl: './facility.component.scss',
    providers: [DialogService, AppTranslatePipe],
})
export class FacilityComponent {
    private translate = inject(TranslateService);
    ref: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private router = inject(Router);
    ngOnInit() {
        this.OpenFacilityForm();
    }

    OpenFacilityForm() {
        const headertext = this.translate.instant('Facility');
        this.ref = this.dialogService.open(FacilityForm, {
            inputValues: {
                CancelBtn: true,
            },
            header: headertext,
            closable: false,
            modal: true,
            keepInViewport: true,
            width: '25rem',
        });

        this.ref.onClose.subscribe(() => {
            this.router.navigate(['']);
            // sessionStorage.setItem('language', 'en');
        });
    }
}
