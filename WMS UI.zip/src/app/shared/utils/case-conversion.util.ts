/**
 * Case Conversion Utilities
 * Provides standardized case conversion for API responses (to UPPERCASE)
 * and API request payloads (to lowercase).
 */

export function upperCaseObject(obj: any): any {
    if (!obj || typeof obj !== 'object' || obj instanceof Date) {
        return obj;
    }

    if (Array.isArray(obj)) {
        return upperCaseArray(obj);
    }

    return Object.fromEntries(
        Object.entries(obj).map(([key, value]) => [
            key.toUpperCase(),
            value,
        ]),
    );
}

export function lowerCaseObject(obj: any): any {
    if (!obj || typeof obj !== 'object' || obj instanceof Date) {
        return obj;
    }

    if (Array.isArray(obj)) {
        return lowerCaseArray(obj);
    }

    return Object.fromEntries(
        Object.entries(obj).map(([key, value]) => [
            key.toLowerCase(),
            value,
        ]),
    );
}

export function upperCaseArray(data: any[]): any[] {
    return (data || []).map((item) => upperCaseObject(item));
}

export function lowerCaseArray(data: any[]): any[] {
    return (data || []).map((item) => lowerCaseObject(item));
}
