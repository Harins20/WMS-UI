import { CommonModule } from '@angular/common';
import { Component, computed, input, signal, Type } from '@angular/core';

@Component({
    selector: 'app-tab-panel',
    imports: [CommonModule],
    templateUrl: './tab-panel.component.html',
    styleUrl: './tab-panel.component.scss',
})
export class TabPanelComponent {
    title = input.required<string>();
    component = input.required<Type<any>>();
    params = input<any[]>([]);
    paramsObject = signal<{ [key: string]: any }>({});
    customHeight = input<string>('calc(100vh - 6rem)');
    inputs = computed(() => {
        if (this.params() && this.params().length > 0) {
            const paramsObj: { [key: string]: any } = {};
            for (const param of this.params()) {
                paramsObj[param['name']] = param['value'];
            }
            return paramsObj;
        } else {
            return undefined;
        }
    });
}
