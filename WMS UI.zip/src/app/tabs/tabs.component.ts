import { map } from 'rxjs/operators';
import { Route, Routes } from '@angular/router';
import {
    Component,
    computed,
    DestroyRef,
    effect,
    ElementRef,
    HostListener,
    inject,
    OnInit,
    signal,
    ViewChild,
} from '@angular/core';
import { TabsModule } from 'primeng/tabs';
import { Tab, TabService } from './tab.service';
import { TabPanelComponent } from './tab-panel/tab-panel.component';
import { ButtonModule } from 'primeng/button';

import InboundRoutes from '../views/inbound/inbound.routes';
import OutboundRoutes from '../views/outbound/outbound.routes';
import { CardModule } from 'primeng/card';
import {
    CdkDrag,
    CdkDragDrop,
    CdkDragEnd,
    CdkDragMove,
    CdkDragPlaceholder,
    CdkDragPreview,
    CdkDragStart,
    CdkDropList,
    moveItemInArray,
} from '@angular/cdk/drag-drop';
import { CommonModule, DOCUMENT } from '@angular/common';
import { TooltipModule } from 'primeng/tooltip';
import { AppTranslatePipe } from '../common/pipes/translate.pipe';
import { Popover, PopoverModule } from 'primeng/popover';
import { DialogModule } from 'primeng/dialog';
import { AuthService } from '../common/services/auth.service';
import { OptionsService } from '../common/services/options.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FacilityForm } from '../layout/component/facility-form';
import { StorerService } from '../views/admin-panel/storer/storer.service';
import { formatBase64Image } from '../common/functions/formatBase64Image';
import { AppQuickTabs } from '../layout/component/app.quicktabs';
import { StyleClassModule } from 'primeng/styleclass';
import { AppConfigurator } from '../layout/component/app.configurator';
import { LayoutService } from '../layout/service/layout.service';
import { FormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import { OverlayPanel, OverlayPanelModule } from 'primeng/overlaypanel';
import { $t, updatePreset, updateSurfacePalette } from '@primeng/themes';

import Aura from '@primeng/themes/aura';
import Lara from '@primeng/themes/lara';
import Nora from '@primeng/themes/nora';
import { LanguageService } from '../common/services/language.service';
import { AppTopbar } from '../layout/component/app.topbar';
import {
    WakeWordService,
    VoiceCommandService,
    SpeechRecognitionService,
    VoiceAssistButtonComponent,
} from '../voice-assist';
declare type KeyOfType<T> = keyof T extends infer U ? U : never;

const presets = {
    Aura,
    Lara,
    Nora,
} as const;

@Component({
    selector: 'app-tabs',
    imports: [
        TabsModule,
        TabPanelComponent,
        ButtonModule,
        CardModule,
        CdkDrag,
        CdkDropList,
        CdkDragPlaceholder,
        CdkDragPreview,
        AppTranslatePipe,
        CommonModule,
        PopoverModule,
        DialogModule,
        AppQuickTabs,
        StyleClassModule,
        AppConfigurator,
        FormsModule,
        CheckboxModule,
        OverlayPanelModule,
        AppTopbar,
        TooltipModule,
        VoiceAssistButtonComponent,
    ],
    templateUrl: './tabs.component.html',
    styleUrl: './tabs.component.scss',
    providers: [AppConfigurator],
})
export class TabsComponent implements OnInit {
    public tabService = inject(TabService);
    public languageService = inject(LanguageService);
    private authService = inject(AuthService);
    private optionService = inject(OptionsService);
    private dialogService = inject(DialogService);
    private destroyRef = inject(DestroyRef);
    private appConfigurator = inject(AppConfigurator);
    private document = inject(DOCUMENT);
    private storerService = inject(StorerService);
    public wakeWordService = inject(WakeWordService);
    public commandService = inject(VoiceCommandService);
    public speechService = inject(SpeechRecognitionService);

    public toggleVoiceAssistant(): void {
        this.commandService.toggleDock();
    }

    facilityView = signal<any[]>([]);
    facility = atob(sessionStorage.getItem('Facility') ?? '');
    storerLogo = signal<string | null>(null);
    displayConfirmation: boolean = false;
    ref: DynamicDialogRef | undefined;
    protected selectedTabIndex = 0;
    activeTab: string = 'Dashboard';
    languageSelectorOpen = signal<boolean>(false);
    @ViewChild('op') op!: Popover;
    @ViewChild('splitMenu') splitMenu!: Popover;
    @ViewChild('panel1TabsPopover') panel1TabsPopover!: Popover;
    @ViewChild('panel2TabsPopover') panel2TabsPopover!: Popover;
    @ViewChild('splitContainer') splitContainer!: ElementRef<HTMLDivElement>;

    items!: any[];
    isDraggingDivider = false;

    // Drag-and-drop & Detach State
    @ViewChild('tabListContainer') tabListContainer!: ElementRef<HTMLDivElement>;

    draggingTab: Tab | null = null;
    isDetachZone = false;
    private tabListRect: DOMRect | null = null;

    // Context Menu State
    contextMenuVisible = false;
    contextMenuPosition = { x: 0, y: 0 };
    contextMenuTab: Tab | null = null;

    // Popup Blocker Fallback Notification
    popupBlockedNotice = false;
    pendingPopupTab: Tab | null = null;

    constructor(public layoutService: LayoutService) {
        // Automatically ensure the active tab is selected whenever tabs change or selectedTab changes
        effect(() => {
            const tabs = this.tabService.tabs();
            const currentSelected = this.tabService.selectedTab();

            if (tabs.length > 0) {
                // If no active tab or active tab no longer exists, default to the first tab
                if (!currentSelected || !tabs.some((t) => t.id === currentSelected)) {
                    this.tabService.selectedTab.set(tabs[0].id);
                    this.tabService.selectedName.set(tabs[0].title);
                }
            }
        });
    }

    ngOnInit() {
        this.getOptions();
        this.languageService.loadLanguages();
        this.loadStorerLogo();
        this.items = [
            {
                label: 'Facility',
                icon: 'fa-solid fa-house-signal',
                command: () => this.OpenFacilityForm(),
            },
            {
                label: 'Logout',
                icon: 'pi pi-fw pi-sign-in',
                command: () => this.openConfirmation(),
            },
        ];

        // Hands-free voice control: automatically start background wake-word listening for "Hey Vyapi"
        this.initHandsFreeVoiceControl();
    }

    private initHandsFreeVoiceControl(): void {
        const startVoice = () => {
            if (!this.wakeWordService.isHandsFreeEnabled()) {
                this.wakeWordService.enableHandsFree();
            }
        };

        // Try direct initialization
        startVoice();

        // Browser policy fallback: activate on initial interaction if microphone requires user gesture
        const onFirstInteraction = () => {
            startVoice();
            window.removeEventListener('click', onFirstInteraction);
            window.removeEventListener('keydown', onFirstInteraction);
        };
        window.addEventListener('click', onFirstInteraction, { once: true });
        window.addEventListener('keydown', onFirstInteraction, { once: true });
    }

    loadStorerLogo(): void {
        this.storerService.getTopbarlogo().subscribe({
            next: (res: any) => {
                let fileData: string | null = null;
                if (Array.isArray(res) && res.length > 0) {
                    fileData =
                        res[0]?.FileData ||
                        res[0]?.fileData ||
                        res[0]?.File ||
                        res[0]?.Data;
                } else if (res && typeof res === 'object') {
                    if (Array.isArray(res.data) && res.data.length > 0) {
                        fileData =
                            res.data[0]?.FileData ||
                            res.data[0]?.fileData;
                    } else {
                        fileData =
                            res.FileData ||
                            res.fileData ||
                            res.File ||
                            res.Data;
                    }
                }

                if (fileData) {
                    const formatted = formatBase64Image(fileData);
                    this.storerLogo.set(formatted);
                } else {
                    this.storerLogo.set(null);
                }
            },
            error: (err) => {
                console.error('[TabsComponent] Failed to load header storer logo', err);
                this.storerLogo.set(null);
            },
        });
    }

    isSidebarOpen = false;

    openSidebar() {
        this.isSidebarOpen = true;
        this.languageService.loadLanguages();
    }

    onLanguageTabSelected() {
        this.activeTab = 'Language';
        this.languageService.loadLanguages();
    }

    closeSidebar() {
        this.isSidebarOpen = false;
    }

    resetMenu() {
        const defaultConfig = {
            preset: 'Aura',
            primary: 'Ateneo Blue',
            surface: null,
            darkTheme: false,
            menuMode: 'static',
            dir: 'ltr' as const,
        };
        this.layoutService.layoutConfig.update((state) => defaultConfig);
        this.layoutService.applyDirection('ltr');
        updatePreset(this.appConfigurator.getPresetExt());
        const preset = presets['Aura' as KeyOfType<typeof presets>];
        const surfacePalette = this.appConfigurator.surfaces.find(
            (s) => s.name === this.appConfigurator.selectedSurfaceColor(),
        )?.palette;
        $t()
            .preset(preset)
            .preset(this.appConfigurator.getPresetExt())
            .surfacePalette(surfacePalette)
            .use({ useDefaultOptions: true });
        sessionStorage.setItem(
            'layoutConfig',
            btoa(JSON.stringify(defaultConfig)),
        );
    }

    fontOptions = [
        { label: 'System UI', value: 'system-ui, sans-serif' },
        { label: 'Arial', value: 'Arial, sans-serif' },
        { label: 'Arial Black', value: '"Arial Black", sans-serif' },
        { label: 'Consolas', value: 'Consolas, monospace' },
        { label: 'Comic Sans', value: '"Comic Sans MS", cursive, sans-serif' },
        { label: 'Courier New', value: '"Courier New", monospace' },
        { label: 'Garamond', value: 'Garamond, serif' },
        { label: 'Georgia', value: 'Georgia, serif' },
        { label: 'Tahoma', value: 'Tahoma, sans-serif' },
        { label: 'Trebuchet MS', value: '"Trebuchet MS", sans-serif' },
        { label: 'Verdana', value: 'Verdana, sans-serif' },
    ];

    selectedFontFamily = computed(
        () => this.layoutService.layoutConfig().fontFamily || 'Arial, sans-serif',
    );

    isFontSelected(fontValue: string): boolean {
        const current = this.selectedFontFamily();
        if (!current) return fontValue === 'Arial, sans-serif';
        return current === fontValue || fontValue.toLowerCase().includes(current.toLowerCase().replace(/['"]/g, ''));
    }

    onFontChange(fontFamily: string) {
        this.layoutService.layoutConfig.update((state) => ({
            ...state,
            fontFamily,
        }));
    }

    selectFont(value: string) {
        this.onFontChange(value);
        this.fontOverlay?.hide();
    }

    @ViewChild('fontOverlay') fontOverlay!: OverlayPanel;

    toggleFontDropdown(event: MouseEvent) {
        this.fontOverlay.toggle(event);
    }

    toggleDarkMode() {
        this.layoutService.layoutConfig.update((state) => ({
            ...state,
            darkTheme: !state.darkTheme,
        }));
    }

    onMenuModeChange(mode: string) {
        this.layoutService.layoutConfig.update((state) => ({
            ...state,
            menuMode: mode,
        }));
    }

    onDirectionChange(dir: 'ltr' | 'rtl') {
        this.layoutService.layoutConfig.update((state) => ({
            ...state,
            dir: dir,
        }));
        this.layoutService.applyDirection(dir);
    }

    LogoutAction() {
        this.authService.Logout();
    }

    selectLanguage(code: string): void {
        this.languageService.setLanguage(code);
        this.languageSelectorOpen.set(false);
    }

    toggleLanguageSelector(event: MouseEvent): void {
        event.stopPropagation();
        this.languageSelectorOpen.update((v) => !v);
    }

    closeLanguageSelector(): void {
        this.languageSelectorOpen.set(false);
    }

    @HostListener('document:click')
    onDocumentClick(): void {
        if (this.languageSelectorOpen()) {
            this.languageSelectorOpen.set(false);
        }
        if (this.contextMenuVisible) {
            this.closeContextMenu();
        }
    }

    @HostListener('document:keydown.escape')
    onEscapeKey(): void {
        if (this.contextMenuVisible) {
            this.closeContextMenu();
        }
        if (this.languageSelectorOpen()) {
            this.languageSelectorOpen.set(false);
        }
    }

    @HostListener('window:beforeunload')
    onBeforeUnload(): void {
        this.tabService.notifyWindowClosing();
    }

    getOptions() {
        const subscription = this.optionService
            .getFacilityOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    if (data.length === 1) {
                        this.facilityView.set(data);
                    }
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    openConfirmation() {
        this.displayConfirmation = !this.displayConfirmation;
    }

    OpenFacilityForm() {
        this.ref = this.dialogService.open(FacilityForm, {
            header: 'Facility',
            closable: false,
            modal: true,
            keepInViewport: true,
            width: '25rem',
        });

        this.ref.onClose.subscribe((data) => {
            if (data) window.location.reload();
        });
    }

    readonly MAX_VISIBLE_TABS = 3;

    get visibleTabs(): Tab[] {
        const tabs = this.tabService.tabs();
        if (tabs.length <= this.MAX_VISIBLE_TABS) {
            return tabs;
        }

        const activeIndex = tabs.findIndex(
            (t) => t.id === this.tabService.selectedTab(),
        );

        if (activeIndex === -1 || activeIndex < this.MAX_VISIBLE_TABS) {
            return tabs.slice(0, this.MAX_VISIBLE_TABS);
        }

        const startIndex = Math.max(
            0,
            Math.min(
                activeIndex - (this.MAX_VISIBLE_TABS - 1),
                tabs.length - this.MAX_VISIBLE_TABS,
            ),
        );
        return tabs.slice(startIndex, startIndex + this.MAX_VISIBLE_TABS);
    }

    get recentTabs(): Tab[] {
        const visibleIds = new Set(this.visibleTabs.map((t) => t.id));
        return this.tabService.tabs().filter((t) => !visibleIds.has(t.id));
    }

    canGoBack(): boolean {
        return this.tabService.tabsHistory().length > 1;
    }

    toggle(event: any) {
        this.op.toggle(event);
    }

    onTabClick(event: Event, id: number, name: string) {
        event.preventDefault();

        if (this.tabService.isSplitActive()) {
            const p1Id = this.tabService.splitPanel1TabId();
            const p2Id = this.tabService.splitPanel2TabId();
            const currentFocus = this.tabService.splitFocusedPanel();

            if (currentFocus === 'panel1' && id === p2Id) {
                this.tabService.setFocusedPanel('panel2');
                return;
            } else if (currentFocus === 'panel2' && id === p1Id) {
                this.tabService.setFocusedPanel('panel1');
                return;
            }

            this.tabService.setPanelTab(currentFocus, id);
            return;
        }

        const history = this.tabService.tabsHistory();
        const currentActive = this.tabService.selectedTab();

        // Only push to history if navigating to a different tab
        if (id !== currentActive) {
            this.tabService.addTabsHistory(id);
        }

        this.tabService.selectedTab.set(id);
        this.tabService.selectedName.set(name);
    }

    onCloseTab(event: Event, id: number) {
        event.preventDefault();
        event.stopPropagation();
        this.tabService.removeTab(id);
    }

    onRemoveAllTabs(event?: Event): void {
        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }
        if (this.op) {
            this.op.hide();
        }
        this.tabService.removeAllTabs();
    }

    removeAllTabs(): void {
        this.onRemoveAllTabs();
    }

    onTabAuxClick(event: MouseEvent, tabId: number): void {
        // Middle mouse button click (button === 1) closes tab like Chrome
        if (event.button === 1) {
            event.preventDefault();
            event.stopPropagation();
            this.tabService.removeTab(tabId);
        }
    }

    goBack() {
        const history = this.tabService.tabsHistory();
        if (history.length <= 1) return;

        // Remove current tab from history, don't close it
        const updatedHistory = history.slice(0, -1);
        const previousTabId = updatedHistory[updatedHistory.length - 1];

        const previousTab = this.tabService
            .tabs()
            .find((tab) => tab.id === previousTabId);

        if (previousTab) {
            this.tabService.tabsHistory.set(updatedHistory);
            this.tabService.selectedTab.set(previousTabId);
            this.tabService.selectedName.set(previousTab.title);
        }
    }

    /** -------------------- CDK Drag and Drop Handlers -------------------- */
    onTabDragStarted(event: CdkDragStart, tab: Tab): void {
        this.draggingTab = tab;
        this.isDetachZone = false;
        this.closeContextMenu();

        if (this.tabListContainer?.nativeElement) {
            this.tabListRect =
                this.tabListContainer.nativeElement.getBoundingClientRect();
        }
    }

    onTabDragMoved(event: CdkDragMove, tab: Tab): void {
        const { x, y } = event.pointerPosition;
        const rect = this.tabListRect;
        if (!rect) return;

        // Detach detection: dragged below tab bar into page body, above window, or past viewport edge
        const isBelowTabBar = y > rect.bottom + 35;
        const isAboveTabBar = y < rect.top - 20;
        const isBeyondViewport =
            x < 15 || x > window.innerWidth - 15 || y < 10 || y > window.innerHeight - 10;

        this.isDetachZone = isBelowTabBar || isAboveTabBar || isBeyondViewport;
    }

    onTabDragEnded(event: CdkDragEnd, tab: Tab): void {
        const shouldDetach = this.isDetachZone;
        this.isDetachZone = false;
        this.draggingTab = null;

        if (shouldDetach) {
            this.detachTabToNewWindow(tab);
        }
    }

    onTabDropped(event: CdkDragDrop<Tab[]>): void {
        this.isDetachZone = false;
        this.draggingTab = null;

        if (event.previousIndex === event.currentIndex) return;

        const currentVisible = this.visibleTabs;
        const fromTab = currentVisible[event.previousIndex];
        const toTab = currentVisible[event.currentIndex];
        if (!fromTab || !toTab) return;

        const allTabs = this.tabService.tabs();
        const globalFrom = allTabs.findIndex((t) => t.id === fromTab.id);
        const globalTo = allTabs.findIndex((t) => t.id === toTab.id);

        if (globalFrom !== -1 && globalTo !== -1) {
            const prevActive = allTabs.find(
                (t) => t.id === this.tabService.selectedTab(),
            );

            this.tabService.reorderTabs(globalFrom, globalTo);

            if (prevActive) {
                this.tabService.selectedTab.set(prevActive.id);
            }
        }
    }

    // Keep drop method for backwards compatibility
    drop(event: CdkDragDrop<any>): void {
        this.onTabDropped(event);
    }

    /** -------------------- New Window Support -------------------- */
    openTabInNewWindow(tab: Tab): void {
        const success = this.tabService.openInNewWindow(tab, { detach: true });
        if (!success) {
            this.pendingPopupTab = tab;
            this.popupBlockedNotice = true;
        }
    }

    detachTabToNewWindow(tab: Tab): void {
        this.openTabInNewWindow(tab);
    }

    retryOpenBlockedPopup(): void {
        if (this.pendingPopupTab) {
            const tab = this.pendingPopupTab;
            this.popupBlockedNotice = false;
            this.pendingPopupTab = null;
            this.tabService.openInNewWindow(tab, { detach: true });
        }
    }

    dismissPopupBlockedNotice(): void {
        this.popupBlockedNotice = false;
        this.pendingPopupTab = null;
    }

    /** -------------------- Context Menu Handlers -------------------- */
    get canCloseTabsToRight(): boolean {
        if (!this.contextMenuTab) return false;
        const tabs = this.tabService.tabs();
        const index = tabs.findIndex((t) => t.id === this.contextMenuTab!.id);
        return index !== -1 && index < tabs.length - 1;
    }

    onTabContextMenu(event: MouseEvent, tab: Tab): void {
        event.preventDefault();
        event.stopPropagation();
        this.contextMenuTab = tab;

        const menuWidth = 220;
        const menuHeight = 230;
        const x = Math.min(event.clientX, window.innerWidth - menuWidth - 12);
        const y = Math.min(event.clientY, window.innerHeight - menuHeight - 12);

        this.contextMenuPosition = { x: Math.max(8, x), y: Math.max(8, y) };
        this.contextMenuVisible = true;
    }

    closeContextMenu(): void {
        this.contextMenuVisible = false;
        this.contextMenuTab = null;
    }

    onContextMenuAction(
        action:
            | 'openInNewWindow'
            | 'duplicate'
            | 'close'
            | 'closeOthers'
            | 'closeRight'
            | 'closeAll'
            | 'splitRight'
            | 'splitLeft'
            | 'splitDown'
            | 'splitUp'
            | 'closeSplit'
            | 'maximize'
            | 'restore'
            | 'toggleOrientation'
            | 'swapPanels',
    ): void {
        const tab = this.contextMenuTab;
        this.closeContextMenu();

        switch (action) {
            case 'openInNewWindow':
                if (tab) this.openTabInNewWindow(tab);
                break;
            case 'duplicate':
                if (tab) this.tabService.duplicateTab(tab.id);
                break;
            case 'close':
                if (tab) this.tabService.removeTab(tab.id);
                break;
            case 'closeOthers':
                if (tab) this.tabService.closeOtherTabs(tab.id);
                break;
            case 'closeRight':
                if (tab) this.tabService.closeTabsToTheRight(tab.id);
                break;
            case 'closeAll':
                this.onRemoveAllTabs();
                break;
            case 'splitRight':
                this.tabService.splitRight(tab || undefined);
                break;
            case 'splitLeft':
                this.tabService.splitLeft(tab || undefined);
                break;
            case 'splitDown':
                this.tabService.splitDown(tab || undefined);
                break;
            case 'splitUp':
                this.tabService.splitUp(tab || undefined);
                break;
            case 'closeSplit':
                this.tabService.closeSplitView();
                break;
            case 'maximize':
                if (tab && this.tabService.splitPanel2TabId() === tab.id) {
                    this.tabService.maximizePanel('panel2');
                } else if (tab && this.tabService.splitPanel1TabId() === tab.id) {
                    this.tabService.maximizePanel('panel1');
                } else {
                    this.tabService.maximizePanel();
                }
                break;
            case 'restore':
                this.tabService.restoreSplitView();
                break;
            case 'toggleOrientation':
                this.tabService.toggleSplitOrientation();
                break;
            case 'swapPanels':
                this.tabService.swapSplitPanels();
                break;
        }
    }

    /** -------------------- Split View Handlers -------------------- */
    onDividerMouseDown(event: MouseEvent): void {
        event.preventDefault();
        event.stopPropagation();

        const container = this.splitContainer?.nativeElement;
        if (!container) return;

        this.isDraggingDivider = true;
        const containerRect = container.getBoundingClientRect();
        const isHorizontal = this.tabService.splitOrientation() === 'horizontal';

        const originalUserSelect = document.body.style.userSelect;
        const originalCursor = document.body.style.cursor;
        document.body.style.userSelect = 'none';
        document.body.style.cursor = isHorizontal ? 'col-resize' : 'row-resize';

        const onMouseMove = (moveEvent: MouseEvent) => {
            if (!this.isDraggingDivider) return;
            moveEvent.preventDefault();

            let ratio: number;
            if (isHorizontal) {
                const offsetX = moveEvent.clientX - containerRect.left;
                ratio = (offsetX / containerRect.width) * 100;
            } else {
                const offsetY = moveEvent.clientY - containerRect.top;
                ratio = (offsetY / containerRect.height) * 100;
            }

            this.tabService.setSplitRatio(ratio);
        };

        const onMouseUp = () => {
            this.isDraggingDivider = false;
            document.body.style.userSelect = originalUserSelect;
            document.body.style.cursor = originalCursor;

            window.removeEventListener('mousemove', onMouseMove);
            window.removeEventListener('mouseup', onMouseUp);
        };

        window.addEventListener('mousemove', onMouseMove);
        window.addEventListener('mouseup', onMouseUp);
    }

    onDividerDoubleClick(): void {
        this.tabService.setSplitRatio(50);
    }

    isPanelFocused(panel: 'panel1' | 'panel2'): boolean {
        return this.tabService.splitFocusedPanel() === panel;
    }

    onFocusPanel(panel: 'panel1' | 'panel2'): void {
        this.tabService.setFocusedPanel(panel);
    }

    onSwitchPanelTab(panel: 'panel1' | 'panel2', tabId: number): void {
        this.tabService.setPanelTab(panel, tabId);
        if (panel === 'panel1') {
            this.panel1TabsPopover?.hide();
        } else {
            this.panel2TabsPopover?.hide();
        }
    }

    toggleSplitMenu(event: Event): void {
        this.splitMenu?.toggle(event);
    }

    togglePanel1Tabs(event: Event): void {
        this.panel1TabsPopover?.toggle(event);
    }

    togglePanel2Tabs(event: Event): void {
        this.panel2TabsPopover?.toggle(event);
    }

    getTabSplitBadge(tabId: number): string | null {
        if (!this.tabService.isSplitActive()) return null;
        const isHorizontal = this.tabService.splitOrientation() === 'horizontal';
        if (tabId === this.tabService.splitPanel1TabId()) {
            return isHorizontal ? 'Left' : 'Top';
        }
        if (tabId === this.tabService.splitPanel2TabId()) {
            return isHorizontal ? 'Right' : 'Bottom';
        }
        return null;
    }

    get panel1FlexStyle(): string {
        if (!this.tabService.isSplitActive()) return '100%';
        if (this.tabService.isSplitMaximized()) {
            return this.tabService.splitMaximizedPanel() === 'panel1' ? '100%' : '0%';
        }
        const ratio = this.tabService.splitRatio();
        return `calc(${ratio}% - 4px)`;
    }

    get panel2FlexStyle(): string {
        if (!this.tabService.isSplitActive()) return '0%';
        if (this.tabService.isSplitMaximized()) {
            return this.tabService.splitMaximizedPanel() === 'panel2' ? '100%' : '0%';
        }
        const ratio = this.tabService.splitRatio();
        return `calc(${100 - ratio}% - 4px)`;
    }

    get splitPanelBodyHeight(): string {
        if (this.tabService.isSplitMaximized()) {
            return 'calc(100vh - 8.2rem)';
        }
        return this.tabService.splitOrientation() === 'horizontal'
            ? 'calc(100vh - 8.2rem)'
            : 'calc(50vh - 5.5rem)';
    }

    @HostListener('window:keydown', ['$event'])
    onWindowKeyDown(event: KeyboardEvent): void {
        const target = event.target as HTMLElement;
        if (target && ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName)) {
            return;
        }

        if (event.altKey) {
            if (event.key === 'ArrowRight') {
                event.preventDefault();
                this.tabService.splitRight();
            } else if (event.key === 'ArrowLeft') {
                event.preventDefault();
                this.tabService.splitLeft();
            } else if (event.key === 'ArrowDown') {
                event.preventDefault();
                this.tabService.splitDown();
            } else if (event.key === 'ArrowUp') {
                event.preventDefault();
                this.tabService.splitUp();
            } else if (event.key === 'm' || event.key === 'M') {
                if (this.tabService.isSplitActive()) {
                    event.preventDefault();
                    if (this.tabService.isSplitMaximized()) {
                        this.tabService.restoreSplitView();
                    } else {
                        this.tabService.maximizePanel();
                    }
                }
            }
        }
    }

    addTabs(title: string) {
        let route: Route;
        if (title === 'Receipt') {
            route = InboundRoutes.find((x) => x.path === 'Receipt') as Route;
        } else {
            route = OutboundRoutes.find((x) => x.path === 'orders') as Route;
        }
        this.tabService.addTab(route, '', title, true);
    }
}
