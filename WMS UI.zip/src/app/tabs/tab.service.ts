import {
    Injectable,
    signal,
    effect,
    inject,
    PLATFORM_ID,
    computed,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Route } from '@angular/router';

// Import all route arrays for component lookup
import inboundRoutes from '../views/inbound/inbound.routes';
import outboundRoutes from '../views/outbound/outbound.routes';
import inventoryRoutes from '../views/inventory/inventory.routes';
import masterRoutes from '../views/masters/master.routes';
import configurationRoutes from '../views/configurations/configuration.routes';
import businessIntelligenceRoutes from '../views/business-intelligence/business-intelligence.routes';
import adminPanelRoutes from '../views/admin-panel/admin-panel.routes';
import appointmentsRoutes from '../views/appointments/appointments.routes';
import waveRoutes from '../views/wave/wave.routes';

export interface Tab {
    id: number;
    title: string;
    icon: string;
    component: any;
    routeName?: string;
    params?: any[];
}

export interface SerializedTab {
    id: number;
    title: string;
    icon: string;
    routeName?: string;
    params?: any[];
}

export interface WindowHandoffData {
    tab: SerializedTab;
    auth: Record<string, string | null>;
    timestamp: number;
}

export interface BroadcastTabMessage {
    type:
        | 'TAB_DETACHED'
        | 'TAB_OPENED'
        | 'TAB_CLOSED'
        | 'WINDOW_CLOSING'
        | 'SESSION_LOGOUT'
        | 'SYNC_TABS';
    windowId: string;
    tabId?: number;
    title?: string;
    routeName?: string;
    params?: any[];
}

export interface SplitViewState {
    active: boolean;
    orientation: 'horizontal' | 'vertical';
    panel1TabId: number | null;
    panel2TabId: number | null;
    focusedPanel: 'panel1' | 'panel2';
    ratio: number;
    isMaximized: boolean;
    maximizedPanel: 'panel1' | 'panel2' | null;
}

@Injectable({
    providedIn: 'root',
})
export class TabService {
    private platformId = inject(PLATFORM_ID);
    private SESSION_KEY = 'app_open_tabs';
    private CHANNEL_NAME = 'wms_tabs_channel';

    public readonly windowId =
        'win_' + Math.random().toString(36).substring(2, 9) + '_' + Date.now();

    private channel: BroadcastChannel | null = null;

    // Consolidated list of all routes – allows us to map a stored routeName back to a component
    readonly allRoutes: Route[] = [
        ...inboundRoutes,
        ...outboundRoutes,
        ...inventoryRoutes,
        ...masterRoutes,
        ...configurationRoutes,
        ...businessIntelligenceRoutes,
        ...adminPanelRoutes,
        ...appointmentsRoutes,
        ...waveRoutes,
    ];

    nextTabId = signal<number>(1);
    tabs = signal<Tab[]>([]);
    tabsHistory = signal<number[]>([]);
    selectedTab = signal<number>(0);
    selectedName = signal<string>('');

    // Split View Signals
    splitActive = signal<boolean>(false);
    splitOrientation = signal<'horizontal' | 'vertical'>('horizontal');
    splitPanel1TabId = signal<number | null>(null);
    splitPanel2TabId = signal<number | null>(null);
    splitFocusedPanel = signal<'panel1' | 'panel2'>('panel1');
    splitRatio = signal<number>(50);
    splitMaximized = signal<boolean>(false);
    splitMaximizedPanel = signal<'panel1' | 'panel2' | null>(null);

    isSplitActive = computed(() => this.splitActive());
    isSplitMaximized = computed(() => this.splitMaximized());
    panel1Tab = computed(() => {
        const id = this.splitPanel1TabId();
        const all = this.tabs();
        return all.find((t) => t.id === id) || (all.length > 0 ? all[0] : null);
    });
    panel2Tab = computed(() => {
        const id = this.splitPanel2TabId();
        const all = this.tabs();
        return (
            all.find((t) => t.id === id) ||
            (all.length > 1 ? all[1] : all.length > 0 ? all[0] : null)
        );
    });

    constructor() {
        this.initBroadcastChannel();
        const handledHandoff = this.handleWindowHandoff();
        if (!handledHandoff) {
            this.loadFromSession();
        }

        // Persist any change to session storage
        effect(() => {
            this.saveToSession();
        });
    }

    /** -------------------- BroadcastChannel & Cross-Window -------------------- */
    private initBroadcastChannel(): void {
        if (
            !isPlatformBrowser(this.platformId) ||
            typeof BroadcastChannel === 'undefined'
        ) {
            return;
        }

        try {
            this.channel = new BroadcastChannel(this.CHANNEL_NAME);
            this.channel.onmessage = (
                event: MessageEvent<BroadcastTabMessage>,
            ) => {
                this.handleBroadcastMessage(event.data);
            };

            // Announce presence
            this.channel.postMessage({
                type: 'SYNC_TABS',
                windowId: this.windowId,
            });
        } catch (e) {
            console.warn(
                'BroadcastChannel initialization failed; falling back to single-window mode',
                e,
            );
        }
    }

    private handleBroadcastMessage(message: BroadcastTabMessage): void {
        if (!message || message.windowId === this.windowId) return;

        switch (message.type) {
            case 'TAB_DETACHED':
                console.info(
                    `[Tabs] Tab detached from window ${message.windowId}: ${message.title}`,
                );
                break;
            case 'TAB_OPENED':
                console.info(
                    `[Tabs] Tab opened in window ${message.windowId}: ${message.title}`,
                );
                break;
            case 'WINDOW_CLOSING':
                console.info(`[Tabs] Window closed: ${message.windowId}`);
                break;
        }
    }

    public notifyWindowClosing(): void {
        if (this.channel) {
            try {
                this.channel.postMessage({
                    type: 'WINDOW_CLOSING',
                    windowId: this.windowId,
                });
            } catch (e) {
                // Ignore closing error
            }
        }
    }

    /** -------------------- Window Handoff (Detached Tab Recovery) -------------------- */
    private handleWindowHandoff(): boolean {
        if (!isPlatformBrowser(this.platformId)) return false;

        try {
            const urlParams = new URLSearchParams(window.location.search);
            const transferId =
                urlParams.get('transferId') || urlParams.get('detachId');
            const openTabParam = urlParams.get('openTab');

            if (transferId) {
                const storageKey = `wms_tab_handoff_${transferId}`;
                const rawHandoff = localStorage.getItem(storageKey);

                if (rawHandoff) {
                    const handoffData: WindowHandoffData =
                        JSON.parse(rawHandoff);

                    // 1. Restore auth & session tokens in this window's sessionStorage if missing
                    if (handoffData.auth) {
                        for (const [key, val] of Object.entries(
                            handoffData.auth,
                        )) {
                            if (val && !sessionStorage.getItem(key)) {
                                sessionStorage.setItem(key, val);
                            }
                        }
                    }

                    // 2. Resolve matching route for the transferred tab
                    const tabData = handoffData.tab;
                    const route = this.findRouteForTab(
                        tabData.routeName,
                        tabData.title,
                    );

                    if (route && route.component) {
                        const restoredTab: Tab = {
                            id: 1,
                            title: tabData.title,
                            icon: tabData.icon || 'fa-solid fa-file',
                            component: route.component,
                            routeName: tabData.routeName ?? tabData.title,
                            params: tabData.params,
                        };

                        this.tabs.set([restoredTab]);
                        this.selectedTab.set(restoredTab.id);
                        this.selectedName.set(restoredTab.title);
                        this.tabsHistory.set([restoredTab.id]);
                        this.nextTabId.set(2);

                        // Clean up localStorage and URL parameter without reloading
                        localStorage.removeItem(storageKey);
                        this.cleanUrlParams([
                            'transferId',
                            'detachId',
                            'openTab',
                            'tabParams',
                        ]);

                        if (this.channel) {
                            this.channel.postMessage({
                                type: 'TAB_OPENED',
                                windowId: this.windowId,
                                tabId: restoredTab.id,
                                title: restoredTab.title,
                                routeName: restoredTab.routeName,
                            });
                        }

                        return true;
                    }
                }
            } else if (openTabParam) {
                // Direct openTab query param
                const route = this.findRouteForTab(openTabParam, openTabParam);
                if (route && route.component) {
                    let parsedParams: any[] | undefined = undefined;
                    try {
                        const rawParams = urlParams.get('tabParams');
                        if (rawParams) parsedParams = JSON.parse(rawParams);
                    } catch {}

                    const directTab: Tab = {
                        id: 1,
                        title: openTabParam,
                        icon: 'fa-solid fa-file',
                        component: route.component,
                        routeName: route.data?.['name'] ?? openTabParam,
                        params: parsedParams,
                    };

                    this.tabs.set([directTab]);
                    this.selectedTab.set(directTab.id);
                    this.selectedName.set(directTab.title);
                    this.tabsHistory.set([directTab.id]);
                    this.nextTabId.set(2);

                    this.cleanUrlParams(['openTab', 'tabParams']);
                    return true;
                }
            }
        } catch (e) {
            console.error('Error handling window handoff for detached tab', e);
        }

        return false;
    }

    private cleanUrlParams(keysToRemove: string[]): void {
        try {
            const url = new URL(window.location.href);
            let hasChanged = false;
            for (const key of keysToRemove) {
                if (url.searchParams.has(key)) {
                    url.searchParams.delete(key);
                    hasChanged = true;
                }
            }
            if (hasChanged) {
                window.history.replaceState(
                    {},
                    document.title,
                    url.pathname + (url.search ? url.search : ''),
                );
            }
        } catch {}
    }

    /** -------------------- Route Resolution Helper -------------------- */
    public findRouteForTab(
        routeName?: string,
        title?: string,
    ): Route | undefined {
        if (!routeName && !title) return undefined;

        const targetName = (routeName || '').trim().toLowerCase();
        const targetTitle = (title || '').trim().toLowerCase();

        return this.allRoutes.find((r) => {
            const rName = (r.data?.['name'] || '')
                .toString()
                .trim()
                .toLowerCase();
            const rPath = (r.path || '').toString().trim().toLowerCase();
            return (
                rName === targetName ||
                rName === targetTitle ||
                rPath === targetName ||
                rPath === targetTitle ||
                (targetName && rName.includes(targetName))
            );
        });
    }

    /** -------------------- Persistence Helpers -------------------- */
    private saveToSession(): void {
        if (!isPlatformBrowser(this.platformId)) return;
        const serialized: SerializedTab[] = this.tabs().map((t) => ({
            id: t.id,
            title: t.title,
            icon: t.icon,
            routeName: t.routeName ?? t.title,
            params: t.params,
        }));
        const payload = {
            tabs: serialized,
            selectedTab: this.selectedTab(),
            selectedName: this.selectedName(),
            tabsHistory: this.tabsHistory(),
            nextTabId: this.nextTabId(),
            splitState: {
                active: this.splitActive(),
                orientation: this.splitOrientation(),
                panel1TabId: this.splitPanel1TabId(),
                panel2TabId: this.splitPanel2TabId(),
                focusedPanel: this.splitFocusedPanel(),
                ratio: this.splitRatio(),
                isMaximized: this.splitMaximized(),
                maximizedPanel: this.splitMaximizedPanel(),
            },
        };
        sessionStorage.setItem(this.SESSION_KEY, JSON.stringify(payload));
    }

    private loadFromSession(): void {
        if (!isPlatformBrowser(this.platformId)) return;
        const raw = sessionStorage.getItem(this.SESSION_KEY);
        if (!raw) return;
        try {
            const data = JSON.parse(raw);
            const restoredTabs: Tab[] = [];
            for (const item of data.tabs ?? []) {
                const route = this.findRouteForTab(item.routeName, item.title);
                if (route && route.component) {
                    restoredTabs.push({
                        id: item.id,
                        title: item.title,
                        icon: item.icon,
                        component: route.component,
                        routeName: item.routeName,
                        params: item.params,
                    });
                }
            }
            if (restoredTabs.length) {
                this.tabs.set(restoredTabs);
                const matchingTab = restoredTabs.find(
                    (t) => t.id === data.selectedTab,
                );
                const activeTab = matchingTab ?? restoredTabs[0];
                this.selectedTab.set(activeTab.id);
                this.selectedName.set(activeTab.title);
                this.tabsHistory.set(data.tabsHistory ?? [activeTab.id]);
                this.nextTabId.set(data.nextTabId ?? restoredTabs.length + 1);

                // Restore Split View State
                if (data.splitState && data.splitState.active) {
                    const s = data.splitState;
                    const hasPanel1 = restoredTabs.some(
                        (t) => t.id === s.panel1TabId,
                    );
                    const hasPanel2 = restoredTabs.some(
                        (t) => t.id === s.panel2TabId,
                    );
                    if (hasPanel1 && hasPanel2) {
                        this.splitActive.set(true);
                        this.splitOrientation.set(
                            s.orientation || 'horizontal',
                        );
                        this.splitPanel1TabId.set(s.panel1TabId);
                        this.splitPanel2TabId.set(s.panel2TabId);
                        this.splitFocusedPanel.set(s.focusedPanel || 'panel1');
                        this.splitRatio.set(s.ratio || 50);
                        this.splitMaximized.set(s.isMaximized || false);
                        this.splitMaximizedPanel.set(s.maximizedPanel || null);
                    }
                }
            }
        } catch (e) {
            console.error('Failed to load tabs from sessionStorage', e);
        }
    }

    /** -------------------- Drag & Drop Reordering -------------------- */
    public reorderTabs(fromIndex: number, toIndex: number): void {
        if (
            fromIndex < 0 ||
            toIndex < 0 ||
            fromIndex >= this.tabs().length ||
            toIndex >= this.tabs().length ||
            fromIndex === toIndex
        ) {
            return;
        }

        const updated = [...this.tabs()];
        const [movedTab] = updated.splice(fromIndex, 1);
        updated.splice(toIndex, 0, movedTab);

        this.tabs.set(updated);
    }

    /** -------------------- Open / Detach in New Window -------------------- */
    public openInNewWindow(
        tab: Tab,
        options: { detach?: boolean } = { detach: true },
    ): boolean {
        if (!isPlatformBrowser(this.platformId)) return false;

        const transferId =
            'detach_' +
            Date.now() +
            '_' +
            Math.random().toString(36).substring(2, 8);

        // Gather critical authentication & layout settings so new window mirrors session
        const authData: Record<string, string | null> = {
            Facility: sessionStorage.getItem('Facility'),
            TraderKey: sessionStorage.getItem('TraderKey'),
            Token: sessionStorage.getItem('Token'),
            TokenAp: sessionStorage.getItem('TokenAp'),
            currentUserId: sessionStorage.getItem('currentUserId'),
            layoutConfig: sessionStorage.getItem('layoutConfig'),
        };

        const handoffPayload: WindowHandoffData = {
            tab: {
                id: tab.id,
                title: tab.title,
                icon: tab.icon,
                routeName: tab.routeName ?? tab.title,
                params: tab.params,
            },
            auth: authData,
            timestamp: Date.now(),
        };

        try {
            localStorage.setItem(
                `wms_tab_handoff_${transferId}`,
                JSON.stringify(handoffPayload),
            );
        } catch (err) {
            console.error('Failed to save tab handoff to localStorage', err);
        }

        // Build target URL
        const url = new URL(window.location.origin + window.location.pathname);
        url.searchParams.set('transferId', transferId);
        url.searchParams.set('openTab', tab.routeName || tab.title);
        if (tab.params && tab.params.length > 0) {
            try {
                url.searchParams.set('tabParams', JSON.stringify(tab.params));
            } catch {}
        }

        // Calculate offset screen positioning for Chrome-style tab detachment
        const screenW = window.screen.availWidth || 1440;
        const screenH = window.screen.availHeight || 900;
        const targetW = Math.min(1366, Math.floor(screenW * 0.88));
        const targetH = Math.min(840, Math.floor(screenH * 0.88));
        const targetLeft = Math.min(
            Math.max(window.screenX + 50, 0),
            screenW - targetW,
        );
        const targetTop = Math.min(
            Math.max(window.screenY + 40, 0),
            screenH - targetH,
        );

        const features = `left=${targetLeft},top=${targetTop},width=${targetW},height=${targetH},menubar=no,toolbar=no,location=yes,status=yes,resizable=yes,scrollbars=yes`;

        const newWin = window.open(url.toString(), '_blank', features);

        if (!newWin || newWin.closed || typeof newWin.closed === 'undefined') {
            console.warn('Popup blocker prevented opening the new window.');
            return false;
        }

        try {
            newWin.focus();
        } catch {}

        // Broadcast to other windows
        if (this.channel) {
            this.channel.postMessage({
                type: 'TAB_DETACHED',
                windowId: this.windowId,
                tabId: tab.id,
                title: tab.title,
                routeName: tab.routeName,
            });
        }

        // If detachment requested, remove tab from current window
        if (options.detach) {
            this.removeTab(tab.id);
        }

        return true;
    }

    /** -------------------- Context Menu Operations -------------------- */
    public duplicateTab(id: number): Tab | null {
        const target = this.tabs().find((t) => t.id === id);
        if (!target) return null;

        const newId = this.nextTabId();
        this.nextTabId.update((n) => n + 1);

        const clonedParams = target.params
            ? JSON.parse(JSON.stringify(target.params))
            : undefined;

        const duplicated: Tab = {
            id: newId,
            title: target.title,
            icon: target.icon,
            component: target.component,
            routeName: target.routeName,
            params: clonedParams,
        };

        const targetIndex = this.tabs().findIndex((t) => t.id === id);
        const updated = [...this.tabs()];
        updated.splice(targetIndex + 1, 0, duplicated);

        this.tabs.set(updated);
        this.selectedTab.set(duplicated.id);
        this.selectedName.set(duplicated.title);
        this.addTabsHistory(duplicated.id);

        return duplicated;
    }

    public closeOtherTabs(keepId: number): void {
        const keepTab = this.tabs().find((t) => t.id === keepId);
        if (!keepTab) return;

        this.tabs.set([keepTab]);
        this.selectedTab.set(keepTab.id);
        this.selectedName.set(keepTab.title);
        this.tabsHistory.set([keepTab.id]);
    }

    public closeTabsToTheRight(id: number): void {
        const index = this.tabs().findIndex((t) => t.id === id);
        if (index === -1 || index >= this.tabs().length - 1) return;

        const remainingTabs = this.tabs().slice(0, index + 1);
        this.tabs.set(remainingTabs);

        const stillActive = remainingTabs.some(
            (t) => t.id === this.selectedTab(),
        );
        if (!stillActive) {
            this.selectedTab.set(id);
            const currentTab = remainingTabs.find((t) => t.id === id);
            if (currentTab) {
                this.selectedName.set(currentTab.title);
            }
        }

        const remainingIds = new Set(remainingTabs.map((t) => t.id));
        this.tabsHistory.set(
            this.tabsHistory().filter((hId) => remainingIds.has(hId)),
        );
    }

    /** Selects a tab by its 1-based index (e.g. 1 for first tab, 2 for second tab) */
    public selectTabByIndex(oneBasedIndex: number): Tab | null {
        const allTabs = this.tabs();
        const zeroIndex = oneBasedIndex - 1;
        if (zeroIndex >= 0 && zeroIndex < allTabs.length) {
            const tab = allTabs[zeroIndex];
            this.selectedTab.set(tab.id);
            this.selectedName.set(tab.title);
            this.tabsHistory.update((v) => [...v, tab.id]);
            if (this.splitActive()) {
                if (this.splitFocusedPanel() === 'panel1') {
                    this.splitPanel1TabId.set(tab.id);
                } else {
                    this.splitPanel2TabId.set(tab.id);
                }
            }
            return tab;
        }
        return null;
    }

    /** Selects the next open tab */
    public switchToNextTab(): Tab | null {
        const allTabs = this.tabs();
        if (allTabs.length === 0) return null;
        const currentIdx = allTabs.findIndex((t) => t.id === this.selectedTab());
        const nextIdx = (currentIdx + 1) % allTabs.length;
        return this.selectTabByIndex(nextIdx + 1);
    }

    /** Selects the previous open tab */
    public switchToPreviousTab(): Tab | null {
        const allTabs = this.tabs();
        if (allTabs.length === 0) return null;
        const currentIdx = allTabs.findIndex((t) => t.id === this.selectedTab());
        const prevIdx = (currentIdx - 1 + allTabs.length) % allTabs.length;
        return this.selectTabByIndex(prevIdx + 1);
    }

    /** -------------------- Existing Tab Operations -------------------- */
    getTab(title: string) {
        return this.tabs().find((tab) => tab.title == title);
    }

    addTab(
        route: Route,
        icon: string,
        Title: string,
        multiple: boolean = false,
    ) {
        if (route != undefined) {
            const tab: Tab = {
                id: this.nextTabId(),
                title: Title,
                component: route.component,
                icon: icon,
                routeName: route.data?.['name'] ?? Title,
            };
            if (multiple) {
                this.tabs.update((cur) => [...cur, tab]);
                setTimeout(() => {
                    this.selectedTab.set(tab.id);
                    this.selectedName.set(tab.title);
                    if (this.splitActive()) {
                        if (this.splitFocusedPanel() === 'panel1') {
                            this.splitPanel1TabId.set(tab.id);
                        } else {
                            this.splitPanel2TabId.set(tab.id);
                        }
                    }
                });
                this.nextTabId.set(this.nextTabId() + 1);
                this.tabsHistory.update((v) => [...v, tab.id]);
                return;
            }
            const exists = this.getTab(tab.title);
            if (exists) {
                this.selectedTab.set(exists.id);
                this.selectedName.set(tab.title);
                this.tabsHistory.update((v) => [...v, exists.id]);
                if (this.splitActive()) {
                    if (this.splitFocusedPanel() === 'panel1') {
                        this.splitPanel1TabId.set(exists.id);
                    } else {
                        this.splitPanel2TabId.set(exists.id);
                    }
                }
            } else {
                this.tabs.update((cur) => [...cur, tab]);
                setTimeout(() => {
                    this.selectedTab.set(tab.id);
                    this.selectedName.set(tab.title);
                    if (this.splitActive()) {
                        if (this.splitFocusedPanel() === 'panel1') {
                            this.splitPanel1TabId.set(tab.id);
                        } else {
                            this.splitPanel2TabId.set(tab.id);
                        }
                    }
                });
                this.nextTabId.set(this.nextTabId() + 1);
                this.tabsHistory.update((v) => [...v, tab.id]);
            }
        }
    }

    addTabWithParams(route: Route, icon: string, Title: string, params: any[]) {
        if (route != undefined) {
            params.push({ name: 'id', value: this.nextTabId() });
            const tab: Tab = {
                id: this.nextTabId(),
                title: Title,
                component: route.component,
                icon: icon,
                routeName: route.data?.['name'] ?? Title,
                params: params,
            };
            const existing = this.getTab(tab.title);
            if (existing) {
                this.selectedName.set(tab.title);
                this.selectedTab.set(existing.id);
                this.tabsHistory.update((v) => [...v, existing.id]);
                if (this.splitActive()) {
                    if (this.splitFocusedPanel() === 'panel1') {
                        this.splitPanel1TabId.set(existing.id);
                    } else {
                        this.splitPanel2TabId.set(existing.id);
                    }
                }
            } else {
                this.tabs.update((cur) => [...cur, tab]);
                setTimeout(() => {
                    this.selectedTab.set(tab.id);
                    this.selectedName.set(tab.title);
                    if (this.splitActive()) {
                        if (this.splitFocusedPanel() === 'panel1') {
                            this.splitPanel1TabId.set(tab.id);
                        } else {
                            this.splitPanel2TabId.set(tab.id);
                        }
                    }
                });
                this.tabsHistory.update((v) => [...v, tab.id]);
            }
            this.nextTabId.set(this.nextTabId() + 1);
        }
    }

    addTabsHistory(id: number) {
        this.tabsHistory.update((v) => [...v, id]);
    }

    /** -------------------- Split View Operations -------------------- */
    public openSplit(
        targetTab: Tab | undefined,
        orientation: 'horizontal' | 'vertical',
        position: 'left' | 'right' | 'up' | 'down',
    ): void {
        const all = this.tabs();
        if (all.length === 0) return;

        const currentActiveId = this.selectedTab() || all[0].id;
        const currentActiveTab =
            all.find((t) => t.id === currentActiveId) || all[0];
        const selected = targetTab
            ? all.find((t) => t.id === targetTab.id) || targetTab
            : currentActiveTab;

        let p1Id: number;
        let p2Id: number;
        let focus: 'panel1' | 'panel2';

        if (position === 'right' || position === 'down') {
            // Target tab goes to panel2 (Right / Bottom)
            if (selected.id === currentActiveId) {
                const other = all.find((t) => t.id !== currentActiveId);
                if (!other) {
                    const duplicated = this.duplicateTab(selected.id);
                    p1Id = currentActiveId;
                    p2Id = duplicated ? duplicated.id : currentActiveId;
                    focus = 'panel2';
                } else {
                    p1Id = currentActiveId;
                    p2Id = other.id;
                    focus = 'panel2';
                }
            } else {
                p1Id = currentActiveId;
                p2Id = selected.id;
                focus = 'panel2';
            }
        } else {
            // Target tab goes to panel1 (Left / Top)
            if (selected.id === currentActiveId) {
                const other = all.find((t) => t.id !== currentActiveId);
                if (!other) {
                    const duplicated = this.duplicateTab(selected.id);
                    p1Id = duplicated ? duplicated.id : currentActiveId;
                    p2Id = currentActiveId;
                    focus = 'panel1';
                } else {
                    p1Id = other.id;
                    p2Id = currentActiveId;
                    focus = 'panel1';
                }
            } else {
                p1Id = selected.id;
                p2Id = currentActiveId;
                focus = 'panel1';
            }
        }

        this.splitOrientation.set(orientation);
        this.splitPanel1TabId.set(p1Id);
        this.splitPanel2TabId.set(p2Id);
        this.splitFocusedPanel.set(focus);
        this.splitActive.set(true);
        this.splitMaximized.set(false);
        this.splitMaximizedPanel.set(null);
        this.splitRatio.set(50);

        const focusedId = focus === 'panel1' ? p1Id : p2Id;
        const focusedTab = this.tabs().find((t) => t.id === focusedId);
        if (focusedTab) {
            this.selectedTab.set(focusedTab.id);
            this.selectedName.set(focusedTab.title);
        }
    }

    public splitRight(targetTab?: Tab): void {
        this.openSplit(targetTab, 'horizontal', 'right');
    }

    public splitLeft(targetTab?: Tab): void {
        this.openSplit(targetTab, 'horizontal', 'left');
    }

    public splitDown(targetTab?: Tab): void {
        this.openSplit(targetTab, 'vertical', 'down');
    }

    public splitUp(targetTab?: Tab): void {
        this.openSplit(targetTab, 'vertical', 'up');
    }

    public closeSplitView(): void {
        const focused = this.splitFocusedPanel();
        const activeId =
            focused === 'panel2'
                ? (this.splitPanel2TabId() ?? this.splitPanel1TabId())
                : (this.splitPanel1TabId() ?? this.splitPanel2TabId());

        this.splitActive.set(false);
        this.splitMaximized.set(false);
        this.splitMaximizedPanel.set(null);

        if (activeId) {
            const target = this.tabs().find((t) => t.id === activeId);
            if (target) {
                this.selectedTab.set(target.id);
                this.selectedName.set(target.title);
            }
        }
    }

    public maximizePanel(panel?: 'panel1' | 'panel2'): void {
        if (!this.splitActive()) return;
        const target = panel || this.splitFocusedPanel();
        this.splitMaximized.set(true);
        this.splitMaximizedPanel.set(target);
    }

    public restoreSplitView(): void {
        if (!this.splitActive()) return;
        this.splitMaximized.set(false);
        this.splitMaximizedPanel.set(null);
    }

    public toggleSplitOrientation(): void {
        if (!this.splitActive()) return;
        this.splitOrientation.update((o) =>
            o === 'horizontal' ? 'vertical' : 'horizontal',
        );
    }

    public swapSplitPanels(): void {
        if (!this.splitActive()) return;
        const p1 = this.splitPanel1TabId();
        const p2 = this.splitPanel2TabId();
        this.splitPanel1TabId.set(p2);
        this.splitPanel2TabId.set(p1);
        this.splitFocusedPanel.update((f) =>
            f === 'panel1' ? 'panel2' : 'panel1',
        );
    }

    public setSplitRatio(ratio: number): void {
        const clamped = Math.max(15, Math.min(85, Math.round(ratio)));
        this.splitRatio.set(clamped);
    }

    public setFocusedPanel(panel: 'panel1' | 'panel2'): void {
        this.splitFocusedPanel.set(panel);
        const activeId =
            panel === 'panel1'
                ? this.splitPanel1TabId()
                : this.splitPanel2TabId();
        if (activeId) {
            const tab = this.tabs().find((t) => t.id === activeId);
            if (tab) {
                this.selectedTab.set(tab.id);
                this.selectedName.set(tab.title);
            }
        }
    }

    public setPanelTab(panel: 'panel1' | 'panel2', tabId: number): void {
        if (panel === 'panel1') {
            this.splitPanel1TabId.set(tabId);
        } else {
            this.splitPanel2TabId.set(tabId);
        }
        this.setFocusedPanel(panel);
        this.addTabsHistory(tabId);
    }

    removeTab(id: number) {
        const currentTabs = this.tabs();
        const index = currentTabs.findIndex((t) => t.id === id);
        const remaining = currentTabs.filter((t) => t.id !== id);

        if (remaining.length === 0) {
            this.removeAllTabs();
            return;
        }

        this.tabs.set(remaining);
        // Clean up history entries for this tab
        this.tabsHistory.set(this.tabsHistory().filter((hId) => hId !== id));

        // Clean up Split View
        if (this.splitActive()) {
            if (remaining.length === 0) {
                this.splitActive.set(false);
                this.splitMaximized.set(false);
                this.splitMaximizedPanel.set(null);
            } else if (remaining.length === 1) {
                this.closeSplitView();
            } else {
                if (this.splitPanel1TabId() === id) {
                    const fallback =
                        remaining.find(
                            (t) => t.id !== this.splitPanel2TabId(),
                        ) || remaining[0];
                    this.splitPanel1TabId.set(fallback.id);
                }
                if (this.splitPanel2TabId() === id) {
                    const fallback =
                        remaining.find(
                            (t) => t.id !== this.splitPanel1TabId(),
                        ) || remaining[0];
                    this.splitPanel2TabId.set(fallback.id);
                }
            }
        }

        if (this.selectedTab() === id) {
            if (remaining.length > 0) {
                const newIndex = Math.max(0, index - 1);
                const newTab = remaining[newIndex];
                this.selectedTab.set(newTab.id);
                this.selectedName.set(newTab.title);
            } else {
                this.selectedTab.set(0);
                this.selectedName.set('');
            }
        }
    }

    CloseAndNewtab(route: Route, icon: string, Title: string, params: any[]) {
        if (Title) {
            const existing = this.getTab(Title);
            if (existing) {
                this.removeTab(existing?.id || 0);
                this.addTabWithParams(route, icon, Title, params);
            } else {
                this.addTabWithParams(route, icon, Title, params);
            }
        }
    }

    public openDefaultDashboardTab(): void {
        const route =
            this.findRouteForTab('Dashboard', 'Dashboard') ||
            this.allRoutes.find(
                (r) =>
                    r.data?.['name'] === 'Dashboard' ||
                    r.path === 'dashboard',
            );
        if (route && route.component) {
            const nextId = this.nextTabId();
            this.nextTabId.update((id) => id + 1);
            const dashboardTab: Tab = {
                id: nextId,
                title: 'Dashboard',
                component: route.component,
                icon: 'pi pi-home',
                routeName: 'Dashboard',
            };
            this.tabs.set([dashboardTab]);
            this.selectedTab.set(dashboardTab.id);
            this.selectedName.set(dashboardTab.title);
            this.tabsHistory.set([dashboardTab.id]);

            setTimeout(() => {
                this.selectedTab.set(dashboardTab.id);
                this.selectedName.set(dashboardTab.title);
            });
        }
    }

    clearTabs() {
        this.tabs.set([]);
        this.selectedTab.set(0);
        this.selectedName.set('');
        this.tabsHistory.set([]);
        this.splitActive.set(false);
        this.splitMaximized.set(false);
        this.splitMaximizedPanel.set(null);
        if (isPlatformBrowser(this.platformId)) {
            sessionStorage.removeItem(this.SESSION_KEY);
        }
    }

    removeAllTabs() {
        this.clearTabs();
        this.openDefaultDashboardTab();
    }
}
