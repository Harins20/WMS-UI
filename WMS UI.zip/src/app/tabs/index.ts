export * from './tab-panel/tab-panel.component';
export * from './tab.service';
export * from './tabs.component';
