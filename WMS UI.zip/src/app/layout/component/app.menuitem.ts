import {
    Component,
    ElementRef,
    HostBinding,
    HostListener,
    inject,
    Input,
    PLATFORM_ID,
    signal,
} from '@angular/core';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import {
    animate,
    state,
    style,
    transition,
    trigger,
} from '@angular/animations';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { RippleModule } from 'primeng/ripple';
import { MenuItem } from 'primeng/api';
import { LayoutService } from '../service/layout.service';
import { TabService } from '../../tabs/tab.service';

@Component({
    // eslint-disable-next-line @angular-eslint/component-selector
    selector: '[app-menuitem]',
    imports: [CommonModule, RouterModule, RippleModule],
    template: `
        <ng-container>
            <div
                *ngIf="root && item.visible !== false"
                class="layout-menuitem-root-text"
            >
                {{ item.label }}
            </div>
            <a
                *ngIf="
                    (!item.routerLink || item.items) && item.visible !== false
                "
                [attr.href]="item.url"
                (click)="itemClick($event)"
                [ngClass]="item.styleClass"
                [attr.target]="item.target"
                tabindex="0"
                pRipple
                [class.active-menu]="tabservice.selectedName() === item.label"
            >
                <i [ngClass]="item.icon" class="layout-menuitem-icon"></i>
                <span class="layout-menuitem-text">{{ item.label }}</span>
                <i
                    class="pi pi-fw pi-angle-down layout-submenu-toggler"
                    *ngIf="item.items"
                ></i>
            </a>
            <a
                *ngIf="item.routerLink && !item.items && item.visible !== false"
                (click)="itemClick($event)"
                [ngClass]="item.styleClass"
                [routerLink]="item.routerLink"
                routerLinkActive="active-route"
                [routerLinkActiveOptions]="
                    item.routerLinkActiveOptions || {
                        paths: 'exact',
                        queryParams: 'ignored',
                        matrixParams: 'ignored',
                        fragment: 'ignored',
                    }
                "
                [fragment]="item.fragment"
                [queryParamsHandling]="item.queryParamsHandling"
                [preserveFragment]="item.preserveFragment"
                [skipLocationChange]="item.skipLocationChange"
                [replaceUrl]="item.replaceUrl"
                [state]="item.state"
                [queryParams]="item.queryParams"
                [attr.target]="item.target"
                tabindex="0"
                pRipple
            >
                <i [ngClass]="item.icon" class="layout-menuitem-icon"></i>
                <span class="layout-menuitem-text">{{ item.label }}</span>
                <i
                    class="pi pi-fw pi-angle-down layout-submenu-toggler"
                    *ngIf="item.items"
                ></i>
            </a>

            <ul
                *ngIf="item.items && item.visible !== false"
                [@children]="submenuAnimation"
            >
                <ng-template
                    ngFor
                    let-child
                    let-i="index"
                    [ngForOf]="item.items"
                >
                    <li
                        app-menuitem
                        [item]="child"
                        [index]="i"
                        [parentKey]="key"
                        [class]="child['badgeClass']"
                    ></li>
                </ng-template>
            </ul>
        </ng-container>
    `,
    animations: [
        trigger('children', [
            state(
                'collapsed',
                style({
                    height: '0',
                }),
            ),
            state(
                'expanded',
                style({
                    height: '*',
                }),
            ),
            transition(
                'collapsed <=> expanded',
                animate('400ms cubic-bezier(0.86, 0, 0.07, 1)'),
            ),
        ]),
    ],
    // providers: [LayoutService],
})
export class AppMenuitem {
    @Input() item!: MenuItem;

    @Input() index!: number;

    @Input() @HostBinding('class.layout-root-menuitem') root!: boolean;

    @Input() parentKey!: string;

    active = false;

    /** Dedicated toggle state for the Traders accordion. Never auto-set by route events. */
    isTradersOpen = false;

    menuSourceSubscription: Subscription;

    menuResetSubscription: Subscription;

    key: string = '';

    selectmenu = signal<string>('');

    public tabservice = inject(TabService);
    public el = inject(ElementRef);
    private platformId = inject(PLATFORM_ID);

    constructor(
        public router: Router,
        private layoutService: LayoutService,
    ) {
        this.menuSourceSubscription = this.layoutService.menuSource$.subscribe(
            (value) => {
                Promise.resolve(null).then(() => {
                    // Traders accordion: NEVER auto-expand from route events.
                    // Its visibility is controlled solely by isTradersOpen (click-only).
                    if (this.item?.label === 'Traders') {
                        return;
                    }

                    if (value.routeEvent) {
                        this.active =
                            value.key === this.key ||
                            value.key.startsWith(this.key + '-')
                                ? true
                                : false;
                    } else {
                        if (
                            value.key !== this.key &&
                            !value.key.startsWith(this.key + '-')
                        ) {
                            this.active = false;
                        }
                    }
                });
            },
        );

        this.menuResetSubscription = this.layoutService.resetSource$.subscribe(
            () => {
                this.active = false;
            },
        );

        this.router.events
            .pipe(filter((event) => event instanceof NavigationEnd))
            .subscribe((params) => {
                if (this.item.routerLink) {
                    this.updateActiveStateFromRoute();
                }
            });
    }

    ngOnInit() {
        this.key = this.parentKey
            ? this.parentKey + '-' + this.index
            : String(this.index);

        if (this.item.routerLink) {
            this.updateActiveStateFromRoute();
        }
    }

    @HostListener('mouseenter')
    onMouseEnter() {
        if (!this.root && this.item?.items?.length) {
            this.adjustSubmenuPosition();
        }
    }

    @HostListener('mousemove')
    onMouseMove() {
        if (!this.root && this.item?.items?.length) {
            this.adjustSubmenuPosition();
        }
    }

    @HostListener('window:resize')
    onWindowResize() {
        if (!this.root && this.item?.items?.length) {
            this.adjustSubmenuPosition();
        }
    }

    /**
     * Calculates and adjusts the vertical position of floating submenus
     * relative to the window viewport (window.innerHeight) to prevent
     * overflowing off the top or bottom of the screen.
     */
    adjustSubmenuPosition() {
        const hostEl = this.el?.nativeElement as HTMLElement;
        if (!hostEl) return;
        this.adjustSubmenuForElement(hostEl);
        this.setupSubmenuResizeObserver(hostEl);
    }

    private submenuResizeObserver?: ResizeObserver;

    setupSubmenuResizeObserver(hostEl: HTMLElement) {
        if (
            !isPlatformBrowser(this.platformId) ||
            typeof window === 'undefined' ||
            typeof ResizeObserver === 'undefined'
        ) {
            return;
        }

        const submenu = hostEl.querySelector<HTMLElement>(':scope > ul');
        if (!submenu || this.submenuResizeObserver) return;

        this.submenuResizeObserver = new ResizeObserver(() => {
            this.adjustSubmenuForElement(hostEl);
        });
        this.submenuResizeObserver.observe(submenu);
    }

    /**
     * Calculates and adjusts the vertical position of floating submenus
     * relative to the window viewport (window.innerHeight) to prevent
     * overflowing off the top or bottom of the screen.
     */
    adjustSubmenuForElement(hostEl: HTMLElement) {
        if (!isPlatformBrowser(this.platformId) || typeof window === 'undefined') {
            return;
        }
        if (!hostEl) return;

        const submenu = hostEl.querySelector<HTMLElement>(':scope > ul');
        if (!submenu) return;

        const rect = hostEl.getBoundingClientRect();
        const windowHeight = window.innerHeight;

        // Use scrollHeight to capture full expanded height including dropdown fields
        let submenuHeight = submenu.scrollHeight || submenu.offsetHeight;
        if (!submenuHeight || submenuHeight < 20) {
            const prevDisplay = submenu.style.display;
            const prevHeight = submenu.style.height;
            submenu.style.setProperty('display', 'block', 'important');
            submenu.style.setProperty('height', 'auto', 'important');
            submenuHeight = submenu.scrollHeight || submenu.offsetHeight;
            if (prevDisplay) {
                submenu.style.display = prevDisplay;
            } else {
                submenu.style.removeProperty('display');
            }
            if (prevHeight) {
                submenu.style.height = prevHeight;
            } else {
                submenu.style.removeProperty('height');
            }
        }

        if (!submenuHeight || submenuHeight < 20) {
            const itemCount = this.item?.items?.length || 5;
            submenuHeight = Math.min(itemCount * 44 + 20, windowHeight - 48);
        }

        const padding = 24;
        let top = rect.top;

        // Prevent overflowing past bottom of the window, leaving comfortable bottom clearance
        if (top + submenuHeight > windowHeight - padding) {
            top = windowHeight - submenuHeight - padding;
        }

        // Prevent overflowing above top of the window
        if (top < padding) {
            top = padding;
        }

        const maxAvailableHeight = Math.max(180, windowHeight - top - padding);

        hostEl.style.setProperty('--submenu-top', `${Math.round(top)}px`);
        hostEl.style.setProperty('--submenu-max-height', `${Math.round(maxAvailableHeight)}px`);
        hostEl.style.setProperty('--submenu-translate-y', '0px');
    }

    notifyParentSubmenuResize() {
        if (!isPlatformBrowser(this.platformId) || typeof window === 'undefined') {
            return;
        }

        const recalculate = () => {
            const host = this.el?.nativeElement as HTMLElement;
            const rootParentLi = host?.closest(
                '.layout-root-menuitem > ul > li',
            ) as HTMLElement;
            if (rootParentLi) {
                this.adjustSubmenuForElement(rootParentLi);
            } else if (!this.root && this.item?.items?.length) {
                this.adjustSubmenuForElement(host);
            }
        };

        // Recalculate immediately, during animation, and after completion
        recalculate();
        setTimeout(recalculate, 80);
        setTimeout(recalculate, 220);
        setTimeout(recalculate, 420);
    }

    updateActiveStateFromRoute() {
        let activeRoute = this.router.isActive(this.item.routerLink[0], {
            paths: 'exact',
            queryParams: 'ignored',
            matrixParams: 'ignored',
            fragment: 'ignored',
        });

        if (activeRoute) {
            this.layoutService.onMenuStateChange({
                key: this.key,
                routeEvent: true,
            });
        }
    }

    itemClickq(event: Event) {
        // avoid processing disabled items
        if (this.item.disabled) {
            event.preventDefault();
            return;
        }

        // execute command
        if (this.item.command) {
            this.item.command({ originalEvent: event, item: this.item });
        }

        // toggle active state
        if (this.item.items) {
            this.active = !this.active;
        }

        this.layoutService.onMenuStateChange({ key: this.key });
    }

    itemClick(event: Event) {
        // avoid processing disabled items
        if (this.item.disabled) {
            event.preventDefault();
            return;
        }

        // execute command
        if (this.item.command) {
            this.item.command({ originalEvent: event, item: this.item });
        }

        // Traders: toggle via dedicated isTradersOpen flag only.
        // Do NOT broadcast state change to other items — Masters hover must not interfere.
        if (this.item?.label === 'Traders') {
            if (this.item.items) {
                this.isTradersOpen = !this.isTradersOpen;
                this.notifyParentSubmenuResize();
            }
            return;
        }

        // toggle active state for all other items
        if (this.item.items) {
            const wasActive = this.active;

            // Notify all other menu items
            this.layoutService.onMenuStateChange({
                key: this.key,
            });

            // Toggle current menu
            this.active = !wasActive;
            this.notifyParentSubmenuResize();
        }
    }

    get submenuAnimation() {
        if (this.root) return 'expanded';
        // Traders uses its own dedicated state so hover/route events can't override it
        if (this.item?.label === 'Traders') {
            return this.isTradersOpen ? 'expanded' : 'collapsed';
        }
        return this.active ? 'expanded' : 'collapsed';
    }

    @HostBinding('class.active-menuitem')
    get activeClass() {
        return this.active && !this.root;
    }

    ngOnDestroy() {
        if (this.submenuResizeObserver) {
            this.submenuResizeObserver.disconnect();
        }

        if (this.menuSourceSubscription) {
            this.menuSourceSubscription.unsubscribe();
        }

        if (this.menuResetSubscription) {
            this.menuResetSubscription.unsubscribe();
        }
    }
}
