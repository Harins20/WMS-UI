import { AuthService } from './../../common/services/auth.service';
import {
    Component,
    DestroyRef,
    inject,
    signal,
    OnInit,
    input,
} from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { StyleClassModule } from 'primeng/styleclass';
import { PopoverModule } from 'primeng/popover';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { Select } from 'primeng/select';
import {
    FormControl,
    FormGroup,
    FormsModule,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { OptionsService } from '../../common/services';
import { markAllControlsAsDirty } from '../../common/functions';
import { AppTranslatePipe } from '../../common/pipes/translate.pipe';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-facility',
    standalone: true,
    imports: [
        ReactiveFormsModule,
        RouterModule,
        CommonModule,
        StyleClassModule,
        PopoverModule,
        DialogModule,
        ButtonModule,
        Select,
        FormsModule,
        AppTranslatePipe,
    ],
    template: `
        <form [formGroup]="facilityForm" (ngSubmit)="onSubmit()">
            <div class="items-center justify-center gap-4 mb-8">
                @if (facilitySelectVisible()) {
                    <p-select
                        [options]="facilityOptions()"
                        formControlName="facility"
                        optionLabel="label"
                        optionValue="value"
                        [class.ng-invalid]="hasError()"
                        [class.ng-dirty]="hasError()"
                        fluid
                        appendTo="body"
                    />
                }

                <p class="mt-5 text-lg font-bold">
                    {{ 'Storer' | appTranslate }}
                </p>

                @if (storerSelectVisible()) {
                    <p-select
                        [options]="storerOptions()"
                        formControlName="storer"
                        optionLabel="label"
                        optionValue="value"
                        fluid
                        appendTo="body"
                    />
                }
            </div>
            <div class="flex justify-end gap-2">
                <p-button
                    [label]="'Cancel' | appTranslate"
                    severity="secondary"
                    [disabled]="hasError() || CancelBtn()"
                    (click)="onClose()"
                />
                <p-button
                    type="submit"
                    [label]="'Ok' | appTranslate"
                    [disabled]="hasError()"
                />
            </div>
        </form>
    `,
})
export class FacilityForm implements OnInit {
    CancelBtn = input<any>();
    facilityOptions = signal<any[]>([]);
    storerOptions = signal<any[]>([]);
    facilitySelectVisible = signal(true);
    storerSelectVisible = signal(true);
    private optionService = inject(OptionsService);
    private destroyRef = inject(DestroyRef);
    private ref = inject(DynamicDialogRef);
    authService = inject(AuthService);

    facilityForm = new FormGroup({
        facility: new FormControl<string | undefined | null>(undefined, [
            Validators.required,
        ]),
        storer: new FormControl<string | undefined | null>(undefined, []),
    });

    ngOnInit() {
        const encodedFacility = sessionStorage.getItem('Facility');
        const facility = encodedFacility ? atob(encodedFacility) : null;

        const encodedTraderKey = sessionStorage.getItem('TraderKey');
        const TraderKey = encodedTraderKey ? atob(encodedTraderKey) : null;

        this.facilityForm.patchValue({
            facility: 'DEV',
            storer: 'RTL-OWNER',
        });

        this.getOptions();

        this.facilityForm.get('facility')?.valueChanges.subscribe((value) => {
            this.refreshFacilitySelect();
            this.getstorerOptions();
        });
        this.facilityForm.get('storer')?.valueChanges.subscribe((value) => {
            this.refreshStorerSelect();
        });
    }

    getOptions() {
        const subscription = this.optionService.getFacilityOptions().subscribe({
            next: (data) => {
                if (data.length === 1) {
                    this.onSetdefaultFacility(data[0]);
                } else {
                    this.facilityOptions.set(data);
                    this.getstorerOptions();
                }
            },
        });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    getstorerOptions() {
        const facility = this.facilityForm.getRawValue().facility;
        if (!facility) {
            // this.storerOptions.set([
            //     { Id: 3, label: 'RTL-OWNER', value: 'RTL-OWNER' },
            //     { Id: 336, label: 'RTL-OWNER-01', value: 'RTL-OWNER-01' },
            //     { Id: 337, label: 'RTL-OWNER-02', value: 'RTL-OWNER-02' },
            //     { Id: 338, label: 'RTL-OWNER-03', value: 'RTL-OWNER-03' },
            //     { Id: 339, label: 'RTL-OWNER-04', value: 'RTL-OWNER-04' },
            //     { Id: 340, label: 'RTL-OWNER-05', value: 'RTL-OWNER-05' },
            // ]);

            this.storerOptions.set([]);
            return;
        }
        const subscription = this.optionService
            .getStorerOptions(facility)
            .subscribe({
                next: (data) => {
                    // this.storerOptions.set([
                    //     { Id: 3, label: 'RTL-OWNER', value: 'RTL-OWNER' },
                    //     {
                    //         Id: 336,
                    //         label: 'RTL-OWNER-01',
                    //         value: 'RTL-OWNER-01',
                    //     },
                    //     {
                    //         Id: 337,
                    //         label: 'RTL-OWNER-02',
                    //         value: 'RTL-OWNER-02',
                    //     },
                    //     {
                    //         Id: 338,
                    //         label: 'RTL-OWNER-03',
                    //         value: 'RTL-OWNER-03',
                    //     },
                    //     {
                    //         Id: 339,
                    //         label: 'RTL-OWNER-04',
                    //         value: 'RTL-OWNER-04',
                    //     },
                    //     {
                    //         Id: 340,
                    //         label: 'RTL-OWNER-05',
                    //         value: 'RTL-OWNER-05',
                    //     },
                    // ]);
                    this.storerOptions.set(data);
                    if (data.length === 1) {
                        this.facilityForm.patchValue({
                            storer: data[0]?.value,
                        });
                    }
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }

    private refreshFacilitySelect() {
        this.facilitySelectVisible.set(false);
        setTimeout(() => {
            this.facilitySelectVisible.set(true);
        });
    }

    private refreshStorerSelect() {
        this.storerSelectVisible.set(false);
        setTimeout(() => {
            this.storerSelectVisible.set(true);
        });
    }

    hasError() {
        const formControl = this.facilityForm.get('facility');
        return (
            formControl &&
            (formControl.touched || formControl.dirty) &&
            formControl.invalid
        );
    }

    onClose() {
        if (this.facilityForm.valid) {
            this.ref.close(false);
        } else {
            this.facilityForm.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.facilityForm.controls));
        }
    }

    onSetdefaultFacility(facilityObj: any) {
        const facilityName = facilityObj.Name;
        const facilityId = facilityObj.Id;

        this.authService.facility.set(facilityName!);
        sessionStorage.setItem('Facility', btoa(facilityName!));

        if (facilityId) {
            sessionStorage.setItem('FacilityId', facilityId.toString());
        }

        this.ref.close(true);
    }

    onSubmit() {
        if (this.facilityForm.valid) {
            const facility = this.facilityForm.getRawValue().facility!;
            const storer = this.facilityForm.getRawValue().storer!;

            const encodedFacility = btoa(facility);
            const encodedTokenTraderKey = btoa(storer);

            sessionStorage.setItem('Facility', encodedFacility);
            sessionStorage.setItem('TraderKey', encodedTokenTraderKey);
            this.authService.facility.set(encodedFacility);
            this.authService.TraderKey.set(encodedTokenTraderKey);

            const selectedFacilityObj = this.facilityOptions().find(
                (f) => f.value === facility || f.Name === facility,
            );
            const selectedStorerObj = this.storerOptions().find(
                (s) => s.value === storer || s.Name === storer,
            );

            if (selectedFacilityObj?.Id) {
                sessionStorage.setItem(
                    'FacilityId',
                    selectedFacilityObj.Id.toString(),
                );
            }
            if (selectedStorerObj?.Id) {
                sessionStorage.setItem(
                    'StorerId',
                    selectedStorerObj.Id.toString(),
                );
            }

            sessionStorage.removeItem('app_open_tabs');
            this.ref.close(true);
        } else {
            this.facilityForm.markAllAsTouched();
            markAllControlsAsDirty(Object.values(this.facilityForm.controls));
        }
    }
}
