import { Component, DestroyRef, inject, signal } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { StyleClassModule } from 'primeng/styleclass';
import { AppConfigurator } from './app.configurator';
import { LayoutService } from '../service/layout.service';
import { PopoverModule } from 'primeng/popover';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { AuthService, OptionsService } from '../../common/services';
import { FormsModule } from '@angular/forms';
import { DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';
import { FacilityForm } from './facility-form';
import { CheckboxModule } from 'primeng/checkbox';
import { TranslateComponent } from './app.translate';
import { LanguageService } from '../../common/services/language.service';
import { StorerService } from '../../views/admin-panel/storer/storer.service';
import { formatBase64Image } from '../../common/functions/formatBase64Image';

@Component({
    selector: 'app-topbar',
    standalone: true,
    imports: [
        RouterModule,
        CommonModule,
        StyleClassModule,
        AppConfigurator,
        PopoverModule,
        DialogModule,
        ButtonModule,
        FormsModule,
        CheckboxModule,
    ],
    template: `
        <div class="layout-topbar">
            <div class="layout-topbar-logo-container">
                <!-- <button
                    class="layout-menu-button layout-topbar-action"
                    (click)="layoutService.onMenuToggle()"
                >
                    <i class="pi pi-bars"></i>
                </button> -->
                <!-- <a class="layout-topbar-logo">
                    <img
                        src="assets/img/logo.png"
                        width="90px"
                        height="150px"
                    />
                </a> -->
            </div>

            <div class="layout-topbar-actions">
                <div class="layout-config-menu">
                    @if (facilityView().length === 1) {
                        <div class="flex items-center gap-2">
                            @if (storerLogo()) {
                                <img
                                    [src]="storerLogo()"
                                    alt="Storer Logo"
                                    class="h-8 max-w-[100px] object-contain rounded-md"
                                />
                            }
                            <button>
                                <p-button [label]="">{{
                                    facilityView()[0]?.Name
                                }}</p-button>
                            </button>
                        </div>
                    } @else {
                        <div class="hidden md:flex items-center gap-2.5">
                            @if (storerLogo()) {
                                <img
                                    [src]="storerLogo()"
                                    alt="Storer Logo"
                                    class="h-8 max-w-[100px] object-contain rounded-md"
                                />
                            }
                            <div class="flex flex-col leading-tight">
                                <span class="text-[10px] text-gray-400"
                                    >Facility</span
                                >
                                <span
                                    class="text-sm font-semibold text-gray-800 dark:text-gray-100"
                                >
                                    {{ this.facility || '' }}
                                </span>
                            </div>
                            <div class="h-8 w-1 rounded-full bg-primary"></div>
                        </div>
                        <button
                            type="button"
                            class="h-10 w-10 rounded-xl
                           bg-white dark:bg-slate-900
                           shadow ring-1 ring-black/5 dark:ring-white/10
                           flex items-center justify-center"
                            (click)="OpenFacilityForm()"
                            tooltipPosition="bottom"
                            pTooltip="Storer"
                        >
                            <i class="fa-solid fa-house-signal"></i>
                        </button>
                    }
                    <button
                        (click)="toggleDarkMode()"
                        class="h-10 w-10 rounded-xl
                           bg-white dark:bg-slate-900
                           shadow ring-1 ring-black/5 dark:ring-white/10
                           flex items-center justify-center"
                    >
                        <i
                            [ngClass]="{
                                pi: true,
                                'pi-sun': !layoutService.isDarkTheme(),
                                'pi-moon': layoutService.isDarkTheme(),
                            }"
                            class="text-gray-700 dark:text-gray-200"
                        ></i>
                    </button>
                    <div class="relative">
                        <button
                            class="h-10 w-10 rounded-xl
                               bg-white dark:bg-slate-900
                               shadow ring-1 ring-black/5 dark:ring-white/10
                               flex items-center justify-center"
                            pStyleClass="@next"
                            enterFromClass="hidden"
                            enterActiveClass="animate-scalein"
                            leaveToClass="hidden"
                            leaveActiveClass="animate-fadeout"
                            [hideOnOutsideClick]="true"
                        >
                            <i
                                class="pi pi-palette text-gray-700 dark:text-gray-200"
                            ></i>
                        </button>
                        <!-- <app-configurator /> -->
                    </div>
                </div>

                <button
                    class="layout-topbar-menu-button layout-topbar-action"
                    pStyleClass="@next"
                    enterFromClass="hidden"
                    enterActiveClass="animate-scalein"
                    leaveToClass="hidden"
                    leaveActiveClass="animate-fadeout"
                    [hideOnOutsideClick]="true"
                >
                    <i class="pi pi-ellipsis-v"></i>
                </button>
                <!-- <div class="layout-topbar-menu hidden lg:block">
                    <div class="layout-topbar-menu-content">
                        <button
                            type="button"
                            class="layout-topbar-action"
                            (click)="OpenLanguage()"
                        >
                            <i class="pi pi-fw pi-language"></i>
                        </button>
                    </div>
                </div> -->
                <div class="layout-topbar-menu hidden lg:block">
                    <div class="layout-topbar-menu-content">
                        <button
                            type="button"
                            (click)="openConfirmation()"
                            class="flex items-center gap-2 px-4 py-2.5 rounded-xl 
           bg-red-50 text-red-600 
           hover:bg-red-500 hover:text-white 
           transition-all duration-200 shadow-sm"
                        >
                            <i class="pi pi-sign-out"></i>
                            <span class="text-sm font-medium">Logout</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <p-dialog
            header="Confirm"
            [(visible)]="displayConfirmation"
            [style]="{ width: '350px' }"
            [modal]="true"
        >
            <div class="flex items-center justify-center">
                <i
                    class="pi pi-exclamation-triangle mr-4"
                    style="font-size: 2rem"
                >
                </i>
                <span>Are you sure you want to Logout?</span>
            </div>
            <ng-template #footer>
                <p-button
                    label="No"
                    icon="pi pi-times"
                    (click)="openConfirmation()"
                    text
                    severity="secondary"
                />
                <p-button
                    label="Yes"
                    icon="pi pi-check"
                    (click)="LogoutAction()"
                    severity="danger"
                    outlined
                    autofocus
                />
            </ng-template>
        </p-dialog>
    `,
    providers: [DialogService],
})
export class AppTopbar {
    private languageService = inject(LanguageService);
    displayConfirmation: boolean = false;
    facilityView = signal<any[]>([]);
    facility = '';
    storerLogo = signal<string | null>(null);

    items!: MenuItem[];
    private authService = inject(AuthService);
    private optionService = inject(OptionsService);
    private storerService = inject(StorerService);
    ref: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);
    private destroyRef = inject(DestroyRef);

    constructor(public layoutService: LayoutService) { }

    ngOnInit() {
        this.getOptions();
        this.loadStorerLogo();
        const encodedFacility = sessionStorage.getItem('Facility');

        this.facility = encodedFacility ? atob(encodedFacility) : '';
    }

    loadStorerLogo() {
        this.storerService.getTopbarlogo().subscribe({
            next: (response: any) => {
                if (response) {
                    this.storerLogo.set(response.Url);
                }
            }
        });
    }
    toggleDarkMode() {
        this.layoutService.layoutConfig.update((state) => ({
            ...state,
            darkTheme: !state.darkTheme,
        }));
    }
    LogoutAction() {
        this.authService.Logout();
    }

    openConfirmation() {
        this.displayConfirmation = !this.displayConfirmation;
    }
    OpenFacilityForm() {
        const headertext = this.languageService.translate('Facility');
        this.ref = this.dialogService.open(FacilityForm, {
            header: headertext,
            closable: false,
            modal: true,
            keepInViewport: true,
            width: '25rem',
        });

        this.ref.onClose.subscribe((data) => {
            if (data) window.location.reload();
        });
    }

    OpenLanguage() {
        const headertext = this.languageService.translate('Language Selection');
        this.ref = this.dialogService.open(TranslateComponent, {
            header: headertext,
            closable: false,
            modal: true,
            keepInViewport: true,
            width: '25rem',
        });

        // this.ref.onClose.subscribe((data) => {});
    }
    getOptions() {
        const subscription = this.optionService
            .getFacilityOptions()
            .pipe()
            .subscribe({
                next: (data) => {
                    if (data.length === 1) {
                        this.facilityView.set(data);
                    }
                },
            });
        this.destroyRef.onDestroy(() => subscription.unsubscribe());
    }
}
