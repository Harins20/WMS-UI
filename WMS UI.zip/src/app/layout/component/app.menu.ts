import {
    Component,
    computed,
    inject,
    linkedSignal,
    signal,
} from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { Route, RouterModule } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { AppMenuitem } from './app.menuitem';
import inboundRoutes from '../../views/inbound/inbound.routes';
import { TabService } from '../../tabs/tab.service';
import outboundRoutes from '../../views/outbound/outbound.routes';
import inventoryRoutes from '../../views/inventory/inventory.routes';
import masterRoutes from '../../views/masters/master.routes';
import { finalize } from 'rxjs';
import { MenuService, OptionMenu } from '../service/menu.service';
import businessIntelligenceRoutes from '../../views/business-intelligence/business-intelligence.routes';
import configurationRoutes from '../../views/configurations/configuration.routes';
import { AuthService } from '../../common/services';
import { LanguageService } from '../../common/services/language.service';
import adminPanelRoutes from '../../views/admin-panel/admin-panel.routes';
import appointmentsRoutes from '../../views/appointments/appointments.routes';
import waveRoutes from '../../views/wave/wave.routes';

@Component({
    selector: 'app-menu',
    standalone: true,
    imports: [CommonModule, AppMenuitem, RouterModule],
    template: `
        <div class="sidebar-logo">
            <img src="assets/img/vyapilogo.png" alt="Logo" class="logo-img" />
        </div>

        <div class="sidebar-menu">
            <ul class="layout-menu">
                <ng-container *ngFor="let item of treeMenus(); let i = index">
                    <li
                        app-menuitem
                        *ngIf="!item.separator"
                        [item]="item"
                        [index]="i"
                        [root]="true"
                    ></li>

                    <li *ngIf="item.separator" class="menu-separator"></li>
                </ng-container>
            </ul>
        </div>
    `,
})
export class AppMenu {
    private languageService = inject(LanguageService);
    private document = inject(DOCUMENT);
    model: MenuItem[] = [];
    private authService = inject(AuthService);
    private tabService = inject(TabService);
    routes = [
        ...inboundRoutes,
        ...outboundRoutes,
        ...inventoryRoutes,
        ...masterRoutes,
        ...configurationRoutes,
        ...businessIntelligenceRoutes,
        ...adminPanelRoutes,
        ...appointmentsRoutes,
        ...waveRoutes,
    ];
    Menus = signal<OptionMenu[]>([]);
    treeMenus = computed(() => {
        const mapped: { [key: number]: MenuItem } = {};
        const traderId = this.Menus().find(
            (menu) => menu.Name == 'Traders',
        )?.Id;

        const appointmentId = this.Menus().find(
            (menu) => menu.Name == 'Appointments',
        )?.Id;

        // Initialize the mapped object with all data items
        this.Menus().forEach((item) => {
            if (item.IsClickable && item.ParentId === traderId)
                mapped[item.Id] = {
                    id: item.Id.toString(),
                    label: this.languageService.translate(item.Name),
                    icon: item.IconClass,
                    command: () => this.addTraderTabsWithParams(item.Name),
                };
            else if (item.ParentId === traderId && item.IsClickable == false)
                mapped[item.Id] = {
                    id: item.Id.toString(),
                    label: this.languageService.translate(item.Name),
                    icon: item.IconClass,
                    command: () => this.addTraderTabsWithParams(item.Name),
                };
            else if (item.IsClickable && item.ParentId === appointmentId)
                mapped[item.Id] = {
                    id: item.Id.toString(),
                    label: this.languageService.translate(item.Name),
                    icon: item.IconClass,
                    command: () => this.addAppointmentTabsWithParams(item.Name),
                };
            else if (item.IsClickable)
                mapped[item.Id] = {
                    id: item.Id.toString(),
                    label: this.languageService.translate(item.Name),
                    icon: item.IconClass,
                    command: () => this.addTabs(item.Name),
                };
            else
                mapped[item.Id] = {
                    id: item.Id.toString(),
                    label: this.languageService.translate(item.Name),
                    icon: item.IconClass,
                    command: () => this.addTabs(item.Name),
                    items: [],
                };
        });
        // Build tree by assigning children to parents
        const tree: MenuItem[] = [];
        const treeBase = {
            label: '',
            icon: '',
            items: [] as MenuItem[],
        };
        const master = this.Menus().find((menu) => menu.Name == 'Masters');
        this.Menus().forEach((item) => {
            if (item.ParentId === 0) {
                treeBase.items.push(mapped[item.Id]);
            } else if (master == undefined && item.Name == 'Traders') {
                treeBase.items.push(mapped[item.Id]);
            } else {
                mapped[item.ParentId]?.items?.push(mapped[item.Id]);
            }
        });

        // Set styleClass for Masters item and Traders item
        this.Menus().forEach((item) => {
            if (item.Name === 'Masters' && mapped[item.Id]) {
                mapped[item.Id].styleClass = 'menuitem-masters';
            }
            if (item.Name === 'Traders' && mapped[item.Id]) {
                mapped[item.Id].styleClass = 'menuitem-traders';
            }
        });
        //

        const InboundMenu = treeBase.items.filter(
            (x: any) => x.label === 'Inbound',
        ) as any;

        const custominbound = [
            'POs',
            'Receipt',
            'Receipt Details',
            'Putaway Details',
        ];

        InboundMenu[0]?.items.sort((a: any, b: any) => {
            const indexA = custominbound.indexOf(a.label);
            const indexB = custominbound.indexOf(b.label);

            // Move matching items to top
            if (indexA !== -1 && indexB !== -1) {
                return indexA - indexB;
            }

            if (indexA !== -1) return -1;
            if (indexB !== -1) return 1;

            return 0;
        });
        const OutBoundMenu = treeBase.items.filter(
            (x: any) => x.label === 'Outbound',
        ) as any;

        const customOrder = [
            'Cross Dock',
            'Loads',
            'Orders',
            'Order Detail',
            'Packing Slip',
            'Return Orders',
            'Sales Order',
            'Waves',
            'Wave Filter',
        ];

        OutBoundMenu[0]?.items.sort((a: any, b: any) => {
            const indexA = customOrder.indexOf(a.label);
            const indexB = customOrder.indexOf(b.label);

            // Move matching items to top
            if (indexA !== -1 && indexB !== -1) {
                return indexA - indexB;
            }

            if (indexA !== -1) return -1;
            if (indexB !== -1) return 1;

            return 0;
        });

        // treeBase.items.push({
        //     id: '999',
        //     label: 'Wave Filter',
        //     icon: 'fa-solid fa-sliders',
        //     command: () => this.addTabs('Wave Filter'),
        // });
        tree.push(treeBase);
        return tree;
    });

    private menuService = inject(MenuService);

    getMenus() {
        this.menuService
            .getMenus()
            .pipe(finalize(() => {}))
            .subscribe({
                next: (data) => {
                    data.push({
                        Id: 21,
                        Name: 'Sales Order',
                        IsParent: false,
                        ParentId: 4,
                        IsClickable: true,
                        CreatedBy: '',
                        CreatedAt: new Date(),
                        EditedBy: '',
                        EditedAt: new Date(),
                        OrderSequence: 1,
                        IconClass: 'fa-solid fa-dolly',
                    });
                    if (!data || data.length === 0) {
                        this.authService.Logout();
                        return;
                    } else {
                        const filtered = data.filter((x) => x.Name !== 'ASNs');
                        this.Menus.set(filtered);
                        this.menuService.currentMenus.set(filtered);
                        try {
                            sessionStorage.setItem(
                                'wms_current_menus',
                                JSON.stringify(filtered),
                            );
                        } catch {}
                        // Only add the default tab if there are no tabs loaded from the session
                        if (this.tabService.tabs().length === 0) {
                            const initialTab = data.filter(
                                (x) => x.IsClickable,
                            )[0];
                            const route = this.routes.find(
                                (route: Route) =>
                                    route.data?.['name'] === initialTab.Name,
                            ) as Route;
                            this.tabService.addTab(
                                route,
                                '',
                                initialTab.Name,
                                true,
                            );
                        }
                    }
                },
                error: (error) => {
                    console.error('Error fetching menus', error);
                },
            });
    }
    addTabs(label: string) {
        const route = this.routes.find(
            (route: Route) => route.data?.['name'] === label,
        ) as Route;

        this.tabService.addTab(
            route,
            '',
            label === 'ASNs' ? 'Receipt' : label,
            false,
        );
    }
    addTraderTabsWithParams(label: string) {
        const route = this.routes.find(
            (route: Route) => route.data?.['name'] === label,
        ) as Route;
        var params = [
            { name: 'traderName', value: label },
            { name: 'traderType', value: route.data?.['type'] },
            { name: 'traderFormName', value: route.data?.['formName'] },
        ];
        this.tabService.addTabWithParams(route, '', label, params);
    }
    addAppointmentTabsWithParams(label: string) {
        const route = this.routes.find(
            (route: Route) => route.data?.['name'] === label,
        ) as Route;
        var params = [{ name: 'Name', value: label?.trim().split(/\s+/)[0] }];
        this.tabService.addTabWithParams(route, '', label, params);
    }
    ngOnInit() {
        this.getMenus();
    }
}
