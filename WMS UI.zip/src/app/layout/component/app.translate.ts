import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { LanguageService } from '../../common/services/language.service';
import { LanguageOption, AVAILABLE_LANGUAGES } from '../../languages';

@Component({
    selector: 'app-translate',
    standalone: true,
    imports: [CommonModule, ButtonModule],
    providers: [DialogService],
    template: `
        <div class="flex flex-col gap-4 min-w-[280px]">
            <p
                class="text-base font-semibold text-gray-700 dark:text-gray-200 m-0"
            >
                {{ languageService.translate('Please select the language') }}
            </p>

            <div class="flex flex-col gap-2">
                @for (lang of languages; track lang.code) {
                    <button
                        type="button"
                        class="flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-sm font-medium transition-all duration-200 cursor-pointer text-left w-full"
                        [ngClass]="
                            selectedLanguage() === lang.code
                                ? 'border-primary bg-primary/10 text-primary'
                                : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-slate-800 text-gray-700 dark:text-gray-200 hover:border-primary/40'
                        "
                        (click)="selectLanguage(lang.code)"
                    >
                        <span class="text-xl">{{ lang.flag }}</span>
                        <span class="flex-1">{{ lang.label }}</span>
                        @if (selectedLanguage() === lang.code) {
                            <i class="pi pi-check text-primary text-xs"></i>
                        }
                    </button>
                }
            </div>

            <div class="flex justify-end gap-2 pt-1">
                <p-button
                    [label]="languageService.translate('Cancel')"
                    (click)="close()"
                    severity="secondary"
                />
                <p-button
                    [label]="languageService.translate('Ok')"
                    (click)="applyLanguage()"
                />
            </div>
        </div>
    `,
})
export class TranslateComponent {
    protected languageService = inject(LanguageService);
    private ref = inject(DynamicDialogRef);

    get languages(): LanguageOption[] {
        return this.languageService.availableLanguages();
    }
    selectedLanguage = signal<string>(this.languageService.currentLanguage());

    readonly originalLanguage = 'en';

    selectLanguage(code: string): void {
        this.selectedLanguage.set(code);
    }

    resetLanguage(): void {
        this.selectedLanguage.set(this.originalLanguage);
    }

    applyLanguage(): void {
        this.languageService.setLanguage(this.selectedLanguage());
        this.ref.close(true);
    }

    close(): void {
        this.ref.close(false);
    }
}
