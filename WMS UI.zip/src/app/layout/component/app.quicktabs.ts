import { Component, effect, inject, input, signal } from '@angular/core';
import { MenuService } from '../service/menu.service';
import { AuthService } from '../../common/services/auth.service';
import { TabService } from '../../tabs/tab.service';
import { finalize } from 'rxjs';
import { Route } from '@angular/router';
import { OptionMenu } from '../service/action.service';
import inboundRoutes from '../../views/inbound/inbound.routes';
import outboundRoutes from '../../views/outbound/outbound.routes';
import inventoryRoutes from '../../views/inventory/inventory.routes';
import masterRoutes from '../../views/masters/master.routes';
import configurationRoutes from '../../views/configurations/configuration.routes';
import businessIntelligenceRoutes from '../../views/business-intelligence/business-intelligence.routes';
import adminPanelRoutes from '../../views/admin-panel/admin-panel.routes';
import waveRoutes from '../../views/wave/wave.routes';
import appointmentsRoutes from '../../views/appointments/appointments.routes';
import { ButtonModule } from 'primeng/button';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-quicktabs',
    standalone: true,
    imports: [ButtonModule, CommonModule],
    template: ` <div>
        @for (item of tree; track item.label) {
            <p-button
                [label]="item.label"
                link
                size="small"
                icon="pi pi-external-link"
                (click)="item.command()"
            />
        }
    </div>`,
})
export class AppQuickTabs {
    tree!: any[];
    access = input.required<string | undefined>();
    private menuService = inject(MenuService);
    private authService = inject(AuthService);
    private tabService = inject(TabService);
    Menus = signal<OptionMenu[]>([]);
    routes = [
        ...inboundRoutes,
        ...outboundRoutes,
        ...inventoryRoutes,
        ...masterRoutes,
        ...configurationRoutes,
        ...businessIntelligenceRoutes,
        ...adminPanelRoutes,
        ...appointmentsRoutes,
        ...waveRoutes,
    ];

    item = effect(() => {
        if (this.access()) {
            this.tree = [];
            const parent = this.Menus().find(
                (item: any) => item.Name === this.access(),
            );
            const group = this.Menus().filter(
                (item: any) =>
                    item.ParentId === parent?.ParentId &&
                    item.Name !== this.access() &&
                    item.IsParent === false,
            );

            group.forEach((item) => {
                this.tree.push({
                    id: item.Id.toString(),
                    label: item.Name,
                    command: () => this.addTabs(item.Name),
                });
            });
        }
    });

    ngOnInit() {
        this.getMenus();
    }

    getMenus() {
        this.menuService
            .getMenus()
            .pipe(finalize(() => {}))
            .subscribe({
                next: (data) => {
                    if (!data || data.length === 0) {
                        this.authService.Logout();
                        return;
                    } else {
                        this.Menus.set(data);
                    }
                },
                error: (error) => {
                    console.error('Error fetching menus', error);
                },
            });
    }
    addTabs(label: string) {
        const route = this.routes.find(
            (route: Route) => route.data?.['name'] === label,
        ) as Route;
        this.tabService.addTab(route, '', label, false);
    }
    addAppointmentTabsWithParams(label: string) {
        const route = this.routes.find(
            (route: Route) => route.data?.['name'] === label,
        ) as Route;
        var params = [{ name: 'Name', value: label?.trim().split(/\s+/)[0] }];
        this.tabService.addTabWithParams(route, '', label, params);
    }
}
