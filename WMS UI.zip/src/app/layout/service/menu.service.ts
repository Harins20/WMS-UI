import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { tap } from 'rxjs';
import { AppConfigService } from '../../../app.config.service';
import { AuthService } from '../../common/services';

export interface OptionMenu {
    Id: number;
    Name: string;
    IsParent: boolean;
    ParentId: number;
    IsClickable: boolean;
    CreatedBy: string;
    CreatedAt: Date;
    EditedBy: string;
    EditedAt: Date;
    OrderSequence: number;
    IconClass: string;
}

@Injectable({
    providedIn: 'root',
})
export class MenuService {
    private authService = inject(AuthService);
    private http = inject(HttpClient);
    private configService = inject(AppConfigService);
    // facility = signal<string | null>(sessionStorage.getItem('Facility'));

    public currentMenus = signal<OptionMenu[]>([]);

    constructor() {
        try {
            const cached = sessionStorage.getItem('wms_current_menus');
            if (cached) {
                const parsed = JSON.parse(cached);
                if (Array.isArray(parsed) && parsed.length > 0) {
                    this.currentMenus.set(parsed);
                }
            }
        } catch {}
    }

    getMenus() {
        const encodedFacility = sessionStorage.getItem('Facility');
        const facility = encodedFacility ? atob(encodedFacility) : null;
        return this.http
            .get<OptionMenu[]>(
                this.configService.AuthUrl + `users/menus?Facility=${facility}`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                tap((data) => {
                    if (data && data.length > 0) {
                        const filtered = data.filter((x) => x.Name !== 'ASNs');
                        this.currentMenus.set(filtered);
                        try {
                            sessionStorage.setItem(
                                'wms_current_menus',
                                JSON.stringify(filtered),
                            );
                        } catch {}
                    }
                }),
            );
    }
}
