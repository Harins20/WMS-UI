import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { AppConfigService } from '../../../app.config.service';
import { AuthService } from '../../common/services';

export interface OptionMenu {
    Id: number;
    Name: string;
    IsParent: boolean;
    ParentId: number;
    IsClickable: boolean;
    CreatedBy: string;
    CreatedAt: Date;
    EditedBy: string;
    EditedAt: Date;
    OrderSequence: number;
    IconClass: string;
}

@Injectable({
    providedIn: 'root',
})
export class ActionService {
    private authService = inject(AuthService);
    private http = inject(HttpClient);
    private configService = inject(AppConfigService);

    getActions() {
        return this.http.get<OptionMenu[]>(
            this.configService.AuthUrl +
                `users/actions?Facility=${this.authService.facility()}`,
            { headers: this.authService.getAuthHeaders() },
        );
    }
}
