import { isPlatformBrowser } from '@angular/common';
import {
    Injectable,
    effect,
    signal,
    computed,
    inject,
    PLATFORM_ID,
} from '@angular/core';
import { Subject } from 'rxjs';
import Chart from 'chart.js/auto';


export interface layoutConfig {
    preset?: string;
    primary?: string;
    surface?: string | undefined | null;
    darkTheme?: boolean;
    menuMode?: string;
    fontFamily?: string;
    dir?: 'ltr' | 'rtl';
}

interface LayoutState {
    staticMenuDesktopInactive?: boolean;
    overlayMenuActive?: boolean;
    configSidebarVisible?: boolean;
    staticMenuMobileActive?: boolean;
    menuHoverActive?: boolean;
}

interface MenuChangeEvent {
    key: string;
    routeEvent?: boolean;
}

@Injectable({
    providedIn: 'root',
})
export class LayoutService {
    private platformId = inject(PLATFORM_ID);

    _config: layoutConfig = {
        preset: 'Aura',
        primary: 'teal',
        surface: null,
        darkTheme: false,
        menuMode: 'static',
        fontFamily: 'Arial, sans-serif',
        dir: 'ltr',
    };

    _state: LayoutState = {
        staticMenuDesktopInactive: false,
        overlayMenuActive: false,
        configSidebarVisible: false,
        staticMenuMobileActive: false,
        menuHoverActive: false,
    };

    layoutConfig = signal<layoutConfig>(this.loadConfig());

    layoutState = signal<LayoutState>(this._state);

    private configUpdate = new Subject<layoutConfig>();

    private overlayOpen = new Subject<any>();

    private menuSource = new Subject<MenuChangeEvent>();

    private resetSource = new Subject();

    menuSource$ = this.menuSource.asObservable();

    resetSource$ = this.resetSource.asObservable();

    configUpdate$ = this.configUpdate.asObservable();

    overlayOpen$ = this.overlayOpen.asObservable();

    theme = computed(() => (this.layoutConfig()?.darkTheme ? 'light' : 'dark'));

    isSidebarActive = computed(
        () =>
            this.layoutState().overlayMenuActive ||
            this.layoutState().staticMenuMobileActive,
    );

    isDarkTheme = computed(() => this.layoutConfig().darkTheme);

    getPrimary = computed(() => this.layoutConfig().primary);

    getSurface = computed(() => this.layoutConfig().surface);

    isOverlay = computed(() => this.layoutConfig().menuMode === 'overlay');

    selectedFontFamily = computed(
        () => this.layoutConfig().fontFamily || 'Arial, sans-serif',
    );

    transitionComplete = signal<boolean>(false);

    private initialized = false;
    private loadConfig(): layoutConfig {
        if (!isPlatformBrowser(this.platformId)) return this._config;
        const raw = sessionStorage.getItem('layoutConfig');
        if (raw) {
            try {
                const saved = atob(raw);
                const loaded = { ...this._config, ...JSON.parse(saved) };
                if (loaded.dir) {
                    this.applyDirection(loaded.dir);
                }
                return loaded;
            } catch {
                return this._config;
            }
        }
        return this._config;
    }

    constructor() {
        effect(() => {
            const config = this.layoutConfig();
            if (config) {
                this.onConfigUpdate();
                this.applyGlobalFont(config.fontFamily || 'Arial, sans-serif');
                if (config.dir) {
                    this.applyDirection(config.dir);
                }
            }
        });

        effect(() => {
            const config = this.layoutConfig();

            if (!this.initialized || !config) {
                this.initialized = true;
                return;
            }

            this.handleDarkModeTransition(config);
        });
        this.toggleDarkMode(this.layoutConfig());
    }

    applyDirection(dir: 'ltr' | 'rtl'): void {
        if (!isPlatformBrowser(this.platformId)) return;
        document.documentElement.dir = dir;
    }

    // ✅ SET FONT
    setFontFamily(font: string) {
        this.layoutConfig.update((config) => ({
            ...config,
            fontFamily: font,
        }));
    }

    // ✅ UI CLICK
    selectFont(font: string) {
        this.setFontFamily(font); // IMPORTANT
    }

    private loadedFonts = new Set<string>();

    private loadGoogleFont(fontName: string) {
        if (this.loadedFonts.has(fontName)) return;

        const linkId = `font-${fontName.replace(/\s+/g, '-')}`;

        if (!document.getElementById(linkId)) {
            const link = document.createElement('link');
            link.id = linkId;
            link.rel = 'stylesheet';

            // Google Fonts URL
            link.href = `https://fonts.googleapis.com/css2?family=${fontName.replace(/ /g, '+')}:wght@300;400;500;600;700&display=swap`;

            document.head.appendChild(link);
        }

        this.loadedFonts.add(fontName);
    }

    // ✅ APPLY FONT (FIXED)
    applyGlobalFont(fontFamily: string): void {
        if (!isPlatformBrowser(this.platformId) || !fontFamily) return;

        const raw = fontFamily.trim();

        // ✅ Extract clean font name
        const fontName = raw.split(',')[0].replace(/"/g, '').trim();

        // ✅ System fonts list (CLEAN NAMES ONLY)
        const systemFonts = [
            'Arial',
            'Verdana',
            'Tahoma',
            'Georgia',
            'Courier New',
            'Trebuchet MS',
            'Times New Roman',
            'Segoe UI',
            'Helvetica',
            'Helvetica Neue',
            'Arial Black',
            'Consolas',
        ];

        // ✅ Google fonts list
        const googleFonts = [
            'Roboto',
            'Inter',
            'Noto Sans',
            'Ubuntu',
            'Lato',
            'Open Sans',
            'Source Sans Pro',
            'Outfit',
        ];

        // 🔥 Load Google fonts only
        if (googleFonts.includes(fontName)) {
            this.loadGoogleFont(fontName);
        }

        // ✅ Apply font ALWAYS
        document.documentElement.style.setProperty('--app-font-family', raw);
        document.documentElement.style.setProperty('--p-font-family', raw);
        document.documentElement.style.setProperty('font-family', raw);

        document.body.style.fontFamily = `${raw}, system-ui, sans-serif`;

        // ✅ Apply font to Chart.js default configuration
        if (typeof Chart !== 'undefined' && Chart?.defaults?.font) {
            Chart.defaults.font.family = raw;
        }
    }
    private handleDarkModeTransition(config: layoutConfig): void {
        if ((document as any).startViewTransition) {
            this.startViewTransition(config);
        } else {
            this.toggleDarkMode(config);
            this.onTransitionEnd();
        }
    }

    private startViewTransition(config: layoutConfig): void {
        const transition = (document as any).startViewTransition(() => {
            this.toggleDarkMode(config);
        });

        transition.ready
            .then(() => {
                this.onTransitionEnd();
            })
            .catch(() => {});
    }

    toggleDarkMode(config?: layoutConfig): void {
        const _config = config || this.layoutConfig();
        if (_config.darkTheme) {
            document.documentElement.classList.add('app-dark');
        } else {
            document.documentElement.classList.remove('app-dark');
        }
    }

    private onTransitionEnd() {
        this.transitionComplete.set(true);
        setTimeout(() => {
            this.transitionComplete.set(false);
        });
    }

    onMenuToggle() {
        if (this.isDesktop()) {
            this.layoutConfig.update((prev) => ({
                ...prev,
                menuMode: prev.menuMode === 'overlay' ? 'static' : 'overlay',
            }));
        } else {
            this.layoutState.update((prev) => ({
                ...prev,
                staticMenuMobileActive:
                    !this.layoutState().staticMenuMobileActive,
            }));

            if (this.layoutState().staticMenuMobileActive) {
                this.overlayOpen.next(null);
            }
        }
    }

    isDesktop() {
        return window.innerWidth > 991;
    }

    isMobile() {
        return !this.isDesktop();
    }

    onConfigUpdate() {
        this._config = { ...this.layoutConfig() };
        this.configUpdate.next(this.layoutConfig());
        this.saveConfig(this.layoutConfig());
    }

    private saveConfig(config: layoutConfig) {
        if (isPlatformBrowser(this.platformId)) {
            sessionStorage.setItem(
                'layoutConfig',
                btoa(JSON.stringify(config)),
            );
        }
    }

    onMenuStateChange(event: MenuChangeEvent) {
        this.menuSource.next(event);
    }

    reset() {
        this.resetSource.next(true);
    }
}
