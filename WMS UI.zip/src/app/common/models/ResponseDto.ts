export interface ResponseDto<T> {
    InventoryPage: any;
    totalRecords: number;
    Response: T;
    Message: string;
    Success: boolean;
}
