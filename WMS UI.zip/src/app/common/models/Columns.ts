import { TemplateRef } from '@angular/core';
import { ValidatorFn } from '@angular/forms';
import { Data } from '@angular/router';

export interface Column {
    label: string;
    field: string;
    validators?: ValidatorFn[];
    order?: number;
    type?: 'date' | 'number' | 'text' | 'select' | 'image';
    options?: { label: any; value: any }[];
    tableHidden?: boolean;
    restrictInsert?: boolean;
    restrictEdit?: boolean;
    defaultValue?: any;
    tableAlias?: string;
    dbField?: string;
    width?: string;
    customCellTemplate?: TemplateRef<any>;
    ignoreInRequest?: boolean;
    dateFormate?: 'short' | 'full';
}

export interface Columns {
    [key: string]: Column;
}

export interface selectOption {
    label: any;
    value: any;
}
