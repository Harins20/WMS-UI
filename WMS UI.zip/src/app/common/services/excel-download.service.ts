import { Injectable } from '@angular/core';
import FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

@Injectable({
    providedIn: 'root',
})
export class ExcelDownloadService {
    // downloadExcelFile(title: string, Column: any, Row: any) {
    //     if (!Row?.length) {
    //         return;
    //     }
    //     const Columns = [];
    //     if (Row?.length > 0 && Column?.length > 0) {
    //         Columns.push(Column);
    //         Row.forEach((x: any) => {
    //             const rowData = Column.map((header: any) =>
    //                 this.formatExcelValue(x[header]),
    //             ); // Map each row data according to headers
    //             Columns.push(rowData);
    //         });
    //     } else if (Row?.length > 0) {
    //         const headers = Object.keys(Row[0]);
    //         Columns.push(headers);
    //         Row.forEach((x: any) => {
    //             const rowData = headers.map((header) =>
    //                 this.formatExcelValue(x[header]),
    //             );
    //             // Map each row data according to headers
    //             Columns.push(rowData);
    //         });
    //     } else {
    //         Columns.push(Column);
    //     }
    //     this.ExcelFun(Columns, title);
    // }

    downloadExcelFile(title: string, Column: any[], Row: any[] | null) {
        const Columns: any[][] = [];

        // Template download: create headers even when there are no data rows.
        if (!Row?.length) {
            if (!Column?.length) {
                return;
            }

            Columns.push(Column);
            this.ExcelFun(Columns, title);
            return;
        }

        // Normal export with specified columns.
        if (Column?.length) {
            Columns.push(Column);

            Row.forEach((x: any) => {
                const rowData = Column.map((header: string) =>
                    this.formatExcelValue(x[header]),
                );
                Columns.push(rowData);
            });
        } else {
            // Normal export using object property names as headers.
            const headers = Object.keys(Row[0]);
            Columns.push(headers);

            Row.forEach((x: any) => {
                const rowData = headers.map((header) =>
                    this.formatExcelValue(x[header]),
                );
                Columns.push(rowData);
            });
        }

        this.ExcelFun(Columns, title);
    }

    private formatExcelValue(value: any): any {
        if (!value) {
            return value;
        }

        // If value is already a Date object
        if (value instanceof Date && !isNaN(value.getTime())) {
            return this.formatDate(value);
        }

        // If value is a date string
        if (typeof value === 'string') {
            const date = new Date(value);

            if (!isNaN(date.getTime()) && this.isDateString(value)) {
                return this.formatDate(date);
            }
        }

        return value;
    }

    private isDateString(value: string): boolean {
        // ISO / common date formats
        return (
            /^\d{4}-\d{2}-\d{2}/.test(value) ||
            /^\d{4}\/\d{2}\/\d{2}/.test(value) ||
            /^\d{2}-\d{2}-\d{4}/.test(value) ||
            /^\d{2}\/\d{2}\/\d{4}/.test(value)
        );
    }

    private formatDate(date: Date): string {
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = String(date.getFullYear()).slice(-2);

        return `${month}/${day}/${year} `;
    }

    private ExcelFun(Columns: any, title: string) {
        if (!Columns.length) return;
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.aoa_to_sheet(Columns);
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        XLSX.writeFile(wb, `${title}.xlsx`);
    }
}
