import { Injectable, signal } from '@angular/core';

@Injectable({
    providedIn: 'root',
})
export class CommonLoadingService {
    loading = signal<boolean>(false);
}
