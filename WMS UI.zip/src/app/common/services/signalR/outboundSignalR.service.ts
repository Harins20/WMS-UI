import { effect, inject, Injectable, signal } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { Observable, Subject } from 'rxjs';
import { AppConfigService } from '../../../../app.config.service';

@Injectable()
export class OutboundSignalrService {
    private hubConnection = signal<signalR.HubConnection | null>(null);
    private config = inject(AppConfigService);
    OrderUploadResponse = new Subject<any>();
    CDOUploadResponse = new Subject<any>();
    constructor() {
        effect(() => {
            this.hubConnection()?.onreconnecting((error: any) => {
                console.warn('SignalR reconnecting...', error);
            });
            this.hubConnection()?.onreconnected((connectionId: any) => {});
            this.hubConnection()?.onclose((error: any) => {
                console.error('SignalR connection closed', error);
            });
            this.hubConnection()?.on('OrderUpload', (message: string) => {
                this.OrderUploadResponse.next(message);
            });
            this.hubConnection()?.on('CDOrderUpload', (message: string) => {
                this.CDOUploadResponse.next(message);
            });
        });
    }

    startConnection(token: string, facility: string) {
        const encodedToken = sessionStorage.getItem('Token');
        const tokena = encodedToken ? atob(encodedToken) : '';
        this.hubConnection.set(
            new signalR.HubConnectionBuilder()
                .withUrl(
                    `${this.config.appConfig()?.OutUrl}Notification?facility=${facility}`,
                    {
                        accessTokenFactory: () => tokena,
                    },
                ) // SignalR hub URL
                .configureLogging(signalR.LogLevel.Information) // Optional: Enable logging
                .withAutomaticReconnect({
                    nextRetryDelayInMilliseconds: (retryContext: any) => {
                        if (retryContext.elapsedMilliseconds < 60000) {
                            return 3000;
                        } else {
                            return 3000;
                        }
                    },
                }) // Retry intervals (in ms)
                .build(),
        );
        return this.hubConnection()?.start();
    }

    stopConnection() {
        this.hubConnection()?.stop();
    }
}
