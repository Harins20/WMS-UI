import { effect, inject, Injectable, signal } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { Subject } from 'rxjs';
import { AppConfigService } from '../../../../app.config.service';

@Injectable()
export class InboundSignalrService {
    private hubConnection = signal<signalR.HubConnection | null>(null);
    private config = inject(AppConfigService);
    AsnUploadResponse = new Subject<any>();
    constructor() {
        effect(() => {
            this.hubConnection()?.onreconnecting((error: any) => {
                console.warn('SignalR reconnecting...', error);
            });
            this.hubConnection()?.onreconnected((connectionId: any) => {});
            this.hubConnection()?.onclose((error: any) => {
                console.error('SignalR connection closed', error);
            });
            this.hubConnection()?.on('AsnUpload', (message: string) => {
                this.AsnUploadResponse.next(message);
            });
        });
    }

    startConnection(token: string, facility: string) {
        const encodedToken = sessionStorage.getItem('Token');
        const tokena = encodedToken ? atob(encodedToken) : '';
        this.hubConnection.set(
            new signalR.HubConnectionBuilder()
                .withUrl(
                    `${this.config.appConfig()?.InbUrl}Notification?facility=${facility}`,
                    {
                        accessTokenFactory: () => tokena,
                    },
                ) // SignalR hub URL
                .configureLogging(signalR.LogLevel.Information) // Optional: Enable logging
                .withAutomaticReconnect({
                    nextRetryDelayInMilliseconds: (retryContext: any) => {
                        if (retryContext.elapsedMilliseconds < 60000) {
                            return 3000;
                        } else {
                            return 3000;
                        }
                    },
                }) // Retry intervals (in ms)
                .build(),
        );
        return this.hubConnection()?.start();
    }

    stopConnection() {
        this.hubConnection()?.stop();
    }
}
