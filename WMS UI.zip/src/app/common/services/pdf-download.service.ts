import { Injectable } from '@angular/core';
import jsPDF from 'jspdf';
import { autoTable } from 'jspdf-autotable';

@Injectable({
    providedIn: 'root',
})
export class PDFDownloadService {
    exportToPdf(title: string, Column: any, Row: any) {
        const rows = this.getRows(Row, Column);
        const doc = new jsPDF({
            unit: 'mm', // Unit of measurement (mm is default)
            format: 'a2', // Set A2 paper size
        });
        autoTable(doc, {
            html: '',
            body: [
                [
                    {
                        content: title,
                        colSpan: 2,
                        rowSpan: 2,
                        styles: { halign: 'center', fontStyle: 'bold' },
                    },
                ],
            ],
        });

        autoTable(doc, {
            head: [Column],
            body: rows,
            theme: 'grid',
        });
        doc.save(`${title}.pdf`);
    }

    getRows(data: any[], columns: string[]): any[] {
        const rows: any[] = [];
        data.forEach((row) => {
            const values: any[] = [];
            columns.forEach((col) => {
                values.push(row[col] || '');
            });
            rows.push(values);
        });
        return rows;
    }
}
