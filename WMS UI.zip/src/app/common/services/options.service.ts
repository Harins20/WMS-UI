import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map } from 'rxjs';
import { AppConfigService } from '../../../app.config.service';
import { Item, Packkey, Trader } from '../../views';
import { ResponseDto } from '../models';
import { AuthService } from './auth.service';

interface DropDown {
    Label: any;
    Value: any;
}

@Injectable({
    providedIn: 'root',
})
export class OptionsService {
    ownerType = 1;
    carrierType = 4;
    shipFromType = 3;
    shipToType = 8;
    supplierType = 2;

    private httpClient = inject(HttpClient);
    private authService = inject(AuthService);
    private config = inject(AppConfigService);
    getTraderOptions(type: number = 1) {
        return this.httpClient
            .get(
                this.config.appConfig()?.MasterUrl +
                    `traders/options?Type=${type}&Detail=true`,
                { headers: this.authService.getAuthHeaders() },
            )
            .pipe(
                map((value: any) =>
                    value.map((x: any) => ({
                        ...x,
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }
    getOwnerOptions() {
        return this.getTraderOptions(this.ownerType);
    }
    getCarrierOptions() {
        return this.getTraderOptions(this.carrierType);
    }
    getShipFromOptions() {
        return this.getTraderOptions(this.shipFromType);
    }
    getShipToOptions() {
        return this.getTraderOptions(this.shipToType);
    }
    getSupplierOptions() {
        return this.getTraderOptions(this.supplierType);
    }
    getFacilityOptions() {
        return this.httpClient
            .get<
                any[]
            >(this.config.appConfig()?.AuthUrl + 'users/facilities', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x) => ({
                        ...x,
                        label: x.Name,
                        value: x.Name,
                    })),
                ),
            );
    }
    getStorerOptions(storer: any) {
        return this.httpClient
            .get<
                any[]
            >(this.config.appConfig()?.AuthUrl + `users/storers?Facility=${storer}`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x) => ({
                        ...x,
                        label: x.Name,
                        Name: x.Name,
                        value: x.Name,
                    })),
                ),
            );
    }
    getPackOptions() {
        return this.httpClient
            .get<
                DropDown[]
            >(this.config.appConfig()?.MasterUrl + 'packs/options', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) => [
                    {
                        label: 'RTL-EACH',
                        value: 'RTL-EACH',
                    },
                ]),
            );
    }
    getItems() {
        return this.httpClient
            .get<
                Item[]
            >(this.config.appConfig()?.MasterUrl + 'items', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x: any) => ({
                        ...x,
                        label: x.Sku,
                        value: x.Sku,
                    })),
                ),
            );
    }
    getPackkey() {
        return this.httpClient
            .get<
                Packkey[]
            >(this.config.appConfig()?.MasterUrl + 'packs', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x: any) => ({
                        ...x,
                        label: x.PackKey,
                        value: x.PackKey,
                    })),
                ),
            );
    }
    getOwner() {
        return this.httpClient
            .get<
                Trader[]
            >(this.config.appConfig()?.MasterUrl + `traders?type=1`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x: any) => ({
                        ...x,
                        label: x.TraderKey,
                        value: x.TraderKey,
                    })),
                ),
            );
    }
    getLocation() {
        return this.httpClient
            .get<
                Location[]
            >(this.config.appConfig()?.MasterUrl + 'locations', { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x: any) => ({
                        ...x,
                        label: x.Loc,
                        value: x.Loc,
                    })),
                ),
            );
    }

    getItemOptions(TraderKey: string, ParentOnly?: boolean, Exclude?: string) {
        return this.httpClient
            .get<DropDown[]>(
                this.config.appConfig()?.MasterUrl +
                    `items/options?TraderKey=${TraderKey}`,
                {
                    headers: this.authService.getAuthHeaders(),
                    params: {
                        ParentOnly: ParentOnly ? 'true' : 'false',
                        Exclude: Exclude ? Exclude : '',
                    },
                },
            )
            .pipe(
                map((value) =>
                    value.map((x) => ({
                        ...x,
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }
    getParentItemOptions(TraderKey: string) {
        return this.getItemOptions(TraderKey, true);
    }
    getChildItemOptions(TraderKey: string, Exclude: string) {
        return this.getItemOptions(TraderKey, false, Exclude);
    }
    getItemDetailsOptions(TraderKey: string) {
        return this.httpClient
            .get<
                Item[]
            >(this.config.appConfig()?.MasterUrl + `items?TraderKey=${TraderKey}`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x: any) => ({
                        ...x,
                        label: x.Sku,
                        value: x.Sku,
                    })),
                ),
            );
    }
    getUomOptions(Packkey: string) {
        return this.httpClient
            .get<
                DropDown[]
            >(this.config.appConfig()?.MasterUrl + `Packs/Uoms?Pack=${Packkey}`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x) => ({
                        ...x,
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }
    getLocationOptions() {
        return this.httpClient
            .get<
                DropDown[]
            >(this.config.appConfig()?.MasterUrl + `locations/options`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x) => ({
                        ...x,
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }

    getCodeOptions(listName: string) {
        return this.httpClient
            .get<
                DropDown[]
            >(this.config.appConfig()?.MasterUrl + `codes/options?ListName=${listName}`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x) => ({
                        ...x,
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }
    getPickLocationOptions() {
        return this.httpClient
            .get<
                DropDown[]
            >(this.config.appConfig()?.MasterUrl + `locations/options`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((value) =>
                    value.map((x: any) => ({
                        ...x,
                        label: x.Label,
                        value: x.Value,
                    })),
                ),
            );
    }

    getQcStatusOptions() {
        return this.getCodeOptions('QCSTATUS');
    }
    getReceiptTypeOptions() {
        return this.getCodeOptions('ReceiptType');
    }
    getOrderTypeOptions() {
        return this.getCodeOptions('OrderType');
    }
    getReasonCodeOptions() {
        return this.getCodeOptions('AdjReason');
    }
    getPriorityOptions() {
        return this.getCodeOptions('PRIORITY');
    }
    getTransportationModeOptions() {
        return this.getCodeOptions('TransMode');
    }
    getZoneTypeOptions() {
        return this.getCodeOptions('ZoneType');
    }
    getUomTypeOptions() {
        return this.getCodeOptions('UOMTYPE');
    }
    getReciptStatusOptions() {
        return this.getCodeOptions('PoStatus');
    }
    getOrderStatusOptions() {
        return this.getCodeOptions('OrderStatus');
    }
    getItemTypeOptions() {
        return this.getCodeOptions('ItemType');
    }
    getOrderPriority() {
        return this.getCodeOptions('OrderPriority');
    }
    getPickLocOptions() {
        return this.getCodeOptions('PickLocation');
    }

    getColumns(columns: any, tableName: string) {
        return this.httpClient
            .get<
                any[]
            >(this.config.appConfig()?.AuthUrl + `WmsFields/columns?storerName=${this.authService.TraderKey()}&tableName=${tableName}`, { headers: this.authService.getAuthHeaders() })
            .pipe(
                map((response) => {
                    return response.map((item: any) => {
                        const matchedColumn = Object.values(columns).find(
                            (col: any) => col.field === item?.Field,
                        ) as any;
                        // If frontend column exists
                        if (matchedColumn) {
                            return {
                                ...matchedColumn,
                                label:
                                    item.IsCustomizable === 1
                                        ? item.DefaultLabel
                                        : item.DisplayName,
                            };
                        }

                        // Dynamic fallback column
                        return {
                            ...(matchedColumn || {}),

                            label:
                                item.IsCustomizable === 1
                                    ? item.DefaultLabel
                                    : item.DisplayName,

                            field: item.Field,
                            type: matchedColumn?.type || 'text',
                            defaultValue: matchedColumn?.defaultValue || '',
                            dynamic: !matchedColumn,
                        };
                    });
                }),
            );
    }
}
