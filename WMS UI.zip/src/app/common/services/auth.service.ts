import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';
import { AppConfigService } from '../../../app.config.service';

export function safeAtob(val: string | null): string | null {
    if (!val) return null;
    try {
        return atob(val);
    } catch {
        return null;
    }
}

@Injectable({
    providedIn: 'root',
})
export class AuthService {
    private router = inject(Router);
    private http = inject(HttpClient);
    private configService = inject(AppConfigService);

    facility = signal<string | null>(
        safeAtob(sessionStorage.getItem('Facility')),
    );
    TraderKey = signal<string | null>(
        safeAtob(sessionStorage.getItem('TraderKey')),
    );
    token = signal<string | null>(safeAtob(sessionStorage.getItem('Token')));
    tokenAp = signal<string | null>(
        safeAtob(sessionStorage.getItem('TokenAp')),
    );
    currentUserId: any;

    getAuthHeaders() {
        const token = safeAtob(sessionStorage.getItem('Token'));
        const facility = safeAtob(sessionStorage.getItem('Facility'));
        const TraderKey = safeAtob(sessionStorage.getItem('TraderKey'));

        const headers = new HttpHeaders()
            .set('Authorization', `Bearer ${token || ''}`)
            .set('Facility', facility || '')
            .set('TraderKey', TraderKey || '');
        return headers;
    }

    getAuthHeadersAp() {
        const tokenAp = safeAtob(sessionStorage.getItem('TokenAp'));

        const headers = new HttpHeaders().set(
            'Authorization',
            `Bearer ${tokenAp || ''}`,
        );
        return headers;
    }

    getMfaAuthHeaders() {
        const tokenencodedMfa = safeAtob(sessionStorage.getItem('TempToken'));
        const headers = new HttpHeaders().set(
            'Authorization',
            `Bearer ${tokenencodedMfa || ''}`,
        );
        return headers;
    }

    login(data: any) {
        return this.http.post(this.configService.AuthUrl + 'login', data);
    }
    loginAP(data: any) {
        return this.http.post(this.configService.AuthUrl + 'login/ap', data);
    }
    getQrCode() {
        return this.http.get(this.configService.AuthUrl + 'mfa/setup', {
            headers: this.getMfaAuthHeaders(),
        });
    }

    validateMfa(otp: string) {
        return this.http.post(
            this.configService.AuthUrl + 'mfa/validate',
            { Mfa: otp },
            { headers: this.getMfaAuthHeaders() },
        );
    }

    Logout() {
        this.router.navigate(['login']);
        sessionStorage.clear();
        location.reload();
    }

    public isAuthenticated(): boolean {
        const token = safeAtob(sessionStorage.getItem('Token'));
        return !!token;
    }

    public isMfaSetup(): boolean {
        const mfaJson = safeAtob(sessionStorage.getItem('MfaSetup'));
        if (!mfaJson) return false;
        try {
            return JSON.parse(mfaJson);
        } catch {
            return false;
        }
    }

    public isAuthenticatedForMfa(): boolean {
        const tokenencodedMfa = safeAtob(sessionStorage.getItem('TempToken'));
        const mfaEnabled = safeAtob(sessionStorage.getItem('MfaEnabled'));

        return !!(tokenencodedMfa && mfaEnabled);
    }
}
