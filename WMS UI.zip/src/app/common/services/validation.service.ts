import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
})
export class ValidationService {
    constructor() {}

    getErrorMessages(
        errors: { [key: string]: any } | null,
        name?: string,
    ): string[] {
        const temp: string[] = [];
        const Title = name || 'Field';
        if (!errors) {
            return temp;
        }

        if (errors['required']) {
            temp.push(`${Title} is required.`);
        }
        if (errors['minlength']) {
            temp.push(
                `${Title} has to be at least ${errors['minlength'].requiredLength} characters long. Current Length: ${errors['minlength'].actualLength}`,
            );
        }
        if (errors['maxlength']) {
            temp.push(
                `${Title} can't be longer than ${errors['maxlength'].requiredLength} characters. Current Length: ${errors['maxlength'].actualLength}`,
            );
        }
        if (errors['min']) {
            temp.push(`${Title} can't be less than ${errors['min'].min}`);
        }
        if (errors['max']) {
            temp.push(`${Title} can't be greater than ${errors['max'].max}`);
        }

        if (errors['pattern']) {
            temp.push(`${Title} doesn't match the required pattern.`);
            const patternResult = errors['pattern'];
        }
        return temp;
    }
}
