import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
})
export class Base64ConvertService {
    baseConverFile(file: any) {
        return new Promise((resolve, reject) => {
            const fileReader = new FileReader();
            fileReader.readAsDataURL(file);
            fileReader.onload = () => {
                resolve(fileReader.result);
            };
            fileReader.onerror = (error) => {
                resolve(null);
            };
        });
    }

    base46ConvertFileDownload(base64: string, filename: string) {
        const linkSource = base64;
        const downloadLink = document.createElement('a');
        const fileName = filename;
        downloadLink.href = linkSource;
        downloadLink.download = fileName;
        downloadLink.click();
    }
}
