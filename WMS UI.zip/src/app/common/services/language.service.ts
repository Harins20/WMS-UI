import {
    computed,
    effect,
    Injectable,
    PLATFORM_ID,
    signal,
    inject,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {
    getTranslations,
    AVAILABLE_LANGUAGES,
    LanguageOption,
} from '../../languages';
import { AuthService } from './auth.service';
import { OptionsService } from './options.service';
import { StorerService } from '../../views/admin-panel/storer/storer.service';
import { TranslateService } from '@ngx-translate/core';

function safeAtob(val: string | null): string | null {
    if (!val) return null;
    try {
        return atob(val);
    } catch {
        return val;
    }
}

const STORAGE_KEY = 'appLanguage';
const DEFAULT_LANG = 'en';

@Injectable({
    providedIn: 'root',
})
export class LanguageService {
    private platformId = inject(PLATFORM_ID);
    private authService = inject(AuthService);
    private optionService = inject(OptionsService);
    private storerService = inject(StorerService);
    private ngxTranslate = inject(TranslateService);

    /** Currently active language code (e.g. 'en', 'de', 'es') */
    readonly currentLanguage = signal<string>(this.loadSavedLanguage());

    /** All available language options for display in a selector */
    readonly availableLanguages = signal<LanguageOption[]>(AVAILABLE_LANGUAGES);

    /** Loading state for dynamic language fetching */
    readonly loadingLanguages = signal<boolean>(false);

    /** Reactive translation dictionary — updates whenever `currentLanguage` changes */
    readonly translations = computed(() =>
        getTranslations(this.currentLanguage()),
    );

    /** DOM Observer to handle dynamic modals and view rendering */
    private domObserver?: MutationObserver;

    /**
     * Monotonically increasing counter — incremented on every setLanguage() call.
     * Used to cancel pending google-reset timers if the user switches again quickly.
     */
    private translationEpoch = 0;

    /** Pending setTimeout handle for the Google Translate intermediate reset */
    private pendingGoogleResetTimer: ReturnType<typeof setTimeout> | null =
        null;

    /**
     * Re-entrancy guard — set true while we write `notranslate` attributes so the
     * MutationObserver ignores those attribute mutations and doesn't re-trigger itself.
     */
    private isApplyingProtection = false;

    constructor() {
        if (isPlatformBrowser(this.platformId)) {
            // Enforce default English ('en') on app open
            const initialLang = DEFAULT_LANG;
            this.currentLanguage.set(initialLang);
            this.clearGoogleTranslateCookie();
            this.applyGoogleTranslate(initialLang);

            // Setup dynamic DOM observer for modal popups and dynamic tab changes
            this.setupMutationObserver();

            // Persist language whenever it changes during the session
            effect(() => {
                const lang = this.currentLanguage();
                if (lang === DEFAULT_LANG) {
                    this.clearGoogleTranslateCookie();
                } else {
                    this.applyGoogleTranslate(lang);
                }
            });

            // Automatically load languages if FacilityId and StorerId are present
            if (
                sessionStorage.getItem('FacilityId') &&
                sessionStorage.getItem('StorerId')
            ) {
                this.loadLanguages();
            }
        }
    }

    /**
     * Loads languages configured for the active Facility and Storer from the header/session.
     * Uses the endpoint: GET /Storer/Language?FacilityId=${facilityId}&StorerId=${storerId}
     */
    loadLanguages(
        facilityId?: number | string | null,
        storerId?: number | string | null,
    ): void {
        if (!isPlatformBrowser(this.platformId)) return;

        let fId =
            facilityId ??
            (sessionStorage.getItem('FacilityId')
                ? Number(sessionStorage.getItem('FacilityId'))
                : null);
        let sId =
            storerId ??
            (sessionStorage.getItem('StorerId')
                ? Number(sessionStorage.getItem('StorerId'))
                : null);

        if (fId && sId) {
            this.fetchStorerLanguages(fId, sId);
            return;
        }

        const facilityName =
            safeAtob(sessionStorage.getItem('Facility')) ||
            this.authService.facility();
        const storerName =
            safeAtob(sessionStorage.getItem('TraderKey')) ||
            this.authService.TraderKey();

        if (!facilityName) {
            console.warn('[LanguageService] No facility found in header/session');
            return;
        }

        this.loadingLanguages.set(true);

        this.optionService.getFacilityOptions().subscribe({
            next: (facilities: any[]) => {
                const facMatch = facilities.find(
                    (f: any) =>
                        f.Name === facilityName ||
                        f.value === facilityName ||
                        f.label === facilityName,
                );
                if (facMatch?.Id) {
                    fId = facMatch.Id;
                    sessionStorage.setItem('FacilityId', String(facMatch.Id));
                }

                this.optionService.getStorerOptions(facilityName).subscribe({
                    next: (storers: any[]) => {
                        let storerMatch = storerName
                            ? storers.find(
                                  (s: any) =>
                                      s.Name === storerName ||
                                      s.value === storerName ||
                                      s.label === storerName,
                              )
                            : null;

                        if (!storerMatch && storers.length === 1) {
                            storerMatch = storers[0];
                        }

                        if (storerMatch?.Id) {
                            sId = storerMatch.Id;
                            sessionStorage.setItem('StorerId', String(storerMatch.Id));
                        }

                        if (fId && sId) {
                            this.fetchStorerLanguages(fId, sId);
                        } else {
                            this.loadingLanguages.set(false);
                        }
                    },
                    error: (err) => {
                        console.error('[LanguageService] Failed to resolve storer options', err);
                        this.loadingLanguages.set(false);
                    },
                });
            },
            error: (err) => {
                console.error('[LanguageService] Failed to resolve facility options', err);
                this.loadingLanguages.set(false);
            },
        });
    }

    private fetchStorerLanguages(
        facilityId: number | string,
        storerId: number | string,
    ): void {
        this.loadingLanguages.set(true);
        console.log(
            `[LanguageService] Requesting languages for FacilityId=${facilityId}, StorerId=${storerId}`,
        );

        this.storerService.getLanguages(facilityId, storerId).subscribe({
            next: (res: any) => {
                this.loadingLanguages.set(false);
                let list: any[] = [];
                if (Array.isArray(res)) {
                    list = res;
                } else if (res && Array.isArray(res.Languages)) {
                    list = res.Languages;
                } else if (res && Array.isArray(res.data)) {
                    list = res.data;
                } else if (res && typeof res.Languages === 'string') {
                    list = res.Languages.split(',').map((c: string) => ({
                        LanguageCode: c.trim(),
                    }));
                }

                if (list.length > 0) {
                    const mapped: LanguageOption[] = [];
                    for (const item of list) {
                        const code = (
                            item?.LanguageCode ||
                            item?.languageCode ||
                            item?.code ||
                            (typeof item === 'string' ? item : '')
                        ).trim();
                        if (!code) continue;

                        const matched = AVAILABLE_LANGUAGES.find(
                            (l) => l.code.toLowerCase() === code.toLowerCase(),
                        );
                        if (matched) {
                            if (
                                !mapped.some(
                                    (m) =>
                                        m.code.toLowerCase() ===
                                        matched.code.toLowerCase(),
                                )
                            ) {
                                mapped.push(matched);
                            }
                        } else {
                            const name =
                                item?.LanguageName ||
                                item?.languageName ||
                                item?.name ||
                                code;
                            if (
                                !mapped.some(
                                    (m) =>
                                        m.code.toLowerCase() ===
                                        code.toLowerCase(),
                                )
                            ) {
                                mapped.push({
                                    code: code,
                                    label: name,
                                    flag: '🌐',
                                });
                            }
                        }
                    }

                    if (mapped.length > 0) {
                        this.availableLanguages.set(mapped);

                        const current = this.currentLanguage();
                        const isCurrentSupported = mapped.some(
                            (m) => m.code === current,
                        );
                        if (!isCurrentSupported) {
                            const defaultItem = list.find(
                                (item: any) =>
                                    item?.IsDefault === true ||
                                    item?.isDefault === true,
                            );
                            const defaultCode =
                                defaultItem?.LanguageCode ||
                                defaultItem?.languageCode ||
                                defaultItem?.code;
                            const targetLang =
                                defaultCode &&
                                mapped.some((m) => m.code === defaultCode)
                                    ? defaultCode
                                    : mapped[0].code;
                            this.setLanguage(targetLang);
                        }
                        return;
                    }
                }

                this.availableLanguages.set(AVAILABLE_LANGUAGES);
            },
            error: (err) => {
                console.error(
                    '[LanguageService] Error fetching languages for storer',
                    err,
                );
                this.loadingLanguages.set(false);
                this.availableLanguages.set(AVAILABLE_LANGUAGES);
            },
        });
    }

    /** Resets language to English if available, or first available language */
    resetLanguage(): void {
        const langs = this.availableLanguages();
        const hasEn = langs.some((l) => l.code === DEFAULT_LANG);
        if (hasEn) {
            this.setLanguage(DEFAULT_LANG);
        } else if (langs.length > 0) {
            this.setLanguage(langs[0].code);
        }
    }

    /**
     * Switch the application language globally.
     * The Google Translate widget handles full-page translation of all text.
     * Business codes and technical IDs are protected via `notranslate` class.
     */
    setLanguage(lang: string): void {
        const isSupported =
            this.availableLanguages().some((l) => l.code === lang) ||
            AVAILABLE_LANGUAGES.some((l) => l.code === lang);
        const targetLang = isSupported ? lang : DEFAULT_LANG;
        const current = this.currentLanguage();

        // Advance the epoch — cancels any pending intermediate google resets
        this.translationEpoch++;
        const myEpoch = this.translationEpoch;

        if (this.pendingGoogleResetTimer !== null) {
            clearTimeout(this.pendingGoogleResetTimer);
            this.pendingGoogleResetTimer = null;
        }

        this.currentLanguage.set(targetLang);
        this.ngxTranslate.use(targetLang);

        if (targetLang === DEFAULT_LANG) {
            this.clearGoogleTranslateCookie();
            const select = document.querySelector(
                '.goog-te-combo',
            ) as HTMLSelectElement | null;
            if (select) {
                select.value = 'en';
                select.dispatchEvent(new Event('change', { bubbles: true }));
            }
        } else {
            const select = document.querySelector(
                '.goog-te-combo',
            ) as HTMLSelectElement | null;
            // If switching from one non-English language to another, briefly reset to 'en'
            // first so Google Translate reverts DOM nodes back to original English text
            // before re-applying the new language — prevents stale translated text accumulation.
            if (select && current !== DEFAULT_LANG && current !== targetLang) {
                select.value = 'en';
                select.dispatchEvent(new Event('change', { bubbles: true }));
                this.pendingGoogleResetTimer = setTimeout(() => {
                    this.pendingGoogleResetTimer = null;
                    if (this.translationEpoch !== myEpoch) return;
                    this.applyGoogleTranslate(targetLang);
                }, 150);
            } else {
                this.applyGoogleTranslate(targetLang);
            }
        }

        // Always protect technical identifiers and icons after a language switch
        this.protectTechnicalIds();
        this.protectIconsAndNavigation();
    }

    /**
     * Checks if a string represents a Technical Identifier or Business Code
     * that must NOT be translated (e.g. SKUs, ASNs, POs, Owner/Trader Keys, UDF Keys).
     *
     * Rules (any match → protect):
     *  1. UDF keys  — UDFSTR1, UDFNUM2, etc.
     *  2. Known WMS code prefixes — ASN, SKU, PO, LOC, ZONE, BOM, ITEM, ORDER, LOAD, WAVE …
     *  3. Mixed-case alphanumeric IDs with digits — ASNXXX1203, ITEM-001, 0000000355_1
     *  4. Pure ALL-CAPS alphabetic codes ≥ 4 chars — VYAPI, TRADERKEY values, Owner codes
     *     (API entity identifiers are always sent as ALL_CAPS with no spaces)
     */
    private isTechnicalIdentifier(val: string): boolean {
        if (!val) return false;
        const clean = val.trim();

        // 1. UDF Keys (e.g. UDFSTR1, UDFSTR2)
        if (/^UDF[A-Z0-9_]+$/i.test(clean)) return true;

        // 2. Known WMS code prefixes
        if (
            /^(ASN|SKU|PO|LOC|ZONE|BOM|ITEM|ORDER|LOAD|WAVE|SO|ASNXXX)[A-Z0-9_\-\.\\/#]*$/i.test(
                clean,
            )
        )
            return true;

        // 3. Alphanumeric IDs containing both letters and digits (e.g. ASNXXX1203, ITEM-001, 0000000355_1)
        if (
            /^[A-Z0-9_\-\.\\/#]{3,}$/.test(clean) &&
            /\d/.test(clean) &&
            /[A-Z]/.test(clean)
        )
            return true;

        // 4. Pure ALL-CAPS alphabetic codes ≥ 4 chars — owner names, trader keys,
        //    storer keys, and other entity identifiers sent uppercase from the API.
        //    Examples: VYAPI, TRADERKEY, STORERKEY values.
        //    Excludes 3-char or shorter strings to avoid blocking common abbreviations.
        if (/^[A-Z]{4,}$/.test(clean)) return true;

        return false;
    }

    /**
     * Automatically applies `notranslate` class and `translate="no"` attribute to DOM nodes
     * containing technical identifiers (SKUs, ASNs, POs, UDF field names, Owner codes).
     * Google Translate respects these attributes and skips those nodes.
     */
    private protectTechnicalIds(): void {
        if (!isPlatformBrowser(this.platformId)) return;

        setTimeout(() => {
            this.isApplyingProtection = true;
            try {
                const candidates = Array.from(
                    document.querySelectorAll(
                        'span, div, h1, h2, h3, h4, th, td, label, p, button, .p-dialog-title',
                    ),
                );

                candidates.forEach((el) => {
                    if (el.children.length > 0) return;
                    const text = el.textContent?.trim() || '';
                    if (this.isTechnicalIdentifier(text)) {
                        el.classList.add('notranslate');
                        el.setAttribute('translate', 'no');
                    }
                });
            } finally {
                this.isApplyingProtection = false;
            }
        }, 150);
    }

    /**
     * Protects icons, SVG elements, emoji containers, and navigation sidebar icons
     * from being translated or duplicated by Google Translate.
     */
    private protectIconsAndNavigation(): void {
        if (!isPlatformBrowser(this.platformId)) return;

        setTimeout(() => {
            this.isApplyingProtection = true;
            try {
                const icons = Array.from(
                    document.querySelectorAll(
                        '.nav-icon, .nav-icon *, .pi, i, svg, .error-badge, button i, p-fileupload, .goog-te-combo, [class*="icon"], .p-multiselect, .p-multiselect *, .p-multiselect-panel, .p-multiselect-panel *, .p-multiselect-token, .p-multiselect-token *, .notranslate, [translate="no"]',
                    ),
                );

                icons.forEach((el) => {
                    el.classList.add('notranslate');
                    el.setAttribute('translate', 'no');
                });
            } finally {
                this.isApplyingProtection = false;
            }
        }, 100);
    }

    /**
     * Set up a MutationObserver on document.body to automatically protect technical IDs
     * and icons when new elements render (e.g. modal popups, dynamic tabs, lazy routes).
     *
     * NOTE: This observer does NOT perform any translation fetches — translation is handled
     * exclusively by the Google Translate widget to avoid CORS errors and language mixing.
     */
    private setupMutationObserver(): void {
        if (!isPlatformBrowser(this.platformId) || this.domObserver) return;

        let debounceTimer: ReturnType<typeof setTimeout> | null = null;

        this.domObserver = new MutationObserver(() => {
            // Ignore mutations we caused ourselves (notranslate attribute writes)
            if (this.isApplyingProtection) return;

            if (debounceTimer) clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                debounceTimer = null;
                this.protectIconsAndNavigation();
                this.protectTechnicalIds();
            }, 300);
        });

        this.domObserver.observe(document.body, {
            childList: true,
            subtree: true,
            // Watch attribute mutations so dynamically added elements are also protected
            attributes: true,
            attributeFilter: ['class'],
        });
    }

    /**
     * Instant translation lookup for the current language.
     * Supports simple interpolation: translate('Hello {{ name }}', { name: 'World' })
     */
    translate(key: string, params?: Record<string, unknown>): string {
        const dict = this.translations();
        let value: string = dict[key] ?? key;
        if (params) {
            Object.entries(params).forEach(([k, v]) => {
                value = value.replace(
                    new RegExp(`{{\\s*${k}\\s*}}`, 'g'),
                    String(v),
                );
            });
        }
        return value;
    }

    private clearGoogleTranslateCookie(): void {
        if (!isPlatformBrowser(this.platformId)) return;
        const path = '/';
        document.cookie = `googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=${path}`;
        document.cookie = `googtrans=/auto/en; path=${path}`;
        if (location.hostname) {
            document.cookie = `googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; domain=${location.hostname}; path=${path}`;
            document.cookie = `googtrans=/auto/en; domain=${location.hostname}; path=${path}`;
        }
    }

    private applyGoogleTranslate(lang: string): void {
        if (!isPlatformBrowser(this.platformId)) return;

        this.protectTechnicalIds();
        this.protectIconsAndNavigation();
        const googleCode = lang === 'zh' ? 'zh-CN' : lang;

        // Set googtrans cookie so the full-page Google Translate widget applies
        document.cookie = `googtrans=/auto/${googleCode}; path=/`;
        if (location.hostname) {
            document.cookie = `googtrans=/auto/${googleCode}; domain=${location.hostname}; path=/`;
        }

        // Programmatically update Google Translate DOM select box if available
        const select = document.querySelector(
            '.goog-te-combo',
        ) as HTMLSelectElement | null;
        if (select) {
            if (select.value !== googleCode) {
                select.value = googleCode;
                select.dispatchEvent(new Event('change', { bubbles: true }));
            }
        } else {
            // Retry if Google Translate element is still initializing
            setTimeout(() => {
                const retrySelect = document.querySelector(
                    '.goog-te-combo',
                ) as HTMLSelectElement | null;
                if (retrySelect && retrySelect.value !== googleCode) {
                    retrySelect.value = googleCode;
                    retrySelect.dispatchEvent(
                        new Event('change', { bubbles: true }),
                    );
                }
            }, 300);
        }
    }

    private loadSavedLanguage(): string {
        return DEFAULT_LANG;
    }
}
