import { inject, Injectable } from '@angular/core';
import {
    Router,
    CanActivate,
    ActivatedRouteSnapshot,
    RouterStateSnapshot,
    Route,
} from '@angular/router';
import { AuthService } from '../services';

@Injectable({ providedIn: 'root' })
export class MfaGuard implements CanActivate {
    authService = inject(AuthService);
    constructor(public router: Router) {}

    canActivate(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot,
    ): boolean {
        if (state.url) {
            return this.checkLoggedIn(state.url);
        }
        return false;
    }

    canActivateChild(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot,
    ): boolean {
        if (state.url) {
            return this.checkLoggedIn(state.url);
        }
        return false;
    }

    canLoad(route: Route): boolean {
        if (route.path) {
            return this.checkLoggedIn(route.path);
        }
        return false;
    }

    checkLoggedIn(url: string): boolean {
        if (!this.authService.isAuthenticatedForMfa()) {
            this.router.navigate(['/login'], {
                queryParams: { returnUrl: url },
            });
            return false;
        }
        return true;
    }
}
