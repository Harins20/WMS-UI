export * from './translate.pipe';
