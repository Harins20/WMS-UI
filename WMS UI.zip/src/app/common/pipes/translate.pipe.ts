import { Pipe, PipeTransform, inject } from '@angular/core';
import { LanguageService } from '../services/language.service';

/**
 * Custom translate pipe backed by LanguageService.
 * Usage: {{ 'Some Key' | appTranslate }}
 * With params: {{ 'Hello {{ name }}' | appTranslate:{ name: 'World' } }}
 *
 * `pure: false` ensures the pipe re-evaluates when the language changes.
 */
@Pipe({
    name: 'appTranslate',
    standalone: true,
    pure: false,
})
export class AppTranslatePipe implements PipeTransform {
    private languageService = inject(LanguageService);

    transform(
        key: string | null | undefined,
        params?: Record<string, unknown>,
    ): string {
        if (!key) return '';
        return this.languageService.translate(key, params);
    }
}
