export function stringToDate(dateString: string | null | undefined) {
    if (dateString) return new Date(dateString);
    return dateString;
}
