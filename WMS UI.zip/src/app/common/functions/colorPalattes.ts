function hexToRgb(hex: string) {
    hex = hex.replace('#', '');
    if (hex.length === 8) hex = hex.substring(2); // remove alpha if present

    const num = parseInt(hex, 16);
    return {
        r: (num >> 16) & 255,
        g: (num >> 8) & 255,
        b: num & 255
    };
}

function rgbToHex(r: number, g: number, b: number) {
    return (
        '#' +
        [r, g, b]
            .map((x) => Math.max(0, Math.min(255, Math.round(x))))
            .map((x) => x.toString(16).padStart(2, '0'))
            .join('')
    );
}

// factor: -1 (dark) → 1 (light)
function adjustColor(hex: string, factor: number) {
    const { r, g, b } = hexToRgb(hex);

    return rgbToHex(r + (255 - r) * factor, g + (255 - g) * factor, b + (255 - b) * factor);
}

export function generatePalette(base: string) {
    return {
        100: adjustColor(base, 0.75),
        200: adjustColor(base, 0.6),
        300: adjustColor(base, 0.45),
        400: adjustColor(base, 0.25),
        500: base,
        600: adjustColor(base, -0.15),
        700: adjustColor(base, -0.3),
        800: adjustColor(base, -0.45),
        900: adjustColor(base, -0.6)
    };
}
