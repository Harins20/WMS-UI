export function downloadCSVFile(data: any[], filename: string) {
    if (!data.length) return;

    const headers = Object.keys(data[0]);
    const csvRows = data.map((row) =>
        headers
            .map((field) => {
                let val = row[field] ?? '';
                val = formatCsvValue(val);
                const escaped = String(val).replace(/"/g, '""');
                return `"${escaped}"`;
            })
            .join(','),
    );

    const csvContent = [headers.join(','), ...csvRows].join('\r\n');
    const BOM = '\uFEFF'; // Add BOM for Excel
    const blob = new Blob([BOM + csvContent], {
        type: 'text/csv;charset=utf-8;',
    });

    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
export function formatCsvValue(value: any): any {
    if (!value) {
        return value;
    }

    // Date object
    if (value instanceof Date && !isNaN(value.getTime())) {
        return formatDate(value);
    }

    // Date string
    if (typeof value === 'string' && isDateString(value)) {
        const date = new Date(value);

        if (!isNaN(date.getTime())) {
            return formatDate(date);
        }
    }

    return value;
}

export function isDateString(value: string): boolean {
    return (
        /^\d{4}-\d{2}-\d{2}/.test(value) ||
        /^\d{4}\/\d{2}\/\d{2}/.test(value) ||
        /^\d{2}-\d{2}-\d{4}/.test(value) ||
        /^\d{2}\/\d{2}\/\d{4}/.test(value)
    );
}

export function formatDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = String(date.getFullYear()).slice(-2);

    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    return `${month}/${day}/${year}`;
}
