// voice-recognition.service.ts
import { Injectable, NgZone, signal } from '@angular/core';
import { Observable } from 'rxjs';

declare global {
    interface Window {
        webkitSpeechRecognition: any;
    }
}

@Injectable({
    providedIn: 'root',
})
export class VoiceRecognitionService {
    recognition: any;
    transcript = signal('');

    constructor(private ngZone: NgZone) {
        if ('webkitSpeechRecognition' in window) {
            this.recognition = new window.webkitSpeechRecognition();
            this.recognition.continuous = true;
            this.recognition.interimResults = true;
            this.recognition.lang = 'en-IN'; // Set desired language

            this.recognition.onresult = (event: any) => {
                let interimTranscript = '';
                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        this.ngZone.run(() => {
                            this.transcript.set(event.results[i][0].transcript);
                        });
                    } else {
                        interimTranscript += event.results[i][0].transcript;
                    }
                }
            };

            this.recognition.onerror = (event: any) => {
                console.error('Speech recognition error:', event);
            };
        } else {
            console.warn(
                'webkitSpeechRecognition is not supported in this browser.',
            );
        }
    }

    startListening(): void {
        if (this.recognition) {
            this.recognition.start();
        }
    }

    stopListening(): void {
        if (this.recognition) {
            this.recognition.stop();
        }
    }
}
