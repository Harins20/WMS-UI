import { DateTime } from 'luxon';

export function convertExcelDate(serial: number): string {
    // Excel starts at 1900-01-01, but Excel incorrectly treats 1900 as a leap year.
    // So we subtract 2 days.
    return (
        DateTime.fromObject({ year: 1900, month: 1, day: 1 })
            .plus({
                days: serial - 2,
            })
            .toUTC()
            .toISO() ?? ''
    );
}
/**
 * Converts any date format to local date string (YYYY-MM-DD)
 * Handles Excel serial numbers, German dates (DD.MM.YYYY), and various other formats
 * Returns date only without time to avoid timezone issues
 */
export function parseDateToISO(dateValue: any): string | null {
    if (!dateValue) return null;
    
    // Handle Excel serial number
    if (typeof dateValue === 'number') {
        try {
            const excelEpoch = new Date(1900, 0, 1);
            const date = new Date(excelEpoch.getTime() + (dateValue - 2) * 24 * 60 * 60 * 1000);
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        } catch (error) {
            console.error('Error converting Excel serial date:', error);
            return null;
        }
    }
    
    // Handle string dates
    if (typeof dateValue === 'string') {
        const trimmedDate = dateValue.trim();
        
        // German format: DD.MM.YYYY or DD.MM.YY
        if (/^\d{1,2}\.\d{1,2}\.\d{2,4}$/.test(trimmedDate)) {
            const parts = trimmedDate.split('.');
            let year = parseInt(parts[2], 10);
            if (year < 100) {
                year = year < 30 ? 2000 + year : 1900 + year;
            }
            const month = parseInt(parts[1], 10);
            const day = parseInt(parts[0], 10);
            return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        }
        
        // Format: YYYY-MM-DD
        if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(trimmedDate)) {
            const parts = trimmedDate.split('-');
            return `${parts[0]}-${String(parts[1]).padStart(2, '0')}-${String(parts[2]).padStart(2, '0')}`;
        }
        
        // Format: MM/DD/YYYY or MM/DD/YY
        if (/^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(trimmedDate)) {
            const parts = trimmedDate.split('/');
            let year = parseInt(parts[2], 10);
            if (year < 100) {
                year = year < 30 ? 2000 + year : 1900 + year;
            }
            const month = parseInt(parts[0], 10);
            const day = parseInt(parts[1], 10);
            return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        }
        
        // Try parsing as local date
        const jsDate = new Date(trimmedDate);
        if (!isNaN(jsDate.getTime())) {
            const year = jsDate.getFullYear();
            const month = String(jsDate.getMonth() + 1).padStart(2, '0');
            const day = String(jsDate.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }
    }
    
    // Handle Date object
    if (dateValue instanceof Date) {
        if (!isNaN(dateValue.getTime())) {
            const year = dateValue.getFullYear();
            const month = String(dateValue.getMonth() + 1).padStart(2, '0');
            const day = String(dateValue.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }
    }
    
    console.warn('Unable to parse date:', dateValue);
    return null;
}

/**
 * Gets current date in ISO format
 */
export function getCurrentDateISO(): string {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

/**
 * Formats a date value to a specific format
 */
export function formatDate(dateValue: any, format: string = 'dd.MM.yyyy'): string {
    const dateStr = parseDateToISO(dateValue);
    if (!dateStr) return '';
    
    const [year, month, day] = dateStr.split('-');
    const date = DateTime.fromObject({ year: parseInt(year), month: parseInt(month), day: parseInt(day) });
    
    if (!date.isValid) return '';
    
    return date.toFormat(format);
}