export function upperCaseObject(obj: any): any {
    if (!obj || typeof obj !== 'object') {
        return obj;
    }

    return Object.fromEntries(
        Object.entries(obj).map(([key, value]) => [
            key.toUpperCase(),
            value,
        ]),
    );
}

export function lowerCaseObject(obj: any): any {
    if (!obj || typeof obj !== 'object') {
        return obj;
    }

    return Object.fromEntries(
        Object.entries(obj).map(([key, value]) => [
            key.toLowerCase(),
            value,
        ]),
    );
}

export function upperCaseArray(data: any[]): any[] {
    return (data || []).map((item) => upperCaseObject(item));
}

export function lowerCaseArray(data: any[]): any[] {
    return (data || []).map((item) => lowerCaseObject(item));
}

export function lowercasecolumn<T>(data: T | T[]): T | T[] {
    if (Array.isArray(data)) {
        return data.map((obj) =>
            Object.fromEntries(
                Object.entries(obj as object).map(([key, value]) => [
                    key.toLowerCase(),
                    value,
                ]),
            ),
        ) as T[];
    }

    return Object.fromEntries(
        Object.entries(data as object).map(([key, value]) => [
            key.toLowerCase(),
            value,
        ]),
    ) as T;
}

export function uppercasecolumn<T>(data: T | T[]): T | T[] {
    if (Array.isArray(data)) {
        return data.map((obj) =>
            Object.fromEntries(
                Object.entries(obj as object).map(([key, value]) => [
                    key.toUpperCase(),
                    value,
                ]),
            ),
        ) as T[];
    }

    return Object.fromEntries(
        Object.entries(data as object).map(([key, value]) => [
            key.toUpperCase(),
            value,
        ]),
    ) as T;
}
