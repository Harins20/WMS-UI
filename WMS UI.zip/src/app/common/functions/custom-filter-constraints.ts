import { FilterService } from 'primeng/api';

/**
 * Parses a date value from various formats (Date object, ISO string, timestamp)
 */
export function parseFilterDate(val: any): Date | null {
    if (val === null || val === undefined || val === '') {
        return null;
    }
    if (val instanceof Date) {
        return isNaN(val.getTime()) ? null : val;
    }
    if (typeof val === 'string' || typeof val === 'number') {
        const d = new Date(val);
        return isNaN(d.getTime()) ? null : d;
    }
    return null;
}

/**
 * Returns midnight timestamp for local calendar day comparison
 */
export function toMidnight(d: Date): number {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

/**
 * Registers safe date filter constraints for PrimeNG FilterService
 * that handle string dates from API responses and avoid undefined filterConstraint crashes.
 */
export function registerCustomFilterConstraints(filterService: FilterService): void {
    if (!filterService) return;

    const dateIsFilter = (value: any, filter: any): boolean => {
        if (filter === undefined || filter === null || filter === '') return true;
        const filterDate = parseFilterDate(filter);
        if (!filterDate) return true;
        const cellDate = parseFilterDate(value);
        if (!cellDate) return false;
        return toMidnight(cellDate) === toMidnight(filterDate);
    };

    const dateIsNotFilter = (value: any, filter: any): boolean => {
        if (filter === undefined || filter === null || filter === '') return true;
        const filterDate = parseFilterDate(filter);
        if (!filterDate) return true;
        const cellDate = parseFilterDate(value);
        if (!cellDate) return false;
        return toMidnight(cellDate) !== toMidnight(filterDate);
    };

    const dateBeforeFilter = (value: any, filter: any): boolean => {
        if (filter === undefined || filter === null || filter === '') return true;
        const filterDate = parseFilterDate(filter);
        if (!filterDate) return true;
        const cellDate = parseFilterDate(value);
        if (!cellDate) return false;
        return toMidnight(cellDate) < toMidnight(filterDate);
    };

    const dateAfterFilter = (value: any, filter: any): boolean => {
        if (filter === undefined || filter === null || filter === '') return true;
        const filterDate = parseFilterDate(filter);
        if (!filterDate) return true;
        const cellDate = parseFilterDate(value);
        if (!cellDate) return false;
        return toMidnight(cellDate) > toMidnight(filterDate);
    };

    // Standard PrimeNG date filter modes
    filterService.register('dateIs', dateIsFilter);
    filterService.register('dateIsNot', dateIsNotFilter);
    filterService.register('dateBefore', dateBeforeFilter);
    filterService.register('dateAfter', dateAfterFilter);

    // Custom / alias modes used across components
    filterService.register('dateTimeIs', dateIsFilter);
    filterService.register('dateTimeIsNot', dateIsNotFilter);
    filterService.register('dateTimeBefore', dateBeforeFilter);
    filterService.register('dateTimeAfter', dateAfterFilter);
}
