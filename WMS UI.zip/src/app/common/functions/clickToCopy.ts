import { MessageService } from 'primeng/api';

export function copyToClipboardText(
    text: string,
    messageService?: MessageService,
): void {
    // if (navigator.clipboard && navigator.clipboard.writeText) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();

    const successful = document.execCommand('copy');
    document.body.removeChild(textarea);
    if (successful && messageService) {
        messageService.add({
            severity: 'success',
            summary: 'Copied!',
            detail: 'Text copied to clipboard.',
        });
    } else if (!successful && messageService) {
        messageService.add({
            severity: 'error',
            summary: 'Copied!',
            detail: 'Failed to copy text. Please try again.',
        });
    }
    // navigator.clipboard
    //     .writeText(text)
    //     .then(() => {
    //         if (messageService) {
    //             messageService.add({
    //                 severity: 'success',
    //                 summary: 'Copied!',
    //                 detail: 'Text copied to clipboard.',
    //             });
    //         }
    //     })
    //     .catch((err) => {
    //         console.error('Failed to copy text:', err);
    //     });
    // }
}
