import {
    Component,
    computed,
    effect,
    inject,
    Injectable,
    Input,
    signal,
} from '@angular/core';
import { OrderLineService } from '../../views/outbound/orders/order-tabs/order-lines';
@Injectable({
    providedIn: 'root',
})
export class AppReminingTime {
    coolingPeriodActive = signal(false);
    coolerTimer = signal<number | any>(0);
    coolingPeriodEndISO = signal<string>('');
    coolingPeriodEndTime = signal<Date | null>(null);
    private coolingPeriodInterval: any;
    cooldowntimer = signal<string>('');
    private pickDetailsService = inject(OrderLineService);

    init() {
        this.pickDetailsService.orderHeader;
        this.pickDetailsService.getCoolerTime();
    }
    startCoolingPeriod(newLineCreated: boolean = false) {
        if (this.coolingPeriodActive() && !newLineCreated) {
            return;
        }
        const coolingMinutes = this.coolerTimer();
        const endTime1 = new Date();
        const e1 = endTime1.getTime();
        const endTime = new Date(this.coolingPeriodEndISO() + 'z');
        const e = endTime.getTime();
        const setter = e + coolingMinutes * 60 * 1000 - e1;
        endTime.setTime(e + coolingMinutes * 60 * 1000);
        this.coolingPeriodEndTime.set(endTime);
        if (!this.coolingPeriodInterval && setter >= 0) {
            this.coolingPeriodActive.set(true);
            this.coolingPeriodInterval = setInterval(
                () => this.updateCoolingTime(),
                1000,
            );
        }
    }

    updateCoolingTime() {
        const now = new Date();
        const endTime = this.coolingPeriodEndTime();
        if (!endTime) {
            this.clearCoolingPeriod();
            return;
        }

        const diffMs = endTime.getTime() - now.getTime();

        if (diffMs <= 0) {
            this.clearCoolingPeriod();
            return;
        }
        const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
        const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        const diffSecs = Math.floor((diffMs % 60000) / 1000);
        this.cooldowntimer.set(`${diffHrs}h ${diffMins}m ${diffSecs}s`);
    }

    clearCoolingPeriod() {
        clearInterval(this.coolingPeriodInterval);
        this.coolingPeriodInterval = null;
        this.coolingPeriodActive.set(false);
        this.coolingPeriodEndTime.set(null);
        this.cooldowntimer.set('');
    }
}
