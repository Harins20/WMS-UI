import { TableLazyLoadEvent } from 'primeng/table';
import { Columns } from '../models';

export function filterQuery(
    event: TableLazyLoadEvent,
    globalFilterColumns: string[],
    ColumnMapping: Columns,
    alias: string,
) {
    let filter: string | null = null;
    let HoldTypeFilter: string | null = null;

    /**
     * Get table alias prefix
     */
    const getPrefix = (column: string): string => {
        const columnDef = ColumnMapping[column as keyof typeof ColumnMapping];

        return columnDef?.tableAlias ? columnDef.tableAlias : '';
    };

    /**
     * Get database field
     */
    const getDbField = (column: string): string => {
        const columnDef = ColumnMapping[column as keyof typeof ColumnMapping];

        return columnDef?.dbField || column;
    };

    /**
     * Add filter condition
     */
    const addFilter = (conditions: string[], operator = 'and') => {
        if (!conditions.length) {
            return;
        }

        const condition = `(${conditions.join(` ${operator} `)})`;

        filter = filter ? `${filter} and ${condition}` : condition;
    };

    // ============================================================
    // GLOBAL FILTER
    // ============================================================

    if (
        event.globalFilter !== null &&
        event.globalFilter !== undefined &&
        String(event.globalFilter).trim() !== ''
    ) {
        const globalValue = String(event.globalFilter).trim();

        const globalFilters: string[] = [];

        globalFilterColumns.forEach((column) => {
            const columnDef =
                ColumnMapping[column as keyof typeof ColumnMapping];

            if (!columnDef) {
                return;
            }

            const prefix = getPrefix(column);
            const dbField = getDbField(column);

            globalFilters.push(`${prefix}${dbField} like '%${globalValue}%'`);
        });

        addFilter(globalFilters, 'or');
    }

    // ============================================================
    // COLUMN FILTERS
    // ============================================================

    const filters: any = event.filters;

    if (filters) {
        Object.keys(filters).forEach((key) => {
            // Global filter already handled above
            if (key === 'global') {
                return;
            }

            const filterMeta = filters[key];

            if (!filterMeta) {
                return;
            }

            const columnDef = ColumnMapping[key as keyof typeof ColumnMapping];

            // ====================================================
            // HOLD TYPE
            // ====================================================

            if (key === 'HoldType') {
                const values = filterMeta
                    .map((item: any) => item?.value)
                    .filter(
                        (value: any) =>
                            value !== null &&
                            value !== undefined &&
                            value !== '',
                    );

                if (values.length > 0) {
                    const selectedValues = values.flat().join(',');

                    HoldTypeFilter = selectedValues;
                }

                return;
            }

            // ====================================================
            // SELECT FILTER
            // ====================================================

            if (columnDef?.type === 'select') {
                const selectedValues = filterMeta.flatMap((item: any) => {
                    if (Array.isArray(item?.value)) {
                        return item.value;
                    }

                    if (
                        item?.value !== null &&
                        item?.value !== undefined &&
                        item?.value !== ''
                    ) {
                        return [item.value];
                    }

                    return [];
                });

                if (selectedValues.length > 0) {
                    const prefix = getPrefix(key);
                    const dbField = getDbField(key);

                    const values = selectedValues.join(',');

                    addFilter([
                        `${prefix}${dbField} in (SELECT value FROM STRING_SPLIT('${values}', ','))`,
                    ]);
                }

                return;
            }

            // ====================================================
            // NUMBER FILTER
            // ====================================================

            if (columnDef?.type === 'number') {
                const numberFilters: string[] = [];
                let operator = 'and';

                filterMeta.forEach((item: any) => {
                    const value = item?.value;

                    if (value === null || value === undefined || value === '') {
                        return;
                    }

                    const prefix = getPrefix(key);
                    const dbField = getDbField(key);

                    switch (item.matchMode) {
                        case 'gt':
                            numberFilters.push(
                                `${prefix}${dbField} > ${value}`,
                            );
                            break;

                        case 'lt':
                            numberFilters.push(
                                `${prefix}${dbField} < ${value}`,
                            );
                            break;

                        case 'lte':
                            numberFilters.push(
                                `${prefix}${dbField} <= ${value}`,
                            );
                            break;

                        case 'gte':
                            numberFilters.push(
                                `${prefix}${dbField} >= ${value}`,
                            );
                            break;

                        case 'equals':
                            numberFilters.push(
                                `${prefix}${dbField} = ${value}`,
                            );
                            break;

                        case 'notEquals':
                            numberFilters.push(
                                `${prefix}${dbField} <> ${value}`,
                            );
                            break;
                    }

                    if (item.operator) {
                        operator = item.operator.toLowerCase();
                    }
                });

                addFilter(numberFilters, operator);

                return;
            }

            // ====================================================
            // DATE FILTER
            // ====================================================

            if (columnDef?.type === 'date') {
                const dateFilters: string[] = [];
                let operator = 'and';

                filterMeta.forEach((item: any) => {
                    const value = item?.value;

                    if (value === null || value === undefined || value === '') {
                        return;
                    }

                    const prefix = getPrefix(key);
                    const dbField = getDbField(key);
                    console.log(item.matchMode);

                    const date = new Date(value);

                    if (isNaN(date.getTime())) {
                        return;
                    }

                    /**
                     * SQL date format:
                     * YYYY-MM-DD
                     */
                    // const year = date.getUTCFullYear();

                    // const month = String(date.getUTCMonth() + 1).padStart(
                    //     2,
                    //     '0',
                    // );

                    // const day = String(date.getUTCDate()).padStart(2, '0');

                    const year = date.getFullYear();

                    const month = String(date.getMonth() + 1).padStart(2, '0');

                    const day = String(date.getDate()).padStart(2, '0');

                    const queryDate = `${year}-${month}-${day}`;

                    switch (item.matchMode) {
                        case 'dateIs':
                            dateFilters.push(
                                `CAST(${prefix}${dbField} AS DATE) = '${queryDate}'`,
                            );
                            break;

                        case 'dateIsNot':
                            dateFilters.push(
                                `CAST(${prefix}${dbField} AS DATE) <> '${queryDate}'`,
                            );
                            break;

                        case 'dateBefore':
                            dateFilters.push(
                                `CAST(${prefix}${dbField} AS DATE) < '${queryDate}'`,
                            );
                            break;

                        case 'dateAfter':
                            dateFilters.push(
                                `CAST(${prefix}${dbField} AS DATE) > '${queryDate}'`,
                            );
                            break;

                        case 'dateTimeAfter':
                            dateFilters.push(
                                `CAST(${prefix}${dbField} AS DATE) > '${queryDate}'`,
                            );
                            break;

                        case 'dateTimeBefore':
                            dateFilters.push(
                                `CAST(${prefix}${dbField} AS DATE) < '${queryDate}'`,
                            );
                            break;
                        case 'dateTimeIs':
                            dateFilters.push(
                                `CAST(${prefix}${dbField} AS DATE) = '${queryDate}'`,
                            );
                            break;
                        case 'dateTimeIsNot':
                            dateFilters.push(
                                `CAST(${prefix}${dbField} AS DATE) <> '${queryDate}'`,
                            );
                            break;

                        default:
                            console.warn(
                                `Unsupported date matchMode: ${item.matchMode}`,
                            );
                            break;
                    }

                    if (item.operator) {
                        operator = item.operator.toLowerCase();
                    }
                });

                addFilter(dateFilters, operator);

                return;
            }

            // ====================================================
            // TEXT FILTER
            // ====================================================

            const textFilters: string[] = [];
            let operator = 'and';

            filterMeta.forEach((item: any) => {
                const value = item?.value;

                if (value === null || value === undefined || value === '') {
                    return;
                }

                const prefix = getPrefix(key);
                const dbField = getDbField(key);

                const stringValue = String(value);

                switch (item.matchMode) {
                    case 'startsWith':
                        textFilters.push(
                            `${prefix}${dbField} like '${stringValue}%'`,
                        );
                        break;

                    case 'contains':
                        textFilters.push(
                            `${prefix}${dbField} like '%${stringValue}%'`,
                        );
                        break;

                    case 'notContains':
                        textFilters.push(
                            `${prefix}${dbField} not like '%${stringValue}%'`,
                        );
                        break;

                    case 'endsWith':
                        textFilters.push(
                            `${prefix}${dbField} like '%${stringValue}'`,
                        );
                        break;

                    case 'equals':
                        textFilters.push(
                            `${prefix}${dbField} = '${stringValue}'`,
                        );
                        break;

                    case 'notEquals':
                        textFilters.push(
                            `${prefix}${dbField} <> '${stringValue}'`,
                        );
                        break;

                    default:
                        console.warn(
                            `Unsupported text matchMode: ${item.matchMode}`,
                        );
                        break;
                }

                if (item.operator) {
                    operator = item.operator.toLowerCase();
                }
            });

            addFilter(textFilters, operator);
        });
    }

    // ============================================================
    // SORTING
    // ============================================================

    const multiSort = event.multiSortMeta;

    let orderBy: string | null = null;

    if (multiSort && multiSort.length > 0) {
        const order: string[] = [];

        multiSort.forEach((item: any) => {
            if (!item?.field) {
                return;
            }

            const sortDirection = item.order === -1 ? 'desc' : 'asc';

            // rowId → SerialKey
            if (item.field === 'rowId') {
                order.push(`${alias}SerialKey ${sortDirection}`);

                return;
            }

            const columnDef =
                ColumnMapping[item.field as keyof typeof ColumnMapping];

            if (!columnDef) {
                return;
            }

            const prefix = columnDef.tableAlias || '';
            const dbField = columnDef.dbField || item.field;

            order.push(`${prefix}${dbField} ${sortDirection}`);
        });

        if (order.length > 0) {
            orderBy = order.join(',');
        }
    }

    // ============================================================
    // SINGLE COLUMN SORT
    // ============================================================
    else if (
        event.sortField &&
        typeof event.sortField === 'string' &&
        event.sortOrder !== undefined &&
        event.sortOrder !== null
    ) {
        const sortField = event.sortField;

        const sortDirection = event.sortOrder === -1 ? 'desc' : 'asc';

        // rowId → SerialKey
        if (sortField === 'rowId') {
            orderBy = `${alias}SerialKey ${sortDirection}`;
        } else {
            const columnDef =
                ColumnMapping[sortField as keyof typeof ColumnMapping];

            if (columnDef) {
                const prefix = columnDef.tableAlias || '';

                const dbField = columnDef.dbField || sortField;

                orderBy = `${prefix}${dbField} ${sortDirection}`;
            }
        }
    }

    // ============================================================
    // DEBUG
    // ============================================================

    // console.log('================================');
    // console.log('FILTER:', filter);
    // console.log('ORDER BY:', orderBy);
    // console.log('HOLD TYPE:', HoldTypeFilter);
    // console.log('================================');

    return {
        filter,
        orderBy,
        HoldTypeFilter,
    };
}
// import { TableLazyLoadEvent } from 'primeng/table';
// import { Columns } from '../models';

// export function filterQuery(
//     event: TableLazyLoadEvent,
//     globalFilterColumns: string[],
//     ColumnMapping: Columns,
//     alias: string,
// ) {
//     let filter: string | null = null;

//     // Handle global filter
//     if (event.globalFilter) {
//         let gfilters: string[] = [];
//         globalFilterColumns.forEach((column) => {
//             const columnDef =
//                 ColumnMapping[column as keyof typeof ColumnMapping];
//             const tableAlias = columnDef?.tableAlias || '';
//             const prefix = tableAlias ? `${tableAlias}` : '';
//             gfilters.push(`${prefix}${column} like '%${event.globalFilter}%'`);
//         });
//         filter = filter
//             ? filter + ' and (' + gfilters.join(' or ') + ')'
//             : '(' + gfilters.join(' or ') + ')';
//     }

//     const filters: any = event.filters;
//     let HoldTypeFilter: string | null = null;

//     if (filters) {
//         const filterKeys = Object.keys(filters);
//         filterKeys.forEach((key) => {
//             if (key === 'global') {
//                 return;
//             }
//             let ffilters: string[] = [];
//             let operator = 'and';

//             const columnDef = ColumnMapping[key as keyof typeof ColumnMapping];

//             if (key === 'HoldType') {
//                 if (filters[key][0].value && filters[key][0].value.length > 0) {
//                     const selectedValues = filters[key][0].value.join(',');
//                     HoldTypeFilter = selectedValues;
//                 }
//             } else if (columnDef?.type && columnDef.type === 'select') {
//                 if (filters[key][0].value && filters[key][0].value.length > 0) {
//                     const tableAlias = columnDef?.tableAlias || '';
//                     const prefix = tableAlias ? `${tableAlias}` : '';
//                     const selectedValues = filters[key][0].value.join(',');
//                     ffilters.push(
//                         `${prefix}${key} in( SELECT value FROM STRING_SPLIT('${selectedValues}',','))`,
//                     );
//                 }
//             } else if (columnDef?.type && columnDef.type === 'number') {
//                 filters[key].forEach((value: any) => {
//                     if (value.value !== null && value.value !== undefined) {
//                         const tableAlias = columnDef?.tableAlias || '';
//                         const prefix = tableAlias ? `${tableAlias}` : '';
//                         if (value.matchMode === 'gt') {
//                             ffilters.push(`${prefix}${key} > ${value.value}`);
//                         }
//                         if (value.matchMode === 'lt') {
//                             ffilters.push(`${prefix}${key} < ${value.value}`);
//                         }
//                         if (value.matchMode === 'lte') {
//                             ffilters.push(`${prefix}${key} <= ${value.value}`);
//                         }
//                         if (value.matchMode === 'gte') {
//                             ffilters.push(`${prefix}${key} >= ${value.value}`);
//                         }
//                         if (value.matchMode === 'equals') {
//                             ffilters.push(`${prefix}${key} = ${value.value}`);
//                         }
//                         if (value.matchMode === 'notEquals') {
//                             ffilters.push(`${prefix}${key} <> ${value.value}`);
//                         }
//                         operator = value.operator;
//                     }
//                 });
//             } else if (columnDef?.type && columnDef.type === 'date') {
//                 filters[key].forEach((value: any) => {
//                     if (value.value !== null && value.value !== undefined) {
//                         const tableAlias = columnDef?.tableAlias || '';
//                         const prefix = tableAlias ? `${tableAlias}` : '';
//                         const date = new Date(value.value);
//                         const year = date.getUTCFullYear();
//                         const day = String(date.getUTCDate()).padStart(2, '0');
//                         const month = String(date.getUTCMonth() + 1).padStart(
//                             2,
//                             '0',
//                         );
//                         const queryDate = `${year}-${day}-${month}`;

//                         if (value.matchMode === 'dateIs') {
//                             ffilters.push(
//                                 `CAST(${prefix}${key} AS DATE) = '${queryDate}'`,
//                             );
//                         }
//                         if (value.matchMode === '"dateTimeAfter"') {
//                             ffilters.push(
//                                 `CAST(${prefix}${key} AS DATE) = '${queryDate}'`,
//                             );
//                         }
//                         if (value.matchMode === 'dateIsNot') {
//                             ffilters.push(
//                                 `CAST(${prefix}${key} AS DATE) <> '${queryDate}'`,
//                             );
//                         }
//                         if (value.matchMode === 'dateBefore') {
//                             ffilters.push(
//                                 `CAST(${prefix}${key} AS DATE) < '${queryDate}'`,
//                             );
//                         }
//                         if (value.matchMode === 'dateAfter') {
//                             ffilters.push(
//                                 `CAST(${prefix}${key} AS DATE) > '${queryDate}'`,
//                             );
//                         }

//                         operator = value.operator;
//                     }
//                 });
//             } else {
//                 filters[key].forEach((value: any) => {
//                     if (value.value) {
//                         const tableAlias = columnDef?.tableAlias || '';
//                         const prefix = tableAlias ? `${tableAlias}` : '';
//                         if (value.matchMode === 'startsWith') {
//                             ffilters.push(
//                                 `${prefix}${key} like '${value.value}%'`,
//                             );
//                         }
//                         if (value.matchMode === 'contains') {
//                             ffilters.push(
//                                 `${prefix}${key} like '%${value.value}%'`,
//                             );
//                         }
//                         if (value.matchMode === 'notContains') {
//                             ffilters.push(
//                                 `${prefix}${key} not like '%${value.value}%'`,
//                             );
//                         }
//                         if (value.matchMode === 'endsWith') {
//                             ffilters.push(
//                                 `${prefix}${key} like '%${value.value}'`,
//                             );
//                         }
//                         if (value.matchMode === 'equals') {
//                             ffilters.push(`${prefix}${key} = '${value.value}'`);
//                         }
//                         if (value.matchMode === 'notEquals') {
//                             ffilters.push(
//                                 `${prefix}${key} <> '${value.value}'`,
//                             );
//                         }
//                         operator = value.operator;
//                     }
//                 });
//             }
//             console.log(ffilters);

//             if (ffilters.length > 0) {
//                 console.log(filter);

//                 filter = filter
//                     ? filter + ' and (' + ffilters.join(` ${operator} `) + ')'
//                     : '(' + ffilters.join(` ${operator} `) + ')';
//             }
//         });
//     }

//     // FIXED: Handle sorting - Properly handle string | string[] type
//     const multiSort = event.multiSortMeta;
//     let orderBy: string | null = null;

//     if (multiSort && multiSort.length > 0) {
//         let order: string[] = [];
//         multiSort.forEach((x: any) => {
//             if (x.field === 'rowId') {
//                 order.push(
//                     `${alias}SerialKey ${x.order === -1 ? 'desc' : 'asc'}`,
//                 );
//             } else if (x.field && typeof x.field === 'string') {
//                 const columnDef =
//                     ColumnMapping[x.field as keyof typeof ColumnMapping];
//                 if (columnDef) {
//                     const tableAlias = columnDef.tableAlias || '';
//                     const prefix = tableAlias ? `${tableAlias}` : '';
//                     const dbField = columnDef.dbField || x.field;
//                     order.push(
//                         `${prefix}${dbField} ${x.order === -1 ? 'desc' : 'asc'}`,
//                     );
//                 }
//             }
//         });
//         orderBy = order.join(',');
//     }
//     // Handle single column sort - FIX: Check if sortField is string, not array
//     else if (
//         event.sortField &&
//         typeof event.sortField === 'string' &&
//         event.sortOrder !== undefined
//     ) {
//         const sortField = event.sortField;

//         if (sortField === 'rowId') {
//             orderBy = `${alias}SerialKey ${event.sortOrder === -1 ? 'desc' : 'asc'}`;
//         } else {
//             const columnDef =
//                 ColumnMapping[sortField as keyof typeof ColumnMapping];
//             if (columnDef) {
//                 const tableAlias = columnDef.tableAlias || '';
//                 const prefix = tableAlias ? `${tableAlias}` : '';
//                 const dbField = columnDef.dbField || sortField;
//                 orderBy = `${prefix}${dbField} ${event.sortOrder === -1 ? 'desc' : 'asc'}`;
//             }
//         }
//     }
//     console.log(filter, orderBy, HoldTypeFilter);

//     return { filter, orderBy, HoldTypeFilter };
// }
