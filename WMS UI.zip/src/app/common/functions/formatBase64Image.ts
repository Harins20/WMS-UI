/**
 * Formats a raw or prefixed Base64 string, byte array, or URL into a valid browser image source URL.
 * Automatically detects and prepends the correct MIME data URI scheme (PNG, JPEG, GIF, WEBP, SVG, ICO)
 * if missing, and strips whitespace or linebreaks.
 */
export function formatBase64Image(value: any): string | null {
    if (!value) {
        return null;
    }

    // Handle array of numbers / byte array / Uint8Array
    if (Array.isArray(value) || value instanceof Uint8Array) {
        try {
            const bytes = new Uint8Array(value);
            let binary = '';
            const len = bytes.byteLength;
            for (let i = 0; i < len; i++) {
                binary += String.fromCharCode(bytes[i]);
            }
            const b64 = btoa(binary);
            return formatBase64Image(b64);
        } catch {
            return null;
        }
    }

    if (typeof value !== 'string') {
        return null;
    }

    const trimmed = value.trim();
    if (!trimmed || trimmed === 'null' || trimmed === 'undefined') {
        return null;
    }

    // Already a valid data URI
    if (trimmed.startsWith('data:image/')) {
        return trimmed;
    }

    // External or local URL / asset path
    if (
        trimmed.startsWith('http://') ||
        trimmed.startsWith('https://') ||
        trimmed.startsWith('blob:') ||
        trimmed.startsWith('assets/')
    ) {
        return trimmed;
    }

    // Clean whitespace and line breaks from serialized base64 string
    const cleanBase64 = trimmed.replace(/\s+/g, '');

    if (cleanBase64.startsWith('data:')) {
        return cleanBase64;
    }

    // Detect image type by magic bytes in base64
    let mimeType = 'image/png';
    if (cleanBase64.startsWith('/9j/')) {
        mimeType = 'image/jpeg';
    } else if (cleanBase64.startsWith('iVBORw0KGgo')) {
        mimeType = 'image/png';
    } else if (cleanBase64.startsWith('R0lGOD')) {
        mimeType = 'image/gif';
    } else if (cleanBase64.startsWith('UklGR')) {
        mimeType = 'image/webp';
    } else if (cleanBase64.startsWith('PHN2Zy') || cleanBase64.startsWith('PD94b')) {
        mimeType = 'image/svg+xml';
    } else if (cleanBase64.startsWith('AAABAA')) {
        mimeType = 'image/x-icon';
    }

    return `data:${mimeType};base64,${cleanBase64}`;
}
