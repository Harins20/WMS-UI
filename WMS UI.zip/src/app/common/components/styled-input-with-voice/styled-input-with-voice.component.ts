import {
    Component,
    effect,
    inject,
    input,
    output,
    signal,
} from '@angular/core';
import {
    FormControl,
    FormGroup,
    FormsModule,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CommonModule } from '@angular/common';
import { Tooltip } from 'primeng/tooltip';
import { VoiceRecognitionService } from '../../functions/voice-recognition.service';

@Component({
    selector: 'app-styled-input-with-voice',
    imports: [
        ButtonModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        Tooltip,
    ],
    templateUrl: './styled-input-with-voice.component.html',
    styleUrl: './styled-input-with-voice.component.scss',
})
export class StyledInputWithVoiceComponent {
    onSubmitMessage = output<any>();
    isRecording = signal<boolean>(false);
    isSubmitting = false;
    form!: FormGroup;
    public voiceService = inject(VoiceRecognitionService);

    constructor() {
        effect(() => {
            const text = this.voiceService.transcript();
            if (
                this.isRecording() === false &&
                text &&
                text.trim().length > 0
            ) {
                this.form.patchValue({ name: text });
            }
        });
    }

    ngOnInit(): void {
        this.form = new FormGroup({
            name: new FormControl('', Validators.required),
        });
    }

    onHoldMic() {
        this.isRecording.set(true);
        this.voiceService.startListening();
    }

    onReleaseMic() {
        this.isRecording.set(false);
        this.voiceService.stopListening();
        setTimeout(async () => {
            const text = this.voiceService.transcript();
            if (text && text.trim().length > 0) {
                await this.submit();
                this.voiceService.transcript.set('');
            }
        }, 300);
    }

    async submit() {
        if (this.form.invalid) return;
        this.isSubmitting = true;
        this.onSubmitMessage.emit(this.form.value.name);
        this.funClear();
    }

    funClear() {
        this.form.reset();
        this.voiceService.transcript.set('');
        this.isSubmitting = false;
    }
}
