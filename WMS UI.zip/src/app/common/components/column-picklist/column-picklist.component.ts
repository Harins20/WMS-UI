import { Component, input, inject, Output, EventEmitter } from '@angular/core';
import { CdkDragDrop, CdkDrag, CdkDropList, CdkDropListGroup, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';

import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { ColumnPreferencesService } from '../column-picklist/column-picklist.service';
import { AuthService } from '../../../common/services/auth.service';
import { PickListModule } from 'primeng/picklist';
import { ButtonModule } from 'primeng/button';
import { TranslatePipe } from '@ngx-translate/core';


@Component({
  selector: 'app-column-picklist',
imports: [PickListModule, CdkDrag, CdkDropList, CdkDropListGroup, ButtonModule, TranslatePipe],
  templateUrl: './column-picklist.component.html',
  styleUrl: './column-picklist.component.scss'
})
export class ColumnPicklistComponent {
selectedColumns = input.required<any[]>();
  unSelectedColumns = input.required<any>();
  pageName = input.required<string>();
    @Output() columnsChanged = new EventEmitter<any>();
  private columnService = inject(ColumnPreferencesService);
  private authService = inject(AuthService);
  private ref = inject(DynamicDialogRef);

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
    }
    this.columnsChanged.emit({
      selected: [...this.selectedColumns()],
      unSelected: [...this.unSelectedColumns()],
    });
  }
}
