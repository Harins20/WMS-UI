import { Component, inject, input } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { Base64ConvertService } from '../../services/base64-convert.service';
import { acceptedImageTypes } from '../../constants';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-user-form',
    imports: [ReactiveFormsModule, InputTextModule, ButtonModule, CheckboxModule],
    templateUrl: './view-image-dialog-aibot.component.html',
    styleUrl: './view-image-dialog-aibot.component.scss'
})
export class ViewImageDialogAIBotComponent {
    restrictedType = acceptedImageTypes;
    image = input.required<string>();
    fileName = input.required<string>();
    private base64convert = inject(Base64ConvertService);
    private http = inject(HttpClient);
    showDownload = input<boolean>(true); // default = true
    showFileName = input<boolean>(true); // default = true
    typeRestricted(filename: string) {
        const params = filename.split('.').pop() || '';
        return acceptedImageTypes.includes(params);
    }
    fileDownload() {
        // this.base64convert.base46ConvertFileDownload(this.image(), this.fileName());
        fetch(this.image()) // ⚠️ requires CORS
            .then((res) => res.blob())
            .then((blob) => this.blobToBase64(blob))
            .then((base64) => {
                const a = document.createElement('a');
                a.href = base64;
                a.download = this.fileName();
                a.click();
            });
    }
    blobToBase64(blob: Blob): Promise<string> {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(blob);

            reader.onload = () => resolve(reader.result as string);
            reader.onerror = (error) => reject(error);
        });
    }
}
