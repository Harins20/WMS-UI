import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { TranslateService } from '@ngx-translate/core';
import { CommonModule, DatePipe } from '@angular/common';
import {
    Component,
    computed,
    inject,
    input,
    linkedSignal,
    model,
    output,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FilterService, MenuItem } from 'primeng/api';
import { registerCustomFilterConstraints } from '../../functions/custom-filter-constraints';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import { Table, TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { acceptedImageTypes, tableOptions } from '../../constants';
import { ColumnPicklistComponent } from '../column-picklist/column-picklist.component';

@Component({
    selector: 'app-custom-table',
    imports: [
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        DatePipe,
        FileUpload,
        TagModule,
        TooltipModule,
        AppTranslatePipe,
    ],
    templateUrl: './custom-table.component.html',
    styleUrl: './custom-table.component.scss',
    providers: [DialogService],
})
export class CustomTableComponent {
    private translate = inject(TranslateService);
    private filterService = inject(FilterService);

    constructor() {
        registerCustomFilterConstraints(this.filterService);
    }

    columns = input.required<any[]>();
    globalcolumns = input.required<any[]>();
    activeFilters = signal<Set<string>>(new Set());
    activeSortField = signal<string | null>(null);
    groupRowsBy = signal<string>('');

    title = input.required<string>();
    enabletitle = input<boolean>(true);
    enableActionColumn = input<boolean>(true);

    PageName = input<string>();
    data = input<any[]>([]);
    dataKey = input.required<string>();
    enableExport = input<boolean>(true);
    loading = input(false);
    customHeaderTemplate = input<TemplateRef<any>>();
    customBodyTemplate = input<TemplateRef<any>>();
    customActionTemplate = input<TemplateRef<any>>();
    customStatusCellTemplate = input<TemplateRef<any>>();
    customRowActionTemplate = input<TemplateRef<any>>();
    customHeaderTitle = input<TemplateRef<any>>();

    enableCreate = input<boolean>(true);
    enableEdit = input<boolean>(true);
    enableDelete = input<boolean>(true);
    selectionMode = input<'multiple' | 'single' | null | undefined>(null);
    getImageDataFn = input<(data: any) => any>();
    selectedData = model<any>([]);
    refresh = output<void>();
    dataKeyClick = output<any>();
    create = output<void>();
    edit = output<any>();
    delete = output<any>();
    fileSelect = output<any>();
    openImage = output<any>();
    exportExcel = output<void>();
    exportCSV = output<void>();
    searchInput = signal<string | undefined>(undefined);
    dt = viewChild.required<Table>('dt');
    globalFilterColumns = computed(() => this.columns().map((x) => x.field));
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    visibleColumns = linkedSignal(() => this.columns());
    invisibleColumns = linkedSignal(() => {
        if (this.visibleColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.visibleColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });

    exportTypes: MenuItem[] = [
        {
            label: this.translate.instant('Excel'),
            command: () => this.exportExcel.emit(),
        },
        {
            label: this.translate.instant('CSV'),
            command: () => this.exportCSV.emit(),
        },
    ];

    validImageType(params: string) {
        return acceptedImageTypes.includes(params);
    }
    ref: DynamicDialogRef | undefined;
    private dialogService = inject(DialogService);

    globalFilter(event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        this.dt().filterGlobal(eventValue, 'contains');
    }
    clear() {
        this.dt().clear();
        this.searchInput.set(undefined);
    }
    refreshData() {
        this.clear();
        this.refresh.emit();
    }
    // exportCSV() {
    //     this.dt().exportCSV();
    // }

    options(field: string) {
        const uniqueValues = new Set(this.data().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedData().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedData().length > 0 ? true : false,
    );

    showColumnsSettingsDialog() {
        const headertext = this.translate.instant('Column Settings');
        this.ref = this.dialogService.open(ColumnPicklistComponent, {
            inputValues: {
                selectedColumns: this.visibleColumns(),
                unSelectedColumns: this.invisibleColumns(),
            },
            header: headertext,
            closable: true,
            modal: true,
            style: { maxHeight: '40rem' },
        });
        this.ref.onClose.subscribe((data) => {});
    }

    onEditAction(data: any) {
        this.edit.emit(data);
    }

    onDeleteAction() {
        this.delete.emit(this.selectedData());
    }

    onCreateAction() {
        this.create.emit();
    }
    onFileSelection(event: any) {
        this.fileSelect.emit(event);
    }

    onOpenImageAction(data: any) {
        this.openImage.emit(data);
    }

    onDataKeyClick(event: Event, row: any): void {
        event.preventDefault();
        this.dataKeyClick.emit(row);
    }

    getImageData(data: any) {
        if (this.getImageDataFn()) {
            return this.getImageDataFn()!(data);
        } else {
            return 'assets/img/noImage.png';
        }
    }

    getDateColumnWidthNormal(column: any) {
        return { width: '170px' };
    }
    isColumnFiltered(field: string): boolean {
        const filters = this.activeFilters();
        return filters instanceof Set ? filters.has(field) : !!filters[field];
    }
    isColumnSorted(field: string): boolean {
        return this.activeSortField() === field;
    }
    isLabelGroupBy(field: string): boolean {
        const filters = this.groupRowsBy();
        // , 'given value', field, filters === field);
        // if (this.groupRowsBy() !== '') );
        return filters === field;
    }
    dateMatchModeOptions = [
        { label: 'Date is', value: 'dateIs' },
        { label: 'Date is not', value: 'dateIsNot' },
        { label: 'Date before', value: 'dateBefore' },
        { label: 'Date after', value: 'dateAfter' },
    ];
    formatExcelValue(value: any): any {
        if (!value) {
            return value;
        }

        // If value is already a Date object
        if (value instanceof Date && !isNaN(value.getTime())) {
            return this.formatDate(value);
        }

        // If value is a date string
        if (typeof value === 'string') {
            const date = new Date(value);

            if (!isNaN(date.getTime()) && this.isDateString(value)) {
                return this.formatDate(date);
            }
        }

        return value;
    }
    formatDate(date: Date): string {
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const year = date.getFullYear();

        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');

        return `${month}/${day}/${year}, ${hours}:${minutes}`;
    }
    isDateString(value: string): boolean {
        // ISO / common date formats
        return (
            /^\d{4}-\d{2}-\d{2}/.test(value) ||
            /^\d{4}\/\d{2}\/\d{2}/.test(value) ||
            /^\d{2}-\d{2}-\d{4}/.test(value) ||
            /^\d{2}\/\d{2}\/\d{4}/.test(value)
        );
    }
}
