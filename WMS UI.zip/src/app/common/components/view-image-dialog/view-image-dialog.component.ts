import { Component, inject, input } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { Base64ConvertService } from '../../services';
import { acceptedImageTypes } from '../../constants';

@Component({
    selector: 'app-user-form',
    imports: [
        ReactiveFormsModule,
        InputTextModule,
        ButtonModule,
        CheckboxModule,
    ],
    templateUrl: './view-image-dialog.component.html',
    styleUrl: './view-image-dialog.component.scss',
})
export class ViewImageDialogComponent {
    restrictedType = acceptedImageTypes;
    image = input.required<string>();
    fileName = input.required<string>();
    private base64convert = inject(Base64ConvertService);
    typeRestricted(filename: string) {
        const params = filename.split('.').pop() || '';
        return acceptedImageTypes.includes(params);
    }
    fileDownload() {
        this.base64convert.base46ConvertFileDownload(
            this.image(),
            this.fileName(),
        );
    }
}
