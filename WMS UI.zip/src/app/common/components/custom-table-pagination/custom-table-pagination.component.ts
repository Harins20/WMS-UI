import { AppTranslatePipe } from '../../../common/pipes/translate.pipe';
import { CommonModule, DatePipe } from '@angular/common';
import {
    AfterViewInit,
    Component,
    computed,
    DestroyRef,
    effect,
    inject,
    input,
    linkedSignal,
    model,
    output,
    signal,
    TemplateRef,
    viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FilterService, MenuItem, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DragDropModule } from 'primeng/dragdrop';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FileUpload } from 'primeng/fileupload';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { Menu } from 'primeng/menu';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinner } from 'primeng/progressspinner';
import { SkeletonModule } from 'primeng/skeleton';
import { SplitButtonModule } from 'primeng/splitbutton';
import {
    Table,
    TableFilterEvent,
    TableLazyLoadEvent,
    TableModule,
} from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { acceptedImageTypes, tableOptions } from '../../constants';
import { ColumnPicklistComponent } from '../column-picklist/column-picklist.component';

import { AuthService } from '../../services/auth.service';
import { finalize } from 'rxjs';
import { SelectModule } from 'primeng/select';
import { DatePickerModule } from 'primeng/datepicker';
import { DateTime } from 'luxon';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { CdkDragPlaceholder } from '@angular/cdk/drag-drop';
import { CustomTableService } from '../custom-table/custom-table.service';
import { ColumnPreferencesService } from '../column-picklist/column-picklist.service';
import { copyToClipboardText } from '../../functions/clickToCopy';
import { filterQuery } from '../../functions';
interface CustomLazyLoadEvent extends TableLazyLoadEvent {
    ColumnName?: string;
}
@Component({
    selector: 'app-custom-table-pagination',
    imports: [
        AppTranslatePipe,
        CardModule,
        TableModule,
        IconFieldModule,
        InputIconModule,
        InputTextModule,
        ButtonModule,
        SkeletonModule,
        Menu,
        SelectModule,
        ProgressSpinner,
        ToolbarModule,
        SplitButtonModule,
        FormsModule,
        CommonModule,
        DragDropModule,
        MultiSelectModule,
        FileUpload,
        TagModule,
        TooltipModule,
        DatePickerModule,
        TranslateModule,
    ],
    templateUrl: './custom-table-pagination.component.html',
    styleUrl: './custom-table-pagination.component.scss',
    providers: [DialogService],
})
export class CustomTablePaginationComponent implements AfterViewInit {
    columns = input.required<any[]>();
    OrginalColumns = input<any>();
    globalcolumns = input.required<any[]>();
    title = input.required<string>();
    enabletitle = input<boolean>(true);
    tempTitle = input<string>();
    PageName = input<string>();
    sortField = input<string>();
    sortOrder = input<number>(-1);
    enableExport = input<boolean>(true);
    enableColumnSettings = input<boolean>(true);
    data = input<any[]>([]);
    GroupedData = input<any[]>([]);
    StatusOption = input<any[]>([]);
    date = signal<string>('');
    dataKey = input.required<string>();
    loading = input(false);
    initialRows = input<number>(tableOptions.initialRows);
    rowsPerPageOptions = input<number[]>(tableOptions.rowsPerPageOptions);
    customHeaderTemplate = input<TemplateRef<any>>();
    customHeaderTitle = input<TemplateRef<any>>();
    customBodyTemplate = input<TemplateRef<any>>();
    customActionTemplate = input<TemplateRef<any>>();
    customRowActionTemplate = input<TemplateRef<any>>();
    customSeverityCellTemplate = input<TemplateRef<any>>();
    customStatusCellTemplate = input<TemplateRef<any>>();
    customPriorityCellTemplate = input<TemplateRef<any>>();
    enableBackButton = input<boolean>(false);
    enableCreate = input<boolean>(true);
    enableEdit = input<boolean>(true);
    enableSetting = input<boolean>(true);
    enableDelete = input<boolean>(true);
    selectionMode = input<'multiple' | 'single' | null | undefined>(null);
    getImageDataFn = input<(data: any) => any>();
    enableActionColumn = input<boolean>(true);
    selectedData = model<any>([]);
    refresh = output<any>();
    dataKeyClick = output<any>();
    create = output<void>();
    edit = output<any>();
    delete = output<any>();
    fileSelect = output<any>();
    exportExcel = output<void>();
    exportCSV = output<void>();
    openImage = output<any>();
    FilteredRequests = signal<Request[]>([]);
    rowClass = input<(rowData: any, rowIndex: number) => string>();
    activeFilters = signal<Set<string>>(new Set());
    savedFilters = signal<any>({});
    totalRecords = input(0);
    UpdateLazyLoad = output<any>();
    UpdateEvent = signal<TableLazyLoadEvent | null>(null);
    groupRowsBy = signal<string>('');
    RowGroups = signal<boolean>(false);
    RowGroupsMode = input<boolean>(false);
    private filterService = inject(FilterService);
    tableFilter = output<TableFilterEvent>();
    searchInput = signal<string | undefined>(undefined);
    dt = viewChild.required<Table>('dt');
    selectedColumns = signal<any[]>([]);
    tableEmptyMessage = signal('No data to display.');
    tableOptions = signal(tableOptions);
    unSelectedColumns = signal<any[]>([]);
    private columnPicklistRef?: DynamicDialogRef;
    private authService = inject(AuthService);
    private columnService = inject(ColumnPreferencesService);
    private messageService = inject(MessageService);
    private dialogService = inject(DialogService);
    private destroyRef = inject(DestroyRef);
    private customTableService = inject(CustomTableService);
    private translate = inject(TranslateService);
    currentPageReportTemplate = signal<string>('');
    ref: DynamicDialogRef | undefined;
    isoWithMillisRegex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/;
    filterStorageKey = computed(
        () =>
            `table-filters-${this.tempTitle() ? this.tempTitle() : this.title()}`,
    );
    globalFilterColumns = computed(() =>
        this.globalcolumns().map((x) => x.field),
    );
    visibleColumns = linkedSignal(() =>
        this.columns().filter((col) => !col.tableHidden),
    );
    invisibleColumns = linkedSignal(() => {
        if (this.visibleColumns().length > 0) {
            return this.columns().filter(
                (column) =>
                    !this.visibleColumns().some(
                        (x: any) => x.field === column.field,
                    ),
            );
        } else {
            return this.columns();
        }
    });
    RowGroupsBtnOptions = linkedSignal<MenuItem[]>(() =>
        this.visibleColumns().map((col) => ({
            label: col.label,
            id: col.field,
            command: () => this.onSelectGroup(col.field),
        })),
    );
    hoveredRow: string | null = null;
    copyToClipboard(text: string) {
        copyToClipboardText(text, this.messageService);
    }
    typeRestricted(params: string) {
        return acceptedImageTypes.includes(params);
    }
    removeGrouping() {
        this.groupRowsBy.set('');
        this.RowGroups.set(false);
        this.onLazyLoad(this.UpdateEvent()!);
        localStorage.setItem('table-group-' + this.title(), '');
    }

    onSelectGroup(field: string) {
        this.groupRowsBy.set(field);
        this.RowGroups.set(true);
        this.onLazyLoad(this.UpdateEvent()!);
        localStorage.setItem('table-group-' + this.title(), field);
        localStorage.removeItem(this.filterStorageKey());
        this.activeFilters.set(new Set());
        const event: TableFilterEvent = {
            filters: {},
            filteredValue: this.dt().value,
        };
        this.tableFilter.emit(event);
    }

    dateMatchModeOptions = [
        { label: 'Date is', value: 'dateTimeIs' },
        { label: 'Date is not', value: 'dateTimeIsNot' },
        { label: 'Date before', value: 'dateTimeBefore' },
        { label: 'Date after', value: 'dateTimeAfter' },
    ];
    exportTypes: MenuItem[] = [
        {
            label: 'Excel',
            command: () => this.exportExcel.emit(),
        },
        {
            label: 'CSV',
            command: () => this.exportCSV.emit(),
        },
    ];
    ngOnInit() {
        const pageName = this.title();
        this.loadColumns(pageName);
        this.Setpagenametext();
        this.translate.onLangChange.subscribe(() => {
            this.Setpagenametext();
        });
        const saveGroup = localStorage.getItem('table-group-' + this.title());
        if (saveGroup && this.RowGroupsMode()) {
            this.groupRowsBy.set(saveGroup);
            this.RowGroups.set(true);
        }
    }
    isSkuNotesHighlight(data: any, column: any): boolean {
        if (!data?.Notes) return false;

        return column?.field === 'Sku' || column?.field === 'itemdescription';
    }
    ngAfterViewInit() {
        this.loadSavedFilters();
    }

    formatToYYYYMMDD(date: Date): string {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    parseMMDDYYYY(dateStr: string): Date {
        const [year, month, day] = dateStr.split('-').map(Number);
        return new Date(year, month - 1, day); // month is 0-indexed
    }
    validImageType(params: string) {
        return acceptedImageTypes.includes(params);
    }

    onLazyLoad(event: CustomLazyLoadEvent) {
        delete event.filters?.['global'];

        // Fix: remap matchMode based on column type before sending to backend
        // if (event.filters) {
        //     Object.keys(event.filters).forEach((field) => {
        //         const column = this.columns().find((c) => c.field === field);

        //         if (!column) {
        //             return;
        //         }

        //         const constraints = event.filters![field];

        //         if (Array.isArray(constraints)) {
        //             event.filters![field] = constraints.map(
        //                 (constraint: any) => {
        //                     let matchMode = constraint.matchMode;

        //                     if (column?.type === 'select') {
        //                         matchMode = 'in';
        //                     } else if (column?.type === 'number') {
        //                         // Keep the numeric match mode
        //                         matchMode = constraint.matchMode || 'equals';
        //                     } else if (column?.type === 'date') {
        //                         matchMode = constraint.matchMode
        //                             ?.toLowerCase()
        //                             .includes('date')
        //                             ? constraint.matchMode
        //                             : 'dateTimeAfter';
        //                     } else {
        //                         matchMode = 'contains';
        //                     }

        //                     return {
        //                         ...constraint,
        //                         matchMode,
        //                     };
        //                 },
        //             );
        //         }
        //     });
        // }

        const fil = this.convertDateFiltersToEST(event.filters ?? {});
        event.filters = fil;
        event.globalFilter = this.searchInput()?.trim() || '';
        // event.ColumnName = this.groupRowsBy();
        if (event.multiSortMeta) {
            event.multiSortMeta = event.multiSortMeta.filter(
                (x: any) => x.field !== this.groupRowsBy(),
            );
        }
        if (this.groupRowsBy()) {
            event.multiSortMeta = [
                {
                    field: this.groupRowsBy(),
                    order: 1,
                },
                ...(event.multiSortMeta ?? []),
            ];
        }
        if (
            /^\d{2}\/\d{2}\/\d{4}, \d{2}:\d{2} [AP]M$/.test(
                String(event.globalFilter ?? ''),
            )
        ) {
            let dt = DateTime.fromFormat(
                String(event.globalFilter ?? ''),
                'MM/dd/yyyy, hh:mm a',
                { zone: 'America/New_York' },
            );
            event.globalFilter = dt.toFormat("yyyy-MM-dd'T'HH:mm");
        } else if (
            /^\d{2}\/\d{2}\/\d{4}$/.test(String(event.globalFilter ?? ''))
        ) {
            let dt = DateTime.fromFormat(
                String(event.globalFilter ?? ''),
                'MM/dd/yyyy',
                { zone: 'America/New_York' },
            );
            event.globalFilter = dt.toFormat('yyyy-MM-dd');
        }
        this.UpdateEvent.set(event);
        this.UpdateLazyLoad.emit(event);
    }
    convertDateFiltersToEST(filtersObj: any) {
        const converted = { ...filtersObj };

        for (const key in converted) {
            const value = converted[key];

            // ✅ If the entire value is an empty array, set it to null
            if (Array.isArray(value) && value.length === 0) {
                converted[key] = null;
                continue;
            }

            if (Array.isArray(value)) {
                converted[key] = value.map((item: any) => {
                    // ✅ If item.value is an empty array, set it to null
                    if (Array.isArray(item?.value) && item.value.length === 0) {
                        return { ...item, value: null };
                    }

                    // ✅ Existing date conversion logic
                    if (
                        item?.matchMode?.toLowerCase().includes('date') &&
                        item?.value
                    ) {
                        const v = new Date(item.value);
                        const estDate =
                            DateTime.fromJSDate(v).toFormat('yyyy-MM-dd');
                        return { ...item, value: estDate };
                    }

                    return item;
                });
            }
        }

        return converted;
    }

    globalFilter(event: Event) {
        const eventValue = (event.target as HTMLInputElement).value;
        this.searchInput.set(eventValue);
        this.dt().filterGlobal(eventValue, 'contains');
    }

    clear() {
        this.searchInput.set(undefined);
        this.UpdateEvent.set(null);
        this.activeFilters.set(new Set());
        this.savedFilters.set({});
        this.groupRowsBy.set('');
        this.RowGroups.set(false);
        localStorage.removeItem(this.filterStorageKey());
        localStorage.removeItem('table-group-' + this.title());
        const event: TableFilterEvent = {
            filters: {}, // no filters applied
            filteredValue: this.dt().value, // full dataset
        };
        this.dt().clear();
        this.tableFilter.emit(event);
    }
    groupByTotal(field: string): number {
        const group = this.GroupedData().find(
            (g: any) => g[field ? field : 'NULL'] !== undefined,
        );
        return group ? group[field ? field : 'NULL'] : 0;
    }

    refreshData() {
        const event = this.UpdateEvent() ?? this.dt()?.createLazyLoadMetadata();
        this.refresh.emit(event);
    }

    onBackAction() {
        window.history.back();
    }

    onFilter(event: TableFilterEvent) {
        const filters = (event && (event as any).filters) ?? {};

        const activeCols = new Set<string>();

        Object.keys(filters ?? {}).forEach((col) => {
            const constraints = (filters as any)[col] as any[];

            if (Array.isArray(constraints)) {
                const isActive = constraints.some((c) => {
                    const val = c?.value;
                    return Array.isArray(val)
                        ? val.length > 0
                        : val !== null &&
                              val !== undefined &&
                              String(val).trim() !== '';
                });

                if (isActive) {
                    activeCols.add(col);
                }
            }
        });

        this.activeFilters.set(activeCols);

        // Save filters to localStorage
        const filterValues: any = {};
        Object.keys(filters).forEach((field) => {
            const constraints = filters[field];
            if (Array.isArray(constraints) && constraints.length > 0) {
                filterValues[field] = constraints[0].value; // Assuming single constraint for simplicity
            }
        });

        localStorage.setItem(
            this.filterStorageKey(),
            JSON.stringify(filterValues),
        );

        // still emit filtered rows if needed
        this.tableFilter.emit(event.filteredValue);
    }

    isColumnFiltered(field: string): boolean {
        const filters = this.activeFilters();
        return filters instanceof Set ? filters.has(field) : !!filters[field];
    }
    isLabelGroupBy(field: string): boolean {
        const filters = this.groupRowsBy();
        // , 'given value', field, filters === field);
        // if (this.groupRowsBy() !== '') );
        return filters === field;
    }
    options(field: string) {
        const uniqueValues = new Set(this.data().map((x: any) => x[field]));
        return Array.from(uniqueValues).map((status) => ({
            value: status,
            label: status,
        }));
    }
    getColumnWidthNormal(column: any) {
        // if (!column?.label) {
        //     console.warn('Column is missing a label:', column);
        // }

        if (column?.field === 'STATUS_DESC') {
            return { width: '140px' };
        }
        if (column?.field === 'PUTAWAYLOC') {
            return { width: '200px' };
        }
        if (column?.field === 'QTYPUTAWAY') {
            return { width: '220px' };
        }

        if ((column?.label?.length ?? 0) > 10) {
            return { width: '140px' };
        }

        return { width: '119px' };
    }
    activeSortField = signal<string | null>(null);

    isSeverity(column: any): boolean {
        return column.label === 'Severity' || column.field === 'Severity';
    }
    isColumnSorted(field: string): boolean {
        return this.activeSortField() === field;
    }
    getDateColumnWidthNormal(column: any) {
        return { width: '170px' };
    }

    getFilterType(column: any): string {
        return column.type === 'number' ? 'numeric' : column.type || 'text';
    }

    enableButtonOnSingleSelection = computed(() =>
        this.selectedData().length === 1 ? true : false,
    );

    enableButtonOnOneOrMoreSelection = computed(() =>
        this.selectedData().length > 0 ? true : false,
    );

    getRowClass(rowData: any, rowIndex: number): string {
        const rowClassFn = this.rowClass?.();
        return rowClassFn ? rowClassFn(rowData, rowIndex) : '';
    }

    // showColumnsSettingsDialog() {
    //     this.ref = this.dialogService.open(ColumnPicklistComponent, {
    //         inputValues: {
    //             selectedColumns: this.visibleColumns(),
    //             unSelectedColumns: this.visibleColumns()
    //         },
    //         header: 'Column settings',
    //         closable: true,
    //         modal: true,
    //         style: { maxHeight: '40rem' }
    //     });
    //     this.ref.onClose.subscribe((data) => {});
    // }

    showColumnsSettingsDialog(pageName: string) {
        // console.log('Opening column settings for', pageName);
        this.columnPicklistRef = this.dialogService.open(
            ColumnPicklistComponent,
            {
                inputValues: {
                    selectedColumns: [...this.visibleColumns()],
                    unSelectedColumns: [...this.invisibleColumns()],
                    pageName: this.title(),
                },
                header: `${this.title()} Column Settings`,
                closable: true,
                modal: true,
                style: { maxHeight: '40rem' },
            },
        );
        this.columnPicklistRef.onChildComponentLoaded.subscribe(
            (cmp: ColumnPicklistComponent) => {
                cmp.columnsChanged.subscribe((data: any) => {
                    if (!data?.selected || !data?.unSelected) return;
                    this.selectedColumns.set(data.selected);
                    this.unSelectedColumns.set(data.unSelected);

                    this.visibleColumns.set(data.selected); // << immediate update
                    this.invisibleColumns.set(data.unSelected);

                    const userId = this.authService.currentUserId;
                    const columns = data.selected.map((col: any) => col.field);

                    this.columnService
                        .getPreferences(pageName)
                        .pipe(
                            finalize(() => {
                                setTimeout(() => {
                                    const random4Digit = Math.floor(
                                        1000 + Math.random() * 9000,
                                    ).toString();
                                    this.customTableService.loadPageVariable.set(
                                        random4Digit,
                                    );
                                }, 1000);
                            }),
                        )
                        .subscribe({
                            next: (res: any) => {
                                if (res && res.length > 0) {
                                    const prefId = res[0].Id;
                                    this.columnService
                                        .updatePreferences(
                                            pageName,
                                            userId,
                                            columns,
                                            prefId,
                                        )
                                        .subscribe({
                                            next: () =>
                                                this.messageService.add({
                                                    severity: 'success',
                                                    summary: 'Columns',
                                                    detail: `${pageName} columns updated successfully`,
                                                }),
                                            error: () =>
                                                this.messageService.add({
                                                    severity: 'error',
                                                    summary: 'Columns',
                                                    detail: `Failed to update ${pageName} columns`,
                                                }),
                                        });
                                } else {
                                    this.columnService
                                        .savePreferences(
                                            pageName,
                                            userId,
                                            columns,
                                        )
                                        .subscribe({
                                            next: () =>
                                                this.messageService.add({
                                                    severity: 'success',
                                                    summary: 'Columns',
                                                    detail: `${pageName} columns saved successfully`,
                                                }),
                                            error: () =>
                                                this.messageService.add({
                                                    severity: 'error',
                                                    summary: 'Columns',
                                                    detail: `Failed to save ${pageName} columns`,
                                                }),
                                        });
                                }
                            },
                            error: (err) =>
                                console.error(
                                    `Error fetching ${pageName} columns:`,
                                    err,
                                ),
                        });
                });
            },
        );
        this.columnPicklistRef.onClose.subscribe(() => {
            // this.refreshData();
            // const pageName = this.title();
            // this.loadColumns(pageName);
        });
    }

    load = effect(() => {
        if (this.customTableService.loadPageVariable()) {
            const pageName = this.title();

            this.loadColumns(pageName);
        }
    });
    loadcolumn = effect(() => {
        if (this.title()) {
            const pageName = this.title();
            this.loadColumns(pageName);
        }
    });

    rebuildPaginator = effect(() => {
        // depend on signals so Angular knows when to rerun
        const title = this.title();
        const pageName = this.PageName();
        const lang = this.translate.currentLang;
        this.Setpagenametext();
    });

    // loadColumns(pageName: string) {
    //     const sub = this.columnService.getColumnById(pageName).subscribe({
    //         next: (columns) => {
    //             this.visibleColumns.set(columns);

    //             const colSet = new Set(columns.map((c: any) => c.field));
    //             this.invisibleColumns.set(this.columns().filter((c) => !colSet.has(c.field)));
    //         },
    //         error: (err) => console.error(`Failed to load ${pageName} columns:`, err)
    //     });

    //     this.destroyRef.onDestroy(() => sub.unsubscribe());
    // }
    loadColumns(pageName: string) {
        if (pageName) {
            const sub = this.columnService.getColumnById(pageName).subscribe({
                next: (savedColumns) => {
                    if (savedColumns && savedColumns.length > 0) {
                        const visible = savedColumns
                            .map((savedCol: any) =>
                                this.columns().find(
                                    (c) => c.field === savedCol.field,
                                ),
                            )
                            .filter(Boolean);
                        this.visibleColumns.set(visible);
                        const savedFields = new Set(
                            savedColumns.map((c: any) => c.field),
                        );
                        const invisible = this.columns().filter(
                            (c) => !savedFields.has(c.field),
                        );
                        this.invisibleColumns.set(invisible);
                    } else {
                        this.visibleColumns.set(this.columns());
                        this.invisibleColumns.set([]);
                    }
                },
                error: (err) =>
                    console.error(`Failed to load ${pageName} columns:`, err),
            });

            this.destroyRef.onDestroy(() => sub.unsubscribe());
        }
    }
    loadSavedFilters(): void {
        const saved = localStorage.getItem(this.filterStorageKey());

        if (saved) {
            try {
                const savedValues = JSON.parse(saved);

                const tableFilters: { [key: string]: any[] } = {};
                const activeCols = new Set<string>();

                Object.keys(savedValues).forEach((field) => {
                    const savedFilter = savedValues[field];

                    const column = this.columns().find(
                        (c) => c.field === field,
                    );

                    let value = savedFilter;
                    let matchMode: string | undefined;

                    if (
                        typeof savedFilter === 'object' &&
                        savedFilter !== null &&
                        !Array.isArray(savedFilter) &&
                        Object.prototype.hasOwnProperty.call(
                            savedFilter,
                            'value',
                        )
                    ) {
                        value = savedFilter.value;
                        matchMode = savedFilter.matchMode;
                    }

                    // Fallback for old localStorage data
                    if (!matchMode) {
                        if (column?.type === 'select') {
                            matchMode = 'in';
                        } else if (column?.type === 'date') {
                            matchMode = 'dateTimeAfter';
                        } else if (column?.type === 'number') {
                            matchMode = 'equals';
                        } else {
                            matchMode = 'contains';
                        }
                    }

                    tableFilters[field] = [
                        {
                            value,
                            matchMode,
                        },
                    ];

                    activeCols.add(field);
                });

                this.activeFilters.set(activeCols);
                this.savedFilters.set(savedValues);

                this.dt().filters = tableFilters;

                (this.dt() as any)._filter();
            } catch (e) {
                console.error('Error parsing saved filters:', e);
            }
        }
    }

    onEditAction(data: any) {
        this.edit.emit(data);
    }

    onDeleteAction() {
        this.delete.emit(this.selectedData());
    }

    onCreateAction() {
        this.create.emit();
    }
    onFileSelection(event: any) {
        this.fileSelect.emit(event);
    }

    onOpenImageAction(data: any) {
        this.openImage.emit(data);
    }

    onDataKeyClick(event: Event, row: any): void {
        event.preventDefault();
        this.dataKeyClick.emit(row);
    }

    getImageData(data: any) {
        if (this.getImageDataFn()) {
            return this.getImageDataFn()!(data);
        } else {
            return 'assets/img/noImage.png';
        }
    }
    getColumnWidth(label: string): string {
        const base = 10; // base width per character
        const min = 145;
        const max = 300;
        const width = label.length * base;
        return `${Math.min(Math.max(width, min), max)}px`;
    }
    Setpagenametext() {
        const pageName = this.PageName() || this.title();

        const name = this.translate.instant(pageName);

        const text = `${this.translate.instant('Showing')} {first} to {last} of {totalRecords} ${name}`;

        this.currentPageReportTemplate.set(text);
    }
    formatExcelValue(value: any): any {
        if (!value) {
            return value;
        }

        // If value is already a Date object
        if (value instanceof Date && !isNaN(value.getTime())) {
            return this.formatDate(value);
        }

        // If value is a date string
        if (typeof value === 'string') {
            const date = new Date(value);

            if (!isNaN(date.getTime()) && this.isDateString(value)) {
                return this.formatDate(date);
            }
        }

        return value;
    }

    formatDate(date: Date): string {
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const year = date.getFullYear();

        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');

        return `${month}/${day}/${year}, ${hours}:${minutes}`;
    }

    isDateString(value: string): boolean {
        // ISO / common date formats
        return (
            /^\d{4}-\d{2}-\d{2}/.test(value) ||
            /^\d{4}\/\d{2}\/\d{2}/.test(value) ||
            /^\d{2}-\d{2}-\d{4}/.test(value) ||
            /^\d{2}\/\d{2}\/\d{4}/.test(value)
        );
    }
}
