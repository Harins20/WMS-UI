/**
 * Defines the shape of the translation dictionary.
 * Add new keys here to make them available to all languages.
 */
export interface AppTranslations {
    // ── Common Actions ──────────────────────────────────────────────────────────
    Save: string;
    Cancel: string;
    Delete: string;
    Edit: string;
    Add: string;
    Close: string;
    Ok: string;
    Yes: string;
    No: string;
    Search: string;
    Reset: string;
    Submit: string;
    Confirm: string;
    Back: string;
    Next: string;
    Previous: string;
    Loading: string;
    Refresh: string;
    Export: string;
    Import: string;
    Print: string;
    Apply: string;
    Clear: string;
    Select: string;
    View: string;
    Upload: string;
    Download: string;

    // ── Export formats ───────────────────────────────────────────────────────────
    Excel: string;
    CSV: string;
    PDF: string;

    // ── Auth / Session ───────────────────────────────────────────────────────────
    Logout: string;
    Login: string;
    'Are you sure you want to Logout?': string;

    // ── Layout & Navigation ──────────────────────────────────────────────────────
    Facility: string;
    'Language Selection': string;
    'Please select the language': string;
    'Theme Customization': string;
    'Theme Mode': string;
    'Sidebar Drawer': string;
    'Preset Colors': string;
    'Font Family': string;
    'Recent Tabs': string;
    'Layout Direction': string;

    // ── Top Menus / Module Names ─────────────────────────────────────────────────
    Inbound: string;
    Outbound: string;
    Inventory: string;
    Masters: string;
    Configurations: string;
    'Business Intelligence': string;
    'Admin Panel': string;
    Appointments: string;
    Wave: string;
    Waves: string;
    Dashboard: string;

    // ── Inbound sub-menus ────────────────────────────────────────────────────────
    POs: string;
    Receipt: string;
    'Receipt Details': string;
    'Putaway Details': string;
    ASNs: string;

    // ── Outbound sub-menus ───────────────────────────────────────────────────────
    Orders: string;
    Loads: string;
    'Order Detail': string;
    'Packing Slip': string;
    'Return Orders': string;
    'Sales Order': string;
    'Cross Dock': string;
    'Wave Filter': string;

    // ── Inventory sub-menus ──────────────────────────────────────────────────────
    'Inventory Balance': string;
    Adjustments: string;
    Replenishment: string;
    'Manage Holds': string;
    Kitting: string;

    // ── Masters sub-menus ────────────────────────────────────────────────────────
    Items: string;
    Locations: string;
    Zones: string;
    Traders: string;
    'Pack Keys': string;
    BOM: string;

    // ── Admin Panel sub-menus ────────────────────────────────────────────────────
    Users: string;
    Roles: string;
    'UDF Columns': string;

    // ── Dialog / Form Headers ────────────────────────────────────────────────────
    'Column Settings': string;
    'Confirm Deletion': string;
    'Create Wave': string;
    'Update Wave': string;
    'Ship Wave': string;
    'Allocate Order Lines': string;
    'UnAllocate Order Lines': string;
    'Pick Order Lines': string;
    'Create Receipt': string;
    'CreateReceiptFromPOLines': string;
    'Receipt has already been created.': string;
    'Update Receipt': string;
    'Create Order': string;
    'Update Order': string;
    'Create Load': string;
    'Update Load': string;
    'Create Return': string;
    'Update Return': string;
    'Create Sales Order': string;
    'Update Sales Order': string;
    'Create Item': string;
    'Update Item': string;
    'Create Location': string;
    'Update Location': string;
    'Create Zone': string;
    'Update Zone': string;
    'Create BOM': string;
    'Update BOM': string;
    'Create Pack Key': string;
    'Update Pack Key': string;
    'Create Adjustment': string;
    'Update Adjustment': string;
    'Create Kitting': string;
    'Create Configuration': string;
    'Update Configuration': string;
    'Create User': string;
    'Update User': string;
    'Create Role': string;
    'Update Role': string;
    'Create Appointment': string;
    'Update Appointment': string;

    // ── Confirmation Messages ────────────────────────────────────────────────────
    'Delete {{ name }}': string;
    'Shiplines {{ count }}': string;
    'Picklines {{ count }}': string;
    'Allocate order lines {{ count }}': string;
    'UnAllocate Order Lines {{ count }}': string;

    // ── Status / Field Labels ────────────────────────────────────────────────────
    Status: string;
    Active: string;
    Inactive: string;
    New: string;
    Open: string;
    Closed: string;
    Pending: string;
    Completed: string;
    Cancelled: string;
    'In Progress': string;
    Date: string;
    Notes: string;
    Description: string;
    Name: string;
    Code: string;
    Type: string;
    Quantity: string;
    Amount: string;
    Total: string;

    // ── Breadcrumbs / Titles ─────────────────────────────────────────────────────
    Order: string;
    'Wave Lines': string;
    'Wave Orders': string;
    'Order Lines': string;
    'Pick Details': string;
    'Load Lines': string;
    'Load Orders': string;
    'ASN Lines': string;
    'PO Lines': string;
    'SO Lines': string;
    'Return Lines': string;
    'BOM Lines': string;
    'Zone Locations': string;

    // ── Misc / Tooltips ──────────────────────────────────────────────────────────
    Storer: string;
    'Move Sheet': string;
    'Repack Instructions': string;
    'Report Viewer': string;
    'Column Picker': string;
    'Filter Settings': string;
    'No records found': string;
    'Please select': string;
    Required: string;
    Optional: string;
    Attachment: string;
    Attachments: string;

    // ── Fallback (all other keys) ────────────────────────────────────────────────
    [key: string]: string;
}
