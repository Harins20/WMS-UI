import { AppTranslations } from './translation.model';
import { englishTranslations } from './english';
import { germanTranslations } from './german';
import { spanishTranslations } from './spanish';

export * from './translation.model';
export * from './english';
export * from './german';
export * from './spanish';

/** Descriptor for an available language option */
export interface LanguageOption {
    code: string;
    label: string;
    flag: string;
}

/** Languages available in the application */
export const AVAILABLE_LANGUAGES: LanguageOption[] = [
    { code: 'en', label: 'English', flag: '🇺🇸' },
    { code: 'hi', label: 'हिन्दी (Hindi)', flag: '🇮🇳' },
    { code: 'ta', label: 'தமிழ் (Tamil)', flag: '🇮🇳' },
    { code: 'te', label: 'తెలుగు (Telugu)', flag: '🇮🇳' },
    { code: 'kn', label: 'ಕನ್ನಡ (Kannada)', flag: '🇮🇳' },
    { code: 'fr', label: 'Français (French)', flag: '🇫🇷' },
    { code: 'de', label: 'Deutsch (German)', flag: '🇩🇪' },
    { code: 'es', label: 'Español (Spanish)', flag: '🇪🇸' },
    { code: 'ar', label: 'العربية (Arabic)', flag: '🇸🇦' },
    { code: 'zh-CN', label: '中文 (Chinese)', flag: '🇨🇳' },
    { code: 'ja', label: '日本語 (Japanese)', flag: '🇯🇵' },
    { code: 'ko', label: '한국어 (Korean)', flag: '🇰🇷' },
    { code: 'pt', label: 'Português (Portuguese)', flag: '🇵🇹' },
    { code: 'ru', label: 'Русский (Russian)', flag: '🇷🇺' },
    { code: 'it', label: 'Italiano (Italian)', flag: '🇮🇹' },
];

const translationMap: Record<string, AppTranslations> = {
    en: englishTranslations,
    de: germanTranslations,
    es: spanishTranslations,
};

/**
 * Returns the translation dictionary for a given language code.
 * Falls back to English when the requested language is not found.
 */
export function getTranslations(lang: string): AppTranslations {
    return translationMap[lang] ?? englishTranslations;
}
