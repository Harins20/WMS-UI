import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import * as XLSX from 'xlsx';

@Injectable({
    providedIn: 'root'
})
export class ExcelDownloadService {
    datePipe = new DatePipe('en-US');

    downloadExcelFile(title: string, Column: any, Row: any) {
        const fieldName = Column.map((x: any) => x.label);
        const Datefield = Column.map((x: any) => x.type == 'date');
        const field = Column.map((x: any) => x.field);
        const Columns: any[] = [];
        if (Row?.length > 0 && Column?.length > 0) {
            Columns.push(fieldName);
            Row.forEach((x: any) => {
                const rowData = field.map((header: any) => {
                    let value = x[header];
                    // Format date fields if necessary
                    if (Datefield[field.indexOf(header)] && value) {
                        const estValue = this.datePipe.transform(value, 'short', 'America/New_York');
                        value = estValue;
                    }

                    return value;
                });
                Columns.push(rowData);
            });
        } else if (Row?.length > 0) {
            const headers = Object.keys(Row[0]);
            Columns.push(headers);

            Row.forEach((x: any) => {
                const rowData = headers.map((header) => x[header]);
                Columns.push(rowData);
            });
        } else if (Column?.length > 0) {
            Columns.push(fieldName);
        }
        this.ExcelFun(Columns, title);
    }

    downloadExcelFileChatbot(title: string, Column: any[], Row: any[]) {
        const Columns: any[] = [];

        if (Row?.length > 0 && Column?.length > 0) {
            const headers = Column.map((c: any) => c.label);
            Columns.push(headers);

            Row.forEach((x: any) => {
                const rowData = Column.map((c: any) => {
                    let value = x[c.field];

                    if (c.type?.toLowerCase() === 'date' && value) {
                        try {
                            value = this.datePipe.transform(value, 'MM/dd/yyyy, h:mm a') || value;
                            value = `${value}`;
                        } catch (err) {
                            console.error('Date conversion error:', err);
                        }
                    }

                    return value;
                });

                Columns.push(rowData);
            });
        } else if (Row?.length > 0) {
            const headers = Object.keys(Row[0]);
            Columns.push(headers);

            Row.forEach((x: any) => {
                const rowData = headers.map((header) => x[header]);
                Columns.push(rowData);
            });
        } else if (Column?.length > 0) {
            const headers = Column.map((c: any) => c.label);
            Columns.push(headers);
        }

        this.ExcelFun(Columns, title);
    }

    private ExcelFun(Columns: any, title: string) {
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.aoa_to_sheet(Columns);
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        XLSX.writeFile(wb, `${title}.xlsx`);
    }
}
